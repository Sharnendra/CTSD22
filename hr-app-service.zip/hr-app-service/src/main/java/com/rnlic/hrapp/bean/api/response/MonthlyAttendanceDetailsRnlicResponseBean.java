package com.rnlic.hrapp.bean.api.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MonthlyAttendanceDetailsRnlicResponseBean extends RnlicRestResponse{
	
	@JsonProperty(value = "Response")
	List<AttendanceDetailsRnlicResponseBean> response;

	public MonthlyAttendanceDetailsRnlicResponseBean() {
		super();
	}

	public MonthlyAttendanceDetailsRnlicResponseBean(List<AttendanceDetailsRnlicResponseBean> response) {
		super();
		this.response = response;
	}

	public List<AttendanceDetailsRnlicResponseBean> getResponse() {
		return response;
	}

	public void setResponse(List<AttendanceDetailsRnlicResponseBean> response) {
		this.response = response;
	}	
}
