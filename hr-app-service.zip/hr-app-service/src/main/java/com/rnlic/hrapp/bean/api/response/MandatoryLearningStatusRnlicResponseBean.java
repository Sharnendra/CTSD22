package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MandatoryLearningStatusRnlicResponseBean extends RnlicRestResponse{
	
	private String response;

	public MandatoryLearningStatusRnlicResponseBean() {
		super();
	}

	public MandatoryLearningStatusRnlicResponseBean(String response) {
		super();
		this.response = response;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}	
}
