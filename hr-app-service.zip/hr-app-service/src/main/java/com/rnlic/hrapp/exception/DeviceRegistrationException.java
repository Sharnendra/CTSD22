package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class DeviceRegistrationException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DeviceRegistrationException() {
		super(ErrorConstants.DEVICE_REGWITH_OTHER_CODE,ErrorConstants.DEVICE_REGWITH_OTHER_MESSAGE,false,false);
	}
	
	public DeviceRegistrationException(String message) {
		super(ErrorConstants.DEVICE_REGWITH_OTHER_CODE,message,false,false);
	}
	
	public DeviceRegistrationException(String message,boolean isFatalError) {
		super(ErrorConstants.DEVICE_REGWITH_OTHER_CODE,message,false,isFatalError);
	}
}
