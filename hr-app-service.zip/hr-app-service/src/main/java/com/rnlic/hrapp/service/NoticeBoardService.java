package com.rnlic.hrapp.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.util.RequestLogDeatils;

/**
 * This service class is responsible to all logic implementation related to service.
 * @author HRMSAPP
 *
 */
@Service
public class NoticeBoardService {

	private static final Logger log = LogManager.getLogger(NoticeBoardService.class);
	
	@Autowired
	private RnlicService rnlicService;
	
	@Autowired
	private RequestLogDeatils requestLog;
		
	/**
	 * This service will call RNLIC api to get details
	 * @param UserDetailsBean userbean
	 * @return ResponseData ResponseData
	 */ 
	//@ValidateRegistry
	public ResponseData getNotices(UserDetailsBean userbean) {
		log.info(requestLog+ "== getNotices service start :=====");
		return rnlicService.getNotices(userbean);
	}
}
