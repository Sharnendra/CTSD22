package com.rnlic.hrapp.bean.api.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NoticesRnlicResponseBean extends RnlicRestResponse{
	
	@JsonProperty(value = "Response")
	List<NoticeDetailsRnlicBean> response;

	public NoticesRnlicResponseBean() {
		super();
	}

	public NoticesRnlicResponseBean(List<NoticeDetailsRnlicBean> response) {
		super();
		this.response = response;
	}

	public List<NoticeDetailsRnlicBean> getResponse() {
		return response;
	}

	public void setResponse(List<NoticeDetailsRnlicBean> response) {
		this.response = response;
	}	
}
