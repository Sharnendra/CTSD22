package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MandatoryLearningDetailsRnlicResponseBean implements RnlicResponseData{
	
	@JsonProperty(value = "LearningId") 
	private String learningId;
	@JsonProperty(value = "LearningName") 
	private String learningName;
	@JsonProperty(value = "DocumentName") 
	private String documentName;
	@JsonProperty(value = "UploadDate") 
	private String uploadDate;
	@JsonProperty(value = "LearningLink") 
	private String learningLink;
	public String getLearningId() {
		return learningId;
	}
	public void setLearningId(String learningId) {
		this.learningId = learningId;
	}
	public String getLearningName() {
		return learningName;
	}
	public void setLearningName(String learningName) {
		this.learningName = learningName;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getUploadDate() {
		return uploadDate;
	}
	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}
	public String getLearningLink() {
		return learningLink;
	}
	public void setLearningLink(String learningLink) {
		this.learningLink = learningLink;
	}
	
	
	 
}
