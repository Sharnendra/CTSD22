package com.rnlic.hrapp.bean.api.request;

public class BirthdayListRnlicReqBean {

	private String SapCode;
	private String empName;
	public String getSapCode() {
		return SapCode;
	}
	public void setSapCode(String sapCode) {
		SapCode = sapCode;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
}
