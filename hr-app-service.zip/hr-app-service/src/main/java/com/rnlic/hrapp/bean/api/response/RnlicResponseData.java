package com.rnlic.hrapp.bean.api.response;

public interface RnlicResponseData {

}
