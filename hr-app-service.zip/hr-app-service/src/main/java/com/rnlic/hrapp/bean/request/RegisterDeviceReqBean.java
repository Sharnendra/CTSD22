package com.rnlic.hrapp.bean.request;

import java.util.ArrayList;
import java.util.Collection;

public class RegisterDeviceReqBean {
	private String appVersion;
	private String deviceType;
	private String action;
	private String otp;
	Collection<InstalledApplicationDetails> installedLinkedApps = new ArrayList<>();
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getAppVersion() {
		return appVersion;
	}
	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public Collection<InstalledApplicationDetails> getInstalledLinkedApps() {
		return installedLinkedApps;
	}
	public void setInstalledLinkedApps(Collection<InstalledApplicationDetails> installedLinkedApps) {
		this.installedLinkedApps = installedLinkedApps;
	}

}
