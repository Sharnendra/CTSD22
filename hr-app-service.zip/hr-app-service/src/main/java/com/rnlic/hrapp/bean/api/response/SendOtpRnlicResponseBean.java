package com.rnlic.hrapp.bean.api.response;

import javax.json.bind.annotation.JsonbProperty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class SendOtpRnlicResponseBean extends RnlicRestResponse{
	
	@JsonbProperty(value="Response")
	private String response;

	public SendOtpRnlicResponseBean() {
		super();
	}
	public SendOtpRnlicResponseBean(String response) {
		super();
		this.response = response;
	}

	public String getResponse() {
		return this.response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	
}
