package com.rnlic.hrapp.service;

import java.io.IOException;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import com.rnlic.hrapp.bean.api.response.RnlicServicesDataTranslator;
import com.rnlic.hrapp.bean.request.MailingReqBean;
import com.rnlic.hrapp.bean.request.OtpReqBean;
import com.rnlic.hrapp.bean.request.OtpValidateReqBean;
import com.rnlic.hrapp.bean.request.RegisterDeviceReqBean;
import com.rnlic.hrapp.bean.request.ShareBranchDetailsReqBean;
import com.rnlic.hrapp.bean.response.MailingResBean;
import com.rnlic.hrapp.bean.response.RegisterDeviceResBean;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.bean.response.SendOtpMobileResBean;
import com.rnlic.hrapp.bean.response.ShareBrachDetailsResBean;
import com.rnlic.hrapp.bean.response.ValidateOtpMobileResBean;
import com.rnlic.hrapp.constant.ErrorConstants;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.entity.OtpMasterModel;
import com.rnlic.hrapp.exception.CommunicationException;
import com.rnlic.hrapp.exception.MailingServiceException;
import com.rnlic.hrapp.exception.OtpException;
import com.rnlic.hrapp.repository.OtpRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestLogDeatils;
import com.rnlic.hrapp.util.RequestValidator;

@Service
public class CommunicationService {

	private static final Logger log = LogManager.getLogger(CommunicationService.class);

	@Autowired
	private RnlicService rnlicService;

	@Autowired
	private GenericConstants genericConstants;

	@Autowired
	private MessagesConstants messagesConstants;

	@Autowired
	private RnlicServicesDataTranslator rnlicServicesDataTranslator;
	
	@Autowired
	private DeviceRegistrationService deviceService;

	@Autowired
	private OtpRepository otpRepo;
	private OtpMasterModel otpEntity;
	@Autowired
	private RequestLogDeatils requestLog;

	/**
	 * This method to generate OTP and send over phone
	 * 
	 * @param OtpReqBean      otpReqBean
	 * @param UserDetailsBean userBean
	 * @return ResponseData sendOtpMobileResBean
	 * @throws RestClientException RestClientException
	 * @throws IOException         iOException
	 */
	@Transactional
	public ResponseData sendOtpOnMobile(OtpReqBean otpReqBean, UserDetailsBean userDetailsBean)
			throws RestClientException, IOException {

		SendOtpMobileResBean sendOtpMobileResBean = new SendOtpMobileResBean();
		log.info(requestLog+ "== sendOtpOnMobile Communication Service call Database:=====");
		// Step 1: Check whether otp present for this user or not
		otpEntity = otpRepo.getOtpDetails(userDetailsBean.getSapCode(), userDetailsBean.getMobileNumber(),
				otpReqBean.getAction(), userDetailsBean.getDeviceIdentifier(),new Date());
		
		if (!HrAppUtil.isNullOrEmpty(otpEntity)) {
			// Check weather resends count < 3 or not
			log.info(requestLog+ "== sendOtpOnMobile Communication Service OTP present in OTP_table :=====");
			if(!otpEntity.isMultipleTry()) {
				// If resends count is less than 3 need to update send count and send OTP
				log.info(requestLog+ "== sendOtpOnMobile Communication Service OTP present in OTP_table Multiple try less than 3 :=====");
				int resendCount = otpEntity.getResendCount();
				otpEntity.setResendCount(++resendCount);
				// Check weather resends count < 3 or not
				if(resendCount==genericConstants.getResendCountValue()) {
					log.info(requestLog+ "== sendOtpOnMobile Communication Service OTP present in OTP_table setiing Multiple try flag :=====");
					otpEntity.setMultipleTry(true);
					otpEntity.setValidUpto(new Date(System.currentTimeMillis() + genericConstants.getOtpLock() * GenericConstants.INTEGER_SIXY * GenericConstants.INTEGER_THOUSAND));
				}
				otpRepo.save(otpEntity);
				//rnlicService.sendOtpMobile(userDetailsBean, otpEntity);
				sendOtpMobileResBean = rnlicService.sendOtpMobile(userDetailsBean, otpEntity);
//				sendOtpMobileResBean.setStatus(true);
//				sendOtpMobileResBean.setMessage(messagesConstants.getSentOtpSuccessMsg() + otpEntity.getMobileNumber()
//				+ GenericConstants.VALID_UPTO + otpEntity.getValidUpto()+" OTP_PT"+otpEntity.getOtpValue()+"TEST");
//				sendOtpMobileResBean.setValidUpto(otpEntity.getValidUpto());
				log.info(requestLog+messagesConstants.getSentOtpSuccessMsg());
			}else {
				log.info(requestLog+messagesConstants.getMultipleReqOtpMsg());
				throw new OtpException(String.format((messagesConstants.getMultipleReqOtpMsg()),String.valueOf(genericConstants.getOtpLock()),HrAppUtil.dateTimeFormator(otpEntity.getValidUpto())));
			}
		} else {
			// if there is no data than need to save it and sent it to user
			log.info(requestLog+ "== sendOtpOnMobile Communication Service otp not present in OTP_table :=====");
			if (!HrAppUtil.isNullOrEmpty(saveOTP(otpReqBean, userDetailsBean))) {
				//rnlicService.sendOtpMobile(userDetailsBean, otpEntity);
				sendOtpMobileResBean = rnlicService.sendOtpMobile(userDetailsBean, otpEntity);
//				sendOtpMobileResBean.setStatus(true);
//				sendOtpMobileResBean.setMessage(messagesConstants.getSentOtpSuccessMsg()
//						+ userDetailsBean.getMobileNumber() + GenericConstants.VALID_UPTO + otpEntity.getValidUpto()+" OTP_PT"+otpEntity.getOtpValue()+"TEST");
//				sendOtpMobileResBean.setValidUpto(otpEntity.getValidUpto());
				log.info(requestLog+messagesConstants.getSentOtpSuccessMsg());
			} else {
				log.info(requestLog+messagesConstants.getInternaErrorOtpMsg());
				throw new OtpException(messagesConstants.getInternaErrorOtpMsg());
			}
		}
		return sendOtpMobileResBean;
	}

	/**
	 * This method to save OTP details in Database
	 * 
	 * @param OtpReqBean      otpReqBean
	 * @param UserDetailsBean userBean
	 * @return OtpMasterModel otpMasterModal
	 */
	private OtpMasterModel saveOTP(OtpReqBean otpReqBean, UserDetailsBean userDetailsBean) {

		log.info(requestLog+ "== saveOTP start:=====");
		OtpMasterModel otpEntityTemp = new OtpMasterModel();
		otpEntityTemp.setSapCode(userDetailsBean.getSapCode());
		otpEntityTemp.setOtpValue(HrAppUtil.generateOtp(genericConstants.getOtpLengthValue()));
		otpEntityTemp.setMobileNumber(userDetailsBean.getMobileNumber());
		otpEntityTemp.setDeviceIdentifier(userDetailsBean.getDeviceIdentifier());
		otpEntityTemp.setGeneratedOn(new Date());
		otpEntityTemp.setValidUpto(new Date(System.currentTimeMillis() + genericConstants.getOtpValidityValue() * GenericConstants.INTEGER_SIXY * GenericConstants.INTEGER_THOUSAND));
		otpEntityTemp.setAction(otpReqBean.getAction());
		otpEntity = otpRepo.save(otpEntityTemp);
		log.info(requestLog+ "== saveOTP end:=====");
		return otpEntity;
	}

	public ResponseData validateOtp(UserDetailsBean userDetailsBean, OtpValidateReqBean otpValidateReqBean) {

		log.info(requestLog+ "== validateOtp Communication Service start :=====");
		ValidateOtpMobileResBean validateOtpMobileResBean = new ValidateOtpMobileResBean();
		otpEntity = otpRepo.getOtpDetails(userDetailsBean.getSapCode(), userDetailsBean.getMobileNumber(),
				otpValidateReqBean.getAction(), userDetailsBean.getDeviceIdentifier(),new Date());

		if (!HrAppUtil.isNullOrEmpty(otpEntity)) {
			log.info(requestLog+ "== validateOtp Communication Service otpEntity data is not null :=====");
			if (!otpEntity.isMultipleTry()) {
				log.info(requestLog+ "== validateOtp Communication Service otpEntity isMultipleTry is false :=====");
				if (Long.valueOf(otpValidateReqBean.getOtp()) == otpEntity.getOtpValue()) {
					otpEntity.setVerified(GenericConstants.TRUE);
					otpRepo.save(otpEntity);
					log.info(requestLog+ "== validateOtp Communication Service otp verified and data is saved:=====");
					validateOtpMobileResBean.setStatus(GenericConstants.TRUE);
					validateOtpMobileResBean.setMessage(messagesConstants.getValidateOtpSuccessMsg());
					log.info(requestLog+ "== validateOtp Communication Service otp verified ===== "+messagesConstants.getValidateOtpSuccessMsg());
				} else {
					log.info(requestLog+ "== validateOtp Communication Service otp is not valid:=====");
					int retryCount = otpEntity.getRetryCount();
					otpEntity.setRetryCount(++retryCount);
					if(retryCount==genericConstants.getRetryCountValue()) {
						otpEntity.setMultipleTry(true);
						otpEntity.setValidUpto(new Date(System.currentTimeMillis() + genericConstants.getOtpLock() * GenericConstants.INTEGER_SIXY * GenericConstants.INTEGER_THOUSAND));
					}
					otpRepo.save(otpEntity);
					throw new OtpException(messagesConstants.getInvalidOtpMsg());
				}
			} else {
				log.info(requestLog+ "== validateOtp Communication Service multiple try was made :===== "+messagesConstants.getMultipleReqOtpMsg());
				throw new OtpException(String.format((messagesConstants.getMultipleReqOtpMsg()),String.valueOf(genericConstants.getOtpLock()),HrAppUtil.dateTimeFormator(otpEntity.getValidUpto())));

			}
		} else {
			log.info(requestLog+ "== validateOtp Communication Service black otp was provided :===== "+String.format(messagesConstants.getBlankOtpMsg(),"!"));
			throw new OtpException(String.format(messagesConstants.getBlankOtpMsg(),"!"));

		}
		return validateOtpMobileResBean;
	}

	/**
	 * This method is used to send Email to the specific 
	 * user as per his/ her email id.
	 * 
	 * @param MailingReqBean  mailingReqBean
	 * @return MailingResBean mailingResBean
	 */	
	public MailingResBean generatedMail(MailingReqBean mailingReqBean){
		log.info(requestLog+ "== generatedMail start:=====");
		MailingResBean mailingResBean=new MailingResBean();
		mailingResBean.setStatus(rnlicService.sendMail(mailingReqBean));
		if(mailingResBean.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
			throw new MailingServiceException();
		}
		log.info(requestLog+ "== generatedMail ends successfully:=====");
		return mailingResBean;
	}

	public ResponseData shareBrachDetails(UserDetailsBean empReqBean, ShareBranchDetailsReqBean shareBranchDetailsReqBean) throws RestClientException, IOException {
		// Use data to call reliance data
		ShareBrachDetailsResBean shareBrachDetailsResBean = null;
		if(HrAppUtil.isNullOrEmpty(shareBranchDetailsReqBean.getEmailAddress())
				&& HrAppUtil.isNullOrEmpty(shareBranchDetailsReqBean.getMobileNo())) {
			throw new CommunicationException(ErrorConstants.NOTIFY_PHONE_OR_EMAIL);
		}
		int count=0;
		boolean isMessageSent =false;
		boolean isMailSent = false;
		Map<String,String> errorMap = new LinkedHashMap<>();
		String message = rnlicService.getShareBrachDetailsMessage(empReqBean, shareBranchDetailsReqBean);
		try {
			if(!HrAppUtil.isNullOrEmpty(shareBranchDetailsReqBean.getEmailAddress())) {
				count++;
				if(RequestValidator.requestValidatorForMail(shareBranchDetailsReqBean.getEmailAddress())) {
					MailingReqBean mailingReqBean=new MailingReqBean();
					mailingReqBean.setMailId(shareBranchDetailsReqBean.getEmailAddress().trim().toLowerCase());
					mailingReqBean.setSubject(GenericConstants.RNLIC_BRANCH_DETAILS);
					mailingReqBean.setMessage(new StringBuilder(message));
					MailingResBean mailingResBean = generatedMail(mailingReqBean);
					isMailSent = GenericConstants.SUCCESS.equalsIgnoreCase(mailingResBean.getStatus());
				}
				else {
					errorMap.put("Mail", "Email id is not valid");
				}
			}
		} catch (Exception e) {
			isMailSent = false;
		}
		if(!HrAppUtil.isNullOrEmpty(shareBranchDetailsReqBean.getMobileNo())){
			count++;
			if(RequestValidator.requestValidatorForPhoneNumber(shareBranchDetailsReqBean.getMobileNo())) {
				isMessageSent = rnlicService.shareBrachDetails(message,shareBranchDetailsReqBean);
			}
			else {
				errorMap.put("Number", "Number id is not valid");
			}
		}
		shareBrachDetailsResBean = rnlicServicesDataTranslator.generateShareBrachDetailsResponse(count,shareBranchDetailsReqBean,isMessageSent,isMailSent,errorMap);
		if(shareBrachDetailsResBean.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
			throw new CommunicationException(shareBrachDetailsResBean.getMessage());
		}
		return shareBrachDetailsResBean;
	}

	/**
	 * This method to validate OTP and register details in Database
	 * 
	 * @param RegisterDeviceReqBean      registerReqBean
	 * @param UserDetailsBean userBean
	 * @return OtpMasterModel otpMasterModal
	 */
	public ResponseData validateOtpAndRegisterDevice(UserDetailsBean userDetailsBean,
			RegisterDeviceReqBean registerReqBean) {
		RegisterDeviceResBean registerDeviceResBean = null;
		OtpValidateReqBean otpBean = new OtpValidateReqBean();
		otpBean.setAction(registerReqBean.getAction());
		otpBean.setOtp(registerReqBean.getOtp());
		ValidateOtpMobileResBean validateOtp = (ValidateOtpMobileResBean) validateOtp(userDetailsBean, otpBean);
		if(validateOtp.isStatus()) {
			registerDeviceResBean = (RegisterDeviceResBean) deviceService.registerDevice(userDetailsBean, registerReqBean);
		}
		return registerDeviceResBean;
	}
}
