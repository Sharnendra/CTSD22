package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RnlicBranchDetailBean implements RnlicResponseData{

	@JsonProperty(value = "Branch")
	private String branch;
	@JsonProperty(value = "Branch_Code")
	private String branchCode;
	@JsonProperty(value = "Address")
	private String address;
	@JsonProperty(value = "Latitude")
	private String latitude;
	@JsonProperty(value = "Longitude")
	private String longitude;
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String lattitude) {
		this.latitude = lattitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	
	
}
