package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class UnAuthorizedAdminException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public UnAuthorizedAdminException() {
		super(ErrorConstants.USER_NOT_AUTHORIZED_CODE,ErrorConstants.USER_NOT_AUTHORIZED_MESSAGE,false,false);
	}
	public UnAuthorizedAdminException(String message) {
		super(ErrorConstants.USER_NOT_AUTHORIZED_MESSAGE,message,false,false);
	}
}
