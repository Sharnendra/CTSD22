package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class CommunicationException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CommunicationException() {
		super(ErrorConstants.COMMUNICATION_CODE,ErrorConstants.COMMUNICATION_MESSAGE,false,false);
	}
	
	public CommunicationException(String message) {
		super(ErrorConstants.COMMUNICATION_CODE,message,false,false);
	}
}
