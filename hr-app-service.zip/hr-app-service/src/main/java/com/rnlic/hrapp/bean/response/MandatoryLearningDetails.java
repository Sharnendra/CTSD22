package com.rnlic.hrapp.bean.response;

public class MandatoryLearningDetails {
	
	private String learningId;
	private String status;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLearningId() {
		return learningId;
	}
	public void setLearningId(String learningId) {
		this.learningId = learningId;
	}
	
}
