package com.rnlic.hrapp.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rnlic.hrapp.constant.GenericConstants;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtGenerator {

	@Autowired
	private GenericConstants genericConstants;
	
    public String generate(UserDetailsBean jwtUser) {

        Claims claims = Jwts.claims()
                .setSubject(jwtUser.getFristName());
        claims.put(GenericConstants.JWT_USER_ID, String.valueOf(jwtUser.getSapCode()));
        claims.put(GenericConstants.JWT_DEVICE_ID, jwtUser.getDeviceIdentifier());
        claims.put(GenericConstants.JWT_LAST_NAME, jwtUser.getLastName());
        claims.put(GenericConstants.JWT_LEVEL,jwtUser.getLevel());
        claims.put(GenericConstants.JWT_MANAGER_SAP_CODE, jwtUser.getManagerSapCode());
        claims.put(GenericConstants.JWT_MOBILE_NUMBER, jwtUser.getMobileNumber());
        claims.put(GenericConstants.JWT_PAN_NUMBER, jwtUser.getPanNumber());
        claims.put(GenericConstants.JWT_ROLE, jwtUser.getRole());
        claims.put(GenericConstants.IS_CANDIDATE, jwtUser.isCandidate());
        claims.put(GenericConstants.FCM_TOKEN, jwtUser.getFcmToken());
        claims.put(GenericConstants.EMAIL, jwtUser.getEmail());

        return Jwts.builder()
                .setClaims(claims)
                .signWith(SignatureAlgorithm.HS512, genericConstants.getSigningKeyValue())
                .compact();
    }
}
