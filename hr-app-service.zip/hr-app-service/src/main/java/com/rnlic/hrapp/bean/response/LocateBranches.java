package com.rnlic.hrapp.bean.response;

import com.rnlic.hrapp.bean.request.UserLocation;

public class LocateBranches {

	@Override
	public String toString() {
		return "branch name=" + name + ",branch address=" + address + ",branch code=" + code + ", branch contactPerson="+ contactPerson + ", branch contactNumber="+ contactNumber + ", branch email=" + email + ", location=" + location	+ ".";
	}
	public LocateBranches() {
		this.location = new UserLocation();
	}
	private String name;
	private String address;
	private String code;
	private String contactPerson;
	private String contactNumber;
	private String email;
	private UserLocation location;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public UserLocation getLocation() {
		return location;
	}
	public void setLocation(UserLocation location) {
		this.location = location;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
}
