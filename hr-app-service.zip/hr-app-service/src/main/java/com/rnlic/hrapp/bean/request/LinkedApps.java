package com.rnlic.hrapp.bean.request;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.rnlic.hrapp.bean.response.AndroidResBean;
import com.rnlic.hrapp.bean.response.IosResBean;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LinkedApps {

	private String name;
	private String title;
	private String description;
	private Boolean isApp;
	private String navigateTo;
	private String link;
	private IosResBean ios;
	private AndroidResBean android;
	private String icon;
	private Boolean showAsRow;
	private List<String> applicableFor=new ArrayList<>();
	private List<String> mandatoryFor=new ArrayList<>(); 
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Boolean getIsApp() {
		return isApp;
	}
	public void setIsApp(Boolean isApp) {
		this.isApp = isApp;
	}
	public List<String> getApplicableFor() {
		return applicableFor;
	}
	public void setApplicableFor(List<String> applicableFor) {
		this.applicableFor = applicableFor;
	}
	public List<String> getMandatoryFor() {
		return mandatoryFor;
	}
	public void setMandatoryFor(List<String> mandatoryFor) {
		this.mandatoryFor = mandatoryFor;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public Boolean getShowAsRow() {
		return showAsRow;
	}
	public void setShowAsRow(Boolean showAsRow) {
		this.showAsRow = showAsRow;
	}
	public IosResBean getIos() {
		return ios;
	}
	public void setIos(IosResBean ios) {
		this.ios = ios;
	}
	public AndroidResBean getAndroid() {
		return android;
	}
	public void setAndroid(AndroidResBean android) {
		this.android = android;
	}
	public String getNavigateTo() {
		return navigateTo;
	}
	public void setNavigateTo(String navigateTo) {
		this.navigateTo = navigateTo;
	}
	@Override
	public String toString() {
		return "LinkedApps [name=" + name + ", title=" + title + ", description=" + description + ", isApp=" + isApp
				+ ", navigateTo=" + navigateTo + ", link=" + link + ", ios=" + ios + ", android=" + android + ", icon="
				+ icon + ", showAsRow=" + showAsRow + ", applicableFor=" + applicableFor + ", mandatoryFor="
				+ mandatoryFor + "]";
	}
}
