package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TroubleWithLoginApiResBean {

	@JsonProperty(value = "HelpMessage")
	private String helpMessage;
	@JsonProperty(value = "ContactNumber")
	private String contactNumber;
	@JsonProperty(value = "ContactEmail")
	private String contactEmail;
	
	public String getHelpMessage() {
		return helpMessage;
	}
	public void setHelpMessage(String helpMessage) {
		this.helpMessage = helpMessage;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	
}
