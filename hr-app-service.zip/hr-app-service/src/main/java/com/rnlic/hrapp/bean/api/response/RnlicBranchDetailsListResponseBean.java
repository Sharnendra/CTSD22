package com.rnlic.hrapp.bean.api.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RnlicBranchDetailsListResponseBean extends RnlicRestResponse{

	@JsonProperty(value = "Response")
	List<RnlicBranchDetailBean> response;

	public RnlicBranchDetailsListResponseBean() {
		super();
	}

	public RnlicBranchDetailsListResponseBean(List<RnlicBranchDetailBean> response) {
		super();
		this.response = response;
	}

	public List<RnlicBranchDetailBean> getResponse() {
		return response;
	}

	public void setResponse(List<RnlicBranchDetailBean> response) {
		this.response = response;
	}	
	
	
}
