package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

public class MandatoryLearningResBean implements ResponseData{
	
	private List<LearningDetails> mandatoryLearnings =new ArrayList<>();

	public List<LearningDetails> getMandatoryLearnings() {
		return mandatoryLearnings;
	}

	public void setMandatoryLearnings(List<LearningDetails> mandatoryLearnings) {
		this.mandatoryLearnings = mandatoryLearnings;
	}

}
