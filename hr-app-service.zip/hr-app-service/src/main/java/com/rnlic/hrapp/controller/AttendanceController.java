package com.rnlic.hrapp.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rnlic.hrapp.bean.request.AttendanceReqBean;
import com.rnlic.hrapp.bean.request.EmployeeCheckInCheckOutReqBean;
import com.rnlic.hrapp.bean.request.LearningStatusUpdateReqBean;
import com.rnlic.hrapp.bean.request.SapReqBean;
import com.rnlic.hrapp.bean.response.RestResponse;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.RequestValidatorConstants;
import com.rnlic.hrapp.constant.UrlConstants;
import com.rnlic.hrapp.exception.BadRequestException;
import com.rnlic.hrapp.exception.HrAppException;
import com.rnlic.hrapp.exception.UnhandledException;
import com.rnlic.hrapp.security.JwtDecriptor;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.AttendanceDetailsService;
import com.rnlic.hrapp.service.CheckInCheckOutService;
import com.rnlic.hrapp.service.LearningService;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestValidator;
import com.rnlic.hrapp.util.RequestValidatorResponse;

@RestController
public class AttendanceController extends BaseController {

	private static final Logger log = LogManager.getLogger(AttendanceController.class);

	@Autowired
	private AttendanceDetailsService attendanceDetailsService;

	@Autowired
	private CheckInCheckOutService checkInCheckOutService;

	@Autowired
	private LearningService learningService;
	
	@Autowired
	private JwtDecriptor jwtDecriptor;
	
	/**
	 * This Function will return the Attendance details of current user.
	 * 
	 * @author HRMSAPP
	 * @param Authorization token
	 * @return ResponseData AttendanceDetailsResBean
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.GET_ATTENDANCE_DETAILS_URL)
	public RestResponse getAttendanceDetails(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken,
			@RequestBody AttendanceReqBean attendanceReqBean) throws JsonProcessingException {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"GetAttendanceDetails");
		log.info(requestLog.toString()+ "== GetAttendanceDetails Start :=====");
		try {
			RequestValidatorResponse reqRes = RequestValidator.requestValidator(attendanceReqBean);
			if(reqRes.isValid()) {
				UserDetailsBean empReqBean=jwtDecriptor.jwtDecript(jwtToken);
				setRequestLog(requestLog,response.getRequestId(),empReqBean.getSapCode(),empReqBean.getMobileNumber(),empReqBean.getDeviceIdentifier(),"GetAttendanceDetails");
				response.setData(attendanceDetailsService.getAttendanceDetails(empReqBean, attendanceReqBean));
			}else {
				log.info(requestLog.toString()+"== After Calling Service GetAttendanceDetails the validation fails:==");
				throw new BadRequestException(reqRes.getMessage());
			}
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== GetApplicationConfiguration HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== GetApplicationConfiguration UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}

	/**
	 * This Function will perform check-in and check-out function for current user.
	 * 
	 * @author HRMSAPP
	 * @param Authorization token
	 * @return ResponseData checkInCheckOutResBean
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.EMPLOYEE_CHECKIN_CHECKOUT_URL)
	public RestResponse employeeCheckInCheckOut(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken,
			@RequestBody final EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean) throws JsonProcessingException {

		RestResponse restResponse = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,restResponse.getRequestId(),null,null,null,"employeeCheckInCheckOut");
		log.info(requestLog.toString()+ "== employeeCheckInCheckOut Start :=====");
		try {
			UserDetailsBean empReqBean = jwtDecriptor.jwtDecript(jwtToken);
			setRequestLog(requestLog,restResponse.getRequestId(),empReqBean.getSapCode(),empReqBean.getMobileNumber(),empReqBean.getDeviceIdentifier(),"employeeCheckInCheckOut");
			restResponse.setData(checkInCheckOutService.employeeCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== employeeCheckInCheckOut HrAppException:=====", e);
			restResponse.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== employeeCheckInCheckOut UnhandledException:=====", t);
			restResponse.setError(new UnhandledException());
		}
		return restResponse;
	}

	/**
	 * This Function will be used to get mandatory learnings for current user.
	 * 
	 * @author HRMSAPP
	 * @param Authorization   token
	 * @param LearningReqBean learningReqBean as request object
	 * @return ResponseData MandatoryLearningResBean
	 */
	@PostMapping(UrlConstants.GET_MANDATORY_LEARNING_URL)
	public RestResponse getMandatoryLearning() {

		RestResponse restResponse = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,restResponse.getRequestId(),null,null,null,"getMandatoryLearning");
		log.info(requestLog.toString()+ "== getMandatoryLearning Start :=====");
		try {
			restResponse.setData(learningService.getMandatoryLearning());
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== getMandatoryLearning HrAppException:=====", e);
			restResponse.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== getMandatoryLearning UnhandledException:=====", t);
			restResponse.setError(new UnhandledException());
		}
		return restResponse;
	}

	/**
	 * This Function will be used to get mandatory learnings skill completion status
	 * for current user.
	 * 
	 * @author HRMSAPP
	 * @param Authorization         token
	 * @param LearningStatusReqBean learningStatusReqBeans as request object
	 * @return ResponseData MandatoryLearningResBean
	 */
	@PostMapping(UrlConstants.GET_MANDATORY_LEARNING_STATUS_URL)
	public RestResponse getMandatoryLearningStatus(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) {

		RestResponse restResponse = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,restResponse.getRequestId(),null,null,null,"getMandatoryLearningStatus");
		log.info(requestLog.toString()+ "== getMandatoryLearningStatus Start :=====");
		try {
			UserDetailsBean empReqBean = jwtDecriptor.jwtDecript(jwtToken);
			setRequestLog(requestLog,restResponse.getRequestId(),empReqBean.getSapCode(),empReqBean.getMobileNumber(),empReqBean.getDeviceIdentifier(),"getMandatoryLearningStatus");
			restResponse.setData(learningService.getMandatoryLearningStatus(empReqBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== getMandatoryLearningStatus HrAppException:=====", e);
			restResponse.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== getMandatoryLearningStatus UnhandledException:=====", t);
			restResponse.setError(new UnhandledException());
		}
		return restResponse;

	}

	/**
	 * This Function will be used to update mandatory learnings skill completion
	 * status for current user on the basis of the learning id's.
	 * 
	 * @author HRMSAPP
	 * @param Authorization token
	 * @param List<String>  learningIds as learning id's of the skill which is
	 *                      completed
	 * @return ResponseData UpdateLearningCompletionResBean
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.UPDATE_LEARNING_COMPLETION_STATUS_URL)
	public RestResponse updateLearningCompletionStatus(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken,@RequestBody LearningStatusUpdateReqBean learningStatusUpdateReqBean) throws JsonProcessingException {
		RestResponse restResponse = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,restResponse.getRequestId(),null,null,null,"updateLearningCompletionStatus");
		log.info(requestLog.toString()+ "== updateLearningCompletionStatus Start :=====");
		try {
			if(!HrAppUtil.isNullOrEmpty(learningStatusUpdateReqBean.getLearningId())) {
				log.info(requestLog.toString()+ "== updateLearningCompletionStatus learning id is not null :=====");
				UserDetailsBean empReqBean = jwtDecriptor.jwtDecript(jwtToken);
				setRequestLog(requestLog,restResponse.getRequestId(),empReqBean.getSapCode(),empReqBean.getMobileNumber(),empReqBean.getDeviceIdentifier(),"updateLearningCompletionStatus");
				restResponse.setData(learningService.updateLearningCompletionStatus(empReqBean, learningStatusUpdateReqBean.getLearningId()));
			}else {
				log.info(requestLog.toString()+ "== updateLearningCompletionStatus learning id is null :=====");
				throw new BadRequestException(RequestValidatorConstants.INVALID_LEARNINGID);
			}
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== updateLearningCompletionStatus HrAppException:=====", e);
			restResponse.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== updateLearningCompletionStatus UnhandledException:=====", t);
			restResponse.setError(new UnhandledException());
		}
		return restResponse;
	}

	/**
	 * This Function will be used to get List of reportee's under manager.
	 * @param String sapCode jwtToken
	 * @param  RequestBody String sapCode 
	 * @return RestResponse response
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.GET_REPORTEE_LIST_URL)
	public RestResponse getListOfReportees(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken,
			@RequestBody SapReqBean sapReqBean) throws JsonProcessingException {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"getListOfReportees");
		log.info(requestLog.toString()+ "== getListOfReportees Start :=====");
		try {
			if(!HrAppUtil.isNullOrEmpty(sapReqBean.getSapCode())) {
				log.info(requestLog.toString()+ "== getListOfReportees sapcode is not null :=====");
				UserDetailsBean userBean = jwtDecriptor.jwtDecript(jwtToken);
				setRequestLog(requestLog,response.getRequestId(),userBean.getSapCode(),userBean.getMobileNumber(),userBean.getDeviceIdentifier(),"getListOfReportees");
				response.setData(attendanceDetailsService.getReporteeList(userBean,sapReqBean.getSapCode()));
			}else {
				log.info(requestLog.toString()+ "== getListOfReportees sapcode is null :=====");
				throw new BadRequestException(RequestValidatorConstants.INVALID_SAPCODE);
			}
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== getListOfReportees HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== getListOfReportees UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}
}
