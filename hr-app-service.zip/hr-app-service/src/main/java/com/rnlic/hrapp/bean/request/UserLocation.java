package com.rnlic.hrapp.bean.request;

public class UserLocation {
	
	private String latitude;
	private String longitude;
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String lattitude) {
		this.latitude = lattitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	@Override
	public String toString() {
		return " latitude=" + latitude + ", longitude=" + longitude + ".";
	}
	

}
