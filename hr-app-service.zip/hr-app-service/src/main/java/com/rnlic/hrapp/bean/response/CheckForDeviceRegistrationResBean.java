package com.rnlic.hrapp.bean.response;

import com.rnlic.hrapp.entity.DeviceRegistrationModel;

/**
 * This class contain properties for CheckForDeviceRegistration
 */
public class CheckForDeviceRegistrationResBean implements ResponseData{
	
	private boolean isAllowed;
	private boolean isDeviceRegisterWithOthers;
	private boolean isRegisterdWithOtherDevice;
	private boolean mobileNumberUpdated;
	private boolean sapCodeUpdated;
	private boolean isAlreadyRegistered;
	private DeviceRegistrationModel deviceRegDetails;
	public boolean isAllowed() {
		return isAllowed;
	}
	public void setAllowed(boolean isAllowed) {
		this.isAllowed = isAllowed;
	}
	public boolean isDeviceRegisterWithOthers() {
		return isDeviceRegisterWithOthers;
	}
	public void setDeviceRegisterWithOthers(boolean isDeviceRegisterWithOthers) {
		this.isDeviceRegisterWithOthers = isDeviceRegisterWithOthers;
	}
	public boolean isRegisterdWithOtherDevice() {
		return isRegisterdWithOtherDevice;
	}
	public void setRegisterdWithOtherDevice(boolean isRegisterdWithOtherDevice) {
		this.isRegisterdWithOtherDevice = isRegisterdWithOtherDevice;
	}
	public boolean isMobileNumberUpdated() {
		return mobileNumberUpdated;
	}
	public void setMobileNumberUpdated(boolean mobileNumberUpdated) {
		this.mobileNumberUpdated = mobileNumberUpdated;
	}
	public boolean isSapCodeUpdated() {
		return sapCodeUpdated;
	}
	public void setSapCodeUpdated(boolean sapCodeUpdated) {
		this.sapCodeUpdated = sapCodeUpdated;
	}
	public boolean isAlreadyRegistered() {
		return isAlreadyRegistered;
	}
	public void setAlreadyRegistered(boolean isAlreadyRegistered) {
		this.isAlreadyRegistered = isAlreadyRegistered;
	}
	public DeviceRegistrationModel getDeviceRegDetails() {
		return deviceRegDetails;
	}
	public void setDeviceRegDetails(DeviceRegistrationModel deviceRegDetails) {
		this.deviceRegDetails = deviceRegDetails;
	}
}
