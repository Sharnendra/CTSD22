package com.rnlic.hrapp.bean.response;

import java.util.Date;

public class SendOtpMobileResBean implements ResponseData {
	 
	private boolean status;
	private String message;
	private Date validUpto;
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getValidUpto() {
		return validUpto;
	}
	public void setValidUpto(Date validUpto) {
		this.validUpto = validUpto;
	}
	
	
	
	
}
