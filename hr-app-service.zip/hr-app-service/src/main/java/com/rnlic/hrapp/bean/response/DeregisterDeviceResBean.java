package com.rnlic.hrapp.bean.response;

public class DeregisterDeviceResBean implements ResponseData{
	
	private boolean isDeleted;
	private String message;
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

}
