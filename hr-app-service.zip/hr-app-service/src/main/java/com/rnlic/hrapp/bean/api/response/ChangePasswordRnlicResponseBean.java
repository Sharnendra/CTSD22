package com.rnlic.hrapp.bean.api.response;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
public class ChangePasswordRnlicResponseBean {

	@JsonProperty(value = "Status")
	private String status;
	@JsonProperty(value = "Message")
	private Map<String,String> message = new HashMap<>();
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Map<String, String> getMessage() {
		return message;
	}
	public void setMessage(Map<String, String> message) {
		this.message = message;
	}
	
	
}
