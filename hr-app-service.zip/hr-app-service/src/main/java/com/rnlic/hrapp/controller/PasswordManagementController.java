package com.rnlic.hrapp.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rnlic.hrapp.bean.request.ChangePasswordReqBean;
import com.rnlic.hrapp.bean.response.RestResponse;
import com.rnlic.hrapp.constant.ErrorConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.constant.UrlConstants;
import com.rnlic.hrapp.exception.HrAppException;
import com.rnlic.hrapp.exception.UnhandledException;
import com.rnlic.hrapp.service.PasswordManagementService;
import com.rnlic.hrapp.util.HrAppUtil;

/**
 * This class is responsible for managing all end point
 * related to password management.
 */
@RestController
public class PasswordManagementController extends BaseController {

	private static final Logger log = LogManager.getLogger(PasswordManagementController.class);
	
	@Autowired
	private PasswordManagementService passwordManagementService;
	
	@Autowired
	private MessagesConstants messagesConstants;

	/**
	 * This end point to request for change password
	 * @param ChangePasswordReqBean changePasswordReqBean
	 * @return  RestResponse response
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.CHANGE_PASSWORD_URL)
	public RestResponse requestForChangePassword(@RequestBody ChangePasswordReqBean changePasswordReqBean) throws JsonProcessingException {

		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"requestForChangePassword");
		boolean isOtpRequest = HrAppUtil.isNullOrEmpty(changePasswordReqBean.getNewPassword())&&HrAppUtil.isNullOrEmpty(changePasswordReqBean.getOtp());
		log.info(requestLog.toString()+ "== requestForChangePassword :=====");
		try {
			response.setData(passwordManagementService.requestForChangePassword(changePasswordReqBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== requestForChangePassword HrAppException:=====", e);
			response.setError(e);
		}
		catch(Exception t) {
			log.error(requestLog.toString()+ "== updatePassword UnhandledException:=====", t);
			String errorMsg = null;
			String errorCode = null;
			if(isOtpRequest) {
				errorCode = ErrorConstants.OTP_GENERATION_ERROR_CODE;
				errorMsg = messagesConstants.getErrorOtpGenerated();
			}else {
				errorCode = ErrorConstants.PASSWORD_UPDATE_ERROR_CODE;
				errorMsg = messagesConstants.getPasswordChangedError();
			}
			response.setError(new UnhandledException(errorCode,errorMsg));
		}
		return response;

	}
	
	/**
	 * This end point to request for Update password
	 * @param ChangePasswordReqBean changePasswordReqBean
	 * @return  RestResponse response
	 * @throws JsonProcessingException 
	 */
//	@PostMapping(UrlConstants.UPDATE_PASSWORD_URL)
//	public RestResponse updatePassword(@RequestBody ChangePasswordReqBean changePasswordReqBean) throws JsonProcessingException {
//
//		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
//		setRequestLog(requestLog,response.getRequestId(),null,null,null,"updatePassword");
//		log.info(requestLog.toString()+ "== updatePassword :=====");
//		try {
//			response.setData(passwordManagementService.updatePassword(changePasswordReqBean));
//		} catch (HrAppException e) {
//			log.error(requestLog.toString()+ "== updatePassword HrAppException:=====", e);
//			response.setError(e);
//		}
//		catch(Exception t) {
//			log.error(requestLog.toString()+ "== updatePassword UnhandledException:=====", t);
//			response.setError(new UnhandledException());
//		}
//		return response;
//
//	}
}
