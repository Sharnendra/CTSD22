package com.rnlic.hrapp.bean.request;

public class WishEmpReqBean {

	private WishesReq wishTo;

	public WishesReq getWishTo() {
		return wishTo;
	}

	public void setWishTo(WishesReq wishTo) {
		this.wishTo = wishTo;
	}
	
}
