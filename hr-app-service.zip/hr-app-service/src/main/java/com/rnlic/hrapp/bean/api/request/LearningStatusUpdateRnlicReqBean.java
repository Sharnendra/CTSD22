package com.rnlic.hrapp.bean.api.request;

public class LearningStatusUpdateRnlicReqBean {
	
	private String sapCode;
	private String learningID;
	public String getSapCode() {
		return sapCode;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getLearningID() {
		return learningID;
	}
	public void setLearningID(String learningID) {
		this.learningID = learningID;
	}
	
}
