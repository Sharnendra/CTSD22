package com.rnlic.hrapp.bean.response;

public class Attendance {

	private String date;
	private String checkInBranch;
	private String checkInBranchAddress;
	private String checkOutBranch;
	private String checkOutBranchAddress;
	private String attendanceCode;
	private String discription;
	private String checkIn;
	private String checkOut;
	private String dayOfWeek;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getCheckInBranch() {
		return checkInBranch;
	}
	public void setCheckInBranch(String checkInBranch) {
		this.checkInBranch = checkInBranch;
	}
	public String getCheckInBranchAddress() {
		return checkInBranchAddress;
	}
	public void setCheckInBranchAddress(String checkInBranchAddress) {
		this.checkInBranchAddress = checkInBranchAddress;
	}
	public String getCheckOutBranch() {
		return checkOutBranch;
	}
	public void setCheckOutBranch(String checkOutBranch) {
		this.checkOutBranch = checkOutBranch;
	}
	public String getCheckOutBranchAddress() {
		return checkOutBranchAddress;
	}
	public void setCheckOutBranchAddress(String checkOutBranchAddress) {
		this.checkOutBranchAddress = checkOutBranchAddress;
	}
	public String getAttendanceCode() {
		return attendanceCode;
	}
	public void setAttendanceCode(String attendanceCode) {
		this.attendanceCode = attendanceCode;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	public String getCheckIn() {
		return checkIn;
	}
	public void setCheckIn(String checkIn) {
		this.checkIn = checkIn;
	}
	public String getCheckOut() {
		return checkOut;
	}
	public void setCheckOut(String checkOut) {
		this.checkOut = checkOut;
	}
	public String getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	
}
