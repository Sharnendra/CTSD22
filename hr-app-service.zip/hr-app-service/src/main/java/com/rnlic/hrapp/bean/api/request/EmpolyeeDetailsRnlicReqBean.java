package com.rnlic.hrapp.bean.api.request;

public class EmpolyeeDetailsRnlicReqBean {
	
	private String employeeCode;

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	

}
