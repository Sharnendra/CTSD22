package com.rnlic.hrapp.bean.response;

import java.util.List;

public class ReporteeListDataRes implements ResponseData{

	private List<ReporteeDetails> reporteeList;

	public List<ReporteeDetails> getReporteeList() {
		return reporteeList;
	}

	public void setReporteeList(List<ReporteeDetails> reporteeList) {
		this.reporteeList = reporteeList;
	}

}
