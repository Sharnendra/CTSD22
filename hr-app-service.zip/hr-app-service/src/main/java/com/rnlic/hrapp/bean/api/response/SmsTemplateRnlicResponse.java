package com.rnlic.hrapp.bean.api.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.rnlic.hrapp.bean.response.SmsTemplateResponse;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SmsTemplateRnlicResponse extends RnlicRestResponse{

	@JsonProperty(value = "Response")
	List<SmsTemplateResponse> response = new ArrayList<>();

	public SmsTemplateRnlicResponse() {
		super();
	}

	public SmsTemplateRnlicResponse(List<SmsTemplateResponse> response) {
		super();
		this.response = response;
	}

	public List<SmsTemplateResponse> getResponse() {
		return response;
	}

	public void setResponse(List<SmsTemplateResponse> response) {
		this.response = response;
	}	
}
