package com.rnlic.hrapp.bean.request;

public class AuthReqBean {
	
	private Boolean isCandidate;
	private String sapCode;
	private String domainPassword;
	private String mobileNumber;
	private String panNumber;
	private String deviceIdentifier;
	private String fcmToken;
	public String getFcmToken() {
		return fcmToken;
	}
	public void setFcmToken(String fcmToken) {
		this.fcmToken = fcmToken;
	}
	public Boolean getIsCandidate() {
		return isCandidate;
	}
	public void setIsCandidate(Boolean isCandidate) {
		this.isCandidate = isCandidate;
	}
	public String getSapCode() {
		return sapCode;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getDomainPassword() {
		return domainPassword;
	}
	public void setDomainPassword(String domainPassword) {
		this.domainPassword = domainPassword;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getDeviceIdentifier() {
		return deviceIdentifier;
	}
	public void setDeviceIdentifier(String deviceIdentifier) {
		this.deviceIdentifier = deviceIdentifier;
	}

}
