package com.rnlic.hrapp.bean.request;

public class AttendanceNoticeReqBean {

	private String testData;

	public String getTestData() {
		return testData;
	}

	public void setTestData(String testData) {
		this.testData = testData;
	}
	
	
}
