package com.rnlic.hrapp.constant;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@ConfigurationProperties(prefix="messages")
@EnableConfigurationProperties
@Component
public class MessagesConstants implements InitializingBean{
	
	private String sentOtpSuccessMsg;
	private String internaErrorOtpMsg;
	private String multipleReqOtpMsg;
	private String validateOtpSuccessMsg;
	private String invalidOtpMsg;
	private String blankOtpMsg;
	private String otpSecureText;
	private String noEmployeeDetailsMsg;
	private String successRegistrationMsg;
	private String errorInRegistrationMsg;
	private String updateInstalledAppSuccessMsg;
	private String serviceForCandidateDetailsMsg;
	private String serviceForEmployeeDetailsMsg;
	private String incorrectJwtTokenMsg;
	private String jwtTokenMissingMsg;
	private String jwtTokenInvalidMsg;
	private String jwtSuccessAuthenticateMsg;
	private String unauthorizeAccessMsg;
	private String iligalUseOfAnotationMsg;
	private String updateDeviceRegistrationSuccessMsg;
	private String updateDeviceRegistrationFailureMsg;
	private String deregisterDeviceSuccesMsg;
	private String deregisterDeviceFailureMsg;
	private String missingMandatoryFieldMsg;
	private String noSuchUserFoundMsg;
	private String updateDeviceRegistrationNotRequiredMsg;
	private String deviceNotRegistered;
	private String deviceNotSync;
	private String noRecordsFound;
	private String checkingOutFailedNoError;
	private String checkingInFailedNoError;
	private String messageSendPartially;
	private String messageSendSuccessfully;
	private String checkInAlreadyMarked;
	private String checkOutAlreadyMarked;
	private String someThingWentWrong;
	private String smsSendSuccessfully;
	private String hasSharedBelowDetails;
	private String bothSmsAndMail;
	private String branchLocationSharedPartiallyEmailFailed;
	private String branchLocationSharedPartiallySmsFailed;
	private String sharingBranchLocationFailed;
	private String sendingSmsFailed;
	private String sendingEmailSuccessfuly;
	private String sendingEmailFailed;
	private String deviceRegisteredWithOtherDevice;
	private String pushHappyBirthdayMsg;
	private String pushHappyAnniversaryMsg;
	private String pleaseTryAfterSomeTime;
	private String dataNotUpdated;
	private String mobileNumberIsNotLinked;
	private String successOtpGenerated; 
	private String  passwordChangedSuccess;
	private String errorOtpGenerated ;
	private String passwordChangedError;
	
	public String getSentOtpSuccessMsg() {
		return sentOtpSuccessMsg;
	}

	public void setSentOtpSuccessMsg(String sentOtpSuccessMsg) {
		this.sentOtpSuccessMsg = sentOtpSuccessMsg;
	}

	public String getInternaErrorOtpMsg() {
		return internaErrorOtpMsg;
	}

	public void setInternaErrorOtpMsg(String internaErrorOtpMsg) {
		this.internaErrorOtpMsg = internaErrorOtpMsg;
	}

	public String getMultipleReqOtpMsg() {
		return multipleReqOtpMsg;
	}

	public void setMultipleReqOtpMsg(String multipleReqOtpMsg) {
		this.multipleReqOtpMsg = multipleReqOtpMsg;
	}

	public String getValidateOtpSuccessMsg() {
		return validateOtpSuccessMsg;
	}

	public void setValidateOtpSuccessMsg(String validateOtpSuccessMsg) {
		this.validateOtpSuccessMsg = validateOtpSuccessMsg;
	}

	public String getInvalidOtpMsg() {
		return invalidOtpMsg;
	}

	public void setInvalidOtpMsg(String invalidOtpMsg) {
		this.invalidOtpMsg = invalidOtpMsg;
	}

	public String getBlankOtpMsg() {
		return blankOtpMsg;
	}

	public void setBlankOtpMsg(String blankOtpMsg) {
		this.blankOtpMsg = blankOtpMsg;
	}

	public String getOtpSecureText() {
		return otpSecureText;
	}

	public void setOtpSecureText(String otpSecureText) {
		this.otpSecureText = otpSecureText;
	}

	public String getNoEmployeeDetailsMsg() {
		return noEmployeeDetailsMsg;
	}

	public void setNoEmployeeDetailsMsg(String noEmployeeDetailsMsg) {
		this.noEmployeeDetailsMsg = noEmployeeDetailsMsg;
	}

	public String getSuccessRegistrationMsg() {
		return successRegistrationMsg;
	}

	public void setSuccessRegistrationMsg(String successRegistrationMsg) {
		this.successRegistrationMsg = successRegistrationMsg;
	}

	public String getErrorInRegistrationMsg() {
		return errorInRegistrationMsg;
	}

	public void setErrorInRegistrationMsg(String errorInRegistrationMsg) {
		this.errorInRegistrationMsg = errorInRegistrationMsg;
	}


	public String getUpdateInstalledAppSuccessMsg() {
		return updateInstalledAppSuccessMsg;
	}

	public void setUpdateInstalledAppSuccessMsg(String updateInstalledAppSuccessMsg) {
		this.updateInstalledAppSuccessMsg = updateInstalledAppSuccessMsg;
	}

	public String getServiceForCandidateDetailsMsg() {
		return serviceForCandidateDetailsMsg;
	}

	public void setServiceForCandidateDetailsMsg(String serviceForCandidateDetailsMsg) {
		this.serviceForCandidateDetailsMsg = serviceForCandidateDetailsMsg;
	}

	public String getServiceForEmployeeDetailsMsg() {
		return serviceForEmployeeDetailsMsg;
	}

	public void setServiceForEmployeeDetailsMsg(String serviceForEmployeeDetailsMsg) {
		this.serviceForEmployeeDetailsMsg = serviceForEmployeeDetailsMsg;
	}

	public String getIncorrectJwtTokenMsg() {
		return incorrectJwtTokenMsg;
	}

	public void setIncorrectJwtTokenMsg(String incorrectJwtTokenMsg) {
		this.incorrectJwtTokenMsg = incorrectJwtTokenMsg;
	}

	public String getJwtTokenMissingMsg() {
		return jwtTokenMissingMsg;
	}

	public void setJwtTokenMissingMsg(String jwtTokenMissingMsg) {
		this.jwtTokenMissingMsg = jwtTokenMissingMsg;
	}

	public String getJwtTokenInvalidMsg() {
		return jwtTokenInvalidMsg;
	}

	public void setJwtTokenInvalidMsg(String jwtTokenInvalidMsg) {
		this.jwtTokenInvalidMsg = jwtTokenInvalidMsg;
	}

	public String getJwtSuccessAuthenticateMsg() {
		return jwtSuccessAuthenticateMsg;
	}

	public void setJwtSuccessAuthenticateMsg(String jwtSuccessAuthenticateMsg) {
		this.jwtSuccessAuthenticateMsg = jwtSuccessAuthenticateMsg;
	}

	public String getUnauthorizeAccessMsg() {
		return unauthorizeAccessMsg;
	}

	public void setUnauthorizeAccessMsg(String unauthorizeAccessMsg) {
		this.unauthorizeAccessMsg = unauthorizeAccessMsg;
	}

	public String getIligalUseOfAnotationMsg() {
		return iligalUseOfAnotationMsg;
	}

	public void setIligalUseOfAnotationMsg(String iligalUseOfAnotationMsg) {
		this.iligalUseOfAnotationMsg = iligalUseOfAnotationMsg;
	}

	public String getUpdateDeviceRegistrationSuccessMsg() {
		return updateDeviceRegistrationSuccessMsg;
	}

	public void setUpdateDeviceRegistrationSuccessMsg(String updateDeviceRegistrationSuccessMsg) {
		this.updateDeviceRegistrationSuccessMsg = updateDeviceRegistrationSuccessMsg;
	}

	public String getUpdateDeviceRegistrationFailureMsg() {
		return updateDeviceRegistrationFailureMsg;
	}

	public void setUpdateDeviceRegistrationFailureMsg(String updateDeviceRegistrationFailureMsg) {
		this.updateDeviceRegistrationFailureMsg = updateDeviceRegistrationFailureMsg;
	}

	public String getDeregisterDeviceSuccesMsg() {
		return deregisterDeviceSuccesMsg;
	}

	public void setDeregisterDeviceSuccesMsg(String deregisterDeviceSuccesMsg) {
		this.deregisterDeviceSuccesMsg = deregisterDeviceSuccesMsg;
	}

	public String getDeregisterDeviceFailureMsg() {
		return deregisterDeviceFailureMsg;
	}

	public void setDeregisterDeviceFailureMsg(String deregisterDeviceFailureMsg) {
		this.deregisterDeviceFailureMsg = deregisterDeviceFailureMsg;
	}

	public String getMissingMandatoryFieldMsg() {
		return missingMandatoryFieldMsg;
	}

	public void setMissingMandatoryFieldMsg(String missingMandatoryFieldMsg) {
		this.missingMandatoryFieldMsg = missingMandatoryFieldMsg;
	}

	public String getNoSuchUserFoundMsg() {
		return noSuchUserFoundMsg;
	}

	public void setNoSuchUserFoundMsg(String noSuchUserFoundMsg) {
		this.noSuchUserFoundMsg = noSuchUserFoundMsg;
	}

	public String getUpdateDeviceRegistrationNotRequiredMsg() {
		return updateDeviceRegistrationNotRequiredMsg;
	}

	public void setUpdateDeviceRegistrationNotRequiredMsg(String updateDeviceRegistrationNotRequiredMsg) {
		this.updateDeviceRegistrationNotRequiredMsg = updateDeviceRegistrationNotRequiredMsg;
	}
	
	public String getDeviceNotRegistered() {
		return deviceNotRegistered;
	}

	public void setDeviceNotRegistered(String deviceNotRegistered) {
		this.deviceNotRegistered = deviceNotRegistered;
	}

	public String getNoRecordsFound() {
		return noRecordsFound;
	}

	public void setNoRecordsFound(String noRecordsFound) {
		this.noRecordsFound = noRecordsFound;
	}

	public String getCheckingOutFailedNoError() {
		return checkingOutFailedNoError;
	}

	public void setCheckingOutFailedNoError(String checkingOutFailedNoError) {
		this.checkingOutFailedNoError = checkingOutFailedNoError;
	}

	public String getCheckingInFailedNoError() {
		return checkingInFailedNoError;
	}

	public void setCheckingInFailedNoError(String checkingInFailedNoError) {
		this.checkingInFailedNoError = checkingInFailedNoError;
	}

	public String getMessageSendPartially() {
		return messageSendPartially;
	}

	public void setMessageSendPartially(String messageSendPartially) {
		this.messageSendPartially = messageSendPartially;
	}

	public String getMessageSendSuccessfully() {
		return messageSendSuccessfully;
	}

	public void setMessageSendSuccessfully(String messageSendSuccessfully) {
		this.messageSendSuccessfully = messageSendSuccessfully;
	}

	public String getCheckInAlreadyMarked() {
		return checkInAlreadyMarked;
	}

	public void setCheckInAlreadyMarked(String checkInAlreadyMarked) {
		this.checkInAlreadyMarked = checkInAlreadyMarked;
	}

	public String getCheckOutAlreadyMarked() {
		return checkOutAlreadyMarked;
	}

	public void setCheckOutAlreadyMarked(String checkOutAlreadyMarked) {
		this.checkOutAlreadyMarked = checkOutAlreadyMarked;
	}
	
	public String getSomeThingWentWrong() {
		return someThingWentWrong;
	}

	public void setSomeThingWentWrong(String someThingWentWrong) {
		this.someThingWentWrong = someThingWentWrong;
	}
	
	public String getSmsSendSuccessfully() {
		return smsSendSuccessfully;
	}

	public void setSmsSendSuccessfully(String smsSendSuccessfully) {
		this.smsSendSuccessfully = smsSendSuccessfully;
	}

	public String getHasSharedBelowDetails() {
		return hasSharedBelowDetails;
	}

	public void setHasSharedBelowDetails(String hasSharedBelowDetails) {
		this.hasSharedBelowDetails = hasSharedBelowDetails;
	}
	
	public String getBothSmsAndMail() {
		return bothSmsAndMail;
	}

	public void setBothSmsAndMail(String bothSmsAndMail) {
		this.bothSmsAndMail = bothSmsAndMail;
	}

	public String getBranchLocationSharedPartiallyEmailFailed() {
		return branchLocationSharedPartiallyEmailFailed;
	}

	public void setBranchLocationSharedPartiallyEmailFailed(String branchLocationSharedPartiallyEmailFailed) {
		this.branchLocationSharedPartiallyEmailFailed = branchLocationSharedPartiallyEmailFailed;
	}

	public String getBranchLocationSharedPartiallySmsFailed() {
		return branchLocationSharedPartiallySmsFailed;
	}

	public void setBranchLocationSharedPartiallySmsFailed(String branchLocationSharedPartiallySmsFailed) {
		this.branchLocationSharedPartiallySmsFailed = branchLocationSharedPartiallySmsFailed;
	}
	
	public String getSharingBranchLocationFailed() {
		return sharingBranchLocationFailed;
	}

	public void setSharingBranchLocationFailed(String sharingBranchLocationFailed) {
		this.sharingBranchLocationFailed = sharingBranchLocationFailed;
	}
	
	public String getSendingSmsFailed() {
		return sendingSmsFailed;
	}

	public void setSendingSmsFailed(String sendingSmsFailed) {
		this.sendingSmsFailed = sendingSmsFailed;
	}
	
	public String getSendingEmailSuccessfuly() {
		return sendingEmailSuccessfuly;
	}

	public void setSendingEmailSuccessfuly(String sendingEmailSuccessfuly) {
		this.sendingEmailSuccessfuly = sendingEmailSuccessfuly;
	}

	public String getSendingEmailFailed() {
		return sendingEmailFailed;
	}

	public void setSendingEmailFailed(String sendingEmailFailed) {
		this.sendingEmailFailed = sendingEmailFailed;
	}

	public String getDeviceRegisteredWithOtherDevice() {
		return deviceRegisteredWithOtherDevice;
	}

	public void setDeviceRegisteredWithOtherDevice(String deviceRegisteredWithOtherDevice) {
		this.deviceRegisteredWithOtherDevice = deviceRegisteredWithOtherDevice;
	}

	public String getPushHappyBirthdayMsg() {
		return pushHappyBirthdayMsg;
	}

	public void setPushHappyBirthdayMsg(String pushHappyBirthdayMsg) {
		this.pushHappyBirthdayMsg = pushHappyBirthdayMsg;
	}

	public String getPushHappyAnniversaryMsg() {
		return pushHappyAnniversaryMsg;
	}

	public void setPushHappyAnniversaryMsg(String pushHappyAnniversaryMsg) {
		this.pushHappyAnniversaryMsg = pushHappyAnniversaryMsg;
	}
	
	public String getPleaseTryAfterSomeTime() {
		return pleaseTryAfterSomeTime;
	}

	public void setPleaseTryAfterSomeTime(String pleaseTryAfterSomeTime) {
		this.pleaseTryAfterSomeTime = pleaseTryAfterSomeTime;
	}
	public String getDataNotUpdated() {
		return dataNotUpdated;
	}

	public void setDataNotUpdated(String dataNotUpdated) {
		this.dataNotUpdated = dataNotUpdated;
	}
	
	public String getMobileNumberIsNotLinked() {
		return mobileNumberIsNotLinked;
	}

	public void setMobileNumberIsNotLinked(String mobileNumberIsNotLinked) {
		this.mobileNumberIsNotLinked = mobileNumberIsNotLinked;
	}

	public String getDeviceNotSync() {
		return deviceNotSync;
	}

	public void setDeviceNotSync(String deviceNotSync) {
		this.deviceNotSync = deviceNotSync;
	}

	public String getSuccessOtpGenerated() {
		return successOtpGenerated;
	}

	public void setSuccessOtpGenerated(String successOtpGenerated) {
		this.successOtpGenerated = successOtpGenerated;
	}

	public String getPasswordChangedSuccess() {
		return passwordChangedSuccess;
	}

	public void setPasswordChangedSuccess(String passwordChangedSuccess) {
		this.passwordChangedSuccess = passwordChangedSuccess;
	}

	public String getErrorOtpGenerated() {
		return errorOtpGenerated;
	}

	public void setErrorOtpGenerated(String errorOtpGenerated) {
		this.errorOtpGenerated = errorOtpGenerated;
	}

	public String getPasswordChangedError() {
		return passwordChangedError;
	}

	public void setPasswordChangedError(String passwordChangedError) {
		this.passwordChangedError = passwordChangedError;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		
	}
	
}
