package com.rnlic.hrapp.bean.response;

public class UpdateInstalledAppResponse implements ResponseData{
	private boolean isLinkedAppUpdated;
	private String message;
	public boolean isLinkedAppUpdated() {
		return isLinkedAppUpdated;
	}
	public void setLinkedAppUpdated(boolean isLinkedAppUpdated) {
		this.isLinkedAppUpdated = isLinkedAppUpdated;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
