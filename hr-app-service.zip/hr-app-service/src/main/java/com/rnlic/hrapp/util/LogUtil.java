package com.rnlic.hrapp.util;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rnlic.hrapp.constant.GenericConstants;

@Component
public class LogUtil {

	private static final ObjectMapper objectToJson = new ObjectMapper();
	
	public static String generateErrorLogs(String requestId, String jwtToken, Object object) throws JsonProcessingException {
		return GenericConstants.REQUEST_ID + requestId + GenericConstants.NEW_LINE 
				+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
				+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(object) + GenericConstants.NEW_LINE
				+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE;
	}
	
	public static String generateErrorLogs(String requestId) {
		return GenericConstants.REQUEST_ID + requestId + GenericConstants.NEW_LINE +
				GenericConstants.EXCEPTION+ GenericConstants.NEW_LINE;
	}
	
	public static String generateErrorLogs(String requestId, String jwtToken) {
		return GenericConstants.REQUEST_ID + requestId + GenericConstants.NEW_LINE 
				+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE;
	}
	
	public static String generateInfoLogs(String requestId, String jwtToken, Object object) throws JsonProcessingException {
		return GenericConstants.REQUEST_ID + requestId + GenericConstants.NEW_LINE 
				+ GenericConstants.DEVICE_IDENTIFIER+GenericConstants.COLLON_SPACE + jwtToken + GenericConstants.NEW_LINE
				+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(object) + GenericConstants.NEW_LINE
				+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE;
	}
	
	public static String generateInfoLogs(String requestId) {
		return GenericConstants.REQUEST_ID + requestId + GenericConstants.NEW_LINE +
				GenericConstants.EXCEPTION+ GenericConstants.NEW_LINE;
	}
	
	public static String generateInfoLogs(String msg,String requestId, String deviceId) {
		return GenericConstants.NEW_LINE+msg+GenericConstants.NEW_LINE + GenericConstants.REQUEST_ID + requestId + GenericConstants.NEW_LINE 
				+ GenericConstants.DEVICE_IDENTIFIER +GenericConstants.COLLON_SPACE+ deviceId + GenericConstants.NEW_LINE;
	}
	
	public static String generateInfoLogs(String msg,String requestId) {
		return GenericConstants.NEW_LINE+msg+GenericConstants.NEW_LINE 
				+ GenericConstants.REQUEST_ID + requestId + GenericConstants.NEW_LINE;
	}
	
	public static String generateErrorLogs(String msg,String requestId, String deviceId) {
		return GenericConstants.NEW_LINE+msg+GenericConstants.NEW_LINE + GenericConstants.REQUEST_ID + requestId + GenericConstants.NEW_LINE 
				+ GenericConstants.DEVICE_IDENTIFIER +GenericConstants.COLLON_SPACE+ deviceId + GenericConstants.NEW_LINE
				+GenericConstants.EXCEPTION+ GenericConstants.NEW_LINE;
	}
	
	public static String generateInfoLogs(String msg,String requestId, String deviceId,String invalidField) {
		return GenericConstants.NEW_LINE+msg+GenericConstants.NEW_LINE + GenericConstants.REQUEST_ID + requestId + GenericConstants.NEW_LINE 
				+ GenericConstants.DEVICE_IDENTIFIER +GenericConstants.COLLON_SPACE+ deviceId + GenericConstants.NEW_LINE
				+ GenericConstants.INCORRECT_VALUES +invalidField + GenericConstants.NEW_LINE;
				
	}
	public static String generateErrorLogs(String msg,String requestId, String deviceId,String invalidField) {
		return GenericConstants.NEW_LINE+msg+GenericConstants.NEW_LINE + GenericConstants.REQUEST_ID + requestId + GenericConstants.NEW_LINE 
				+ GenericConstants.DEVICE_IDENTIFIER +GenericConstants.COLLON_SPACE+ deviceId + GenericConstants.NEW_LINE
				+ GenericConstants.INCORRECT_VALUES +invalidField + GenericConstants.NEW_LINE;
				
	}
	
}
