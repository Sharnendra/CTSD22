package com.rnlic.hrapp.bean.api.response;

import javax.json.bind.annotation.JsonbProperty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class LearningStatusUpdateResponseBean extends RnlicRestResponse{
	
	@JsonbProperty(value="Response")
	private String response;

	public LearningStatusUpdateResponseBean() {
		super();
	}
	public LearningStatusUpdateResponseBean(String response) {
		super();
		this.response = response;
	}

	public String getResponse() {
		return this.response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	

}
