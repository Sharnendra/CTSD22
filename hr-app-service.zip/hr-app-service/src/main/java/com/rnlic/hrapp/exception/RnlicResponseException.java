package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class RnlicResponseException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RnlicResponseException(String message) {
		super(ErrorConstants.RNLIC_RESPONSE_EXCEPTION_CODE,ErrorConstants.RNLIC_RESPONSE_EXCEPTION_MESSAGE+message,false,false);
	}
	
	public RnlicResponseException(String code,String message ) {
		super(ErrorConstants.RNLIC_RESPONSE_EXCEPTION_CODE,message,false,false);
	}
	
}
