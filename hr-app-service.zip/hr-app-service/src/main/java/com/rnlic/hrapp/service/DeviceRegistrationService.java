package com.rnlic.hrapp.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rnlic.hrapp.bean.request.DeRegisterDeviceReqBean;
import com.rnlic.hrapp.bean.request.InstalledApplicationDetails;
import com.rnlic.hrapp.bean.request.RegisterDeviceReqBean;
import com.rnlic.hrapp.bean.request.UpdateDeviceRegistrationReqBean;
import com.rnlic.hrapp.bean.request.UpdateInstalledAppReqBean;
import com.rnlic.hrapp.bean.response.CheckForDeviceRegistrationResBean;
import com.rnlic.hrapp.bean.response.DeregisterDeviceResBean;
import com.rnlic.hrapp.bean.response.RegisterDeviceResBean;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.bean.response.UpdateDeviceRegistrationResBean;
import com.rnlic.hrapp.bean.response.UpdateInstalledAppResponse;
import com.rnlic.hrapp.constant.ErrorConstants;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;
import com.rnlic.hrapp.entity.InstalledApplicationModel;
import com.rnlic.hrapp.exception.DeviceRegistrationException;
import com.rnlic.hrapp.repository.DeviceRegistrationRepository;
import com.rnlic.hrapp.repository.InstalledApplicationRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.util.HrAppUtil;

@Service
public class DeviceRegistrationService {

	private static final Logger log = LogManager.getLogger(DeviceRegistrationService.class);

	@Autowired
	private RnlicService rnlicService;

	@Autowired
	private DeviceRegistrationRepository deviceRegRepo;


	@Autowired
	private MessagesConstants messagesConstants;

	@Autowired
	private InstalledApplicationRepository installAppRepo;

	/**
	 * This is method return device registration Information.
	 * @param String deviceIdentifier
	 * @param String sapCode
	 * @param String mobileNumber
	 * @return CheckForDeviceRegistrationResBean deviceRegisBean
	 */
	public ResponseData checkRegistrationInfomation(String deviceIdentifier, String sapCode, String mobileNumber) {

		log.info("== Inside checking Device Registration Information ==");

		CheckForDeviceRegistrationResBean deviceRegisBean = new CheckForDeviceRegistrationResBean();

		List<DeviceRegistrationModel> deviceRegistrationList = deviceRegRepo
				.getDeviceRegistrationDetails(deviceIdentifier, sapCode, mobileNumber);

		log.info("== After calling database for Device Registration Information =="+(HrAppUtil.isNotEmpty(deviceRegistrationList)?"No Data Available in database":"Data Available in database")); 

		String deviceIdToCheck = deviceIdentifier;
		String sapCodeToCheck = sapCode;
		String mobileNumberToCheck = mobileNumber;

		boolean isDeviceRegisterWithOthers = GenericConstants.FALSE;
		boolean isRegisterdWithOtherDevice = GenericConstants.FALSE;
		boolean mobileNumberUpdated = GenericConstants.FALSE;
		boolean sapCodeUpdated = GenericConstants.FALSE;
		boolean isDataPresent = GenericConstants.FALSE;

		if (HrAppUtil.isNotEmpty(deviceRegistrationList)) {
			isDataPresent = GenericConstants.TRUE;
			for (DeviceRegistrationModel deviceReg : deviceRegistrationList) {
				// device identifier are same
				if (deviceReg.getDeviceIdentifier().equalsIgnoreCase(deviceIdToCheck)) {

					// check candidate
					if (HrAppUtil.isNullOrEmpty(sapCodeToCheck)) {

						if (!HrAppUtil.isNullOrEmpty(mobileNumberToCheck)&& !mobileNumberToCheck.equals(deviceReg.getMobileNumber())) {
							isDeviceRegisterWithOthers = GenericConstants.TRUE;
							setDeviceRegInfo(deviceReg, deviceRegisBean);
							break;
						} 
						// how to handle when mobile number has been updated ... need to actually check
						// with pan number also

					}
					// check employee
					else {
						// NULL existing SAP Code
						if (HrAppUtil.isNullOrEmpty(deviceReg.getSapCode())) {

							// potential to be updated from candidate to employee
							if (!HrAppUtil.isNullOrEmpty(mobileNumberToCheck)&& mobileNumberToCheck.equals(deviceReg.getMobileNumber())) {
								sapCodeUpdated = GenericConstants.TRUE;

								//Mobile update feature won't be available for candidate, so
								//We removed this feature for candidate
							} else {
								// 
								isDeviceRegisterWithOthers = GenericConstants.TRUE;
								setDeviceRegInfo(deviceReg, deviceRegisBean);
								break;
							}
						} else {
							if (!HrAppUtil.isNullOrEmpty(sapCodeToCheck) && !sapCodeToCheck.equals(deviceReg.getSapCode())) {
								// different SAP Code
								isDeviceRegisterWithOthers = GenericConstants.TRUE;
								setDeviceRegInfo(deviceReg, deviceRegisBean);
								break;
							}else {
								if (!HrAppUtil.isNullOrEmpty(mobileNumberToCheck) && !mobileNumberToCheck.equals(deviceReg.getMobileNumber())) {
									mobileNumberUpdated = GenericConstants.TRUE;
								}
							}

						}

					}
				} else {
					// device identifier different - 1. already registered with other device
					// whether this is for candidate
					if (HrAppUtil.isNullOrEmpty(sapCodeToCheck)) {

						// candidate
						if (!HrAppUtil.isNullOrEmpty(mobileNumberToCheck)&& mobileNumberToCheck.equals(deviceReg.getMobileNumber())) {
							isRegisterdWithOtherDevice = GenericConstants.TRUE;
							setDeviceRegInfo(deviceReg, deviceRegisBean);
						}
					} else {
						// employee
						if (!HrAppUtil.isNullOrEmpty(sapCodeToCheck) && sapCodeToCheck.equals(deviceReg.getSapCode())) {
							isRegisterdWithOtherDevice = GenericConstants.TRUE;
							setDeviceRegInfo(deviceReg, deviceRegisBean);
							// potential to have changed mobile
							if (!HrAppUtil.isNullOrEmpty(mobileNumberToCheck)&&!mobileNumberToCheck.equals(deviceReg.getMobileNumber())) {
								mobileNumberUpdated = GenericConstants.TRUE;
							}
						}else {
							if (!HrAppUtil.isNullOrEmpty(mobileNumberToCheck)&& mobileNumberToCheck.equals(deviceReg.getMobileNumber())) {
								setDeviceRegInfo(deviceReg, deviceRegisBean);
								throw new DeviceRegistrationException(messagesConstants.getMobileNumberIsNotLinked());
							}
						}

					}
				}

			}
		}
		deviceRegisBean.setDeviceRegisterWithOthers(isDeviceRegisterWithOthers);
		deviceRegisBean.setMobileNumberUpdated(mobileNumberUpdated);
		deviceRegisBean.setRegisterdWithOtherDevice(isRegisterdWithOtherDevice);
		deviceRegisBean.setSapCodeUpdated(sapCodeUpdated);
		if (!isDeviceRegisterWithOthers) {
			deviceRegisBean.setAllowed(GenericConstants.TRUE);
			if (isDataPresent) {
				deviceRegisBean.setAlreadyRegistered(GenericConstants.TRUE);
			} else {
				deviceRegisBean.setAlreadyRegistered(GenericConstants.FALSE);
			}
		} else {
			deviceRegisBean.setAllowed(GenericConstants.FALSE);
		}
		return deviceRegisBean;
	}

	private void setDeviceRegInfo(DeviceRegistrationModel deviceReg,
			CheckForDeviceRegistrationResBean deviceRegisBean) {
		DeviceRegistrationModel deviceRegDtls = new DeviceRegistrationModel();
		deviceRegDtls.setAppVersion(deviceReg.getAppVersion());
		deviceRegDtls.setDeviceIdentifier(deviceReg.getDeviceIdentifier());
		deviceRegDtls.setDeviceType(deviceReg.getDeviceType());
		deviceRegDtls.setFcmToken(deviceReg.getFcmToken());
		deviceRegDtls.setIsActive(deviceReg.getIsActive());
		deviceRegDtls.setMobileNumber(deviceReg.getMobileNumber());
		deviceRegDtls.setName(deviceReg.getName());
		deviceRegDtls.setPanNumber(deviceReg.getPanNumber());
		deviceRegDtls.setRegisteredOn(deviceReg.getRegisteredOn());
		deviceRegDtls.setRequestId(deviceReg.getRequestId());
		deviceRegDtls.setSapCode(deviceReg.getSapCode());
		deviceRegDtls.setIsSync(deviceReg.getIsSync());
		deviceRegisBean.setDeviceRegDetails(deviceRegDtls);

	}

	/**
	 * This method for registering device logged in database
	 * @param UserDetailsBean userDetailsBean
	 * @param RegisterDeviceReqBean registerDeviceReqBean
	 * @return RegisterDeviceResBean  registerDeviceResBean
	 */
	public ResponseData registerDevice(UserDetailsBean userDetailsBean, RegisterDeviceReqBean registerDeviceReqBean) {
		RegisterDeviceResBean registerDeviceResBean = new RegisterDeviceResBean();
		CheckForDeviceRegistrationResBean deviceRegisBean = (CheckForDeviceRegistrationResBean) checkRegistrationInfomation(
				userDetailsBean.getDeviceIdentifier(), userDetailsBean.getSapCode(), userDetailsBean.getMobileNumber());
		if (!deviceRegisBean.isDeviceRegisterWithOthers()) {
			if (deviceRegisBean.isRegisterdWithOtherDevice()) {
				deleteRegisteredDetails(deviceRegisBean.getDeviceRegDetails());
				saveDeviceRegistration(userDetailsBean, registerDeviceReqBean, registerDeviceResBean);
			} else if (!deviceRegisBean.isAlreadyRegistered()) {
				saveDeviceRegistration(userDetailsBean, registerDeviceReqBean, registerDeviceResBean);
			} else {
//				DeviceRegistrationModel deviceRegDetails=deviceRegRepo.findByDeviceIdentifier(userDetailsBean.getDeviceIdentifier());
//				if(deviceRegDetails!=null) {
//					boolean isDeviceRegUpdatedWithRnlic = rnlicService.updateDeviceRegInfo(userDetailsBean.getDeviceIdentifier(),userDetailsBean.getMobileNumber(),userDetailsBean.getSapCode(),userDetailsBean.getFcmToken());
//					if(isDeviceRegUpdatedWithRnlic) {
//						deviceRegDetails.setIsSync(GenericConstants.TRUE);
//					}else {
//						deviceRegDetails.setIsSync(GenericConstants.FALSE);
//					}
//					deviceRegRepo.save(deviceRegDetails);
//				}else
//				{
//					throw new DeviceRegistrationException(messagesConstants.getDeviceNotRegistered());
//				}
				
				/*
				 * This Change is made in 10/10/2019
				 * in order to resolve the issue for 
				 * data not set for some conditions
				 * 
				 * Assumption: Device registration was null
				 * */
				if(HrAppUtil.isNullOrEmpty(deviceRegisBean.getDeviceRegDetails()))
				{
					DeviceRegistrationModel deviceRegDetails=deviceRegRepo.findByDeviceIdentifier(userDetailsBean.getDeviceIdentifier());
					setDeviceRegInfo(deviceRegDetails, deviceRegisBean);
				}
				deleteRegisteredDetails(deviceRegisBean.getDeviceRegDetails());
				saveDeviceRegistration(userDetailsBean, registerDeviceReqBean, registerDeviceResBean);
				registerDeviceResBean.setStatus(GenericConstants.ALREADY_REGISTERED);
			}
		} else {
			throw new DeviceRegistrationException(messagesConstants.getDeviceRegisteredWithOtherDevice());
		}

		return registerDeviceResBean;
	}

	private void saveDeviceRegistration(UserDetailsBean userDetailsBean, RegisterDeviceReqBean registerDeviceReqBean,
			RegisterDeviceResBean registerDeviceResBean) {
		boolean isDeviceRegUpdatedWithRnlic = false;
		DeviceRegistrationModel deviceRegDetails = new DeviceRegistrationModel();
		if(!userDetailsBean.isCandidate()) {
			isDeviceRegUpdatedWithRnlic = rnlicService.updateDeviceRegInfo(userDetailsBean.getDeviceIdentifier(),userDetailsBean.getMobileNumber(),userDetailsBean.getSapCode(),userDetailsBean.getFcmToken());
			if(isDeviceRegUpdatedWithRnlic) {
				deviceRegDetails.setIsSync(GenericConstants.TRUE);
			}else {
				deviceRegDetails.setIsSync(GenericConstants.FALSE);
			}
		}
		deviceRegDetails.setAppVersion(HrAppUtil.isNullOrEmpty(registerDeviceReqBean.getAppVersion())?null:registerDeviceReqBean.getAppVersion());
		deviceRegDetails.setDeviceIdentifier(HrAppUtil.isNullOrEmpty(userDetailsBean.getDeviceIdentifier())?null:userDetailsBean.getDeviceIdentifier());
		deviceRegDetails.setDeviceType(HrAppUtil.isNullOrEmpty(registerDeviceReqBean.getDeviceType())?null:registerDeviceReqBean.getDeviceType());
		deviceRegDetails.setFcmToken(HrAppUtil.isNullOrEmpty(userDetailsBean.getFcmToken())?userDetailsBean.getDeviceIdentifier():userDetailsBean.getFcmToken());
		deviceRegDetails.setIsActive(GenericConstants.TRUE);
		deviceRegDetails.setMobileNumber(HrAppUtil.isNullOrEmpty(userDetailsBean.getMobileNumber())?null:userDetailsBean.getMobileNumber());
		deviceRegDetails.setPanNumber(HrAppUtil.isNullOrEmpty(userDetailsBean.getPanNumber())?null:userDetailsBean.getPanNumber());
		deviceRegDetails.setRegisteredOn(new Date());
		deviceRegDetails.setSapCode(HrAppUtil.isNullOrEmpty(userDetailsBean.getSapCode())?null:userDetailsBean.getSapCode());
		deviceRegDetails.setName((HrAppUtil.isNullOrEmpty(userDetailsBean.getFristName())?null:userDetailsBean.getFristName())+GenericConstants.WHITE_SPACE+ (HrAppUtil.isNullOrEmpty(userDetailsBean.getLastName())?null:userDetailsBean.getLastName()));
		if (!HrAppUtil.isNullOrEmpty(deviceRegRepo.save(deviceRegDetails))) {
			registerDeviceResBean.setStatus(messagesConstants.getSuccessRegistrationMsg());
		} else {
			registerDeviceResBean.setStatus(messagesConstants.getErrorInRegistrationMsg());
		}
	}

	@Transactional
	private void deleteRegisteredDetails(DeviceRegistrationModel deviceRegDetails) {
		deviceRegRepo.delete(deviceRegDetails);

	}

	/**
	 * This method will help to update device registration information in database
	 * @param UserDetailsBean userDetailsBean
	 * @param UpdateDeviceRegistrationReqBean updateDeviceRegReqBean
	 * @return UpdateDeviceRegistrationResBean updateDeviceReg
	 */
	@Transactional
	public ResponseData updateDeviceReg(UserDetailsBean userDetailsBean,
			UpdateDeviceRegistrationReqBean updateDeviceRegReqBean) {
		UpdateDeviceRegistrationResBean updateDeviceReg = new UpdateDeviceRegistrationResBean();
		CheckForDeviceRegistrationResBean deviceRegisBean = (CheckForDeviceRegistrationResBean) checkRegistrationInfomation(
				userDetailsBean.getDeviceIdentifier(), userDetailsBean.getSapCode(), userDetailsBean.getMobileNumber());
		int noOfRow = GenericConstants.INTEGER_ZERO;
		boolean isUpdateRequired = GenericConstants.FALSE;
		if (deviceRegisBean.isMobileNumberUpdated()) {
			isUpdateRequired = GenericConstants.TRUE;
			if (userDetailsBean.isCandidate()) {
				noOfRow = deviceRegRepo.updateMobileNoForCandidate(userDetailsBean.getDeviceIdentifier(),
						userDetailsBean.getPanNumber(), userDetailsBean.getMobileNumber());
			} else {
				noOfRow = deviceRegRepo.updateMobileNoForEmployee(userDetailsBean.getDeviceIdentifier(),
						userDetailsBean.getSapCode(), userDetailsBean.getMobileNumber());
			}
		}
		if (deviceRegisBean.isSapCodeUpdated()) {
			isUpdateRequired = GenericConstants.TRUE;
			noOfRow = deviceRegRepo.updateSapCode(userDetailsBean.getDeviceIdentifier(), userDetailsBean.getSapCode(),
					userDetailsBean.getMobileNumber(), userDetailsBean.getPanNumber());
		}
		if (isUpdateRequired) {
			if (noOfRow > GenericConstants.INTEGER_ZERO) {
				updateDeviceReg.setUpdated(GenericConstants.TRUE);
				updateDeviceReg.setMessage(messagesConstants.getUpdateDeviceRegistrationSuccessMsg());
			} else {
				updateDeviceReg.setUpdated(GenericConstants.FALSE);
				updateDeviceReg.setMessage(messagesConstants.getUpdateDeviceRegistrationFailureMsg());
			}
		} else {
			updateDeviceReg.setUpdated(GenericConstants.FALSE);
			updateDeviceReg.setMessage(messagesConstants.getUpdateDeviceRegistrationNotRequiredMsg());
		}
		return updateDeviceReg;
	}

	/**
	 * This method de-registered  device from Database
	 * @param UserDetailsBean userDetailsBean
	 * @param DeRegisterDeviceReqBean deregDeviceReqBean
	 * @return DeregisterDeviceResBean deregisterDeviceResBean
	 */
	public ResponseData deRegDevice(UserDetailsBean userDetailsBean, DeRegisterDeviceReqBean deregDeviceReqBean) {
		DeregisterDeviceResBean deregisterDeviceResBean = new DeregisterDeviceResBean();
		int noOfRow = GenericConstants.INTEGER_ZERO;
		if (userDetailsBean.isCandidate()) {
			noOfRow = deviceRegRepo.deleteByPanNumber(userDetailsBean.getPanNumber(),
					userDetailsBean.getMobileNumber());

		} else {
			noOfRow = deviceRegRepo.deleteBySapCode(userDetailsBean.getPanNumber(), userDetailsBean.getMobileNumber(),
					userDetailsBean.getSapCode());
		}
		if (noOfRow > GenericConstants.INTEGER_ZERO) {
			deregisterDeviceResBean.setDeleted(GenericConstants.TRUE);
			deregisterDeviceResBean.setMessage(messagesConstants.getDeregisterDeviceSuccesMsg());
		} else {
			deregisterDeviceResBean.setDeleted(GenericConstants.FALSE);
			deregisterDeviceResBean.setMessage(messagesConstants.getDeregisterDeviceFailureMsg());
		}

		return deregisterDeviceResBean;
	}


	/**
	 * This method will update linked application details for Registered Device.
	 * @param UserDetailsBean userDetailsBean
	 * @param UpdateInstalledAppReqBean updateInstalledAppReqBean
	 * @return
	 */
	public ResponseData updateLinkedAppForRegisteredDevice(UserDetailsBean userDetailsBean,
			UpdateInstalledAppReqBean updateInstalledAppReqBean) {
		UpdateInstalledAppResponse response = new UpdateInstalledAppResponse();
		List<Object[]> requestId = deviceRegRepo.getRequestIdForRegisteredDecive(userDetailsBean.getDeviceIdentifier());
		if(requestId.size()>GenericConstants.INTEGER_ZERO) {
			deleteInstallAppForRegisteredDevice(Integer.valueOf(requestId.get(0)[0].toString()));
			for(InstalledApplicationDetails installedAppDtls:updateInstalledAppReqBean.getInstalledLinkedApps()) {
				InstalledApplicationModel installedAppEntity = new InstalledApplicationModel();
				installedAppEntity.setApplicationDescription(installedAppDtls.getApplicationDescription());
				installedAppEntity.setApplicationName(installedAppDtls.getApplicationName());
				installedAppEntity.setApplicationVersion(installedAppDtls.getApplicationVersion());
				installedAppEntity.setRequestId(Integer.valueOf(requestId.get(0)[0].toString()));
				installedAppEntity.setStatusUpdatedOn(new Date());
				installedAppEntity.setInstalled(installedAppDtls.isInstalled());
				installAppRepo.save(installedAppEntity);
				response.setLinkedAppUpdated(GenericConstants.TRUE);
				response.setMessage(messagesConstants.getUpdateInstalledAppSuccessMsg());
			}
		}else {
			response.setLinkedAppUpdated(GenericConstants.FALSE);
			response.setMessage(ErrorConstants.NO_DEVICE_REHISTERED);
		}
		return response;
	}

	@Transactional
	private void deleteInstallAppForRegisteredDevice(Integer requestId) {
		installAppRepo.deleteByRequestId(requestId);

	}
}
