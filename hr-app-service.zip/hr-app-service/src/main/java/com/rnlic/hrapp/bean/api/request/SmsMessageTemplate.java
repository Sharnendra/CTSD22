package com.rnlic.hrapp.bean.api.request;

public class SmsMessageTemplate {

	private String RequestFor;
	private String ApplicableFor;
	public String getRequestFor() {
		return RequestFor;
	}
	public void setRequestFor(String requestFor) {
		RequestFor = requestFor;
	}
	public String getApplicableFor() {
		return ApplicableFor;
	}
	public void setApplicableFor(String applicableFor) {
		ApplicableFor = applicableFor;
	}
}
