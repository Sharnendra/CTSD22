package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

public class StateDetails {
	
	private String stateName;
	private String stateCode;
	private List<CityDetails> cities = new ArrayList<>();
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public List<CityDetails> getCities() {
		return cities;
	}
	public void setCities(List<CityDetails> cities) {
		this.cities = cities;
	}
	

}
