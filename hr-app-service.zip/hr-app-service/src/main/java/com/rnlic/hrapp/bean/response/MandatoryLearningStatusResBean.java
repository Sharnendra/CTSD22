package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

public class MandatoryLearningStatusResBean implements ResponseData{
	
	private List<MandatoryLearningDetails> mandatoryLearnings =new ArrayList<>();

	public List<MandatoryLearningDetails> getMandatoryLearnings() {
		return mandatoryLearnings;
	}

	public void setMandatoryLearnings(List<MandatoryLearningDetails> mandatoryLearnings) {
		this.mandatoryLearnings = mandatoryLearnings;
	}

}
