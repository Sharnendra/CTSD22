package com.rnlic.hrapp.bean.request;

public class MailingReqBean {

	private String mailId;
	private String subject;
	private StringBuilder message=new StringBuilder();
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public StringBuilder getMessage() {
		return message;
	}
	public void setMessage(StringBuilder message) {
		this.message = message;
	}
}
