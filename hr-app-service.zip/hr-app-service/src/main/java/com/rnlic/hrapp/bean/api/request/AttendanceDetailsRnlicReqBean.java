package com.rnlic.hrapp.bean.api.request;

public class AttendanceDetailsRnlicReqBean {
	
	private String SAPCode;
	private String Month;
	private String Year;
	public String getSAPCode() {
		return SAPCode;
	}
	public void setSAPCode(String sAPCode) {
		SAPCode = sAPCode;
	}
	public String getMonth() {
		return Month;
	}
	public void setMonth(String month) {
		Month = month;
	}
	public String getYear() {
		return Year;
	}
	public void setYear(String year) {
		Year = year;
	}
	

}
