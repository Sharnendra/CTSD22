package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.rnlic.hrapp.bean.api.response.PushResultResBean;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PushNotificationResponse {

	@JsonProperty(value = "success")
	private int success;
	@JsonProperty(value = "failure")
	private int failure;
	@JsonProperty(value = "results")
	private List<PushResultResBean> results =new ArrayList<>();
	public int getSuccess() {
		return success;
	}
	public void setSuccess(int success) {
		this.success = success;
	}
	public int getFailure() {
		return failure;
	}
	public void setFailure(int failure) {
		this.failure = failure;
	}
	public List<PushResultResBean> getResults() {
		return results;
	}
	public void setResults(List<PushResultResBean> results) {
		this.results = results;
	}
}
