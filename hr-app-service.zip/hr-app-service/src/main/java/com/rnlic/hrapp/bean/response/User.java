package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

public class User implements ResponseData {
	
	private String firstName;
	private String lastName;
	private String middleName;
	private String sapCode;
	private String mobileNo;
	private String email;
	private String channel;
	private List<String> orgRoles = new ArrayList<>();
	private String level;
	private String managerSapCode;
	private String managerName;
	private String locationCode;
	private String locationName;
	private String zoneCode;
	private String zoneName;
	private String userRole;
	private boolean hasReportee;
	private String panNo;
	private String category;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getSapCode() {
		return sapCode;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public List<String> getOrgRoles() {
		return orgRoles;
	}
	public void setOrgRoles(List<String> orgRoles) {
		this.orgRoles = orgRoles;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String lavel) {
		this.level = lavel;
	}
	public String getManagerSapCode() {
		return managerSapCode;
	}
	public void setManagerSapCode(String managerSapCode) {
		this.managerSapCode = managerSapCode;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	public String getZoneCode() {
		return zoneCode;
	}
	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}
	public String getZoneName() {
		return zoneName;
	}
	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public boolean isHasReportee() {
		return hasReportee;
	}
	public void setHasReportee(boolean hasReportee) {
		this.hasReportee = hasReportee;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

}
