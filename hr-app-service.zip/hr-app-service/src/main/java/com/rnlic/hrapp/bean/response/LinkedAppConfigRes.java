package com.rnlic.hrapp.bean.response;

import com.rnlic.hrapp.bean.request.LinkedApplicationReq;

public class LinkedAppConfigRes implements ResponseData{
	
	private LinkedApplicationReq applicationConfiguration;
	public LinkedApplicationReq getApplicationConfiguration() {
		return applicationConfiguration;
	}
	public void setApplicationConfiguration(LinkedApplicationReq linkedApplications) {
		this.applicationConfiguration = linkedApplications;
	}
	
}
