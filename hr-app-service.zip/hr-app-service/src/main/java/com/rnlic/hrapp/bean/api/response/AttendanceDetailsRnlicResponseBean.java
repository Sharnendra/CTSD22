package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AttendanceDetailsRnlicResponseBean implements RnlicResponseData{
	@JsonProperty(value = "EmpCode") 
	private String sapCode;
	@JsonProperty(value = "Date") 
	private String date;
	@JsonProperty(value = "Month") 
	private String month;
	@JsonProperty(value = "Year") 
	private String year;
	@JsonProperty(value = "IsHoliday") 
	private String isHoliday;
	@JsonProperty(value = "HolidayName") 
	private String holidayName;
	@JsonProperty(value = "IsLeave") 
	private String isLeave;
	@JsonProperty(value = "LeaveType") 
	private String leaveType;
	@JsonProperty(value = "IsPresent") 
	private String isPresent;
	@JsonProperty(value = "InTime") 
	private String inTime;
	@JsonProperty(value = "OutTime") 
	private String outTime;
	@JsonProperty(value = "IsWaiting") 
	private String isWaiting;
	@JsonProperty(value = "IsRejected") 
	private String isRejected;
	@JsonProperty(value = "LeaveDescript") 
	private String leaveDescription;
	@JsonProperty(value = "Official_Reason") 
	private String officialReason;
	@JsonProperty(value = "CheckInBranch")
	private String checkInBranch;
	@JsonProperty(value = "CheckInBrAddress")
	private String checkInBrAddress;
	@JsonProperty(value = "CheckOutBranch")
	private String checkOutBranch;
	@JsonProperty(value = "CheckOutBrAddress")
	private String checkOutBrAddress;
	public String getSapCode() {
		return sapCode;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getIsHoliday() {
		return isHoliday;
	}
	public void setIsHoliday(String isHoliday) {
		this.isHoliday = isHoliday;
	}
	public String getHolidayName() {
		return holidayName;
	}
	public void setHolidayName(String holidayName) {
		this.holidayName = holidayName;
	}
	public String getIsLeave() {
		return isLeave;
	}
	public void setIsLeave(String isLeave) {
		this.isLeave = isLeave;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public String getIsPresent() {
		return isPresent;
	}
	public void setIsPresent(String isPresent) {
		this.isPresent = isPresent;
	}
	public String getInTime() {
		return inTime;
	}
	public void setInTime(String inTime) {
		this.inTime = inTime;
	}
	public String getOutTime() {
		return outTime;
	}
	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}
	public String getIsWaiting() {
		return isWaiting;
	}
	public void setIsWaiting(String isWaiting) {
		this.isWaiting = isWaiting;
	}
	public String getIsRejected() {
		return isRejected;
	}
	public void setIsRejected(String isRejected) {
		this.isRejected = isRejected;
	}
	public String getLeaveDescription() {
		return leaveDescription;
	}
	public void setLeaveDescription(String leaveDescription) {
		this.leaveDescription = leaveDescription;
	}
	public String getOfficialReason() {
		return officialReason;
	}
	public void setOfficialReason(String officialReason) {
		this.officialReason = officialReason;
	}
	public String getCheckInBranch() {
		return checkInBranch;
	}
	public void setCheckInBranch(String checkInBranch) {
		this.checkInBranch = checkInBranch;
	}
	public String getCheckInBrAddress() {
		return checkInBrAddress;
	}
	public void setCheckInBrAddress(String checkInBrAddress) {
		this.checkInBrAddress = checkInBrAddress;
	}
	public String getCheckOutBranch() {
		return checkOutBranch;
	}
	public void setCheckOutBranch(String checkOutBranch) {
		this.checkOutBranch = checkOutBranch;
	}
	public String getCheckOutBrAddress() {
		return checkOutBrAddress;
	}
	public void setCheckOutBrAddress(String checkOutBrAddress) {
		this.checkOutBrAddress = checkOutBrAddress;
	}
	
	
}
