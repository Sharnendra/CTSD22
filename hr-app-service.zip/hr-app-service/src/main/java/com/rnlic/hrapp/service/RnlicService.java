package com.rnlic.hrapp.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rnlic.hrapp.bean.api.request.AttendanceDetailsRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.AuthDetailsRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.BirthdayListRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.CandidateDetailsRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.ChangePasswordRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.CheckInReqBean;
import com.rnlic.hrapp.bean.api.request.CheckOutReqBean;
import com.rnlic.hrapp.bean.api.request.DeviceInfoRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.EmpolyeeDetailsRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.LearningStatusUpdateRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.LocateBranchRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.SendOtpRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.SmsMessageTemplate;
import com.rnlic.hrapp.bean.api.request.WishEmployeeRnlicReqBean;
import com.rnlic.hrapp.bean.api.response.AnniversaryListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.BirthdayListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.BirthdaySmsResBean;
import com.rnlic.hrapp.bean.api.response.CandidateRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.ChangePasswordRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.CheckInCheckOutRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.DeviceRegInfoResponseBean;
import com.rnlic.hrapp.bean.api.response.EmployeeRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.LearningStatusUpdateResponseBean;
import com.rnlic.hrapp.bean.api.response.MandatoryLearningRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.MandatoryLearningStatusRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.MonthlyAttendanceDetailsRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.NoticesRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.ReporteeListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.RnlicAuthRes;
import com.rnlic.hrapp.bean.api.response.RnlicBranchDetailsListResponseBean;
import com.rnlic.hrapp.bean.api.response.RnlicServicesDataTranslator;
import com.rnlic.hrapp.bean.api.response.SendOtpRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.SmsTemplateRnlicResponse;
import com.rnlic.hrapp.bean.api.response.StateCityMasterRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.SubscriptionRnlicResBean;
import com.rnlic.hrapp.bean.api.response.TroubleWithLoginRnlicResponseBean;
import com.rnlic.hrapp.bean.request.AttendanceReqBean;
import com.rnlic.hrapp.bean.request.AuthReqBean;
import com.rnlic.hrapp.bean.request.BirthdayReqBean;
import com.rnlic.hrapp.bean.request.ChangePasswordReqBean;
import com.rnlic.hrapp.bean.request.EmployeeCheckInCheckOutReqBean;
import com.rnlic.hrapp.bean.request.LocalBranchReqBean;
import com.rnlic.hrapp.bean.request.MailingReqBean;
import com.rnlic.hrapp.bean.request.MessageTemplateRequest;
import com.rnlic.hrapp.bean.request.PushNotification;
import com.rnlic.hrapp.bean.request.PushNotificationReqBean;
import com.rnlic.hrapp.bean.request.ShareBranchDetailsReqBean;
import com.rnlic.hrapp.bean.request.WishesReq;
import com.rnlic.hrapp.bean.response.AnniversaryResBean;
import com.rnlic.hrapp.bean.response.AttendanceDetailsResBean;
import com.rnlic.hrapp.bean.response.BirthdayResBean;
import com.rnlic.hrapp.bean.response.ChangePasswordResBean;
import com.rnlic.hrapp.bean.response.EmployeeCheckInCheckOutResBean;
import com.rnlic.hrapp.bean.response.LocateBranchResBean;
import com.rnlic.hrapp.bean.response.MandatoryLearningResBean;
import com.rnlic.hrapp.bean.response.MandatoryLearningStatusResBean;
import com.rnlic.hrapp.bean.response.MessageTemplate;
import com.rnlic.hrapp.bean.response.NoticesResBean;
import com.rnlic.hrapp.bean.response.PushNotificationResponse;
import com.rnlic.hrapp.bean.response.ReporteeDetails;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.bean.response.SendOtpMobileResBean;
import com.rnlic.hrapp.bean.response.StateCityMasterResBean;
import com.rnlic.hrapp.bean.response.SubscriptionResponseList;
import com.rnlic.hrapp.bean.response.TroubleWithLoginResBean;
import com.rnlic.hrapp.bean.response.User;
import com.rnlic.hrapp.configuration.MailerConfig;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.constant.RnlicUrlConstants;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;
import com.rnlic.hrapp.entity.OtpMasterModel;
import com.rnlic.hrapp.entity.PushDataModal;
import com.rnlic.hrapp.exception.CheckInCheckOutException;
import com.rnlic.hrapp.exception.RestTemplateResponseErrorHandler;
import com.rnlic.hrapp.exception.RnlicServiceException;
import com.rnlic.hrapp.exception.StateDetailsNotFoundException;
import com.rnlic.hrapp.repository.PushDataRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestLogDeatils;

@Service
public class RnlicService {
	private static final Logger log = LogManager.getLogger(RnlicService.class);

	@Autowired
	private RnlicServicesDataTranslator rnlicDataTranslator;

	@Autowired
	private RnlicUrlConstants rnlicUrlConstants;

	@Autowired
	private MessagesConstants messagesConstants;
	
	@Autowired
	private RnlicApiExchange rnlicApiExchange;
	
	@Autowired
	private MailerConfig mailerConfig;
	
	@Autowired
	private GenericConstants genericConstants;
	
	@Autowired
	private PushDataRepository pushDataRepository;

	private static String message="";
	@Autowired
	private RequestLogDeatils requestLog;

	public User getCandidateDtlsFromRnlic(UserDetailsBean empReqBean) throws RestClientException, IOException {
		log.info(requestLog+"==getCandidateDtlsFromRnlic Rnlic API Call");
		User user = null;
		CandidateDetailsRnlicReqBean candidateRnlicReqBean = new CandidateDetailsRnlicReqBean();
		candidateRnlicReqBean.setMoblieNo(empReqBean.getMobileNumber());
		candidateRnlicReqBean.setPanNo(empReqBean.getPanNumber());
		HttpEntity<CandidateDetailsRnlicReqBean> requestEntity = new HttpEntity<>(candidateRnlicReqBean,getRequestHeader());
		CandidateRnlicResponseBean response =rnlicApiExchange.getCandidateDtlsFromRnlicUrl(rnlicUrlConstants.getUrls().getCandidateDetailsRnlicUrl(), requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			log.info(requestLog+"==getCandidateDtlsFromRnlic No response from Rnlic API Call");
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())
					&& response.getMessage().equalsIgnoreCase(GenericConstants.DATA_FOUND)) {
				log.info(requestLog+"==getCandidateDtlsFromRnlic success response from Rnlic API Call");
				user = rnlicDataTranslator.getCandidateDetails(response);
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())
					&& response.getMessage().equalsIgnoreCase(GenericConstants.NO_DATA_FOUND)) {
				log.info(requestLog+"==getCandidateDtlsFromRnlic NO_DATA_FOUND response from Rnlic API Call");
				throw new RnlicServiceException(response.getMessage());
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				log.info(requestLog+"==getCandidateDtlsFromRnlic Failure response from Rnlic API Call");
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				log.info(requestLog+"==getCandidateDtlsFromRnlic failed response from Rnlic API Call");
				throw new RnlicServiceException(response.getMessage());
			} else {
				log.info(requestLog+"==getCandidateDtlsFromRnlic unkown response from Rnlic API Call");
				throw new RnlicServiceException();
			}
		}
		return user;

	}

	public User getEmpDetailsFromRnlic(UserDetailsBean empReqBean) throws RestClientException, IOException {
		
		log.info(requestLog+"==getEmpDetailsFromRnlic Rnlic API Call");
		User user = null;
		EmpolyeeDetailsRnlicReqBean empRnlicReqBean = new EmpolyeeDetailsRnlicReqBean();
		empRnlicReqBean.setEmployeeCode(empReqBean.getSapCode());
		HttpEntity<EmpolyeeDetailsRnlicReqBean> requestEntity = new HttpEntity<>(empRnlicReqBean, getRequestHeader());
		EmployeeRnlicResponseBean response = rnlicApiExchange.getEmpDetailsFromRnlicUrl(rnlicUrlConstants.getUrls().getEmployeeDetailsRnlicUrl(), requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			log.info(requestLog+"==getEmpDetailsFromRnlic No response from RNLIC service");
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&&(response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())
					&& response.getMessage().equalsIgnoreCase(GenericConstants.DATA_FOUND)) {
				log.info(requestLog+"==getEmpDetailsFromRnlic Success response from RNLIC service");
				user = rnlicDataTranslator.getEmpDetails(response);
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())
					&& response.getMessage().equalsIgnoreCase(GenericConstants.NO_DATA_FOUND)) {
				log.info(requestLog+"==getEmpDetailsFromRnlic Success response from RNLIC service but"+GenericConstants.NO_DATA_FOUND);
				throw new RnlicServiceException(response.getMessage());
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				log.info(requestLog+"==getEmpDetailsFromRnlic Failure response from RNLIC service");
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				log.info(requestLog+"==getEmpDetailsFromRnlic Failed response from RNLIC service");
				throw new RnlicServiceException(response.getMessage());
			} else {
				log.info(requestLog+"==getEmpDetailsFromRnlic Unkown response from RNLIC service");
				throw new RnlicServiceException();
			}
		}
		return user;

	}

	public boolean getEmployeeAuthentication(AuthReqBean authReqBean) throws RestClientException, IOException {
		log.info(requestLog+"==EmployeeAuthentication  RNLIC service");
		boolean isValidUser = GenericConstants.FALSE;
		AuthDetailsRnlicReqBean authDetailsRnlicReqBean = new AuthDetailsRnlicReqBean();
		authDetailsRnlicReqBean.setUserName(authReqBean.getSapCode());
		authDetailsRnlicReqBean.setPassword(authReqBean.getDomainPassword());
		HttpEntity<AuthDetailsRnlicReqBean> requestEntity = new HttpEntity<>(authDetailsRnlicReqBean, getRequestHeader());
		RnlicAuthRes response = rnlicApiExchange.getEmployeeAuthenticationUrl(rnlicUrlConstants.getUrls().getEmployeeAuthServiceRnlicUrl(),requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			log.info(requestLog+"==EmployeeAuthentication No response RNLIC service");
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				log.info(requestLog+"==EmployeeAuthentication valid user RNLIC service");
				isValidUser = GenericConstants.TRUE;
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				log.info(requestLog+"==EmployeeAuthentication Invalid User RNLIC service failure");
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				log.info(requestLog+"==EmployeeAuthentication Invalid User RNLIC service failed");
				throw new RnlicServiceException(response.getMessage());
			} else {
				log.info(requestLog+"==EmployeeAuthentication Unkown response RNLIC service failed");
				throw new RnlicServiceException();
			}
		}
		return isValidUser;
	}

	public boolean getCandidateAuthentication(AuthReqBean authReqBean) throws RestClientException, IOException {
		log.info(requestLog+"== CandidateAuthentication  Rnlic API Call");
		boolean isValidUser = GenericConstants.FALSE;
		AuthDetailsRnlicReqBean authDetailsRnlicReqBean = new AuthDetailsRnlicReqBean();
		authDetailsRnlicReqBean.setUserName(authReqBean.getPanNumber());
		authDetailsRnlicReqBean.setPassword(authReqBean.getMobileNumber());
		HttpEntity<AuthDetailsRnlicReqBean> requestEntity = new HttpEntity<>(authDetailsRnlicReqBean, getRequestHeader());
		RnlicAuthRes response = rnlicApiExchange.getCandidateAuthenticationUrl(rnlicUrlConstants.getUrls().getCandidateAuthServiceRnlicUrl(), requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			log.info(requestLog+"== CandidateAuthentication No response Rnlic API Call");
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				log.info(requestLog+"== CandidateAuthentication valid user");
				isValidUser = GenericConstants.TRUE;
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				log.info(requestLog+"== CandidateAuthentication Invalid user failure");
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				log.info(requestLog+"== CandidateAuthentication Invalid user Failed");
				throw new RnlicServiceException(response.getMessage());
			} else {
				log.info(requestLog+"== CandidateAuthentication Unkown user Failed");
				throw new RnlicServiceException();
			}
		}
		return isValidUser;
	}

	private HttpHeaders getRequestHeader() {
		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		requestHeaders.setExpires(0);
		requestHeaders.setCacheControl("private, no-store, max-age=0");
		return requestHeaders;
	}

	public SendOtpMobileResBean sendOtpMobile(UserDetailsBean empReqBean, OtpMasterModel otpEntity)
			throws RestClientException, IOException {
		log.info(requestLog+ "== sendOtpMobile Rnlic Service :=====");
		boolean isOtpSent = GenericConstants.FALSE;
		boolean isMailSent = GenericConstants.FALSE;
		SendOtpRnlicReqBean sendOtpRnlicReqBean = new SendOtpRnlicReqBean();
		sendOtpRnlicReqBean.setMobile(empReqBean.getMobileNumber());
		sendOtpRnlicReqBean.setText(String.format((messagesConstants.getOtpSecureText()),String.valueOf(otpEntity.getOtpValue()),HrAppUtil.dateTimeFormator(otpEntity.getValidUpto())));
		HttpEntity<SendOtpRnlicReqBean> requestEntity = new HttpEntity<>(sendOtpRnlicReqBean, getRequestHeader());
		SendOtpRnlicResponseBean response = rnlicApiExchange.sendOtpMobileUrl(rnlicUrlConstants.getUrls().getSendSmsRnlicUrl(),	requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			log.info(requestLog+ "== sendOtpMobile Rnlic Service no response :=====");
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				log.info(requestLog+ "== sendOtpMobile Rnlic Service Success response :=====");
				isOtpSent = GenericConstants.TRUE;
			} 
//			else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
//					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
//				log.info(requestLog+ "== sendOtpMobile Rnlic Service FAILURE response :=====");
//				throw new RnlicServiceException();
//			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
//					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
//				log.info(requestLog+ "== sendOtpMobile Rnlic Service FAILED response :=====");
//				throw new RnlicServiceException(response.getMessage());
//			} else {
//				log.info(requestLog+ "== sendOtpMobile Rnlic Service FAILED response :=====");
//				throw new RnlicServiceException(messagesConstants.getSomeThingWentWrong());
//			}
		}
		if(!HrAppUtil.isNullOrEmpty(empReqBean.getEmail()))
		{
			MailingReqBean mailingReqBean=new MailingReqBean();
			mailingReqBean.setMailId(empReqBean.getEmail());
			mailingReqBean.setSubject(GenericConstants.OTP_EKONNECT_MAIL);
			mailingReqBean.setMessage(new StringBuilder(sendOtpRnlicReqBean.getText()));
			String mailingResBean = sendMail(mailingReqBean);
			isMailSent = GenericConstants.SUCCESS.equalsIgnoreCase(mailingResBean);
		}
		
		SendOtpMobileResBean sendOtpMobileResBean = new SendOtpMobileResBean();
		//rnlicDataTranslator.genarateOTPResponse(sendOtpMobileResBean, empReqBean, isOtpSent, isMailSent, messagesConstants, otpEntity);
//		if(HrAppUtil.isNullOrEmpty(empReqBean.getEmail()))
//		{
//			if(isOtpSent) {
//				sendOtpMobileResBean.setStatus(true);
//				sendOtpMobileResBean.setMessage(messagesConstants.getSentOtpSuccessMsg() + otpEntity.getMobileNumber()
//				+ GenericConstants.VALID_UPTO + otpEntity.getValidUpto()+" OTP_PT"+otpEntity.getOtpValue()+"TEST");
//				sendOtpMobileResBean.setValidUpto(otpEntity.getValidUpto());
//			}
//			else {
//				sendOtpMobileResBean.setStatus(false);
//			}
//		}
//		else
//		{
//			if(isOtpSent && isMailSent) {
//				sendOtpMobileResBean.setStatus(true);
//				sendOtpMobileResBean.setMessage(messagesConstants.getSentOtpSuccessMsg() + otpEntity.getMobileNumber()
//				+ GenericConstants.VALID_UPTO + otpEntity.getValidUpto()+" OTP_PT"+otpEntity.getOtpValue()+". OTP sent in both email and on mobile");
//				sendOtpMobileResBean.setValidUpto(otpEntity.getValidUpto());
//			}
//			else if(isOtpSent && !isMailSent){
//				sendOtpMobileResBean.setStatus(false);
//				sendOtpMobileResBean.setMessage(messagesConstants.getSentOtpSuccessMsg() + otpEntity.getMobileNumber()
//				+ GenericConstants.VALID_UPTO + otpEntity.getValidUpto()+" OTP_PT"+otpEntity.getOtpValue()+". OTP sent on mobile");
//				sendOtpMobileResBean.setValidUpto(otpEntity.getValidUpto());
//			}
//			else if(!isOtpSent && isMailSent){
//				sendOtpMobileResBean.setStatus(false);
//				sendOtpMobileResBean.setMessage(messagesConstants.getSentOtpSuccessMsg() + otpEntity.getMobileNumber()
//				+ GenericConstants.VALID_UPTO + otpEntity.getValidUpto()+" OTP_PT"+otpEntity.getOtpValue()+". OTP sent in mobile");
//				sendOtpMobileResBean.setValidUpto(otpEntity.getValidUpto());
//			}
//			else {
//				sendOtpMobileResBean.setStatus(false);
//			}
//		}
		
		
		//return isOtpSent;
		return rnlicDataTranslator.genarateOTPResponse(sendOtpMobileResBean, empReqBean, isOtpSent, isMailSent, messagesConstants, otpEntity);

	}

	private EmployeeCheckInCheckOutResBean performCheckIn(UserDetailsBean empReqBean,
			EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean) {
		EmployeeCheckInCheckOutResBean responseBean = null;
		CheckInReqBean checkInReqBean = new CheckInReqBean();
		checkInReqBean.setSAPCode(empReqBean.getSapCode());
		checkInReqBean.setSourceFrom(GenericConstants.MOBILE);
		checkInReqBean.setIMEINo(empReqBean.getDeviceIdentifier());
		checkInReqBean.setCheckInAddress(empReqBean.getDeviceIdentifier());
		checkInReqBean.setCheckInLatitude(employeeCheckInCheckOutReqBean.getUserLocation().getLatitude());
		checkInReqBean.setCheckInLongitude(employeeCheckInCheckOutReqBean.getUserLocation().getLongitude());
		HttpEntity<CheckInReqBean> requestEntity = new HttpEntity<>(checkInReqBean, getRequestHeader());
		CheckInCheckOutRnlicResponseBean response = rnlicApiExchange.performCheckInUrl(rnlicUrlConstants.getUrls().getEmployeeCheckInRnlicUrl(), requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())) {
				responseBean = rnlicDataTranslator.getEmployeeCheckInCheckOutRes(employeeCheckInCheckOutReqBean,response);
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				if(response.getMessage().contains(messagesConstants.getCheckInAlreadyMarked())|| 
						(!HrAppUtil.isNullOrEmpty(response.getResponse()) 
						&& !HrAppUtil.isNullOrEmpty(response.getResponse().get(0)) 
						&& !HrAppUtil.isNullOrEmpty(response.getResponse().get(0).getCheckInTime()))) 
				{
					responseBean = rnlicDataTranslator.getEmployeeCheckInCheckOutRes(employeeCheckInCheckOutReqBean,response);
				}
				else
				{
					responseGenerate(response);
					throw new RnlicServiceException(response.getMessage()+GenericConstants.SPACE+'\r'+'\n'+messagesConstants.getCheckingInFailedNoError()+GenericConstants.SPACE+'\r'+'\n'+checkInReqBean.toString()+'\r'+'\n'+messagesConstants.getPleaseTryAfterSomeTime());
				}
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				responseGenerate(response);
				throw new RnlicServiceException(response.getMessage()+GenericConstants.SPACE+'\r'+'\n'+messagesConstants.getCheckingInFailedNoError()+GenericConstants.SPACE+'\r'+'\n'+checkInReqBean.toString()+'\r'+'\n'+messagesConstants.getPleaseTryAfterSomeTime());
			} else {
				throw new RnlicServiceException(response.getMessage()+GenericConstants.SPACE+'\r'+'\n'+messagesConstants.getCheckingInFailedNoError()+GenericConstants.SPACE+'\r'+'\n'+checkInReqBean.toString()+'\r'+'\n'+messagesConstants.getPleaseTryAfterSomeTime());
			}
		}
		return responseBean;
	}

	public EmployeeCheckInCheckOutResBean performCheckInCheckOut(UserDetailsBean empReqBean,
			EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean)
	{
		EmployeeCheckInCheckOutResBean employeeCheckInCheckOutResBean = null;
		if(null!=employeeCheckInCheckOutReqBean.getType() && employeeCheckInCheckOutReqBean.getType().equalsIgnoreCase("check-in"))
		{
			employeeCheckInCheckOutResBean = performCheckIn(empReqBean,employeeCheckInCheckOutReqBean);
		}
		else if(null!=employeeCheckInCheckOutReqBean.getType() && employeeCheckInCheckOutReqBean.getType().equalsIgnoreCase("check-out"))
		{
			employeeCheckInCheckOutResBean = performCheckOut(empReqBean,employeeCheckInCheckOutReqBean);
		}
		else
		{
			throw new CheckInCheckOutException();
		}
		return employeeCheckInCheckOutResBean;
	}

	private EmployeeCheckInCheckOutResBean performCheckOut(UserDetailsBean empReqBean,
			EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean) {
		EmployeeCheckInCheckOutResBean responseBean =null;
		CheckOutReqBean checkOutReqBean = new CheckOutReqBean();
		checkOutReqBean.setSAPCode(empReqBean.getSapCode());
		checkOutReqBean.setSourceFrom(GenericConstants.MOBILE);// It is important to ask what should be the source
		// from I think It would be Branch name.
		checkOutReqBean.setIMEINo(empReqBean.getDeviceIdentifier());
		checkOutReqBean.setCheckOutLatitude(employeeCheckInCheckOutReqBean.getUserLocation().getLatitude());
		checkOutReqBean.setCheckOutLongitude(employeeCheckInCheckOutReqBean.getUserLocation().getLongitude());
		checkOutReqBean.setCheckOutAddress(empReqBean.getDeviceIdentifier());
		HttpEntity<CheckOutReqBean> requestEntity = new HttpEntity<>(checkOutReqBean, getRequestHeader());
		GenericConstants.REST_TEMPLATE.setErrorHandler(new RestTemplateResponseErrorHandler());
		CheckInCheckOutRnlicResponseBean response = rnlicApiExchange.performCheckOutUrl(rnlicUrlConstants.getUrls().getEmployeeCheckOutRnlicUrl(), requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())) {
				responseBean = rnlicDataTranslator.getEmployeeCheckInCheckOutRes(employeeCheckInCheckOutReqBean,response);
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.NO_DATA_FOUND) || response.getStatus().equalsIgnoreCase(GenericConstants.FAILED))) {
				if(response.getMessage().contains(messagesConstants.getCheckOutAlreadyMarked())|| 
						(!HrAppUtil.isNullOrEmpty(response.getResponse()) 
						&& !HrAppUtil.isNullOrEmpty(response.getResponse().get(0)) 
						&& !HrAppUtil.isNullOrEmpty(response.getResponse().get(0).getCheckOutTime()))) 
				{
					responseBean = rnlicDataTranslator.getEmployeeCheckInCheckOutRes(employeeCheckInCheckOutReqBean,response);
				}
				else
				{
					responseGenerate(response);
					throw new RnlicServiceException(response.getMessage()+GenericConstants.SPACE+'\r'+'\n'+messagesConstants.getCheckingOutFailedNoError()+GenericConstants.SPACE+'\r'+'\n'+checkOutReqBean.toString()+'\r'+'\n'+messagesConstants.getPleaseTryAfterSomeTime());
				}
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				responseGenerate(response);
				throw new RnlicServiceException(response.getMessage()+GenericConstants.SPACE+'\r'+'\n'+messagesConstants.getCheckingOutFailedNoError()+GenericConstants.SPACE+'\r'+'\n'+checkOutReqBean.toString()+'\r'+'\n'+messagesConstants.getPleaseTryAfterSomeTime());
			} else {
				throw new RnlicServiceException(response.getMessage()+GenericConstants.SPACE+'\r'+'\n'+messagesConstants.getCheckingOutFailedNoError()+GenericConstants.SPACE+'\r'+'\n'+checkOutReqBean.toString()+'\r'+'\n'+messagesConstants.getPleaseTryAfterSomeTime());
			}
		}
		return responseBean;
	}

	/**
	 * This method will consume RNLIC Service to get list of Birthday
	 * 
	 * @return ResponseData
	 */
	public ResponseData getTodayBirthday() {

		BirthdayResBean birthdayRes = null;
		String strDate = HrAppUtil.dateFormator(new Date());
		BirthdayListRnlicResponseBean response = rnlicApiExchange.performGetTodayBirthdayUrl(rnlicUrlConstants.getUrls().getTodayBirthdayRnlicUrl(), strDate);
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())
					&& (response.getMessage().equalsIgnoreCase(GenericConstants.DATA_FOUND)|| response.getMessage().equalsIgnoreCase(GenericConstants.DATA_LOADED_SUCCESS))) {
				birthdayRes = rnlicDataTranslator.getBirthdayList(response);
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())
					&& response.getMessage().equalsIgnoreCase(GenericConstants.NO_DATA_FOUND)) {
				throw new RnlicServiceException(response.getMessage());
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new RnlicServiceException(response.getMessage());
			} else {
				throw new RnlicServiceException();
			}
		}
		return birthdayRes;

	}

	/**
	 * This method will consume RNLIC Service to get list of Anniversary
	 * 
	 * @return ResponseData
	 */
	public ResponseData getTodayAnniversary() {

		AnniversaryResBean anniversaryResBean = null;
		String strDate = HrAppUtil.dateFormator(new Date());
		AnniversaryListRnlicResponseBean response = rnlicApiExchange.performGetTodayAnniversaryUrl(rnlicUrlConstants.getUrls().getTodayAnniversaryRnlicUrl(), strDate);
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())
					&& (response.getMessage().equalsIgnoreCase(GenericConstants.DATA_FOUND)|| response.getMessage().equalsIgnoreCase(GenericConstants.DATA_LOADED_SUCCESS))) {
				anniversaryResBean = rnlicDataTranslator.getAnniversaryList(response);
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))
					&& !HrAppUtil.isNullOrEmpty(response.getMessage())
					&& response.getMessage().equalsIgnoreCase(GenericConstants.NO_DATA_FOUND)) {
				throw new RnlicServiceException(response.getMessage());
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new RnlicServiceException(response.getMessage());
			} else {
				throw new RnlicServiceException();
			}
		}
		return anniversaryResBean;

	}

	/**
	 * This method will call rnlic service to getList of reportee under the given
	 * manager
	 * 
	 * @param String sapCode
	 * @return List<ReporteeDetails> reporteeList
	 */
	public List<ReporteeDetails> getListOfReportees(String sapCode) {
		List<ReporteeDetails> reporteeList = null;

		ReporteeListRnlicResponseBean response = rnlicApiExchange.performGetListOfReporteesUrl(rnlicUrlConstants.getUrls().getListOfReporteeRnlicUrl(), sapCode);
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				reporteeList = rnlicDataTranslator.getReporteeList(response);
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				return reporteeList;
			} else {
				throw new RnlicServiceException();
			}
		}
		return reporteeList;
	}

	public BirthdaySmsResBean sendBirthdaySms(WishesReq wishTo,String senderSapCode) {
		WishEmployeeRnlicReqBean data =new WishEmployeeRnlicReqBean();
		data.setReceiverSAPCode(wishTo.getSapCode());
		data.setSenderSAPCode(senderSapCode);
		HttpEntity<WishEmployeeRnlicReqBean> requestEntity = new HttpEntity<>(data, getRequestHeader());
		BirthdaySmsResBean rnlicAuthRes = rnlicApiExchange.performSendBirthdaySmsUrl(rnlicUrlConstants.getUrls().getSendBirthdaySmsRnlicUrl(),requestEntity);
		if (HrAppUtil.isNullOrEmpty(rnlicAuthRes)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(rnlicAuthRes.getStatus())) {
				return rnlicAuthRes;
			} else {
				throw new RnlicServiceException();
			}
		}
	}
	
	public BirthdaySmsResBean sendAnniversarySms(WishesReq wishTo, String senderSapCode) {

		WishEmployeeRnlicReqBean data =new WishEmployeeRnlicReqBean();
		data.setReceiverSAPCode(wishTo.getSapCode());
		data.setSenderSAPCode(senderSapCode);
		HttpEntity<WishEmployeeRnlicReqBean> requestEntity = new HttpEntity<>(data, getRequestHeader());
		BirthdaySmsResBean rnlicAuthRes = rnlicApiExchange.performSendBirthdaySmsUrl(rnlicUrlConstants.getUrls().getSendAnniversarySmsRnlicUrl(),requestEntity);
		if (HrAppUtil.isNullOrEmpty(rnlicAuthRes)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(rnlicAuthRes.getStatus())) {
				return rnlicAuthRes;
			} else {
				throw new RnlicServiceException();
			}
		}
	}

	public RnlicAuthRes sendBirthdayEmail(WishesReq wishTo, String senderSapCode) {

		WishEmployeeRnlicReqBean data =new WishEmployeeRnlicReqBean();
		data.setReceiverSAPCode(wishTo.getSapCode());
		data.setSenderSAPCode(senderSapCode);
		HttpEntity<WishEmployeeRnlicReqBean> requestEntity = new HttpEntity<>(data, getRequestHeader());
		RnlicAuthRes rnlicAuthRes = rnlicApiExchange.performSendBirthdayEmailUrl(rnlicUrlConstants.getUrls().getSendBirthdayEmailRnlicUrl(),requestEntity);
		if (HrAppUtil.isNullOrEmpty(rnlicAuthRes)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(rnlicAuthRes.getStatus())) {
				return rnlicAuthRes;
			}else {
				throw new RnlicServiceException();
			}
		}
	}
	
	public RnlicAuthRes sendAnniversaryEmail(WishesReq wishTo, String senderSapCode) {

		WishEmployeeRnlicReqBean data =new WishEmployeeRnlicReqBean();
		data.setReceiverSAPCode(wishTo.getSapCode());
		data.setSenderSAPCode(senderSapCode);
		HttpEntity<WishEmployeeRnlicReqBean> requestEntity = new HttpEntity<>(data, getRequestHeader());
		RnlicAuthRes rnlicAuthRes = rnlicApiExchange.performSendAnniversaryEmailUrl(rnlicUrlConstants.getUrls().getSendAnniversaryEmailRnlicUrl(),requestEntity);
		if (HrAppUtil.isNullOrEmpty(rnlicAuthRes)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(rnlicAuthRes.getStatus())) {
				return rnlicAuthRes;
			}else {
				throw new RnlicServiceException();
			}
		}
	}

	public ResponseData searchBirthday(BirthdayReqBean birthdayReqBean) {
		
		BirthdayResBean searchBirthdayResponse =null;
		BirthdayListRnlicReqBean birthdayListRnlicReqBean=new BirthdayListRnlicReqBean();
		birthdayListRnlicReqBean.setSapCode(birthdayReqBean.getSapCode());
		birthdayListRnlicReqBean.setEmpName(birthdayReqBean.getName());
		
	    HttpEntity<BirthdayListRnlicReqBean> requestEntity= new HttpEntity<>(birthdayListRnlicReqBean, getRequestHeader());
	    BirthdayListRnlicResponseBean response = rnlicApiExchange.searchBirthdayUrl(rnlicUrlConstants.getUrls().getSearchBirthdayRnlicUrl(), requestEntity);
		
	    if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				searchBirthdayResponse = rnlicDataTranslator.getBirthdayList(response);
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new StateDetailsNotFoundException();
			} else {
				throw new RnlicServiceException();
			}
		}
		return searchBirthdayResponse;

	}

	public StateCityMasterResBean getStateCityMaster() {
		StateCityMasterResBean stateCityMasterResBean = null;

		StateCityMasterRnlicResponseBean response = rnlicApiExchange.getStateCityMasterUrl(rnlicUrlConstants.getUrls().getStateCityMaster());
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				stateCityMasterResBean = rnlicDataTranslator.getStateCityMasteList(response);
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new StateDetailsNotFoundException();
			} else {
				throw new RnlicServiceException();
			}
		}
		return stateCityMasterResBean;
	}

	public LocateBranchResBean getBranchDetails(LocalBranchReqBean localBranchReqBean) {
		LocateBranchResBean locateBranchResBean=new LocateBranchResBean();
		LocateBranchRnlicReqBean localBranchRnlicReqBean=new LocateBranchRnlicReqBean();
		localBranchRnlicReqBean.setCity(localBranchReqBean.getCityName());
		localBranchRnlicReqBean.setState(localBranchReqBean.getStateName());
		HttpEntity<LocateBranchRnlicReqBean> requestEntity = new HttpEntity<>(localBranchRnlicReqBean, getRequestHeader());
		RnlicBranchDetailsListResponseBean response=rnlicApiExchange.getBranchDetailsUrl(rnlicUrlConstants.getUrls().getLocateBranch(),	requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				locateBranchResBean = rnlicDataTranslator.getBranchDetails(response,locateBranchResBean);
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new StateDetailsNotFoundException();
			} else {
				throw new RnlicServiceException();
			}
		}
		return locateBranchResBean;
	}

	//	public boolean getDeviceRegInfo(String deviceIdentifier, String mobileNumber, String sapCode) {
	//		
	//		boolean isRegWithRnlic = false;
	//		DeviceInfoRnlicReqBean deviceInfoReqBean = new DeviceInfoRnlicReqBean();
	//		deviceInfoReqBean.setDeviceIdentifier(deviceIdentifier);
	//		deviceInfoReqBean.setMobileNo(mobileNumber);
	//		deviceInfoReqBean.setSAPCode(sapCode);
	//		HttpEntity<DeviceInfoRnlicReqBean> requestEntity = new HttpEntity<>(deviceInfoReqBean, getRequestHeader());
	//		DeviceRegInfoResponseBean response = GenericConstants.REST_TEMPLATE.postForObject(rnlicUrlConstants.getUrls().getGetDeviceRegistrationRnlicUrl(),requestEntity, DeviceRegInfoResponseBean.class);
	//		if (HrAppUtil.isNullOrEmpty(response)) {
	//			throw new RnlicServiceException();
	//		} else {
	//			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
	//					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
	//				isRegWithRnlic = GenericConstants.TRUE;
	//			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
	//					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
	//				isRegWithRnlic = GenericConstants.FALSE;
	//			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
	//					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
	//				isRegWithRnlic = GenericConstants.FALSE;
	//			} else {
	//				throw new RnlicServiceException();
	//			}
	//		}
	//		return isRegWithRnlic;
	//	}

	public boolean updateDeviceRegInfo(String deviceIdentifier, String mobileNumber, String sapCode,String fcmToken) {
		boolean isRegUpdatedWithRnlic = false;
		DeviceInfoRnlicReqBean deviceInfoReqBean = new DeviceInfoRnlicReqBean();
		deviceInfoReqBean.setDeviceIdentifier(deviceIdentifier);
		deviceInfoReqBean.setMobileNo(mobileNumber);
		deviceInfoReqBean.setSAPCode(sapCode);
		deviceInfoReqBean.setFCMToken(fcmToken);
		HttpEntity<DeviceInfoRnlicReqBean> requestEntity = new HttpEntity<>(deviceInfoReqBean, getRequestHeader());
		DeviceRegInfoResponseBean response = rnlicApiExchange.updateDeviceRegInfoUrl(rnlicUrlConstants.getUrls().getUpdateDeviceRegistrationRnlicUrl(),requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				isRegUpdatedWithRnlic = GenericConstants.TRUE;
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				isRegUpdatedWithRnlic = GenericConstants.FALSE;
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				isRegUpdatedWithRnlic = GenericConstants.FALSE;
			} else {
				throw new RnlicServiceException();
			}
		}
		return isRegUpdatedWithRnlic;
	}
	
	private CheckInCheckOutRnlicResponseBean responseGenerate(CheckInCheckOutRnlicResponseBean response) {
		if(response.getErrors().size()!=0)
		{
			message="";
			response.getErrors().stream().forEach(errorBean ->{
				if(message.equalsIgnoreCase(""))
				{
					message=GenericConstants.FIELD+errorBean.getField()+GenericConstants.MESSAGE+errorBean.getMessage();
				}
				else
				{
					message=message+", "+GenericConstants.FIELD+errorBean.getField()+GenericConstants.MESSAGE+errorBean.getMessage();
				}
			});
			throw new RnlicServiceException(response.getMessage()+" "+message);
		}
		return response;
	}

	/**
	 * This method call rnlic service and translate response
	 * @param AttendanceReqBean attendanceReqBean
	 * @param UserDetailsBean empReqBean
	 * @return ResponseData AttendanceDetailsResBean
	 */
	public ResponseData getAttendanceDtls(AttendanceReqBean attendanceReqBean, UserDetailsBean empReqBean) {
		
		AttendanceDetailsResBean attendanceResBean=null;
		AttendanceDetailsRnlicReqBean attendanceDtlsReqBean = new AttendanceDetailsRnlicReqBean();
		attendanceDtlsReqBean.setMonth(attendanceReqBean.getMonth());
		attendanceDtlsReqBean.setSAPCode(attendanceReqBean.getSapCode());
		attendanceDtlsReqBean.setYear(attendanceReqBean.getYear());
		HttpEntity<AttendanceDetailsRnlicReqBean> requestEntity = new HttpEntity<>(attendanceDtlsReqBean, getRequestHeader());
		MonthlyAttendanceDetailsRnlicResponseBean response = rnlicApiExchange.getAttendanceDtlsUrl(rnlicUrlConstants.getUrls().getAttendanceDetailsRnlicUrl(),requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				attendanceResBean = rnlicDataTranslator.getAttendanceDtls(response,attendanceReqBean,empReqBean);
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new RnlicServiceException();
			} else {
				throw new RnlicServiceException();
			}
		}
		return attendanceResBean;
	}

	/**
	 * This method will call rnlic api to get learnings details 
	 * @param UserDetailsBean empReqBean //may be use in future
	 * @return MandatoryLearningResBean  mandatoryLearningResBean
	 */
	public ResponseData getMandatoryLearning() {
		MandatoryLearningResBean mandatoryLearningResBean = null;

		MandatoryLearningRnlicResponseBean response = rnlicApiExchange.getMandatoryLearningUrl(rnlicUrlConstants.getUrls().getGetMandatoryLearnigsRnlicUrl());
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				mandatoryLearningResBean = rnlicDataTranslator.getMandatoryLearning(response);
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new StateDetailsNotFoundException();
			} else {
				throw new RnlicServiceException();
			}
		}
		return mandatoryLearningResBean;
	}
	
	/**
	 * This method will call rnlic api to get learnings details 
	 * @param UserDetailsBean empReqBean //may be use in future
	 * @return MandatoryLearningResBean  mandatoryLearningResBean
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	public ResponseData getMandatoryLearningStatus(UserDetailsBean empReqBean) throws JsonParseException, JsonMappingException, IOException {
		MandatoryLearningStatusResBean mandatoryLearningResBean = null;

		ObjectMapper mapper=new ObjectMapper();
		String resp = rnlicApiExchange.getMandatoryLearningStatusUrl(rnlicUrlConstants.getUrls().getGetMandatoryLearnigsStatusRnlicUrl(), empReqBean.getSapCode());
		Map<String,String> result =	HrAppUtil.mapFromJson(resp);
		MandatoryLearningStatusRnlicResponseBean response = mapper.readValue(resp, MandatoryLearningStatusRnlicResponseBean.class);
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				mandatoryLearningResBean = rnlicDataTranslator.getMandatoryLearningStatus(response,result);
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new StateDetailsNotFoundException();
			} else {
				throw new RnlicServiceException();
			}
		}
		return mandatoryLearningResBean;
	}

	/**
	 * This method call rnlic service for any trouble with log in and translate response
	 * @return ResponseData TroubleWithLoginResBean
	 */
	public ResponseData getResponseForTroubleInLogin() {
		TroubleWithLoginResBean troubleWithLoginResBean = null;
		TroubleWithLoginRnlicResponseBean response= rnlicApiExchange.getResponseForTroubleInLoginUrl(rnlicUrlConstants.getUrls().getHavingTroubleWithLogin());
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				if(response.getTroubleWithLoginResBean().size()<1)
				{
					throw new RnlicServiceException();
				}
				troubleWithLoginResBean = rnlicDataTranslator.getTroubleWithLoginDetails(response);
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new StateDetailsNotFoundException();
			} else {
				throw new RnlicServiceException();
			}
		}
		return troubleWithLoginResBean;
	}

	/**
	 * This method call RNLIC API to update learning status
	 * @param UserDetailsBean empReqBean
	 * @param String learningIds
	 * @return boolean isLearningStatusUpdatedWithRnlic
	 */
	public boolean updateLearningCompletion(UserDetailsBean empReqBean, String learningId) {
		boolean isLearningStatusUpdatedWithRnlic = false;
		LearningStatusUpdateRnlicReqBean updateLearningStatusReq = new LearningStatusUpdateRnlicReqBean();
		updateLearningStatusReq.setLearningID(learningId);
		updateLearningStatusReq.setSapCode(empReqBean.getSapCode());
		HttpEntity<LearningStatusUpdateRnlicReqBean> requestEntity = new HttpEntity<>(updateLearningStatusReq, getRequestHeader());
		LearningStatusUpdateResponseBean response = rnlicApiExchange.updateLearningCompletionUrl(rnlicUrlConstants.getUrls().getUpdateMandatoryLearnigsStatusRnlicUrl(),requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				isLearningStatusUpdatedWithRnlic = GenericConstants.TRUE;
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				isLearningStatusUpdatedWithRnlic = GenericConstants.FALSE;
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				isLearningStatusUpdatedWithRnlic = GenericConstants.FALSE;
			} else {
				throw new RnlicServiceException();
			}
		}
		return isLearningStatusUpdatedWithRnlic;
	}
	
	public boolean shareBrachDetails(String message, ShareBranchDetailsReqBean shareBranchDetailsReqBean)
			throws RestClientException, IOException {
		boolean isMessageSent = GenericConstants.FALSE;
		isMessageSent=sendMessagesViaSMS(shareBranchDetailsReqBean.getMobileNo(),message);
		return isMessageSent;
	}
	
	private boolean sendMessagesViaSMS(String mobile, String text) {
		
		boolean isMessageSent = false;
		SendOtpRnlicReqBean sendOtpRnlicReqBean = new SendOtpRnlicReqBean();
		sendOtpRnlicReqBean.setMobile(mobile);
		sendOtpRnlicReqBean.setText(text);
		HttpEntity<SendOtpRnlicReqBean> requestEntity = new HttpEntity<>(sendOtpRnlicReqBean, getRequestHeader());
		SendOtpRnlicResponseBean response = rnlicApiExchange.sendMessagesViaSMSUrl(rnlicUrlConstants.getUrls().getSendSmsRnlicUrl(),
				requestEntity);
		if (!HrAppUtil.isNullOrEmpty(response)){
			if(!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				isMessageSent = GenericConstants.TRUE;
			}
		}
		return isMessageSent;
	}
	
	public String getShareBrachDetailsMessage(UserDetailsBean empReqBean, ShareBranchDetailsReqBean shareBranchDetailsReqBean) {
		return empReqBean.getFristName()+GenericConstants.SPACE+empReqBean.getLastName()+GenericConstants.SPACE+messagesConstants.getHasSharedBelowDetails()+
				GenericConstants.SPACE+rnlicDataTranslator.generateSharedMessage(shareBranchDetailsReqBean.getLocateBranches());
	}

	/**
	 * This method will request RNLIC service to change password
	 * @param ChangePasswordReqBean changePasswordReqBean
	 * @return ChangePasswordResBean changePassRes
	 */
	public ResponseData changePasswordRequest(ChangePasswordReqBean changePasswordReqBean) {
		
		ChangePasswordResBean changePassRes = null;
		ChangePasswordRnlicReqBean req = new ChangePasswordRnlicReqBean();
		req.setSAP_ID(changePasswordReqBean.getSapCode());
		req.setOTP(HrAppUtil.isNullOrEmpty(changePasswordReqBean.getOtp())?GenericConstants.EMPTY_STRING:changePasswordReqBean.getOtp());
		req.setNEW_PSWD(HrAppUtil.isNullOrEmpty(changePasswordReqBean.getNewPassword())?GenericConstants.EMPTY_STRING:changePasswordReqBean.getNewPassword());
		HttpEntity<ChangePasswordRnlicReqBean> requestEntity = new HttpEntity<>(req, getRequestHeader());
		ChangePasswordRnlicResponseBean response = rnlicApiExchange.changePasswordRequest(rnlicUrlConstants.getUrls().getChangePassword(),requestEntity);
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				changePassRes = rnlicDataTranslator.getChangePasswordResponse(response);
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new RnlicServiceException();
			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.ALERT)) {
				throw new RnlicServiceException(response.getMessage().get(GenericConstants.RETURN_MESSAGE));
			} else {
				throw new RnlicServiceException();
			}
		}
		return changePassRes;
	}

//	/**
//	 * This method will request RNLIC service to update password
//	 * @param ChangePasswordReqBean changePasswordReqBean
//	 * @return ChangePasswordResBean changePassRes
//	 */
//	public ResponseData updatePassword(ChangePasswordReqBean changePasswordReqBean) {
//		ChangePasswordResBean changePassRes = null;
//		ChangePasswordRnlicReqBean req = new ChangePasswordRnlicReqBean();
//		req.setSAP_ID(changePasswordReqBean.getSapCode());
//		req.setOTP(HrAppUtil.isNullOrEmpty(changePasswordReqBean.getOtp())?GenericConstants.EMPTY_STRING:changePasswordReqBean.getOtp());
//		req.setNEW_PSWD(HrAppUtil.isNullOrEmpty(changePasswordReqBean.getNewPassword())?GenericConstants.EMPTY_STRING:changePasswordReqBean.getNewPassword());
//		HttpEntity<ChangePasswordRnlicReqBean> requestEntity = new HttpEntity<>(req, getRequestHeader());
//		ChangePasswordRnlicResponseBean response = rnlicApiExchange.changePasswordRequest(rnlicUrlConstants.getUrls().getUpdatePasswordRnlicUrl(),requestEntity);
//		if (HrAppUtil.isNullOrEmpty(response)) {
//			throw new RnlicServiceException();
//		} else {
//			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
//					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
//				changePassRes = rnlicDataTranslator.getChangePasswordResponse(response);
//			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
//					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
//				throw new RnlicServiceException();
//			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
//					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
//				throw new RnlicServiceException();
//			}else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
//					&& response.getStatus().equalsIgnoreCase(GenericConstants.ALERT)) {
//				//throw new RnlicServiceException(response.getMessage().get(0).getReturnMessage());
//			} else {
//				throw new RnlicServiceException();
//			}
//		}
//		return changePassRes;
//	}
	
	public String sendMail(MailingReqBean mailingReqBean) {
		try {
			MimeMessage msg = mailerConfig.getMimeMessage();
			msg.setSubject(mailingReqBean.getSubject(), GenericConstants.MAIL_UTF);
			msg.setText(mailingReqBean.getMessage().toString(), GenericConstants.MAIL_UTF, "html");
			msg.setSentDate(new Date());
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mailingReqBean.getMailId(), false));
			rnlicApiExchange.sendMailToUser(msg);
		} catch (MessagingException e) {
			return GenericConstants.FAILURE;
       }
		return GenericConstants.SUCCESS;
	}

	/**
	 * This method will call rnlic api to get notices details
	 * @param UserDetailsBean userbean
	 * @return ResponseData responseData
	 */
	public ResponseData getNotices(UserDetailsBean userbean) {
		NoticesResBean noticesResBean = null;
		
		NoticesRnlicResponseBean response = rnlicApiExchange.getNotices(rnlicUrlConstants.getUrls().getNoticesRnlicUrl(),userbean.getSapCode());
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS)||response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				noticesResBean = rnlicDataTranslator.getNotices(response);
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException(response.getMessage());
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new RnlicServiceException(response.getMessage());
			} else {
				throw new RnlicServiceException();
			}
		}
		return noticesResBean;
	}

	/**
	 * This method will send data to googleapeis to send push notification
	 * @param WishesReq wishTo
	 * @param DeviceRegistrationModel data
	 * @return int responseData
	 */
	public int sendPushNotification(WishesReq wishTo, DeviceRegistrationModel data, UserDetailsBean userDetailsBean) {
		PushNotification notification = new PushNotification();
		notification.setTitle(GenericConstants.TITLE);
		notification.setBody(pushNotificationMessageGenerator(wishTo.getType()));
		
		PushDataModal pushData = new PushDataModal();
		pushData.setNotifiedBySapCode(userDetailsBean.getSapCode());
		pushData.setNotifiedByName(userDetailsBean.getFristName()+" "+userDetailsBean.getLastName());
		pushData.setNotificationType(wishTo.getType());
		pushData.setTimeStamp(LocalDateTime.now());
		pushData.setNotificationRead('N');
		pushData.setNotifiedTo(wishTo.getName());
		
		pushDataRepository.save(pushData);
		
		PushNotificationReqBean req= new PushNotificationReqBean();
		req.setTo(data.getFcmToken());
		req.setContent_available(true);
		req.setPriority("high");
		req.setNotification(notification);
		req.setData(pushData);
		HttpEntity<PushNotificationReqBean> requestEntity = new HttpEntity<>(req, getPushNotificationRequestHeader("key="+genericConstants.getPushNotificationServerKey()));
		PushNotificationResponse respose = rnlicApiExchange.sendPushNotificationUrl(rnlicUrlConstants.getUrls().getPushNotification(), requestEntity);
		return respose.getSuccess();
	}
	
	private HttpHeaders getPushNotificationRequestHeader(String headerValue) {
		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		requestHeaders.setExpires(0);
		requestHeaders.setCacheControl("private, no-store, max-age=0");
		requestHeaders.set(GenericConstants.AUTHORIZATION, headerValue);
		return requestHeaders;
	}
	
	private String pushNotificationMessageGenerator(String wishFor)
	{
		String message = "";
		if(wishFor.equalsIgnoreCase("birthday")){
			message = messagesConstants.getPushHappyBirthdayMsg();
		}
		else{
			message = messagesConstants.getPushHappyAnniversaryMsg();
		}
		return message;
	}
	
	/**
	 * This method will send subscription List
	 * @param String sapcode
	 * @return SubscriptionRnlicResBean responseData
	 */
	public SubscriptionResponseList getSubsctiptionList(String sapcode) {
		SubscriptionRnlicResBean response = rnlicApiExchange.getSubscriptionListUrl(rnlicUrlConstants.getUrls().getSubscriptionListDetails(), sapcode);
		SubscriptionResponseList res = null;
		if (HrAppUtil.isNullOrEmpty(response)) {
			throw new RnlicServiceException();
		} else {
			if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& (response.getStatus().equalsIgnoreCase(GenericConstants.SUCCESS) || response.getStatus().equalsIgnoreCase(GenericConstants.SUCESS))) {
				res = rnlicDataTranslator.getSubscription(response);
				return res;
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILURE)) {
				throw new RnlicServiceException();
			} else if (!HrAppUtil.isNullOrEmpty(response.getStatus())
					&& response.getStatus().equalsIgnoreCase(GenericConstants.FAILED)) {
				throw new StateDetailsNotFoundException();
			} else {
				throw new RnlicServiceException();
			}
		}
	}

	/**
	 * This method will send MessageTemplae
	 * @param MessageTemplateRequest messageTemplateRequest
	 * @return SubscriptionRnlicResBean responseData
	 */
	public MessageTemplate getMessageTemplate(MessageTemplateRequest messageTemplateRequest) {
		MessageTemplate message = null;
		if(!HrAppUtil.isNullOrEmpty(messageTemplateRequest.getWishType()) && ("sms").equalsIgnoreCase(messageTemplateRequest.getWishType())) {
			SmsMessageTemplate req =new SmsMessageTemplate();
			if(("anniversary").equalsIgnoreCase(messageTemplateRequest.getWishFor()))
			{
				//Anniversary
				req.setApplicableFor("Anniversary");
			}
			else
			{
				req.setApplicableFor("Birthday");
			}
			req.setRequestFor("SMS");
			HttpEntity<SmsMessageTemplate> requestEntity = new HttpEntity<>(req, getRequestHeader());
			SmsTemplateRnlicResponse response = rnlicApiExchange.getSmsMessageTemplate(rnlicUrlConstants.getUrls().getBirthdayMessageTemplate(),requestEntity);
			message = rnlicDataTranslator.generateMessageTemplate(response,messageTemplateRequest.getWishFor());
		}
		else {
			if(("anniversary").equalsIgnoreCase(messageTemplateRequest.getWishFor()))
			{
				message =new MessageTemplate();
				message.setMessage(rnlicApiExchange.getBirtdayEmailMessageTemplate(rnlicUrlConstants.getUrls().getAnniversaryEmailTemplate()));
			}
			else
			{
				message =new MessageTemplate();
				message.setMessage(rnlicApiExchange.getBirtdayEmailMessageTemplate(rnlicUrlConstants.getUrls().getBithdayEmailTemplate()));
			}
		}
		return message;
	}
}
