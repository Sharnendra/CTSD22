package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class BadRequestException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public BadRequestException() {
		super(ErrorConstants.BAD_REQUEST_CODE,ErrorConstants.BAD_REQUEST,false,false);
	}
	public BadRequestException(String message) {
		super(ErrorConstants.BAD_REQUEST_CODE,message,false,false);
	}
}
