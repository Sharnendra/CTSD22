package com.rnlic.hrapp.bean.request;

public class OtpDetailsReqBean {

	private String mobile_number;
	private String message;
	public String getMobile_number() {
		return mobile_number;
	}
	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	
	
	
}
