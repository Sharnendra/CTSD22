package com.rnlic.hrapp.bean.request;

public class Branches {

	private String branchName;
	private String branchId;
	private String branchAddress;
	private String lattitude;
	private String longitude;
	private String allowedPerimeter;
	private String allowedCheckInTime;
	private String allowedCheckouttime;
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	public String getBranchAddress() {
		return branchAddress;
	}
	public void setBranchAddress(String branchAddress) {
		this.branchAddress = branchAddress;
	}
	public String getLattitude() {
		return lattitude;
	}
	public void setLattitude(String lattitude) {
		this.lattitude = lattitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getAllowedPerimeter() {
		return allowedPerimeter;
	}
	public void setAllowedPerimeter(String allowedPerimeter) {
		this.allowedPerimeter = allowedPerimeter;
	}
	public String getAllowedCheckInTime() {
		return allowedCheckInTime;
	}
	public void setAllowedCheckInTime(String allowedCheckInTime) {
		this.allowedCheckInTime = allowedCheckInTime;
	}
	public String getAllowedCheckouttime() {
		return allowedCheckouttime;
	}
	public void setAllowedCheckouttime(String allowedCheckouttime) {
		this.allowedCheckouttime = allowedCheckouttime;
	}
	
	
}
