package com.rnlic.hrapp.bean.api.request;

import com.rnlic.hrapp.bean.request.LinkedApplicationReq;

public class ApplicationConfigReqBean {

	private LinkedApplicationReq appConfig;
	private String comment;
	
	public LinkedApplicationReq getAppConfig() {
		return appConfig;
	}
	public void setAppConfig(LinkedApplicationReq linkedApplications) {
		this.appConfig = linkedApplications;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	@Override
	public String toString() {
		return "ApplicationConfigReqBean [appConfig=" + appConfig + ", comment=" + comment + "]";
	}
	
}