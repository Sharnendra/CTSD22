package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class NoSuchUserExists extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public NoSuchUserExists() {
		super(ErrorConstants.NO_SUCH_USER_EXIST_CODE,ErrorConstants.NO_SUCH_USER_EXIST_MESSAGE,false,false);
	}
	public NoSuchUserExists(String message) {
		super(ErrorConstants.NO_SUCH_USER_EXIST_CODE,message,false,false);
	}
}
