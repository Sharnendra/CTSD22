package com.rnlic.hrapp.bean.response;

public class PushDataResponse implements ResponseData{

	private Boolean isNotificationUpdated;

	public Boolean getIsNotificationUpdated() {
		return isNotificationUpdated;
	}

	public void setIsNotificationUpdated(Boolean isNotificationUpdated) {
		this.isNotificationUpdated = isNotificationUpdated;
	}
	
}
