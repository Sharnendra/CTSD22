package com.rnlic.hrapp.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.rnlic.hrapp.bean.request.MessageTemplateRequest;
import com.rnlic.hrapp.bean.request.UpdateNotificationRequest;
import com.rnlic.hrapp.bean.response.RestResponse;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.UrlConstants;
import com.rnlic.hrapp.exception.HrAppException;
import com.rnlic.hrapp.exception.UnhandledException;
import com.rnlic.hrapp.security.JwtDecriptor;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.PushNotificationService;
import com.rnlic.hrapp.util.HrAppUtil;

@RestController
public class PushNotificationEnablementController extends BaseController {

	private static final Logger log = LogManager.getLogger(PushNotificationEnablementController.class);
	
	@Autowired
	private JwtDecriptor jwtDecriptor;
	
	@Autowired
	private PushNotificationService pushNotificationService;
	
	@GetMapping("/Certificate")
	public String getCertificate() {
		return "Certificate installed";
	}
	
	@PostMapping(UrlConstants.GET_SUBSCRIPTION_LIST)
	public RestResponse getSubscriptionList(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"Subscription List");
		log.info(requestLog.toString()+ "== Subscription List :=====");
		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			setRequestLog(requestLog,response.getRequestId(),userDetailsBean.getSapCode(),null,userDetailsBean.getDeviceIdentifier(),"Subscription List");
			response.setData(pushNotificationService.getSubsctiptionList(userDetailsBean.getSapCode()));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== getSubscriptionList  HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== getSubscriptionList  UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;		
	}
	
	@PostMapping(UrlConstants.UPDATE_NOTIFICATION_DETAILS)
	public RestResponse updateNotificatonDetails(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken,
			@RequestBody UpdateNotificationRequest updateNotificationRequest) {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"updateNotificatonDetails");
		log.info(requestLog.toString()+ "== updateNotificatonDetails :=====");
		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			setRequestLog(requestLog,response.getRequestId(),userDetailsBean.getSapCode(),null,userDetailsBean.getDeviceIdentifier(),"updateNotificatonDetails");
			response.setData(pushNotificationService.updateNotificatonDetails(updateNotificationRequest));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== updateNotificatonDetails  HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== updateNotificatonDetails  UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;	
	}
	
	@PostMapping(UrlConstants.GET_MESSAGE_TEMPLATE)
	public RestResponse getMessageTemplate(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken,
			@RequestBody MessageTemplateRequest messageTemplateRequest) {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"getMessageTemplate");
		log.info(requestLog.toString()+ "== getMessageTemplate :=====");
		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			setRequestLog(requestLog,response.getRequestId(),userDetailsBean.getSapCode(),null,userDetailsBean.getDeviceIdentifier(),"getMessageTemplate");
			response.setData(pushNotificationService.getMessageTemplate(messageTemplateRequest));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== getMessageTemplate  HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== getMessageTemplate  UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;	
	}
}
