package com.rnlic.hrapp.bean.request;

public class UpdateNotificationRequest {

	private int notificationId;
	private char isRead;
	public int getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}
	public char getIsRead() {
		return isRead;
	}
	public void setIsRead(char isRead) {
		this.isRead = isRead;
	}
}
