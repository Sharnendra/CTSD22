package com.rnlic.hrapp.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rnlic.hrapp.bean.request.AttendanceReqBean;
import com.rnlic.hrapp.bean.response.ReporteeListDataRes;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.security.ValidateRegistry;
import com.rnlic.hrapp.util.RequestLogDeatils;

@Service
public class AttendanceDetailsService{

	/*
	 * This service is used to gather the details of Attendance
	 * for thge given person.
	 * 
	 * Developed - Java Team
	 * 
	 * */

	@Autowired
	private RnlicService rnlicService;
	
	@Autowired
	private RequestLogDeatils requestLog;
	
	private static final Logger log = LogManager.getLogger(AttendanceDetailsService.class);

	/**
	 * This method return Attendance details
	 * @param UserDetailsBean empReqBean
	 * @param AttendanceReqBean attendanceReqBean
	 * @return ResponseData AttendanceResBean
	 */
	//@ValidateRegistry
	public ResponseData getAttendanceDetails(UserDetailsBean empReqBean,AttendanceReqBean attendanceReqBean) 
	{
		//Call Rnlic service to get Monthly attendance details
		log.info(requestLog+ "== getAttendanceDetails AttendanceDetailsService call Rnlic Service:=====");
		return rnlicService.getAttendanceDtls(attendanceReqBean,empReqBean);
	}
	/**
	 * This method will call rnlic service to get ReporteeList
	 * @param UserDetailsBean userBean //it will be use for future purpose
	 * @param String sapCode
	 * @return ResponseData reporteeListDataRes 
	 */
	@ValidateRegistry
	public ResponseData getReporteeList(UserDetailsBean userBean, String sapCode) {
		log.info(requestLog+ "== getReporteeList AttendanceDetailsService call Rnlic Service:=====");
		ReporteeListDataRes reporteeListDataRes = new ReporteeListDataRes();
		reporteeListDataRes.setReporteeList(rnlicService.getListOfReportees(sapCode));
		log.info(requestLog+ "== getReporteeList AttendanceDetailsService Rnlic Service called:=====");
		return reporteeListDataRes;
	}
}
