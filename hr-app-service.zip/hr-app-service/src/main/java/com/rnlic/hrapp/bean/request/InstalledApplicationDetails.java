package com.rnlic.hrapp.bean.request;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class InstalledApplicationDetails {
	
	@JsonProperty(value = "applicationName")
	private String applicationName;
	@JsonProperty(value = "applicationDescription")
	private String applicationDescription;
	@JsonProperty(value = "applicationVersion")
	private String applicationVersion;
	@JsonProperty(value = "isInstalled")
	private boolean isInstalled;
	private Date statusUpdatedOn;
	public String getApplicationName() {
		return applicationName;
	}
	public boolean isInstalled() {
		return isInstalled;
	}
	public void setInstalled(boolean isInstalled) {
		this.isInstalled = isInstalled;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public String getApplicationDescription() {
		return applicationDescription;
	}
	public void setApplicationDescription(String applicationDescription) {
		this.applicationDescription = applicationDescription;
	}
	public String getApplicationVersion() {
		return applicationVersion;
	}
	public void setApplicationVersion(String applicationVersion) {
		this.applicationVersion = applicationVersion;
	}
	public Date getStatusUpdatedOn() {
		return statusUpdatedOn;
	}
	public void setStatusUpdatedOn(Date statusUpdatedOn) {
		this.statusUpdatedOn = statusUpdatedOn;
	}
	@Override
	public String toString() {
		return "InstalledApplicationDetails [applicationName=" + applicationName + ", applicationDescription="
				+ applicationDescription + ", applicationVersion=" + applicationVersion + ", isInstalled=" + isInstalled
				+ ", statusUpdatedOn=" + statusUpdatedOn + "]";
	}

}
