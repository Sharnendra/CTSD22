package com.rnlic.hrapp.exception;

public class ExecutionException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExecutionException(String code, String message, boolean isWarning) {
		super(code, message, isWarning,false);
	}

}
