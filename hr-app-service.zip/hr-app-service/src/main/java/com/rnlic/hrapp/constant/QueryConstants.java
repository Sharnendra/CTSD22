package com.rnlic.hrapp.constant;

public class QueryConstants {

	public static final String OTPREPO_FIND_BY_USER_ID="SELECT o FROM OtpMasterModel o WHERE o.mobileNumber =:mobile_number and o.otpValue =:otp_value and validUpto > CURRENT_TIMESTAMP";
	public static final String OTPREPO_GET_OTP_DETAILS="FROM OtpMasterModel WHERE sapCode =:sap_code and mobileNumber =:mobile_number and action =:action and deviceIdentifier =:device_identifier and validUpto > :currentTime and isVerified = '0'";
	public static final String OTPREPO_UPDATE_RESEND_COUNT="UPDATE OtpMasterModel o SET o.resendCount = :resend_count WHERE o.sapCode =:sap_code and o.mobileNumber =:mobile_number and o.action =:action and o.deviceIdentifier =:device_identifier and validUpto > CURRENT_TIMESTAMP";
	public static final String OTPREPO_DELETE_EXPIRED_OTP_RECORD="Delete from OtpMasterModel WHERE validUpto < CURRENT_TIMESTAMP";
	public static final String LINKEDAPPREPO_GET_LINKED_APP_CONFIG="FROM LinkedAppConfigrationModel WHERE isActive='1'";
	public static final String LINKEDAPPREPO_UPDATE_LINKED_APP_CONFIG_ENTRIES="UPDATE LinkedAppConfigrationModel SET isActive='0'";
	public static final String DEVICEREGISREPO_GET_DEVICE_REGIS_DETAILS="FROM DeviceRegistrationModel WHERE deviceIdentifier =:deviceIdentifier OR sapCode =:sapCode OR mobileNumber =:mobileNumber";
	public static final String DEVICEREGISREPO_UPDATE_MOBILE_NO_FOR_CANDIDATE="UPDATE DeviceRegistrationModel  SET mobileNumber = :mobileNumber WHERE panNumber =:panNumber and deviceIdentifier =:deviceIdentifier";
	public static final String DEVICEREGISREPO_UPDATE_MOBILE_NO_FOR_EMPLOYEE="UPDATE DeviceRegistrationModel  SET mobileNumber = :mobileNumber WHERE sapCode =:sapCode and deviceIdentifier =:deviceIdentifier";
	public static final String DEVICEREGISREPO_UPDATE_SAPCODE="UPDATE DeviceRegistrationModel  SET sapCode = :sapCode WHERE mobileNumber =:mobileNumber and deviceIdentifier =:deviceIdentifier and panNumber =:panNumber";
	public static final String DEVICEREGISREPO_DELETE_BY_PANNUMBER="Delete from DeviceRegistrationModel WHERE panNumber =:panNumber and mobileNumber =:mobileNumber";
	public static final String DEVICEREGISREPO_DELETE_BY_SAPCODE="Delete from DeviceRegistrationModel WHERE panNumber =:panNumber and mobileNumber =:mobileNumber and sapCode = :sapCode";
	public static final String LINKEDAPPREPO_GET_LINKED_APP_CONFIG_VERSION = "SELECT version from hrapp_linked_application_config where is_active='1' ";
	public static final String INSTALLEDAPPREPO_DELETE_LINKED_APP_RECORD="Delete from InstalledApplicationModel WHERE requestId=:requestId";
	public static final String REQUESTID_FOR_REGISTERED_DEVICE = "SELECT request_id from hrapp_device_registration where device_identifier =:deviceIdentifier ";
	public static final String REQUEST_FOR_VERSION_SEQUENCE = "SELECT next value for version_sequence";
	public static final String OTPREPO_GET_OTP = "SELECT code from hrapp_otp WHERE sap_code =:sapCode or mobile_number =:mobileNumber and valid_upto > CURRENT_TIMESTAMP and isverified = '0'";
}
