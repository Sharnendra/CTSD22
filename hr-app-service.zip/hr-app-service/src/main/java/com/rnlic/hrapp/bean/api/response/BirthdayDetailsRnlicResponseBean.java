package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BirthdayDetailsRnlicResponseBean implements RnlicResponseData{
	
	@JsonProperty(value = "EmployeeCode") 
	private String  sapCode; 
	@JsonProperty(value = "EmployeeName") 
	private String  name; 
	@JsonProperty(value = "DOB") 
	private String  dob; 
	@JsonProperty(value = "DOJ") 
	private String  doj; 
	@JsonProperty(value = "MobileNumber") 
	private String  mobileNumber;
	@JsonProperty(value = "Email") 
	private String  email; 
	@JsonProperty(value = "ManagerSapCode") 
	private String  managerSapCode;
	@JsonProperty(value = "ManagerName") 
	private String  managerName;
	@JsonProperty(value = "Channel") 
	private String  channel;
	@JsonProperty(value = "ZoneCode") 
	private String  zoneCode;
	@JsonProperty(value = "ZoneName") 
	private String  zoneName;
	@JsonProperty(value = "RegionCode") 
	private String  regionCode;
	@JsonProperty(value = "RegionName") 
	private String  regionName;
	@JsonProperty(value = "PAlocation") 
	private String paLocation;
	@JsonProperty(value = "Designation") 
	private String designation;
	
	public String getSapCode() {
		return sapCode;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getManagerSapCode() {
		return managerSapCode;
	}
	public void setManagerSapCode(String managerSapCode) {
		this.managerSapCode = managerSapCode;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getZoneCode() {
		return zoneCode;
	}
	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}
	public String getZoneName() {
		return zoneName;
	}
	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}
	public String getRegionCode() {
		return regionCode;
	}
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	public String getRegionName() {
		return regionName;
	}
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public String getPaLocation() {
		return paLocation;
	}
	public void setPaLocation(String paLocation) {
		this.paLocation = paLocation;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
}
