package com.rnlic.hrapp.bean.api.request;

public class ChangePasswordRnlicReqBean {

	private String SAP_ID;
	private String OTP;
	private String NEW_PSWD;
	public String getSAP_ID() {
		return SAP_ID;
	}
	public void setSAP_ID(String sAP_ID) {
		SAP_ID = sAP_ID;
	}
	public String getOTP() {
		return OTP;
	}
	public void setOTP(String oTP) {
		OTP = oTP;
	}
	public String getNEW_PSWD() {
		return NEW_PSWD;
	}
	public void setNEW_PSWD(String nEW_PSWD) {
		NEW_PSWD = nEW_PSWD;
	}
	
}
