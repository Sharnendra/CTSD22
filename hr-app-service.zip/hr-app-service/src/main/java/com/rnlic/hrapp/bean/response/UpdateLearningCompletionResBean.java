package com.rnlic.hrapp.bean.response;

public class UpdateLearningCompletionResBean implements ResponseData{

	private String learningId;
	private Boolean hasUpdated;
	public String getLearningId() {
		return learningId;
	}
	public void setLearningId(String learningId) {
		this.learningId = learningId;
	}
	public Boolean getHasUpdated() {
		return hasUpdated;
	}
	public void setHasUpdated(Boolean hasUpdated) {
		this.hasUpdated = hasUpdated;
	}
	
}
