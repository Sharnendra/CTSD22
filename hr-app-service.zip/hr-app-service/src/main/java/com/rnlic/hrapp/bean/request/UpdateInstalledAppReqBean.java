package com.rnlic.hrapp.bean.request;

import java.util.ArrayList;
import java.util.Collection;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateInstalledAppReqBean {
	@JsonProperty(value = "installedLinkedApps") 
	Collection<InstalledApplicationDetails> installedLinkedApps = new ArrayList<>();
	public Collection<InstalledApplicationDetails> getInstalledLinkedApps() {
		return installedLinkedApps;
	}
	public void setInstalledLinkedApps(Collection<InstalledApplicationDetails> installedLinkedApps) {
		this.installedLinkedApps = installedLinkedApps;
	}

}
