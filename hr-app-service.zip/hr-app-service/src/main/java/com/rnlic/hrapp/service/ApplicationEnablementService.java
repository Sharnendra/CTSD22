package com.rnlic.hrapp.service;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rnlic.hrapp.bean.api.request.ApplicationConfigReqBean;
import com.rnlic.hrapp.bean.request.LinkedApplicationReq;
import com.rnlic.hrapp.bean.response.LinkedAppConfigRes;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.entity.LinkedAppConfigrationModel;
import com.rnlic.hrapp.repository.LinkedAppConfigrationRepository;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestLogDeatils;

@Service
public class ApplicationEnablementService {
	
	@Autowired
	private LinkedAppConfigrationRepository linkedAppConfigrationRepository;
	
	@Autowired
	private RequestLogDeatils requestLog;
	
	private static final Logger log = LogManager.getLogger(ApplicationEnablementService.class);
	/**
	 * This method will provide the linked application configuration
	 * 
	 * @return LinkedAppConfigRes linkedAppConfigRes
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	public LinkedAppConfigRes getLinkedAppConfiguration() throws IOException 
	{
		log.info(requestLog+ "== getLinkedAppConfiguration ApplicationEnablement Service call Database:=====");
		LinkedAppConfigrationModel dbResult= linkedAppConfigrationRepository.getLinkedAppConfigration();
		LinkedAppConfigRes linkedAppConfigRes=new LinkedAppConfigRes();
		ObjectMapper mapper=new ObjectMapper();
		linkedAppConfigRes.setApplicationConfiguration(mapper.readValue(dbResult.getJsonConfig(), LinkedApplicationReq.class));
		return linkedAppConfigRes;
	}
	
	/**
	 * This method will update and provide the linked application configuration
	 * 
	 * @param AuthReqBean authReqBean
	 * @return ResponseData authRes
	 * @throws RestClientException
	 * @throws IOException
	 */
	public LinkedAppConfigRes updateLinkedAppConfiguration(ApplicationConfigReqBean appconfig) throws JsonProcessingException 
	{
		linkedAppConfigrationRepository.updateLinkedAppConfigrationEntries();
		log.info(requestLog+ "== updateLinkedAppConfiguration ApplicationEnablement Service previous configurations are made in active:=====");
		String version=linkedAppConfigrationRepository.getSequence();
		
		LinkedAppConfigrationModel updatedValue=new LinkedAppConfigrationModel();
		updatedValue.setIsActive('1');
		ObjectMapper mapper=new ObjectMapper();
		updatedValue.setApplicationDescription(appconfig.getAppConfig().getDescription());
		updatedValue.setVersion("V"+version);
		appconfig.getAppConfig().setVersion("V"+version);
		updatedValue.setJsonConfig(mapper.writeValueAsString(appconfig.getAppConfig()));
		updatedValue.setComment(appconfig.getComment());
		linkedAppConfigrationRepository.save(updatedValue);
		
		log.info(requestLog+ "== updateLinkedAppConfiguration ApplicationEnablement Service new configurations are now updated and is active:=====");
		appconfig.getAppConfig().setVersion("V"+version);
		LinkedAppConfigRes linkedAppConfigRes=new LinkedAppConfigRes();
		linkedAppConfigRes.setApplicationConfiguration(appconfig.getAppConfig());
		return linkedAppConfigRes;
	}
	
	public String getLinkedAppConfigurationVersion() 
	{
		log.info(requestLog+ "== getLinkedAppConfigurationVersion ApplicationEnablement Service call Database:=====");
		List<Object[]> dbResult= linkedAppConfigrationRepository.getLinkedAppConfigrationVersion();
		return HrAppUtil.isNotEmpty(dbResult) && !dbResult.isEmpty() ?dbResult.get(0)[0].toString():GenericConstants.EMPTY_STRING;
	}
}
