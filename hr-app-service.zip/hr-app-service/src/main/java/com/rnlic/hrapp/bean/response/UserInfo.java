package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

public class UserInfo {
	
	public String firstName;
	public String lastName;
	public String level;
	private List<String> roles=new ArrayList<>();
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public List<String> getRoles() {
		return roles;
	}
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	
}
