package com.rnlic.hrapp.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rnlic.hrapp.bean.request.EmployeeCheckInCheckOutReqBean;
import com.rnlic.hrapp.bean.response.EmployeeCheckInCheckOutResBean;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;
import com.rnlic.hrapp.exception.CheckInCheckOutException;
import com.rnlic.hrapp.repository.DeviceRegistrationRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.security.ValidateRegistry;
import com.rnlic.hrapp.util.RequestLogDeatils;

@SuppressWarnings("unused")
@Service
public class CheckInCheckOutService {

	private static final Logger log = LogManager.getLogger(CheckInCheckOutService.class);
	
	@Autowired
	private RnlicService rnlicService;
	
	@Autowired
	private AuthenticationAuthorizationService authService;
	
	@Autowired
	private DeviceRegistrationRepository deviceRepo;
	
	@Autowired
	private MessagesConstants messagesConstants;
	
	@Autowired
	private RequestLogDeatils requestLog;

	@ValidateRegistry
	public ResponseData employeeCheckInCheckOut(UserDetailsBean empReqBean,
			EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean){
		EmployeeCheckInCheckOutResBean employeeCheckInCheckOutResBean = new EmployeeCheckInCheckOutResBean();
		
		boolean isDeviceRegUpdatedWithRnlic=false;
		log.info(requestLog+ "== employeeCheckInCheckOut service start :=====");
		DeviceRegistrationModel deviceRegDetails=deviceRepo.findByDeviceIdentifier(empReqBean.getDeviceIdentifier());
		if(deviceRegDetails!=null) {
			if(deviceRegDetails.getIsSync())
			{
				log.info(requestLog+ "== employeeCheckInCheckOut deviceRegDetails is sync :=====");
				employeeCheckInCheckOutResBean=rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
			}
			else
			{
				log.info(requestLog+ "== employeeCheckInCheckOut deviceRegDetails is not sync :=====");
				isDeviceRegUpdatedWithRnlic = rnlicService.updateDeviceRegInfo(empReqBean.getDeviceIdentifier(),empReqBean.getMobileNumber(),empReqBean.getSapCode(),empReqBean.getFcmToken());
				if(isDeviceRegUpdatedWithRnlic) {
					deviceRegDetails.setIsSync(true);
					deviceRepo.save(deviceRegDetails);
					employeeCheckInCheckOutResBean=rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
				}else {
					log.info(requestLog+ "== employeeCheckInCheckOut Exception occured :=====");
					throw new CheckInCheckOutException(messagesConstants.getDeviceNotSync());
				}
			}
		}
		else
		{
			throw new CheckInCheckOutException(messagesConstants.getDeviceNotRegistered());
		}
		return employeeCheckInCheckOutResBean;
	}

}