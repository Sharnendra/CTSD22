package com.rnlic.hrapp.service;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URI;

import javax.mail.MessagingException;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.rnlic.hrapp.bean.api.request.AttendanceDetailsRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.AuthDetailsRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.BirthdayListRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.CandidateDetailsRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.ChangePasswordRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.CheckInReqBean;
import com.rnlic.hrapp.bean.api.request.CheckOutReqBean;
import com.rnlic.hrapp.bean.api.request.DeviceInfoRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.EmpolyeeDetailsRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.LearningStatusUpdateRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.LocateBranchRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.SendOtpRnlicReqBean;
import com.rnlic.hrapp.bean.api.request.SmsMessageTemplate;
import com.rnlic.hrapp.bean.api.request.WishEmployeeRnlicReqBean;
import com.rnlic.hrapp.bean.api.response.AnniversaryListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.BirthdayListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.BirthdaySmsResBean;
import com.rnlic.hrapp.bean.api.response.CandidateRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.ChangePasswordRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.CheckInCheckOutRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.DeviceRegInfoResponseBean;
import com.rnlic.hrapp.bean.api.response.EmployeeRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.LearningStatusUpdateResponseBean;
import com.rnlic.hrapp.bean.api.response.MandatoryLearningRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.MonthlyAttendanceDetailsRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.NoticesRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.ReporteeListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.RnlicAuthRes;
import com.rnlic.hrapp.bean.api.response.RnlicBranchDetailsListResponseBean;
import com.rnlic.hrapp.bean.api.response.SendOtpRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.SmsTemplateRnlicResponse;
import com.rnlic.hrapp.bean.api.response.StateCityMasterRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.SubscriptionRnlicResBean;
import com.rnlic.hrapp.bean.api.response.TroubleWithLoginRnlicResponseBean;
import com.rnlic.hrapp.bean.request.PushNotificationReqBean;
import com.rnlic.hrapp.bean.response.PushNotificationResponse;
import com.rnlic.hrapp.configuration.MailerConfig;
import com.rnlic.hrapp.constant.GenericConstants;

@Component
public class RnlicApiExchange {
	
	@Autowired
	private MailerConfig mailerConfig;

	public CandidateRnlicResponseBean getCandidateDtlsFromRnlicUrl(String url, HttpEntity<CandidateDetailsRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity,CandidateRnlicResponseBean.class);
	}
	
	public EmployeeRnlicResponseBean getEmpDetailsFromRnlicUrl(String url, HttpEntity<EmpolyeeDetailsRnlicReqBean> requestEntity)
	{
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity,EmployeeRnlicResponseBean.class);
	}
	
	public RnlicAuthRes getEmployeeAuthenticationUrl(String url, HttpEntity<AuthDetailsRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url ,requestEntity, RnlicAuthRes.class);
	}
	
	public RnlicAuthRes getCandidateAuthenticationUrl(String url, HttpEntity<AuthDetailsRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity, RnlicAuthRes.class);
	}
	
	public SendOtpRnlicResponseBean sendOtpMobileUrl (String url, HttpEntity<SendOtpRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity, SendOtpRnlicResponseBean.class);
	}
	
	public CheckInCheckOutRnlicResponseBean performCheckInUrl(String url, HttpEntity<CheckInReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity,	CheckInCheckOutRnlicResponseBean.class);
	}
	
	public CheckInCheckOutRnlicResponseBean performCheckOutUrl(String url, HttpEntity<CheckOutReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity,	CheckInCheckOutRnlicResponseBean.class);
	}
	
	public BirthdayListRnlicResponseBean performGetTodayBirthdayUrl (String url, String date) {
		return GenericConstants.REST_TEMPLATE.getForObject(url, BirthdayListRnlicResponseBean.class, date);
	}
	
	public AnniversaryListRnlicResponseBean performGetTodayAnniversaryUrl (String url, String date) {
		return GenericConstants.REST_TEMPLATE.getForObject(url, AnniversaryListRnlicResponseBean.class,	date);
	}
	
	public ReporteeListRnlicResponseBean performGetListOfReporteesUrl (String url, String sapCode) {
		return GenericConstants.REST_TEMPLATE.getForObject(url, ReporteeListRnlicResponseBean.class, sapCode);
	}
	
	public RnlicAuthRes performSendBirthdayEmailUrl(String url, HttpEntity<WishEmployeeRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity, RnlicAuthRes.class);
	}
	
	public RnlicAuthRes performSendAnniversaryEmailUrl(String url, HttpEntity<WishEmployeeRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity, RnlicAuthRes.class);
	}
	
	public BirthdaySmsResBean performSendBirthdaySmsUrl (String url, HttpEntity<WishEmployeeRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity, BirthdaySmsResBean.class);
	}
	
	public LearningStatusUpdateResponseBean updateLearningCompletionUrl (String url, HttpEntity<LearningStatusUpdateRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url ,requestEntity, LearningStatusUpdateResponseBean.class);
	}
	
	public BirthdayListRnlicResponseBean searchBirthdayUrl(String url, HttpEntity<BirthdayListRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity, BirthdayListRnlicResponseBean.class);
	}
	
	public StateCityMasterRnlicResponseBean getStateCityMasterUrl (String url) {
		return GenericConstants.REST_TEMPLATE.getForObject(url, StateCityMasterRnlicResponseBean.class);
	}
	
	public RnlicBranchDetailsListResponseBean getBranchDetailsUrl(String url, HttpEntity<LocateBranchRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity , RnlicBranchDetailsListResponseBean.class);
	}
	
	public DeviceRegInfoResponseBean updateDeviceRegInfoUrl (String url, HttpEntity<DeviceInfoRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url ,requestEntity, DeviceRegInfoResponseBean.class);
	}
	
	public MonthlyAttendanceDetailsRnlicResponseBean getAttendanceDtlsUrl (String url, HttpEntity<AttendanceDetailsRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url,requestEntity, MonthlyAttendanceDetailsRnlicResponseBean.class);
	}
	
	public MandatoryLearningRnlicResponseBean getMandatoryLearningUrl (String url) {
		return GenericConstants.REST_TEMPLATE.getForObject(url, MandatoryLearningRnlicResponseBean.class);
	}
	
	public String getMandatoryLearningStatusUrl(String url, String sapcode) {
		return GenericConstants.REST_TEMPLATE.getForObject(url, String.class,sapcode);
	}
	
	public TroubleWithLoginRnlicResponseBean getResponseForTroubleInLoginUrl (String url) {
		return GenericConstants.REST_TEMPLATE.getForObject(url, TroubleWithLoginRnlicResponseBean.class);
	} 
	
	public SendOtpRnlicResponseBean sendMessagesViaSMSUrl (String url, HttpEntity<SendOtpRnlicReqBean> requestEntity) {
		return GenericConstants.REST_TEMPLATE.postForObject(url, requestEntity, SendOtpRnlicResponseBean.class);
	}

	public ChangePasswordRnlicResponseBean changePasswordRequest(String url,HttpEntity<ChangePasswordRnlicReqBean> requestEntity) {
		RestTemplate rest = GenericConstants.REST_TEMPLATE;
		SimpleClientHttpRequestFactory clientHttpReq = new SimpleClientHttpRequestFactory();
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(mailerConfig.getProxyIp(), Integer.valueOf(mailerConfig.getPoxyPort())));
		clientHttpReq.setProxy(proxy);
		rest.setRequestFactory(clientHttpReq);
		return rest.postForObject(url, requestEntity, ChangePasswordRnlicResponseBean.class);
	}

	public void sendMailToUser(MimeMessage msg) throws MessagingException {
		Transport.send(msg); 
	}

	public NoticesRnlicResponseBean getNotices(String url,String sapCode) {
		URI targetUrl= UriComponentsBuilder.fromUriString(url)  
			    .queryParam("SapCode", sapCode)                               
			    .build()                                                 
			    .encode()                                               
			    .toUri();    
		return GenericConstants.REST_TEMPLATE.getForObject(targetUrl, NoticesRnlicResponseBean.class);
	}
	
	public PushNotificationResponse sendPushNotificationUrl(String url,HttpEntity<PushNotificationReqBean> requestEntity) {
		RestTemplate rest = GenericConstants.REST_TEMPLATE;
		SimpleClientHttpRequestFactory clientHttpReq = new SimpleClientHttpRequestFactory();
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(mailerConfig.getProxyIp(), Integer.valueOf(mailerConfig.getPoxyPort())));
		clientHttpReq.setProxy(proxy);
		rest.setRequestFactory(clientHttpReq);
		return rest.postForObject(url, requestEntity, PushNotificationResponse.class);
	}
	
	public SubscriptionRnlicResBean getSubscriptionListUrl(String url, String sapcode) {
		return GenericConstants.REST_TEMPLATE.getForObject(url, SubscriptionRnlicResBean.class,sapcode);
	}

	public SmsTemplateRnlicResponse getSmsMessageTemplate(String birthdayMessageTemplate,
			HttpEntity<SmsMessageTemplate> requestEntity) {
		System.err.println(GenericConstants.REST_TEMPLATE.postForObject(birthdayMessageTemplate,requestEntity, String.class));
		return GenericConstants.REST_TEMPLATE.postForObject(birthdayMessageTemplate,requestEntity, SmsTemplateRnlicResponse.class);
	}

	public String getBirtdayEmailMessageTemplate(String url) {
		return GenericConstants.REST_TEMPLATE.getForObject(url, String.class);
	}
}
