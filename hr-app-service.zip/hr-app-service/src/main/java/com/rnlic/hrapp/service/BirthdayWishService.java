package com.rnlic.hrapp.service;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rnlic.hrapp.bean.api.response.BirthdaySmsResBean;
import com.rnlic.hrapp.bean.api.response.RnlicAuthRes;
import com.rnlic.hrapp.bean.request.BirthdayReqBean;
import com.rnlic.hrapp.bean.request.WishEmpReqBean;
import com.rnlic.hrapp.bean.request.WishesReq;
import com.rnlic.hrapp.bean.response.AnniversaryResBean;
import com.rnlic.hrapp.bean.response.BirthdayResBean;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.bean.response.WishEmpResBean;
import com.rnlic.hrapp.bean.response.WishesRes;
import com.rnlic.hrapp.constant.ErrorConstants;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;
import com.rnlic.hrapp.exception.CommunicationException;
import com.rnlic.hrapp.repository.DeviceRegistrationRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.security.ValidateRegistry;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestLogDeatils;
@Service
public class BirthdayWishService {

	private static final Logger log = LogManager.getLogger(BirthdayWishService.class);
	
	@SuppressWarnings("unused")
	private UserDetailsBean empReqBean;
	private String responseStatus="";
	private int indexCount=0;
	private boolean check;

	@Autowired
	private RnlicService rnlicService;
	
	@Autowired
	private MessagesConstants messagesConstants;
	
	@Autowired
	private DeviceRegistrationRepository deviceRepo;
	
	@Autowired
	private RequestLogDeatils requestLog;

	/**
	 * This method call RNLIC service and get BirthdayList
	 * 
	 * @param UserDetailsBean userDetailsBean 
	 * @return ResponseData birthdaylist
	 */
	@ValidateRegistry
	public ResponseData getBirthday(UserDetailsBean userDetailsBean) {

		//call reliance service
		log.info(requestLog+ "== getBirthday Service call :=====");
		return rnlicService.getTodayBirthday();

	}

	/**
	 * This method call RNLIC service and get Reportee BirthdayList 
	 * @param UserDetailsBean userDetailsBean 
	 * @return ResponseData birthdaylist
	 */
	@ValidateRegistry
	public ResponseData getReporteeBirthday(UserDetailsBean userDetailsBean) {

		//call reliance service
		log.info(requestLog+ "== getReporteeBirthday Service call :=====");
		BirthdayResBean reporteebirthdayList = (BirthdayResBean) rnlicService.getTodayBirthday();

		return new BirthdayResBean(reporteebirthdayList.getBirthday().stream()
				.filter(t ->t.getManagerSapcode().equalsIgnoreCase(userDetailsBean.getSapCode()))
				.collect(Collectors.toList()));
	}

	/**
	 * This method call RNLIC service and get AnniversaryList
	 * 
	 * @param UserDetailsBean userDetailsBean 
	 * @return ResponseData AnniversaryList
	 */
	@ValidateRegistry
	public ResponseData getAnniversary(UserDetailsBean userDetailsBean) {

		//call reliance service since it is not working provinding dummy data
		log.info(requestLog+ "== getAnniversary Service call :=====");
		return rnlicService.getTodayAnniversary();

	}

	@ValidateRegistry
	public ResponseData wishEmployee(UserDetailsBean userDetailsBean, WishEmpReqBean wishEmpReqBean) {
		log.info(requestLog+ "== wishEmployee Service call :=====");
		responseStatus="";
		indexCount=0;
		check=false;
		Map<Character,RnlicAuthRes> rnlicAuthRes=new LinkedHashMap<>();
		RnlicAuthRes data=null;
		char[] communicationChannel =wishEmpReqBean.getWishTo().getCommunicationChannel().toCharArray();
		if (communicationChannel.length==0) {
			log.info(requestLog+ "== wishEmployee no communicationChannel mentioned :=====");
			throw new CommunicationException();
		}
		else if (communicationChannel.length!=1) {
			for(char type:communicationChannel) 
			{
				log.info(requestLog+ "== wishEmployee waysToSendBirthdaySMS start :=====");
				data=waysToSendBirthdaySMS(String.valueOf(type), wishEmpReqBean.getWishTo(),userDetailsBean);
				if(data!=null) {
					rnlicAuthRes.put(type, data);
				}
			}
		} else {
			log.info(requestLog+ "== wishEmployee waysToSendBirthdaySMS start :=====");
			data=waysToSendBirthdaySMS(String.valueOf(communicationChannel[0]), wishEmpReqBean.getWishTo(),userDetailsBean);
			if(data!=null) {
				rnlicAuthRes.put(communicationChannel[0], data);
			}
		}		
		
		rnlicAuthRes.entrySet().stream().forEach(value->{
			if(!value.getValue().getStatus().equalsIgnoreCase(GenericConstants.SUCCESS))
			{
				if(indexCount>0)
				{
					log.info(requestLog+ "== wishEmployee check true :=====");
					check=true;
				}
				if (responseStatus.equalsIgnoreCase("")) {
					responseStatus=GenericConstants.wishServiceMapError.get(value.getKey());
					indexCount++;
				} else {
					responseStatus=responseStatus+GenericConstants.COMMA+GenericConstants.wishServiceMapError.get(value.getKey());
					indexCount++;
				}
			}
			else
			{
				if(indexCount>0)
				{
					log.info(requestLog+ "== wishEmployee check true :=====");
					check=true;
				}
				indexCount++;
			}
		});
		
		rnlicAuthRes.entrySet().stream().forEach(value->{			
			if(value.getValue().getStatus().equalsIgnoreCase(GenericConstants.FAILED))
			{
				log.info(requestLog+ "== wishEmployee CommunicationException :=====");
				CommunicationException comExp=new CommunicationException(check==true?messagesConstants.getMessageSendPartially()+responseStatus+GenericConstants.SPACE+GenericConstants.FAILED:responseStatus+GenericConstants.SPACE+GenericConstants.FAILED);
				comExp.setWarning(true);
				throw comExp;
			}
		});
		
		WishesRes wishesRes=new WishesRes();
		WishEmpResBean wishEmpResBean=new WishEmpResBean();
		wishesRes.setCommunicationChannel(wishEmpReqBean.getWishTo().getCommunicationChannel());
		wishesRes.setName(wishEmpReqBean.getWishTo().getName());
		wishesRes.setSapCode(wishEmpReqBean.getWishTo().getSapCode());
		wishesRes.setType(wishEmpReqBean.getWishTo().getType());
		wishesRes.setStatus(messagesConstants.getMessageSendSuccessfully());
		wishEmpResBean.setWishTo(wishesRes);
		return wishEmpResBean;
	}

	@ValidateRegistry
	public ResponseData searchBirthdayAnniversary(UserDetailsBean userDetailsBean, BirthdayReqBean birthdayReqBean) {
		log.info(requestLog+ "== searchBirthdayAnniversary Service call :=====");
		return rnlicService.searchBirthday(birthdayReqBean);
	}

	@ValidateRegistry
	private RnlicAuthRes waysToSendBirthdaySMS(String serviceType, WishesReq wishTo,UserDetailsBean userDetailsBean) {
		RnlicAuthRes rnlicAuthRes=null;
		int successCount = 0;
		BirthdaySmsResBean birthdaySmsResBean= null;
		if(!serviceType.equalsIgnoreCase(" ")) {
			if (serviceType.equalsIgnoreCase(String.valueOf(GenericConstants.SERVICE_TYPE_S))) {
				rnlicAuthRes=new RnlicAuthRes();
				if(wishTo.getType().equalsIgnoreCase("birthday")){
					birthdaySmsResBean= rnlicService.sendBirthdaySms(wishTo,userDetailsBean.getSapCode());
				}
				else{
					birthdaySmsResBean= rnlicService.sendAnniversarySms(wishTo,userDetailsBean.getSapCode());
				}
				rnlicAuthRes.setStatus(birthdaySmsResBean.getStatus());
				rnlicAuthRes.setMessage(birthdaySmsResBean.getMessage());
			} else if (serviceType.equalsIgnoreCase(String.valueOf(GenericConstants.SERVICE_TYPE_E))) {
				if(wishTo.getType().equalsIgnoreCase("birthday")){
					rnlicAuthRes= rnlicService.sendBirthdayEmail(wishTo,userDetailsBean.getSapCode());
				}
				else{
					rnlicAuthRes= rnlicService.sendAnniversaryEmail(wishTo,userDetailsBean.getSapCode());
				}
			} else if (serviceType.equalsIgnoreCase(String.valueOf(GenericConstants.SERVICE_TYPE_P))) {
				DeviceRegistrationModel data = deviceRepo.findBySapCode(wishTo.getSapCode());
				if(!HrAppUtil.isNullOrEmpty(data)) {
					successCount= rnlicService.sendPushNotification(wishTo,data,userDetailsBean);
					if(successCount!=0)
					{
						rnlicAuthRes=new RnlicAuthRes();
						rnlicAuthRes.setStatus(GenericConstants.SUCCESS);
						rnlicAuthRes.setMessage(ErrorConstants.NOTIFICATION_SUCESS_MESSAGE);
					}else {
						rnlicAuthRes=new RnlicAuthRes();
						rnlicAuthRes.setStatus(GenericConstants.FAILED);
						rnlicAuthRes.setMessage(ErrorConstants.NOTIFICATION_FAILED_MESSAGE);
					}
				} else {
					rnlicAuthRes=new RnlicAuthRes();
					rnlicAuthRes.setStatus(GenericConstants.FAILED);
					rnlicAuthRes.setMessage(ErrorConstants.NOTIFICATION_FAILED_MESSAGE);
				}
			} else {
				rnlicAuthRes=new RnlicAuthRes();
				rnlicAuthRes.setStatus(GenericConstants.FAILED);
				rnlicAuthRes.setMessage(ErrorConstants.COMMUNICATION_MESSAGE);
			}
		}
		return rnlicAuthRes;
	}

	@ValidateRegistry
	public ResponseData getReporteeAnniversary(UserDetailsBean userDetailsBean) {
		log.info(requestLog+ "== getReporteeAnniversary Service call :=====");
		AnniversaryResBean reporteeAnniversaryList = (AnniversaryResBean) rnlicService.getTodayAnniversary();
		
		return new AnniversaryResBean(reporteeAnniversaryList.getAnniversary().stream()
				.filter(t ->t.getManagerSapcode().equalsIgnoreCase(userDetailsBean.getSapCode()))
				.collect(Collectors.toList()));
	}

}
