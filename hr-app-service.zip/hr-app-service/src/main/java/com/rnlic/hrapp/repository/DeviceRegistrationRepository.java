package com.rnlic.hrapp.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.rnlic.hrapp.constant.QueryConstants;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;

@Repository
public interface DeviceRegistrationRepository extends JpaRepository<DeviceRegistrationModel, Long>{

	DeviceRegistrationModel findBySapCode(String sapCode);
	
	@Query(QueryConstants.DEVICEREGISREPO_GET_DEVICE_REGIS_DETAILS)
	List<DeviceRegistrationModel> getDeviceRegistrationDetails(@Param("deviceIdentifier") String deviceIdentifier,
			@Param("sapCode") String sapCode, @Param("mobileNumber") String mobileNumber);

	@Transactional
	@Query(QueryConstants.DEVICEREGISREPO_UPDATE_MOBILE_NO_FOR_CANDIDATE)
	int updateMobileNoForCandidate(@Param("deviceIdentifier") String deviceIdentifier, @Param("panNumber") String panNumber, @Param("mobileNumber") String mobileNumber);

	@Transactional
	@Query(QueryConstants.DEVICEREGISREPO_UPDATE_MOBILE_NO_FOR_EMPLOYEE)
	int updateMobileNoForEmployee(@Param("deviceIdentifier") String deviceIdentifier,@Param("sapCode") String sapCode,@Param("mobileNumber") String mobileNumber);

	@Transactional
	@Query(QueryConstants.DEVICEREGISREPO_UPDATE_SAPCODE)
	int updateSapCode(@Param("deviceIdentifier") String deviceIdentifier,@Param("sapCode") String sapCode,@Param("mobileNumber") String mobileNumber,@Param("panNumber") String panNumber);
	
	@Transactional
	@Modifying
	@Query(QueryConstants.DEVICEREGISREPO_DELETE_BY_PANNUMBER)
	int deleteByPanNumber(@Param("panNumber") String panNumber,@Param("mobileNumber") String mobileNumber);
	
	@Transactional
	@Modifying
	@Query(QueryConstants.DEVICEREGISREPO_DELETE_BY_SAPCODE)
	int deleteBySapCode(@Param("panNumber")String panNumber,@Param("mobileNumber") String mobileNumber,@Param("sapCode") String sapCode);

	@Query(value =  QueryConstants.REQUESTID_FOR_REGISTERED_DEVICE, nativeQuery = true)
	List<Object[]> getRequestIdForRegisteredDecive(@Param("deviceIdentifier") String deviceIdentifier);
	
	DeviceRegistrationModel findByDeviceIdentifier(String deviceIdentifier);
	
}
