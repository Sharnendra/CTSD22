package com.rnlic.hrapp.bean.api.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BirthdaySmsResBean extends RnlicRestResponse {
	
	public BirthdaySmsResBean() {
		super();
	}

	public BirthdaySmsResBean(List<BirthdaySms> reponse) {
		super();
		this.reponse = reponse;
	}

	@JsonProperty(value = "Response") 
	private List<BirthdaySms> reponse=new ArrayList<>();

	public List<BirthdaySms> getReponse() {
		return reponse;
	}

	public void setReponse(List<BirthdaySms> reponse) {
		this.reponse = reponse;
	}
	
}
