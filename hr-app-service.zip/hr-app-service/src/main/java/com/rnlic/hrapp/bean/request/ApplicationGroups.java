package com.rnlic.hrapp.bean.request;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationGroups {
	
	private String groupName;
	private String groupTitle;
	private Boolean showAsTile;
	private Boolean showAsRow;
	private String groupIcon;
	private List<String> applicableFor=new ArrayList<>();
	private List<LinkedApps> applications=new ArrayList<>();
	
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getGroupTitle() {
		return groupTitle;
	}
	public void setGroupTitle(String groupTitle) {
		this.groupTitle = groupTitle;
	}
	public Boolean getShowAsTile() {
		return showAsTile;
	}
	public void setShowAsTile(Boolean showAsTile) {
		this.showAsTile = showAsTile;
	}
	public Boolean getShowAsRow() {
		return showAsRow;
	}
	public void setShowAsRow(Boolean showAsRow) {
		this.showAsRow = showAsRow;
	}
	public String getGroupIcon() {
		return groupIcon;
	}
	public void setGroupIcon(String groupIcon) {
		this.groupIcon = groupIcon;
	}
	public List<LinkedApps> getApplications() {
		return applications;
	}
	public void setApplications(List<LinkedApps> applications) {
		this.applications = applications;
	}
	public List<String> getApplicableFor() {
		return applicableFor;
	}
	public void setApplicableFor(List<String> applicableFor) {
		this.applicableFor = applicableFor;
	}
	@Override
	public String toString() {
		return "ApplicationGroups [groupName=" + groupName + ", groupTitle=" + groupTitle + ", showAsTile=" + showAsTile
				+ ", showAsRow=" + showAsRow + ", groupIcon=" + groupIcon + ", applicableFor=" + applicableFor
				+ ", applications=" + applications + "]";
	}
	
}
