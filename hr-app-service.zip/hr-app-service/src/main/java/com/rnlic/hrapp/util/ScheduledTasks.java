package com.rnlic.hrapp.util;

import org.joda.time.LocalTime;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.repository.OtpRepository;

@Component
public class ScheduledTasks {
	
	@Autowired
	private OtpRepository otpRepository;
	
//	@Autowired
//	private GenericConstants genericConstants;

   // private static final Logger log = LoggerFactory.getLogger(ScheduledTasks.class);

   // private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

    //@Scheduled(fixedRate = GenericConstants.MILISECOND*GenericConstants.SECOND* 5)
    @Scheduled(fixedRate = GenericConstants.MILISECOND)
    public void reportCurrentTime() {
        new LocalTime();
        //System.err.println(LocalTime.now()==LocalTime.MIDNIGHT);
		//System.err.println("The time is now {}"+ dateFormat.format(new Date())+" comparison "+LocalTime.now().getHourOfDay()+":"+LocalTime.now().getMinuteOfHour()+":"+LocalTime.now().getSecondOfMinute()+":"+LocalTime.now().getMillisOfSecond());
		if(scheduleTime())
        {
        	otpRepository.deleteExpiredOTPRecord();
        }
    }
    
	private Boolean scheduleTime()
    {
    	return(LocalTime.now()==LocalTime.MIDNIGHT) ? 
    	GenericConstants.TRUE : GenericConstants.FALSE;    	
    }
}
