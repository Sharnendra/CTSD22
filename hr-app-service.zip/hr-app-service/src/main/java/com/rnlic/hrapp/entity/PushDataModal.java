package com.rnlic.hrapp.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "hrapp_pushnotification_record")
public class PushDataModal {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "notification_id")
	private int notificationId;
	
	@Column(name = "notifier_sapcode")
	private String notifiedBySapCode;
	
	@Column(name = "notifier_name")
	private String notifiedByName;
	
	@Column(name = "notification_type")
	private String notificationType;
	
	@Column(name = "notification_time")
	private LocalDateTime timeStamp;
	
	@Column(name = "notification_to")
	private String notifiedTo;
	
	@Column(name = "notification_read")
	private char notificationRead;
	
	@Column(name = "notification_read_on")
	private LocalDateTime notificationReadOn;
	
	
	public String getNotifiedBySapCode() {
		return notifiedBySapCode;
	}
	public void setNotifiedBySapCode(String notifiedBySapCode) {
		this.notifiedBySapCode = notifiedBySapCode;
	}
	public String getNotifiedByName() {
		return notifiedByName;
	}
	public void setNotifiedByName(String notifiedByName) {
		this.notifiedByName = notifiedByName;
	}
	public String getNotificationType() {
		return notificationType;
	}
	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}
	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(LocalDateTime timeStamp) {
		this.timeStamp = timeStamp;
	}
	public char getNotificationRead() {
		return notificationRead;
	}
	public void setNotificationRead(char notificationRead) {
		this.notificationRead = notificationRead;
	}
	public int getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}
	public String getNotifiedTo() {
		return notifiedTo;
	}
	public void setNotifiedTo(String notifiedTo) {
		this.notifiedTo = notifiedTo;
	}
	public LocalDateTime getNotificationReadOn() {
		return notificationReadOn;
	}
	public void setNotificationReadOn(LocalDateTime notificationReadOn) {
		this.notificationReadOn = notificationReadOn;
	}
}
