package com.rnlic.hrapp.bean.response;

public interface ResponseData {

}
