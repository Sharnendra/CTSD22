package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

public class StateCityMasterResBean implements ResponseData{
	
	private List<StateDetails> states = new ArrayList<>();

	public List<StateDetails> getStates() {
		return states;
	}

	public void setStates(List<StateDetails> states) {
		this.states = states;
	}
	

}
