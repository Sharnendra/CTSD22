package com.rnlic.hrapp.bean.api.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class WishEmployeeRnlicReqBean {

	@JsonProperty(value = "SenderSAPCode")
	private String SenderSAPCode;
	
	@JsonProperty(value = "ReceiverSAPCode")
	private String ReceiverSAPCode;

	public String getSenderSAPCode() {
		return SenderSAPCode;
	}

	public void setSenderSAPCode(String senderSAPCode) {
		SenderSAPCode = senderSAPCode;
	}

	public String getReceiverSAPCode() {
		return ReceiverSAPCode;
	}

	public void setReceiverSAPCode(String receiverSAPCode) {
		ReceiverSAPCode = receiverSAPCode;
	}
}
