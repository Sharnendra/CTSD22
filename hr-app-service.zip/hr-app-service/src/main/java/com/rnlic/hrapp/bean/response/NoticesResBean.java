package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

public class NoticesResBean  implements ResponseData{
	
	List<NoticeDetails> notices = new ArrayList<>();

	public List<NoticeDetails> getNotices() {
		return notices;
	}

	public void setNotices(List<NoticeDetails> notices) {
		this.notices = notices;
	}

}
