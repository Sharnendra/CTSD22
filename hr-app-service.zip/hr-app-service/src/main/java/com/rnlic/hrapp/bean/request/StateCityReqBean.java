package com.rnlic.hrapp.bean.request;

public class StateCityReqBean {

	private String demoData;

	public String getDemoData() {
		return demoData;
	}

	public void setDemoData(String demoData) {
		this.demoData = demoData;
	}
	
}
