package com.rnlic.hrapp.bean.response;

public class WishEmpResBean implements ResponseData{

	private WishesRes wishTo;

	public WishesRes getWishTo() {
		return wishTo;
	}

	public void setWishTo(WishesRes wishTo) {
		this.wishTo = wishTo;
	}

}
