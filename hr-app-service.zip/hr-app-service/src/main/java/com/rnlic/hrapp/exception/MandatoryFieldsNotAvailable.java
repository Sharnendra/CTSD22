package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class MandatoryFieldsNotAvailable extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MandatoryFieldsNotAvailable() {
		super(ErrorConstants.MANDATORY_FIELDS_NOT_AVAILABLE_CODE,ErrorConstants.MANDATORY_FIELDS_NOT_AVAILABLE_MESSAGE,false,false);
	}
	public MandatoryFieldsNotAvailable(String message) {
		super(ErrorConstants.MANDATORY_FIELDS_NOT_AVAILABLE_CODE,message,false,false);
	}
}
