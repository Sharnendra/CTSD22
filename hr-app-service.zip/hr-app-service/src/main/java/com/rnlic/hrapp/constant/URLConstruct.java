package com.rnlic.hrapp.constant;

public class URLConstruct {

	private String employeeDetailsRnlicUrl;
	private String candidateDetailsRnlicUrl;
	private String employeeAuthServiceRnlicUrl;
	private String candidateAuthServiceRnlicUrl; 
	private String sendSmsRnlicUrl; 
	private String employeeCheckInRnlicUrl;
	private String employeeCheckOutRnlicUrl;
	private String todayBirthdayRnlicUrl;
	private String listOfReporteeRnlicUrl;
	private String sendBirthdaySmsRnlicUrl;
	private String todayAnniversaryRnlicUrl;
	private String searchBirthdayRnlicUrl;
	private String attendanceDetailsRnlicUrl;
	private String stateCityMaster;
	private String locateBranch;
	private String sendBirthdayEmailRnlicUrl;
	private String getDeviceRegistrationRnlicUrl;
	private String updateDeviceRegistrationRnlicUrl;
	private String getMandatoryLearnigsRnlicUrl;
	private String getMandatoryLearnigsStatusRnlicUrl;
	private String updateMandatoryLearnigsStatusRnlicUrl;
	private String havingTroubleWithLogin;
	private String changePassword;
	private String sendAnniversaryEmailRnlicUrl;
	private String sendAnniversarySmsRnlicUrl;
	private String changePasswordRequestRnlicUrl;
	private String updatePasswordRnlicUrl;
	private String noticesRnlicUrl;
	private String pushNotification;
	private String subscriptionListDetails;
	private String birthdayMessageTemplate;
	private String bithdayEmailTemplate;
	private String anniversaryEmailTemplate;
	
	public String getNoticesRnlicUrl() {
		return noticesRnlicUrl;
	}
	public void setNoticesRnlicUrl(String noticesRnlicUrl) {
		this.noticesRnlicUrl = noticesRnlicUrl;
	}
	public String getSendBirthdayEmailRnlicUrl() {
		return sendBirthdayEmailRnlicUrl;
	}
	public void setSendBirthdayEmailRnlicUrl(String sendBirthdayEmailRnlicUrl) {
		this.sendBirthdayEmailRnlicUrl = sendBirthdayEmailRnlicUrl;
	}
	public String getEmployeeDetailsRnlicUrl() {
		return employeeDetailsRnlicUrl;
	}
	public void setEmployeeDetailsRnlicUrl(String employeeDetailsRnlicUrl) {
		this.employeeDetailsRnlicUrl = employeeDetailsRnlicUrl;
	}
	public String getCandidateDetailsRnlicUrl() {
		return candidateDetailsRnlicUrl;
	}
	public void setCandidateDetailsRnlicUrl(String candidateDetailsRnlicUrl) {
		this.candidateDetailsRnlicUrl = candidateDetailsRnlicUrl;
	}
	public String getEmployeeAuthServiceRnlicUrl() {
		return employeeAuthServiceRnlicUrl;
	}
	public void setEmployeeAuthServiceRnlicUrl(String employeeAuthServiceRnlicUrl) {
		this.employeeAuthServiceRnlicUrl = employeeAuthServiceRnlicUrl;
	}
	public String getCandidateAuthServiceRnlicUrl() {
		return candidateAuthServiceRnlicUrl;
	}
	public void setCandidateAuthServiceRnlicUrl(String candidateAuthServiceRnlicUrl) {
		this.candidateAuthServiceRnlicUrl = candidateAuthServiceRnlicUrl;
	}
	public String getSendSmsRnlicUrl() {
		return sendSmsRnlicUrl;
	}
	public void setSendSmsRnlicUrl(String sendSmsRnlicUrl) {
		this.sendSmsRnlicUrl = sendSmsRnlicUrl;
	}
	public String getEmployeeCheckInRnlicUrl() {
		return employeeCheckInRnlicUrl;
	}
	public void setEmployeeCheckInRnlicUrl(String employeeCheckInRnlicUrl) {
		this.employeeCheckInRnlicUrl = employeeCheckInRnlicUrl;
	}
	public String getEmployeeCheckOutRnlicUrl() {
		return employeeCheckOutRnlicUrl;
	}
	public void setEmployeeCheckOutRnlicUrl(String employeeCheckOutRnlicUrl) {
		this.employeeCheckOutRnlicUrl = employeeCheckOutRnlicUrl;
	}
	public String getTodayBirthdayRnlicUrl() {
		return todayBirthdayRnlicUrl;
	}
	public void setTodayBirthdayRnlicUrl(String todayBirthdayRnlicUrl) {
		this.todayBirthdayRnlicUrl = todayBirthdayRnlicUrl;
	}
	public String getListOfReporteeRnlicUrl() {
		return listOfReporteeRnlicUrl;
	}
	public void setListOfReporteeRnlicUrl(String listOfReporteeRnlicUrl) {
		this.listOfReporteeRnlicUrl = listOfReporteeRnlicUrl;
	}
	public String getSendBirthdaySmsRnlicUrl() {
		return sendBirthdaySmsRnlicUrl;
	}
	public void setSendBirthdaySmsRnlicUrl(String sendBirthdaySmsRnlicUrl) {
		this.sendBirthdaySmsRnlicUrl = sendBirthdaySmsRnlicUrl;
	}
	public String getTodayAnniversaryRnlicUrl() {
		return todayAnniversaryRnlicUrl;
	}
	public void setTodayAnniversaryRnlicUrl(String todayAnniversaryRnlicUrl) {
		this.todayAnniversaryRnlicUrl = todayAnniversaryRnlicUrl;
	}
	public String getSearchBirthdayRnlicUrl() {
		return searchBirthdayRnlicUrl;
	}
	public void setSearchBirthdayRnlicUrl(String searchBirthdayRnlicUrl) {
		this.searchBirthdayRnlicUrl = searchBirthdayRnlicUrl;
	}
	public String getAttendanceDetailsRnlicUrl() {
		return attendanceDetailsRnlicUrl;
	}
	public void setAttendanceDetailsRnlicUrl(String attendanceDetailsRnlicUrl) {
		this.attendanceDetailsRnlicUrl = attendanceDetailsRnlicUrl;
	}
	public String getStateCityMaster() {
		return stateCityMaster;
	}
	public void setStateCityMaster(String stateCityMaster) {
		this.stateCityMaster = stateCityMaster;
	}
	public String getLocateBranch() {
		return locateBranch;
	}
	public void setLocateBranch(String locateBranch) {
		this.locateBranch = locateBranch;
	}
	public String getGetDeviceRegistrationRnlicUrl() {
		return getDeviceRegistrationRnlicUrl;
	}
	public void setGetDeviceRegistrationRnlicUrl(String getDeviceRegistrationRnlicUrl) {
		this.getDeviceRegistrationRnlicUrl = getDeviceRegistrationRnlicUrl;
	}
	public String getUpdateDeviceRegistrationRnlicUrl() {
		return updateDeviceRegistrationRnlicUrl;
	}
	public void setUpdateDeviceRegistrationRnlicUrl(String updateDeviceRegistrationRnlicUrl) {
		this.updateDeviceRegistrationRnlicUrl = updateDeviceRegistrationRnlicUrl;
	}
	public String getHavingTroubleWithLogin() {
		return havingTroubleWithLogin;
	}
	public void setHavingTroubleWithLogin(String havingTroubleWithLogin) {
		this.havingTroubleWithLogin = havingTroubleWithLogin;
	}
	public String getChangePassword() {
		return changePassword;
	}
	public void setChangePassword(String changePassword) {
		this.changePassword = changePassword;
	}
	public String getGetMandatoryLearnigsRnlicUrl() {
		return getMandatoryLearnigsRnlicUrl;
	}
	public void setGetMandatoryLearnigsRnlicUrl(String getMandatoryLearnigsRnlicUrl) {
		this.getMandatoryLearnigsRnlicUrl = getMandatoryLearnigsRnlicUrl;
	}
	public String getGetMandatoryLearnigsStatusRnlicUrl() {
		return getMandatoryLearnigsStatusRnlicUrl;
	}
	public void setGetMandatoryLearnigsStatusRnlicUrl(String getMandatoryLearnigsStatusRnlicUrl) {
		this.getMandatoryLearnigsStatusRnlicUrl = getMandatoryLearnigsStatusRnlicUrl;
	}
	public String getUpdateMandatoryLearnigsStatusRnlicUrl() {
		return updateMandatoryLearnigsStatusRnlicUrl;
	}
	public void setUpdateMandatoryLearnigsStatusRnlicUrl(String updateMandatoryLearnigsStatusRnlicUrl) {
		this.updateMandatoryLearnigsStatusRnlicUrl = updateMandatoryLearnigsStatusRnlicUrl;
	}
	public String getSendAnniversaryEmailRnlicUrl() {
		return sendAnniversaryEmailRnlicUrl;
	}
	public void setSendAnniversaryEmailRnlicUrl(String sendAnniversaryEmailRnlicUrl) {
		this.sendAnniversaryEmailRnlicUrl = sendAnniversaryEmailRnlicUrl;
	}
	public String getSendAnniversarySmsRnlicUrl() {
		return sendAnniversarySmsRnlicUrl;
	}
	public void setSendAnniversarySmsRnlicUrl(String sendAnniversarySmsRnlicUrl) {
		this.sendAnniversarySmsRnlicUrl = sendAnniversarySmsRnlicUrl;
	}
	public String getChangePasswordRequestRnlicUrl() {
		return changePasswordRequestRnlicUrl;
	}
	public void setChangePasswordRequestRnlicUrl(String changePasswordRequestRnlicUrl) {
		this.changePasswordRequestRnlicUrl = changePasswordRequestRnlicUrl;
	}
	public String getUpdatePasswordRnlicUrl() {
		return updatePasswordRnlicUrl;
	}
	public void setUpdatePasswordRnlicUrl(String updatePasswordRnlicUrl) {
		this.updatePasswordRnlicUrl = updatePasswordRnlicUrl;
	}
	public String getPushNotification() {
		return pushNotification;
	}
	public void setPushNotification(String pushNotification) {
		this.pushNotification = pushNotification;
	}
	public String getSubscriptionListDetails() {
		return subscriptionListDetails;
	}
	public void setSubscriptionListDetails(String subscriptionList) {
		this.subscriptionListDetails = subscriptionList;
	}
	
	public String getBirthdayMessageTemplate() {
		return birthdayMessageTemplate;
	}
	public void setBirthdayMessageTemplate(String birthdayMessageTemplate) {
		this.birthdayMessageTemplate = birthdayMessageTemplate;
	}
	public String getBithdayEmailTemplate() {
		return bithdayEmailTemplate;
	}
	public void setBithdayEmailTemplate(String bithdayEmailTemplate) {
		this.bithdayEmailTemplate = bithdayEmailTemplate;
	}
	public String getAnniversaryEmailTemplate() {
		return anniversaryEmailTemplate;
	}
	public void setAnniversaryEmailTemplate(String anniversaryEmailTemplate) {
		this.anniversaryEmailTemplate = anniversaryEmailTemplate;
	}
	@Override
	public String toString() {
		return "URLConstruct [employeeDetailsRnlicUrl=" + employeeDetailsRnlicUrl + ", candidateDetailsRnlicUrl="
				+ candidateDetailsRnlicUrl + ", employeeAuthServiceRnlicUrl=" + employeeAuthServiceRnlicUrl
				+ ", candidateAuthServiceRnlicUrl=" + candidateAuthServiceRnlicUrl + ", sendSmsRnlicUrl="
				+ sendSmsRnlicUrl + ", employeeCheckInRnlicUrl=" + employeeCheckInRnlicUrl
				+ ", employeeCheckOutRnlicUrl=" + employeeCheckOutRnlicUrl + ", todayBirthdayRnlicUrl="
				+ todayBirthdayRnlicUrl + ", listOfReporteeRnlicUrl=" + listOfReporteeRnlicUrl
				+ ", sendBirthdaySmsRnlicUrl=" + sendBirthdaySmsRnlicUrl + ", todayAnniversaryRnlicUrl="
				+ todayAnniversaryRnlicUrl + ", searchBirthdayRnlicUrl=" + searchBirthdayRnlicUrl
				+ ", attendanceDetailsRnlicUrl="
				+ attendanceDetailsRnlicUrl + ", stateCityMaster=" + stateCityMaster + ", locateBranch=" + locateBranch
				+ ", sendBirthdayEmailRnlicUrl=" + sendBirthdayEmailRnlicUrl + ", getDeviceRegistrationRnlicUrl="
				+ getDeviceRegistrationRnlicUrl + ", updateDeviceRegistrationRnlicUrl="
				+ updateDeviceRegistrationRnlicUrl + ", getMandatoryLearnigsRnlicUrl=" + getMandatoryLearnigsRnlicUrl
				+ ", getMandatoryLearnigsStatusRnlicUrl=" + getMandatoryLearnigsStatusRnlicUrl
				+ ", updateMandatoryLearnigsStatusRnlicUrl=" + updateMandatoryLearnigsStatusRnlicUrl
				+ ", havingTroubleWithLogin=" + havingTroubleWithLogin + ", changePassword=" + changePassword
				+ ", sendAnniversaryEmailRnlicUrl=" + sendAnniversaryEmailRnlicUrl + ", sendAnniversarySmsRnlicUrl="
				+ sendAnniversarySmsRnlicUrl + ", changePasswordRequestRnlicUrl=" + changePasswordRequestRnlicUrl
				+ ", updatePasswordRnlicUrl=" + updatePasswordRnlicUrl + "]";
	}
	
}
