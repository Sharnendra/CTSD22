package com.rnlic.hrapp.bean.request;

public class LearningStatusUpdateReqBean {
	private String learningId;

	public String getLearningId() {
		return learningId;
	}

	public void setLearningId(String learningId) {
		this.learningId = learningId;
	}
}
