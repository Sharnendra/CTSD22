package com.rnlic.hrapp.security;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rnlic.hrapp.constant.GenericConstants;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@Component
public class JwtValidator {
	
	@Autowired
	private GenericConstants genericConstants;

	private static final Logger log = LogManager.getLogger(JwtValidator.class);
	
    @SuppressWarnings("unchecked")
	public UserDetailsBean validate(String token) {

      
        UserDetailsBean jwtUser = null;
        try {
            Claims body = Jwts.parser()
                    .setSigningKey(genericConstants.getSigningKeyValue())
                    .parseClaimsJws(token)
                    .getBody();

            jwtUser = new UserDetailsBean();
            jwtUser.setFristName(body.getSubject());
            jwtUser.setSapCode( (String) body.get(GenericConstants.JWT_USER_ID));
            jwtUser.setRole((List<String>) body.get(GenericConstants.JWT_ROLE));
            jwtUser.setDeviceIdentifier((String) body.get(GenericConstants.JWT_DEVICE_ID));
            jwtUser.setLastName((String) body.get(GenericConstants.JWT_LAST_NAME));
            jwtUser.setLevel((String) body.get(GenericConstants.JWT_LEVEL));
            jwtUser.setManagerSapCode((String) body.get(GenericConstants.JWT_MANAGER_SAP_CODE));
            jwtUser.setMobileNumber((String) body.get(GenericConstants.JWT_MOBILE_NUMBER));
            jwtUser.setPanNumber((String) body.get(GenericConstants.JWT_PAN_NUMBER));
            jwtUser.setEmail((String) body.get(GenericConstants.EMAIL));
        }
        catch (Exception e) {
        	log.error(GenericConstants.EXCEPTION+e);
        }
        return jwtUser;
    }
}
