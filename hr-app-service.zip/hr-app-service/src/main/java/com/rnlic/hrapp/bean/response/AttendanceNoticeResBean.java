package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;


public class AttendanceNoticeResBean  implements ResponseData{
	
	List<NoticeEmpDetailsBean> punctual = new ArrayList<>();
	List<NoticeEmpDetailsBean> lateComers = new ArrayList<>();
	public List<NoticeEmpDetailsBean> getPunctual() {
		return punctual;
	}
	public void setPunctual(List<NoticeEmpDetailsBean> punctual) {
		this.punctual = punctual;
	}
	public List<NoticeEmpDetailsBean> getLateComers() {
		return lateComers;
	}
	public void setLateComers(List<NoticeEmpDetailsBean> lateComers) {
		this.lateComers = lateComers;
	}
	

}
