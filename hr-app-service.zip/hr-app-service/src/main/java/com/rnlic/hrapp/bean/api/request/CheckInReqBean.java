package com.rnlic.hrapp.bean.api.request;

public class CheckInReqBean {

	private String SAPCode;
	private String SourceFrom;
	private String IMEINo;
	private String CheckInLatitude;
	private String CheckInLongitude;
	private String CheckInAddress;
	public String getSAPCode() {
		return SAPCode;
	}
	public void setSAPCode(String sAPCode) {
		SAPCode = sAPCode;
	}
	public String getSourceFrom() {
		return SourceFrom;
	}
	public void setSourceFrom(String sourceFrom) {
		SourceFrom = sourceFrom;
	}
	public String getIMEINo() {
		return IMEINo;
	}
	public void setIMEINo(String iMEINo) {
		IMEINo = iMEINo;
	}
	public String getCheckInLatitude() {
		return CheckInLatitude;
	}
	public void setCheckInLatitude(String checkInLatitude) {
		CheckInLatitude = checkInLatitude;
	}
	public String getCheckInLongitude() {
		return CheckInLongitude;
	}
	public void setCheckInLongitude(String checkInLongitude) {
		CheckInLongitude = checkInLongitude;
	}
	public String getCheckInAddress() {
		return CheckInAddress;
	}
	public void setCheckInAddress(String checkInAddress) {
		CheckInAddress = checkInAddress;
	}
	@Override
	public String toString() {
		return "Latitude: " + CheckInLatitude + ","+'\r'+'\n'+"Longitude: " + CheckInLongitude +".";
	}
}
