package com.rnlic.hrapp.bean.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SmsTemplateResponse {

	@JsonProperty(value = "AnniversaryMsg")
	private String anniversaryMsg;

	@JsonProperty(value = "BirthdayMsg")
	private String birthdayMsg;
	
	public String getAnniversaryMsg() {
		return anniversaryMsg;
	}

	public void setAnniversaryMsg(String anniversaryMsg) {
		this.anniversaryMsg = anniversaryMsg;
	}

	public String getBirthdayMsg() {
		return birthdayMsg;
	}

	public void setBirthdayMsg(String birthdayMsg) {
		this.birthdayMsg = birthdayMsg;
	}
	
}
