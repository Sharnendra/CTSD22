package com.rnlic.hrapp.security;

import java.util.ArrayList;
import java.util.List;

public class UserDetailsBean {
    public UserDetailsBean() {
	}
	private String fristName;
    private String lastName;
    private String sapCode;
    private String mobileNumber;
    private String panNumber;
    private String deviceIdentifier;
	private boolean hasReportee;
    private boolean isCandidate;
	private String managerSapCode;
	private String email;
    private List<String> role=new ArrayList<>();
    private String level;
    private String fcmToken;
	public String getFcmToken() {
		return fcmToken;
	}
	public void setFcmToken(String fcmToken) {
		this.fcmToken = fcmToken;
	}
	public String getFristName() {
		return fristName;
	}
	public void setFristName(String fristName) {
		this.fristName = fristName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSapCode() {
		return sapCode;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getDeviceIdentifier() {
		return deviceIdentifier;
	}
	public void setDeviceIdentifier(String deviceIdentifier) {
		this.deviceIdentifier = deviceIdentifier;
	}
	public boolean isHasReportee() {
		return hasReportee;
	}
	public void setHasReportee(boolean hasReportee) {
		this.hasReportee = hasReportee;
	}
	public boolean isCandidate() {
		return isCandidate;
	}
	public void setCandidate(boolean isCandidate) {
		this.isCandidate = isCandidate;
	}
	public String getManagerSapCode() {
		return managerSapCode;
	}
	public void setManagerSapCode(String managerScope) {
		this.managerSapCode = managerScope;
	}
	public List<String> getRole() {
		return role;
	}
	public void setRole(List<String> role) {
		this.role = role;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public UserDetailsBean(String fristName, String lastName, String sapCode, String mobileNumber, String panNumber,
			String deviceIdentifier, boolean hasReportee, boolean isCandidate, String managerSapCode, List<String> role,
			String level) {
		super();
		this.fristName = fristName;
		this.lastName = lastName;
		this.sapCode = sapCode;
		this.mobileNumber = mobileNumber;
		this.panNumber = panNumber;
		this.deviceIdentifier = deviceIdentifier;
		this.hasReportee = hasReportee;
		this.isCandidate = isCandidate;
		this.managerSapCode = managerSapCode;
		this.role = role;
		this.level = level;
	}
	@Override
	public String toString() {
		return "UserDetailsBean [fristName=" + fristName + ", lastName=" + lastName + ", sapCode=" + sapCode
				+ ", mobileNumber=" + mobileNumber + ", panNumber=" + panNumber + ", deviceIdentifier="
				+ deviceIdentifier + ", hasReportee=" + hasReportee + ", isCandidate=" + isCandidate + ", managerSapCode="
				+ managerSapCode + ", role=" + role + ", level=" + level + "]";
	}
	
    
}
