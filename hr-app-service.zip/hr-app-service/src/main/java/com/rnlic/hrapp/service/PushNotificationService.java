package com.rnlic.hrapp.service;

import java.time.LocalDateTime;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rnlic.hrapp.bean.request.MessageTemplateRequest;
import com.rnlic.hrapp.bean.request.UpdateNotificationRequest;
import com.rnlic.hrapp.bean.response.PushDataResponse;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.bean.response.SubscriptionResponseList;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.entity.PushDataModal;
import com.rnlic.hrapp.repository.PushDataRepository;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestLogDeatils;

/**
 * This service class responsible to push notification service
 */
@Service
public class PushNotificationService {
	
	private static final Logger log = LogManager.getLogger(PushNotificationService.class);
	
	@Autowired
	private RequestLogDeatils requestLog;
	
	@Autowired
	private RnlicService rnlicService;
	
	@Autowired
	private PushDataRepository pushDataRepository;
	
	/**
	 * This method will provide the Subscription List
	 * 
	 * @return SubscriptionResponseList subscriptionResponseList
	 */
	public SubscriptionResponseList getSubsctiptionList(String sapCode)
	{
		log.info(requestLog+ "== getSubsctiptionList Service call :=====");
		return rnlicService.getSubsctiptionList(sapCode);
	}
	
	/**
	 * This method will updateNotificatonDetails 
	 * 
	 * @return PushDataResponse pushDataResponse
	 */
	public PushDataResponse updateNotificatonDetails(UpdateNotificationRequest updateNotificationRequest) {
		PushDataResponse response = new PushDataResponse();
		log.info(requestLog+ "== updateNotificatonDetails Service call :=====");
		PushDataModal data = pushDataRepository.findByNotificationId(updateNotificationRequest.getNotificationId());
		if(!HrAppUtil.isNullOrEmpty(data))
		{
			log.info(requestLog+ "== updateNotificatonDetails notification data is found :=====");
			data.setNotificationReadOn(LocalDateTime.now());
			data.setNotificationRead(updateNotificationRequest.getIsRead());
			pushDataRepository.save(data);
			response.setIsNotificationUpdated(GenericConstants.TRUE);
		}
		else {
			log.info(requestLog+ "== updateNotificatonDetails notification data not found :=====");
			response.setIsNotificationUpdated(GenericConstants.FALSE);
		}
		return response;
	}

	public ResponseData getMessageTemplate(MessageTemplateRequest messageTemplateRequest) {
		log.info(requestLog+ "== getMessageTemplate Service call :=====");
		return rnlicService.getMessageTemplate(messageTemplateRequest);
	}

}
