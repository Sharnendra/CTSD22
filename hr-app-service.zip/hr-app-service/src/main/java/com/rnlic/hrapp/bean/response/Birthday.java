package com.rnlic.hrapp.bean.response;

public class Birthday {

	private String sapCode;
	private String name;
	private String email;
	private String mobile;
	private String managerSapcode;
	private String channel;
	private String zone;
	private String region;
	private String dateOfBirth;
	private String dateOfJoining;
	private String paLocation;
	private String designation;
	public String getSapCode() {
		return sapCode;
	}
	public String getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getManagerSapcode() {
		return managerSapcode;
	}
	public void setManagerSapcode(String managerSapcode) {
		this.managerSapcode = managerSapcode;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPaLocation() {
		return paLocation;
	}
	public void setPaLocation(String paLocation) {
		this.paLocation = paLocation;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
}
