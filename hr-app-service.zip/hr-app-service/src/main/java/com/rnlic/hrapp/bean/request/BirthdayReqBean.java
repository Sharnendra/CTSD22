package com.rnlic.hrapp.bean.request;

public class BirthdayReqBean {

	private String sapCode;
	private String name;
	
	public String getSapCode() {
		return sapCode;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
