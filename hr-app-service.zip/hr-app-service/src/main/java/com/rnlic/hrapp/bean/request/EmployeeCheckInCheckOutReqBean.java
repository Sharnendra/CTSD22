package com.rnlic.hrapp.bean.request;

public class EmployeeCheckInCheckOutReqBean {
	
	public EmployeeCheckInCheckOutReqBean() {
		this.userLocation = new UserLocation();
	}
	private UserLocation userLocation;
	private String type;
	public UserLocation getUserLocation() {
		return userLocation;
	}
	public void setUserLocation(UserLocation userLocation) {
		this.userLocation = userLocation;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
