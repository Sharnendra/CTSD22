package com.rnlic.hrapp.bean.api.response;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.rnlic.hrapp.bean.request.AttendanceReqBean;
import com.rnlic.hrapp.bean.request.EmployeeCheckInCheckOutReqBean;
import com.rnlic.hrapp.bean.request.ShareBranchDetailsReqBean;
import com.rnlic.hrapp.bean.request.UserLocation;
import com.rnlic.hrapp.bean.response.Anniversary;
import com.rnlic.hrapp.bean.response.AnniversaryResBean;
import com.rnlic.hrapp.bean.response.Attendance;
import com.rnlic.hrapp.bean.response.AttendanceDetailsResBean;
import com.rnlic.hrapp.bean.response.Birthday;
import com.rnlic.hrapp.bean.response.BirthdayResBean;
import com.rnlic.hrapp.bean.response.ChangePasswordResBean;
import com.rnlic.hrapp.bean.response.CityDetails;
import com.rnlic.hrapp.bean.response.EmployeeCheckInCheckOutResBean;
import com.rnlic.hrapp.bean.response.LearningDetails;
import com.rnlic.hrapp.bean.response.LocateBranchResBean;
import com.rnlic.hrapp.bean.response.LocateBranches;
import com.rnlic.hrapp.bean.response.MandatoryLearningDetails;
import com.rnlic.hrapp.bean.response.MandatoryLearningResBean;
import com.rnlic.hrapp.bean.response.MandatoryLearningStatusResBean;
import com.rnlic.hrapp.bean.response.MessageTemplate;
import com.rnlic.hrapp.bean.response.NoticeDetails;
import com.rnlic.hrapp.bean.response.NoticesResBean;
import com.rnlic.hrapp.bean.response.ReporteeDetails;
import com.rnlic.hrapp.bean.response.SendOtpMobileResBean;
import com.rnlic.hrapp.bean.response.ShareBrachDetailsResBean;
import com.rnlic.hrapp.bean.response.StateCityMasterResBean;
import com.rnlic.hrapp.bean.response.StateDetails;
import com.rnlic.hrapp.bean.response.SubscriptionResponseList;
import com.rnlic.hrapp.bean.response.TroubleWithLoginResBean;
import com.rnlic.hrapp.bean.response.User;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.entity.OtpMasterModel;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.RnlicService;
import com.rnlic.hrapp.util.HrAppUtil;

@Component
public class RnlicServicesDataTranslator {
	
	private StateDetails statesDetails = null;
	private CityDetails cityDetails=null;
	
	@Autowired
	private RnlicService rnlicService;
	
	@Autowired
	private MessagesConstants messageConstants;

	/**
	 * This method convert RNLIC response to HRAPP Wrapper Service
	 * Response and Get the Employee Details
	 * 
	 * @param EmployeeRnlicResponseBean response
	 * @return User empDtls
	 */
	public User getEmpDetails(EmployeeRnlicResponseBean response) {
		User empDtls = null;
		if (!HrAppUtil.isNullOrEmpty(response) && !HrAppUtil.isNullOrEmpty(response.getResponse())) {
			EmployeeDetailsRnlicResponseBean empDtlsRnlic = response.getResponse().get(0);
			if (!HrAppUtil.isNullOrEmpty(empDtlsRnlic)) {
				empDtls = new User();
				empDtls.setFirstName(getFristName(empDtlsRnlic.getName()));
				empDtls.setLastName(getLastName(empDtlsRnlic.getName()));
				empDtls.setMiddleName(getMiddleName(empDtlsRnlic.getName()));
				empDtls.setHasReportee(getHasReporteeStatus(empDtlsRnlic.getSapCode()));
				empDtls.setLevel(empDtlsRnlic.getLevel());
				empDtls.setOrgRoles(getOrgRoles(empDtlsRnlic.getRole()));
				empDtls.setSapCode(empDtlsRnlic.getSapCode());
				empDtls.setUserRole(empDtlsRnlic.getUserRole());
				empDtls.setChannel(empDtlsRnlic.getChannel());
				empDtls.setEmail(empDtlsRnlic.getEmailID());
				empDtls.setLocationCode(empDtlsRnlic.getLocationCode());
				empDtls.setLocationName(empDtlsRnlic.getLocationName());
				empDtls.setManagerName(empDtlsRnlic.getManagerName());
				empDtls.setManagerSapCode(empDtlsRnlic.getManagerSAPCode());
				empDtls.setMobileNo(getMobileNo(empDtlsRnlic.getMobileNo()));
				empDtls.setPanNo(empDtlsRnlic.getPanNumber());
				empDtls.setZoneCode(empDtlsRnlic.getZoneCode());
				empDtls.setZoneName(empDtlsRnlic.getZoneName());
			}
		}
		return empDtls;
	}

	/**
	 * This method convert RNLIC response to HRAPP Wrapper Service
	 * Response and Determine whether the Employee has Reportee's or
	 * not.
	 * 
	 * @param String sapCode
	 * @return Boolean
	 */
	private boolean getHasReporteeStatus(String sapCode) {
		List<ReporteeDetails> reportee = rnlicService.getListOfReportees(sapCode);
		return HrAppUtil.isNullOrEmpty(reportee)?GenericConstants.FALSE:GenericConstants.TRUE;
	}

	private String getMobileNo(String mobileNo) {
		String[] mobileNoList = mobileNo.split(GenericConstants.HYPHEN);
		int nameLength = mobileNoList.length - GenericConstants.INTEGER_ONE;
		return mobileNoList[nameLength];
	}

	private List<String> getOrgRoles(String rloe) {
		List<String> roleList = new ArrayList<>();
		roleList.add(rloe);
		return roleList;
	}

	/**
	 * This method convert RNLIC response to HRAPP Wrapper Service
	 * Response and Get the Candidate Details.
	 * 
	 * @param CandidateRnlicResponseBean response
	 * @return User candidateDtls
	 */
	public User getCandidateDetails(CandidateRnlicResponseBean response) {
		User candidateDtls = null;
		if (!HrAppUtil.isNullOrEmpty(response) && !HrAppUtil.isNullOrEmpty(response.getResponse())) {
			CandidateDetailsRnlicResponseBean candidateDtlsRnlic = response.getResponse().get(0);
			if (!HrAppUtil.isNullOrEmpty(candidateDtlsRnlic)) {
				candidateDtls = new User();
				candidateDtls.setFirstName(getFristName(candidateDtlsRnlic.getName()));
				candidateDtls.setLastName(getLastName(candidateDtlsRnlic.getName()));
				candidateDtls.setMiddleName(getMiddleName(candidateDtlsRnlic.getName()));
				candidateDtls.setHasReportee(GenericConstants.FALSE);
				candidateDtls.setLevel(candidateDtlsRnlic.getLevel());
				candidateDtls.setOrgRoles(getOrgRoles(candidateDtlsRnlic.getRole()));
				candidateDtls.setCategory(candidateDtlsRnlic.getCategory());
				candidateDtls.setChannel(candidateDtlsRnlic.getChannel());
				candidateDtls.setEmail(candidateDtlsRnlic.getEmail());
				candidateDtls.setLocationCode(candidateDtlsRnlic.getLocationCode());
				candidateDtls.setLocationName(candidateDtlsRnlic.getLocationName());
				candidateDtls.setManagerName(candidateDtlsRnlic.getManagerName());
				candidateDtls.setManagerSapCode(candidateDtlsRnlic.getManagerSAPCode());
				candidateDtls.setMobileNo(candidateDtlsRnlic.getMobileNo());
			}
		}
		return candidateDtls;
	}

	private String getMiddleName(String name) {
		String[] nameList = name.split(GenericConstants.WHITE_SPACE);
		int nameLength = nameList.length;
		StringBuilder middleName = new StringBuilder();
		if (nameLength > GenericConstants.INTEGER_TWO) {
			for (int i = 1; i < nameLength - 1; i++) {
				middleName.append(nameList[i]);
			}
		} else {
			middleName.append(GenericConstants.EMPTY_STRING);
		}
		return String.valueOf(middleName);
	}

	private String getFristName(String name) {
		return name.split(GenericConstants.WHITE_SPACE)[GenericConstants.INTEGER_ZERO];
	}

	private String getLastName(String name) {
		String[] nameList = name.split(GenericConstants.WHITE_SPACE);
		int nameLength = nameList.length - GenericConstants.INTEGER_ONE;
		return nameList[nameLength];
	}

	/**
	 * This translator method convert RNLIC response to HRAPP Wrapper Service
	 * Response
	 * 
	 * @param BirthdayListRnlicResponseBean response
	 * @return BirthdayResBean birthdayResBean
	 */
	public BirthdayResBean getBirthdayList(BirthdayListRnlicResponseBean response) {
		List<Birthday> birthDayList = new ArrayList<>();
		if (!HrAppUtil.isNullOrEmpty(response) && !HrAppUtil.isNullOrEmpty(response.getResponse())) {
			for (BirthdayDetailsRnlicResponseBean birth : response.getResponse()) {
				Birthday birthday = new Birthday();
				birthday.setChannel(birth.getChannel());
				birthday.setDateOfBirth(getDate(birth.getDob()));
				birthday.setDateOfJoining(getDate(birth.getDoj()));
				birthday.setEmail(birth.getEmail());
				birthday.setManagerSapcode(birth.getManagerSapCode());
				birthday.setMobile(birth.getMobileNumber());
				birthday.setRegion(birth.getRegionName());
				birthday.setSapCode(birth.getSapCode());
				birthday.setZone(birth.getZoneName());
				birthday.setName(birth.getName());
				birthday.setPaLocation(birth.getPaLocation());
				birthday.setDesignation(birth.getDesignation());
				birthDayList.add(birthday);
			}
		}
		birthDayList.sort((Birthday o1, Birthday o2)->o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase()));
		return new BirthdayResBean(birthDayList);
	}

	/**
	 * This translator method convert RNLIC response to HRAPP Wrapper Service
	 * Response
	 * 
	 * @param BirthdayListRnlicResponseBean response
	 * @return BirthdayResBean birthdayResBean
	 */
	public AnniversaryResBean getAnniversaryList(AnniversaryListRnlicResponseBean response) {
		List<Anniversary> anniversaryList = new ArrayList<>();
		if (!HrAppUtil.isNullOrEmpty(response) && !HrAppUtil.isNullOrEmpty(response.getResponse())) {
			for (AnniversaryDetailsRnlicResponseBean anniversary : response.getResponse()) {
				Anniversary anniversaryDtls = new Anniversary();
				anniversaryDtls.setChannel(anniversary.getChannel());
				anniversaryDtls.setJoinDate(getDate(anniversary.getDoj()));
				anniversaryDtls.setEmail(anniversary.getEmail());
				anniversaryDtls.setManagerSapcode(anniversary.getManagerSapCode());
				anniversaryDtls.setMobile(anniversary.getMobileNumber());
				anniversaryDtls.setRegion(anniversary.getRegionName());
				anniversaryDtls.setSapCode(anniversary.getSapCode());
				anniversaryDtls.setZone(anniversary.getZoneName());
				anniversaryDtls.setName(anniversary.getName());
				anniversaryList.add(anniversaryDtls);
			}
		}
		anniversaryList.sort((Anniversary o1, Anniversary o2)->o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase()));
		return new AnniversaryResBean(anniversaryList);
	}

	/**
	 * This method will translate rnlic response to mobile application response
	 * @param ReporteeListResponseBean response
	 * @return List<ReporteeDetails> reporteeList
	 */
	public List<ReporteeDetails> getReporteeList(ReporteeListRnlicResponseBean response) {
		List<ReporteeDetails> reporteeList = new ArrayList<>();
		if (!HrAppUtil.isNullOrEmpty(response) && !HrAppUtil.isNullOrEmpty(response.getResponse())
				&& !HrAppUtil.isNullOrEmpty(response.getResponse().getReporteeInformation())) {
			for (ReporteeInformationRnlicResponseBean reportee : response.getResponse().getReporteeInformation()) {
				ReporteeDetails reporteeDtls = new ReporteeDetails();
				reporteeDtls.setHasAnyReportee(reportee.getHasAnyReportee().equalsIgnoreCase(GenericConstants.TRUE_STRING));
				reporteeDtls.setManagerName(reportee.getManagerName());
				reporteeDtls.setManagerSapCode(reportee.getManagerSapCode());
				reporteeDtls.setName(reportee.getName());
				reporteeDtls.setSapCode(reportee.getSapCode());
				reporteeList.add(reporteeDtls);
			}
		}
		reporteeList.sort((ReporteeDetails o1, ReporteeDetails o2)->o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase()));	
		return reporteeList.stream().distinct().collect(Collectors.toList());
	}
	
	public StateCityMasterResBean getStateCityMasteList(StateCityMasterRnlicResponseBean response) {
		StateCityMasterResBean stateCityMasterResBean = new StateCityMasterResBean();
		
		Map<String, Set<String>> mapper=new LinkedHashMap<>();
		Map<String, Set<String>> sortedMapper;
		if (!HrAppUtil.isNullOrEmpty(response) && !HrAppUtil.isNullOrEmpty(response.getStateCityReqBean())) 
		{
			response.getStateCityReqBean().stream().forEach(stateCityMasterReqBean ->{
				
				if(!mapper.containsKey(StringUtils.capitalize(stateCityMasterReqBean.getState().toLowerCase())))
				{
					Set<String> cityValue=new LinkedHashSet<>();
					cityValue.add(stateCityMasterReqBean.getCity());
					mapper.put(StringUtils.capitalize(stateCityMasterReqBean.getState().toLowerCase()), cityValue);
				}
				else
				{
					Set<String> cityValue=mapper.get(StringUtils.capitalize(stateCityMasterReqBean.getState().toLowerCase()));
					if(HrAppUtil.isNullOrEmpty(cityValue))
					{
						cityValue=new HashSet<>();
						cityValue.add(stateCityMasterReqBean.getCity());
					}
					else
					{
						mapper.get(StringUtils.capitalize(stateCityMasterReqBean.getState().toLowerCase())).add(stateCityMasterReqBean.getCity());
					}
				}
			});
		}
		sortedMapper=mapper.entrySet().stream()
				.sorted(Map.Entry.comparingByKey())
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
		                (oldValue, newValue) -> newValue, LinkedHashMap::new));
	
		//sortedMapper.entrySet().stream().forEach(X->{ System.out.println(X.getKey());});
	
		sortedMapper.entrySet().stream().forEach(map->{
			String key=map.getKey();
			Set<String> value=map.getValue();
			statesDetails = new StateDetails();
			statesDetails.setStateName(key);
			value.stream().forEach(listValue->{
				cityDetails =new CityDetails();
				cityDetails.setCityName(listValue);
				statesDetails.getCities().add(cityDetails);
				cityDetails=null;
			});
			stateCityMasterResBean.getStates().add(statesDetails);
			statesDetails=null;
		});
		
		return stateCityMasterResBean;
	}
	
	public EmployeeCheckInCheckOutResBean getEmployeeCheckInCheckOutRes(
			EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean,
			CheckInCheckOutRnlicResponseBean response) 
	{
		EmployeeCheckInCheckOutResBean employeeCheckInCheckOutResBean = new EmployeeCheckInCheckOutResBean();
		CheckInCheckOutDateTimeResponseBean checkInCheckOutDateTimeResponseBean = response.getResponse().get(0);
		if(null!=checkInCheckOutDateTimeResponseBean && employeeCheckInCheckOutReqBean.getType().equalsIgnoreCase("check-in")) {
			employeeCheckInCheckOutResBean.setDate(generateDateForCheckInCheckout(checkInCheckOutDateTimeResponseBean.getCheckInTime()));
			employeeCheckInCheckOutResBean.setTime(generateTimeForCheckInCheckout(checkInCheckOutDateTimeResponseBean.getCheckInTime()));
		}
		else if(null!=checkInCheckOutDateTimeResponseBean && employeeCheckInCheckOutReqBean.getType().equalsIgnoreCase("check-out")) {
			employeeCheckInCheckOutResBean.setDate(generateDateForCheckInCheckout(checkInCheckOutDateTimeResponseBean.getCheckOutTime()));
			employeeCheckInCheckOutResBean.setTime(generateTimeForCheckInCheckout(checkInCheckOutDateTimeResponseBean.getCheckOutTime()));
		}
		employeeCheckInCheckOutResBean.setType(employeeCheckInCheckOutReqBean.getType());
		employeeCheckInCheckOutResBean.setStatus(response.getStatus());
		employeeCheckInCheckOutResBean.setMessage(response.getMessage());
		return employeeCheckInCheckOutResBean;
	}

	public LocateBranchResBean getBranchDetails(RnlicBranchDetailsListResponseBean response,
			LocateBranchResBean locateBranchResBean) {
		response.getResponse().stream()
		.forEach(branchDetails->{
			LocateBranches localBranches=new LocateBranches();
			localBranches.setName(branchDetails.getBranch());
			localBranches.setAddress(branchDetails.getAddress());
			localBranches.setCode(branchDetails.getBranchCode());
			UserLocation userLocation=new UserLocation();
			userLocation.setLatitude(branchDetails.getLatitude());
			userLocation.setLongitude(branchDetails.getLongitude());
			localBranches.setLocation(userLocation);
			locateBranchResBean.getBranches().add(localBranches);
		});
		return locateBranchResBean;
	}

	/**
	 * This method translate service response into wrapper service
	 * @param MonthlyAttendanceDetailsRnlicResponseBean response
	 * @param AttendanceReqBean attendanceReqBean
	 * @param UserDetailsBean empReqBean
	 * @return AttendanceDetailsResBean attendanceDetailsResBean
	 */
	public AttendanceDetailsResBean getAttendanceDtls(MonthlyAttendanceDetailsRnlicResponseBean response, AttendanceReqBean attendanceReqBean, UserDetailsBean empReqBean) {
		AttendanceDetailsResBean attendanceDetailsResBean = new  AttendanceDetailsResBean();
		attendanceDetailsResBean.setFirstName(empReqBean.getFristName());
		attendanceDetailsResBean.setLastName(empReqBean.getLastName());
		attendanceDetailsResBean.setMonth(attendanceReqBean.getMonth());
		attendanceDetailsResBean.setSapCode(attendanceReqBean.getSapCode());
		attendanceDetailsResBean.setYear(attendanceReqBean.getYear());
		if (!HrAppUtil.isNullOrEmpty(response) && !HrAppUtil.isNullOrEmpty(response.getResponse())) {
			response.getResponse().stream().forEach(attendanceDtls ->{
				Attendance attendance = new Attendance();
				String date = getDate(attendanceDtls.getYear(),attendanceDtls.getMonth(),attendanceDtls.getDate());
				attendance.setDate(date);
				int dayOfWeek = getDayOfWeek(date);
				attendance.setDayOfWeek(String.valueOf(dayOfWeek));
				getAttendanceCodeAndDiscriptions(attendanceDtls,attendance,dayOfWeek);
				attendance.setCheckIn(getTimeInfo(attendanceDtls.getInTime()));
				attendance.setCheckOut(getTimeInfo(attendanceDtls.getOutTime()));
				attendance.setCheckInBranch(HrAppUtil.isNullOrEmpty(attendanceDtls.getCheckInBranch())?GenericConstants.EMPTY_STRING:attendanceDtls.getCheckInBranch());
				attendance.setCheckInBranchAddress(HrAppUtil.isNullOrEmpty(attendanceDtls.getCheckInBrAddress())?GenericConstants.EMPTY_STRING:attendanceDtls.getCheckInBrAddress());
				attendance.setCheckOutBranch(HrAppUtil.isNullOrEmpty(attendanceDtls.getCheckOutBranch())?GenericConstants.EMPTY_STRING:attendanceDtls.getCheckOutBranch());
				attendance.setCheckOutBranchAddress(HrAppUtil.isNullOrEmpty(attendanceDtls.getCheckOutBrAddress())?GenericConstants.EMPTY_STRING:attendanceDtls.getCheckOutBrAddress());
				attendanceDetailsResBean.getAttendance().add(attendance);
			});
		}
		
		return attendanceDetailsResBean;
	}

	private String getTimeInfo(String time) {
		String checkTime=null;
		if(!HrAppUtil.isNullOrEmpty(time)) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(GenericConstants.PATTERN_MMM_D_YYYY_H_MM_A);
		time=time.replaceAll(GenericConstants.DOUBLE_SPACE, GenericConstants.WHITE_SPACE);
	    LocalDateTime dateTime = LocalDateTime.parse(time, formatter);
	    DateTimeFormatter format1 = DateTimeFormatter.ofPattern("HH:mm:ss"); 
	    checkTime = dateTime.format(format1);
		}else {
			checkTime =GenericConstants.EMPTY_STRING;
		}
		return checkTime;
	}
	
	private String getDate(String time) {
		String checkTime=null;
		if(!HrAppUtil.isNullOrEmpty(time)) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(GenericConstants.PATTERN_YYYY_MM_DD_T_HH_MM_SS);
		time=time.replaceAll(GenericConstants.DOUBLE_SPACE, GenericConstants.WHITE_SPACE);
	    LocalDateTime dateTime = LocalDateTime.parse(time, formatter);
	    DateTimeFormatter format1 = DateTimeFormatter.ofPattern(GenericConstants.PATTERN_YYYY_MM_DD); 
	    checkTime = dateTime.format(format1);
		}else {
			checkTime =GenericConstants.WHITE_SPACE;
		}
		return checkTime;
	}

	private int getDayOfWeek(String date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(GenericConstants.PATTERN_YYYY_M_D);
		LocalDate loaclDate = LocalDate.parse(date, formatter);
		return loaclDate.getDayOfWeek().getValue();
	}

	private String getDate(String year,String month,String day) {
		String date=null;
		if(!HrAppUtil.isNullOrEmpty(year)&&!HrAppUtil.isNullOrEmpty(month)&&!HrAppUtil.isNullOrEmpty(day)) {
			date=  year.trim()+GenericConstants.HYPHEN+month.trim()+GenericConstants.HYPHEN+day.trim();
		}
		return date;
	}

	private void getAttendanceCodeAndDiscriptions(AttendanceDetailsRnlicResponseBean attendanceDtls, Attendance attendance, int dayOfWeek) {
		
		String attendanceCode = "";
		String discriptions = "";
		if(HrAppUtil.isNullOrEmpty(attendanceDtls.getIsPresent())) {
			attendanceCode = GenericConstants.EMPTY_STRING;
		}else if(GenericConstants.TRUE_STRING.equalsIgnoreCase(attendanceDtls.getIsPresent())) {
			attendanceCode = GenericConstants.STRING_P;
		}else {
			attendanceCode = GenericConstants.STRING_A;
		}
		if(!HrAppUtil.isNullOrEmpty(attendanceDtls.getIsLeave()) && GenericConstants.TRUE_STRING.equalsIgnoreCase(attendanceDtls.getIsLeave())) {
			attendanceCode = GenericConstants.STRING_L;
			discriptions = (HrAppUtil.isNullOrEmpty(attendanceDtls.getLeaveType())?GenericConstants.EMPTY_STRING:attendanceDtls.getLeaveType()+GenericConstants.COLLON_SPACE)+
					(HrAppUtil.isNullOrEmpty(attendanceDtls.getLeaveDescription())?GenericConstants.EMPTY_STRING:attendanceDtls.getLeaveDescription());
		}
		if(!HrAppUtil.isNullOrEmpty(attendanceDtls.getIsHoliday()) && GenericConstants.TRUE_STRING.equalsIgnoreCase(attendanceDtls.getIsHoliday())) {
		
			discriptions = HrAppUtil.isNullOrEmpty(attendanceDtls.getHolidayName())?GenericConstants.EMPTY_STRING:attendanceDtls.getHolidayName();
			if(GenericConstants.SATURDAY_OFF.equalsIgnoreCase(discriptions)) {
				attendanceCode = GenericConstants.STRING_SO;
			}else {
				attendanceCode = GenericConstants.STRING_H;
			}
		}
		if(!HrAppUtil.isNullOrEmpty(attendanceDtls.getIsWaiting()) && GenericConstants.TRUE_STRING.equalsIgnoreCase(attendanceDtls.getIsWaiting())) {
			attendanceCode = GenericConstants.STRING_WL;
		}
		if(!HrAppUtil.isNullOrEmpty(attendanceDtls.getOfficialReason())) {
			attendanceCode = GenericConstants.STRING_OD;
			discriptions = attendanceDtls.getOfficialReason();
		}
		if(dayOfWeek == GenericConstants.INTEGER_SEVEN) {
			attendanceCode = GenericConstants.STRING_S;
		}
		attendance.setAttendanceCode(attendanceCode);
		attendance.setDiscription(discriptions);
	}


	/**
	 * This method will translate response to wrapper service response
	 * @param MandatoryLearningRnlicResponseBean response
	 * @return MandatoryLearningResBean mandatoryLearningResBean
	 */
	public MandatoryLearningResBean getMandatoryLearning(MandatoryLearningRnlicResponseBean response) {
		MandatoryLearningResBean  mandatoryLearningResBean = new MandatoryLearningResBean();
		if (!HrAppUtil.isNullOrEmpty(response) && !HrAppUtil.isNullOrEmpty(response.getResponse())) {
			response.getResponse().stream().forEach(learningDtls ->{
				LearningDetails learnings = new LearningDetails();
				learnings.setDocumentName(learningDtls.getDocumentName());
				learnings.setDocumentUploadDate(learningDtls.getUploadDate());
				learnings.setLearningId(learningDtls.getLearningId());
				learnings.setLearningLink(learningDtls.getLearningLink());
				learnings.setLearningName(learningDtls.getLearningName());
				mandatoryLearningResBean.getMandatoryLearnings().add(learnings);
			});
		}
		return mandatoryLearningResBean;
	}
	
	/**
	 * This method will translate response to wrapper service response
	 * @param MandatoryLearningRnlicResponseBean response
	 * @return MandatoryLearningResBean mandatoryLearningResBean
	 */
	public MandatoryLearningStatusResBean getMandatoryLearningStatus(MandatoryLearningStatusRnlicResponseBean response,
			Map<String,String> result) {
		MandatoryLearningStatusResBean  mandatoryLearningResBean = new MandatoryLearningStatusResBean();
		if (!HrAppUtil.isNullOrEmpty(result)) {
			result.entrySet().stream().forEach(data -> {
				MandatoryLearningDetails learnings = new MandatoryLearningDetails();
				learnings.setLearningId(data.getKey());
				learnings.setStatus(data.getValue());
				mandatoryLearningResBean.getMandatoryLearnings().add(learnings);
			});
		}
		return mandatoryLearningResBean;
	}
	
	public TroubleWithLoginResBean getTroubleWithLoginDetails(TroubleWithLoginRnlicResponseBean response) {
		TroubleWithLoginResBean troubleWithLoginResBean = new TroubleWithLoginResBean();
		TroubleWithLoginApiResBean troubleWithLoginApiResBean = response.getTroubleWithLoginResBean().get(0);
		troubleWithLoginResBean.setContactEmail(troubleWithLoginApiResBean.getContactEmail());
		troubleWithLoginResBean.setContactNumber(troubleWithLoginApiResBean.getContactNumber());
		troubleWithLoginResBean.setHelpMessage(troubleWithLoginApiResBean.getHelpMessage());
		return troubleWithLoginResBean;
	}

	public String generateSharedMessage(LocateBranches locateBranches) {
		String resp=GenericConstants.EMPTY_STRING;
		if(locateBranches.getName()!=null && !(GenericConstants.EMPTY_STRING).equalsIgnoreCase(locateBranches.getName())
				&& !(GenericConstants.NULL_STRING).equalsIgnoreCase(locateBranches.getName())) {
			if(resp.equalsIgnoreCase(GenericConstants.EMPTY_STRING)) {
				resp="\r\n"+locateBranches.getName()+GenericConstants.COMMA+"\n";
			}
			else {
				resp=resp+locateBranches.getName()+GenericConstants.COMMA+"\n";
			}
		}
		if(locateBranches.getAddress()!=null && !(GenericConstants.EMPTY_STRING).equalsIgnoreCase(locateBranches.getAddress())
				&& !(GenericConstants.NULL_STRING).equalsIgnoreCase(locateBranches.getAddress())) {
			if(resp.equalsIgnoreCase(GenericConstants.EMPTY_STRING)) {
				resp="\r\n"+locateBranches.getAddress()+GenericConstants.COMMA+"\n";
			}
			else {
				resp=resp+locateBranches.getAddress()+GenericConstants.COMMA+"\n";
			}
		}
		if(locateBranches.getCode()!=null && !(GenericConstants.EMPTY_STRING).equalsIgnoreCase(locateBranches.getCode())
				&& !(GenericConstants.NULL_STRING).equalsIgnoreCase(locateBranches.getCode())) {
			if(resp.equalsIgnoreCase(GenericConstants.EMPTY_STRING)) {
				resp="\r\n"+locateBranches.getCode()+GenericConstants.COMMA+"\n";
			}
			else {
				resp=resp+locateBranches.getCode()+GenericConstants.COMMA+"\n";
			}
		}
		if(locateBranches.getContactNumber()!=null && !(GenericConstants.EMPTY_STRING).equalsIgnoreCase(locateBranches.getContactNumber())
				&& !(GenericConstants.NULL_STRING).equalsIgnoreCase(locateBranches.getContactNumber())) {
			if(resp.equalsIgnoreCase(GenericConstants.EMPTY_STRING)) {
				resp="\r\n"+locateBranches.getContactNumber()+GenericConstants.COMMA+"\n";
			}
			else {
				resp=resp+locateBranches.getContactNumber()+GenericConstants.COMMA+"\n";
			}
		}
		if(locateBranches.getContactPerson()!=null && !(GenericConstants.EMPTY_STRING).equalsIgnoreCase(locateBranches.getContactPerson())
				&& !(GenericConstants.NULL_STRING).equalsIgnoreCase(locateBranches.getContactPerson())) {
			if(resp.equalsIgnoreCase(GenericConstants.EMPTY_STRING)) {
				resp="\r\n"+locateBranches.getContactPerson()+GenericConstants.COMMA+"\n";
			}
			else {
				resp=resp+locateBranches.getContactPerson()+GenericConstants.COMMA+"\n";
			}
		}
		if(locateBranches.getEmail()!=null && !(GenericConstants.EMPTY_STRING).equalsIgnoreCase(locateBranches.getEmail())
				&& !(GenericConstants.NULL_STRING).equalsIgnoreCase(locateBranches.getEmail())) {
			if(resp.equalsIgnoreCase(GenericConstants.EMPTY_STRING)) {
				resp="\r\n"+locateBranches.getEmail()+GenericConstants.COMMA+"\n";
			}
			else {
				resp=resp+locateBranches.getEmail()+GenericConstants.COMMA+"\n";
			}
		}
		if(locateBranches.getLocation().getLatitude()!=null && !(GenericConstants.EMPTY_STRING).equalsIgnoreCase(locateBranches.getLocation().getLatitude())
				&& !(GenericConstants.NULL_STRING).equalsIgnoreCase(locateBranches.getLocation().getLatitude())) {
			if(resp.equalsIgnoreCase(GenericConstants.EMPTY_STRING)) {
				resp="\r\n"+GenericConstants.LOCATION_LATITUDE+locateBranches.getLocation().getLatitude()+GenericConstants.COMMA+"\n";
			}
			else {
				resp=resp+GenericConstants.LOCATION_LATITUDE+locateBranches.getLocation().getLatitude()+GenericConstants.COMMA+"\n";
			}
		}
		if(locateBranches.getLocation().getLatitude()!=null && !(GenericConstants.EMPTY_STRING).equalsIgnoreCase(locateBranches.getLocation().getLatitude())
				&& !(GenericConstants.NULL_STRING).equalsIgnoreCase(locateBranches.getLocation().getLatitude())) {
			if(resp.equalsIgnoreCase(GenericConstants.EMPTY_STRING)) {
				resp="\r\n"+GenericConstants.LOCATION_LONGITUDE+locateBranches.getLocation().getLatitude()+GenericConstants.COMMA+"\n";
			}
			else {
				resp=resp+GenericConstants.LOCATION_LONGITUDE+locateBranches.getLocation().getLatitude()+GenericConstants.COMMA+"\n";
			}
		}
		System.err.println("\r\n"+"Branch Address:"+"\n"+resp.substring(0,resp.lastIndexOf(',')));
		if(!resp.equalsIgnoreCase(GenericConstants.EMPTY_STRING))
		{
			resp = "\n"+"Branch Address:"+"\n"+resp.substring(0,resp.lastIndexOf(','))+".";
			return resp;
		}
		return resp;
	}

	public ShareBrachDetailsResBean generateShareBrachDetailsResponse(int count, ShareBranchDetailsReqBean shareBranchDetailsReqBean,
			boolean isMessageSent, boolean isMailSent, Map<String,String> errorMap) {
		ShareBrachDetailsResBean shareBrachDetailsResBean=new ShareBrachDetailsResBean();
		if(count>1) {
			if(isMessageSent && isMailSent) {
				shareBrachDetailsResBean.setMessage(messageConstants.getBothSmsAndMail());
				shareBrachDetailsResBean.setStatus(GenericConstants.SUCCESS);
			}
			else if(isMessageSent && !isMailSent) {
				if(errorMap.containsKey("Mail")){
					shareBrachDetailsResBean.setMessage("Branch Location shared partially - Email id is not valid");
				}else {
					shareBrachDetailsResBean.setMessage(messageConstants.getBranchLocationSharedPartiallyEmailFailed());
				}
				shareBrachDetailsResBean.setStatus(GenericConstants.FAILED);
			}
			else if(!isMessageSent && isMailSent) {
				if(errorMap.containsKey("Number")){
					shareBrachDetailsResBean.setMessage("Branch Location shared partially - Mobile number is not valid");
				}
				else {
					shareBrachDetailsResBean.setMessage(messageConstants.getBranchLocationSharedPartiallySmsFailed());
				}
				shareBrachDetailsResBean.setStatus(GenericConstants.FAILED);
			}
			else
			{
				if(errorMap.containsKey("Number") && errorMap.containsKey("Mail")){
					shareBrachDetailsResBean.setMessage("Sharing Branch Location Failed - Both mobile number and email id is not valid");
				}
				else {
					shareBrachDetailsResBean.setMessage(messageConstants.getBranchLocationSharedPartiallySmsFailed());
				}
				shareBrachDetailsResBean.setMessage(messageConstants.getSharingBranchLocationFailed());
				shareBrachDetailsResBean.setStatus(GenericConstants.FAILED);
			}
		}
		else
		{
			if(!HrAppUtil.isNullOrEmpty(shareBranchDetailsReqBean.getMobileNo())){
				if(isMessageSent)
				{
					shareBrachDetailsResBean.setMessage(messageConstants.getSmsSendSuccessfully());
					shareBrachDetailsResBean.setStatus(GenericConstants.SUCCESS);
				}
				else
				{
					if(errorMap.containsKey("Number")){
						shareBrachDetailsResBean.setMessage("Sending ams failed - mobile number is not valid");
					}else {
						shareBrachDetailsResBean.setMessage(messageConstants.getSendingEmailFailed());
					}
					shareBrachDetailsResBean.setMessage(messageConstants.getSendingSmsFailed());
					shareBrachDetailsResBean.setStatus(GenericConstants.FAILED);
				}
			}
			else {
				if(isMailSent)
				{
					shareBrachDetailsResBean.setMessage(messageConstants.getSendingEmailSuccessfuly());
					shareBrachDetailsResBean.setStatus(GenericConstants.SUCCESS);
				}
				else
				{
					if(errorMap.containsKey("Mail")){
						shareBrachDetailsResBean.setMessage("Sending email failed - email id is not valid");
					}else {
						shareBrachDetailsResBean.setMessage(messageConstants.getSendingEmailFailed());
					}
					shareBrachDetailsResBean.setStatus(GenericConstants.FAILED);
				}
			}
		}
		return shareBrachDetailsResBean;
	}
	
	private String generateDateForCheckInCheckout(String dateTime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(GenericConstants.PATTERN_CHECK_IN_CHECK_OUT);
		LocalDateTime date = LocalDateTime.parse(generateDateTimeFormatForCheckInCheckOut(dateTime), formatter);
		return String.valueOf(date.toLocalDate());
	}
	
	private String generateTimeForCheckInCheckout(String dateTime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(GenericConstants.PATTERN_CHECK_IN_CHECK_OUT);
		LocalDateTime date = LocalDateTime.parse(generateDateTimeFormatForCheckInCheckOut(dateTime), formatter);
		return String.valueOf(date.toLocalTime());
	}
	
	private String generateDateTimeFormatForCheckInCheckOut(String dateTime) {
		String[] dateParam = dateTime.split(" ");
		String data = "";
		for(int i=0;i<dateParam.length;i++){
			if(data.equals("") && !dateParam[i].equalsIgnoreCase("")){
				data = dateParam[i].trim();
			}
			else {
				if(!dateParam[i].equalsIgnoreCase(""))
				{
					data = data+" "+dateParam[i].trim();
				}
			}
		}
		return data;
	}

	/**
	 * This method will translate RNLIC response to wrapper service response 
	 * @param ChangePasswordRnlicResponseBean response
	 * @return ChangePasswordResBean changePasswordResBean
	 */
	public ChangePasswordResBean getChangePasswordResponse(ChangePasswordRnlicResponseBean response) {
		
		ChangePasswordResBean changePasswordResBean = new ChangePasswordResBean(); 
		if (!HrAppUtil.isNullOrEmpty(response)) {
			if(GenericConstants.OTP_GENERATED_SUCCESS.equalsIgnoreCase(response.getMessage().get(GenericConstants.RETURN_MESSAGE))) {
				changePasswordResBean.setMessage(messageConstants.getSuccessOtpGenerated());
			}else if(GenericConstants.PASSWORD_CHANGED_SUCCESS.equalsIgnoreCase(response.getMessage().get(GenericConstants.RETURN_MESSAGE))) {
				changePasswordResBean.setMessage(messageConstants.getPasswordChangedSuccess());
			}
			changePasswordResBean.setStatus(response.getStatus());
		}
		return changePasswordResBean;
	}

	/**
	 *  This method will translate API response to wrapper service.
	 * @param NoticesRnlicResponseBean response
	 * @return NoticesResBean notices
	 */
	public NoticesResBean getNotices(NoticesRnlicResponseBean response) {
		NoticesResBean notices = new NoticesResBean();
		if (!HrAppUtil.isNullOrEmpty(response) && !HrAppUtil.isNullOrEmpty(response.getResponse())) {
			response.getResponse().stream().forEach(noticeDetails ->{
				NoticeDetails notice = new NoticeDetails();
				notice.setCreatedOn(getDateTime(noticeDetails.getCreatedOn()));
				notice.setLink(HrAppUtil.isNullOrEmpty(noticeDetails.getLink())?GenericConstants.EMPTY_STRING:noticeDetails.getLink());
				notice.setName(HrAppUtil.isNullOrEmpty(noticeDetails.getShortDescription())?GenericConstants.EMPTY_STRING:noticeDetails.getShortDescription());
				notice.setType(HrAppUtil.isNullOrEmpty(noticeDetails.getDocumentType())?GenericConstants.EMPTY_STRING:String.join("", noticeDetails.getDocumentType()));
				notice.setDescription(HrAppUtil.isNullOrEmpty(noticeDetails.getDescription())?GenericConstants.EMPTY_STRING:noticeDetails.getDescription());
				notices.getNotices().add(notice);
			});
		}
		return notices;
	}
	
	private String getDateTime(String date) {
		String checkTime=null;
		if(!HrAppUtil.isNullOrEmpty(date)) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(GenericConstants.PATTERN_YYYY_MM_DD_T_HH_MM_SS);
		date=date.replaceAll(GenericConstants.DOUBLE_SPACE, GenericConstants.WHITE_SPACE);
		date = date.substring(GenericConstants.INTEGER_ZERO, date.indexOf('.'));
	    LocalDateTime dateTime = LocalDateTime.parse(date, formatter);
	    DateTimeFormatter format1 = DateTimeFormatter.ofPattern(GenericConstants.PATTERN_YYYY_MM_DD_HH_MM_SS); 
	    checkTime = dateTime.format(format1);
		}else {
			checkTime =GenericConstants.WHITE_SPACE;
		}
		return checkTime;
	}

	public SubscriptionResponseList getSubscription(SubscriptionRnlicResBean response) {
		SubscriptionResponseList res = new SubscriptionResponseList();
		response.getResponse().stream().forEach(x->res.getSubscriptionList().add(x));
		return res;
	}
	
	public SendOtpMobileResBean genarateOTPResponse(SendOtpMobileResBean sendOtpMobileResBean,UserDetailsBean empReqBean, 
			boolean isOtpSent, boolean isMailSent,  MessagesConstants messagesConstants, OtpMasterModel otpEntity) {
		if(HrAppUtil.isNullOrEmpty(empReqBean.getEmail()))
		{
			if(isOtpSent) {
				sendOtpMobileResBean.setStatus(true);
				sendOtpMobileResBean.setMessage(messagesConstants.getSentOtpSuccessMsg() + otpEntity.getMobileNumber()
				+ GenericConstants.VALID_UPTO + otpEntity.getValidUpto()+" OTP_PT"+otpEntity.getOtpValue()+"TEST");
				sendOtpMobileResBean.setValidUpto(otpEntity.getValidUpto());
			}
			else {
				sendOtpMobileResBean.setStatus(false);
			}
		}
		else
		{
			if(isOtpSent && isMailSent) {
				sendOtpMobileResBean.setStatus(true);
				sendOtpMobileResBean.setMessage("OTP sent in both email "+empReqBean.getEmail()+" and on mobile number "+ otpEntity.getMobileNumber()
				+ GenericConstants.VALID_UPTO + otpEntity.getValidUpto()+" OTP_PT"+otpEntity.getOtpValue()+".");
				sendOtpMobileResBean.setValidUpto(otpEntity.getValidUpto());
			}
			else if(isOtpSent && !isMailSent){
				sendOtpMobileResBean.setStatus(false);
				sendOtpMobileResBean.setMessage(messagesConstants.getSentOtpSuccessMsg() + otpEntity.getMobileNumber()
				+ GenericConstants.VALID_UPTO + otpEntity.getValidUpto()+" OTP_PT"+otpEntity.getOtpValue()+"");
				sendOtpMobileResBean.setValidUpto(otpEntity.getValidUpto());
			}
			else if(!isOtpSent && isMailSent){
				sendOtpMobileResBean.setStatus(false);
				sendOtpMobileResBean.setMessage("OTP sent in email " + empReqBean.getEmail()
				+ GenericConstants.VALID_UPTO + otpEntity.getValidUpto()+" OTP_PT"+otpEntity.getOtpValue()+".");
				sendOtpMobileResBean.setValidUpto(otpEntity.getValidUpto());
			}
			else {
				sendOtpMobileResBean.setStatus(false);
			}
		}
		return sendOtpMobileResBean;
	}

	public MessageTemplate generateMessageTemplate(SmsTemplateRnlicResponse data, String wishFor) {
		MessageTemplate response = new MessageTemplate();
		if(("anniversary").equalsIgnoreCase(wishFor)) {
			response.setMessage(data.getResponse().get(0).getAnniversaryMsg());
		}
		else {
			response.setMessage(data.getResponse().get(0).getBirthdayMsg());
		}
		return response;
	}
}