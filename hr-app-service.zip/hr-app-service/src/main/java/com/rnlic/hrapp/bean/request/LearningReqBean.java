package com.rnlic.hrapp.bean.request;

public class LearningReqBean {

}
