package com.rnlic.hrapp.bean.api.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CandidateRnlicResponseBean extends RnlicRestResponse{
	
	@JsonProperty(value = "Response")
	List<CandidateDetailsRnlicResponseBean> response;

	public CandidateRnlicResponseBean() {
		super();
	}

	public CandidateRnlicResponseBean(List<CandidateDetailsRnlicResponseBean> response) {
		super();
		this.response = response;
	}

	public List<CandidateDetailsRnlicResponseBean> getResponse() {
		return response;
	}

	public void setResponse(List<CandidateDetailsRnlicResponseBean> response) {
		this.response = response;
	}	
}
