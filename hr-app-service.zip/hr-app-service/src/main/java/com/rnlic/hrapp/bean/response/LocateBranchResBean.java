package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

public class LocateBranchResBean implements ResponseData{
	
	private List<LocateBranches> branches=new ArrayList<>();

	public List<LocateBranches> getBranches() {
		return branches;
	}

	public void setBranches(List<LocateBranches> branches) {
		this.branches = branches;
	}
}
