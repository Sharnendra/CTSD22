package com.rnlic.hrapp.util;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.beans.XMLEncoder;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;

import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.exception.ExecutionException;

public abstract class HrAppUtil {

	private static final SecretKeySpec secKey = new SecretKeySpec(("yuybrtRhHoPN9xHz").getBytes(), "AES");

	private static String autoritiesRole = "";

	public static String generateRequestId() {
		return UUID.randomUUID().toString();
	}
	
	public static int generateOtp(int length) {
		int initialValue = 1;
		int maxValue=9;
		for(int i=1;i<length;i++) {
			initialValue = initialValue * 10;
			maxValue = (initialValue * 10)-1;
		}
		return new Random().ints(initialValue,(maxValue+1)).findFirst().getAsInt();
	}
	
	public static String returnBlankWhenNull(String st)
	{
		if(null==st)
		{
			return "";
		}
		else {
			return st;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static Map<String,String> mapFromJson(String jsonString) throws JsonParseException, JsonMappingException, IOException {
		/**String autoritiesRole="\"[{\"AML_KYC\":\"COMPLETED\",\"ULIP\":\"COMPLETED\",\"Infosec\":\"COMPLETED\"}]";*/
		ObjectMapper mapper=new ObjectMapper();
		String data =new String(jsonString.substring(jsonString.indexOf("[", 0)+1, jsonString.indexOf("]", 0)));
		Map<String,String> result =	mapper.readValue(data, LinkedHashMap.class);
		return result;
	}
	
	public static String roleMapper(List<String> list) {
		if (list != null && !list.isEmpty()) {
			list.stream().forEach(string -> {
				if (string == null) {
					autoritiesRole = "";
				} else {
					if (autoritiesRole.equalsIgnoreCase("")) {
						autoritiesRole = string;
					} else {
						autoritiesRole = autoritiesRole + "," + string;
					}
				}
			});
		}

		if (autoritiesRole.equalsIgnoreCase("")) {
			autoritiesRole = "null";
		}
		return autoritiesRole;
	}

	/**
	 * This method checks whether the source String is empty.
	 *
	 * @param source String
	 * @return true if source is empty, false if source is not empty.
	 */
	public static boolean isNullOrEmpty(String source) {

		return (null == source || "".equals(source.trim()));
	}

	/**
	 * This method checks whether the source Collection is empty.
	 *
	 * @param source Collection
	 * @return true if source Collection is empty, false if source Collection is not
	 *         empty.
	 */
	public static boolean isNullOrEmpty(Collection<?> source) {

		return (null == source || source.isEmpty());
	}

	/**
	 * This method checks whether the source Object is empty.
	 *
	 * @param source Object
	 * @return true if source is empty, false if source is not empty.
	 */
	public static boolean isNullOrEmpty(Object source) {

		return (null == source);
	}

	/**
	 * This method checks whether the source array is empty.
	 *
	 * @param source Object[]
	 * @return true if source array is empty, false if source array is not empty.
	 */
	public static boolean isNullOrEmpty(Object[] source) {

		return (null == source || source.length <= 0);
	}

	/**
	 * This method checks whether the source String is not empty.
	 *
	 * @param source String
	 * @return true if source is not empty, false if source is empty.
	 */
	public static boolean isNotEmpty(String source) {

		return !isNullOrEmpty(source);
	}

	/**
	 * This method checks whether the source Collection is not empty.
	 *
	 * @param source Collection
	 * @return true if source Collection is not empty, false if source Collection is
	 *         empty.
	 */
	public static boolean isNotEmpty(Collection<?> source) {

		return !isNullOrEmpty(source);
	}

	/**
	 * This method checks whether the source Object is not empty.
	 *
	 * @param source Object
	 * @return true if source is not empty, false if source is empty.
	 */
	public static boolean isNotEmpty(Object source) {

		return !isNullOrEmpty(source);
	}

	/**
	 * This method checks whether the source Object[] is not empty.
	 *
	 * @param source Object[]
	 * @return true if source array is not empty, false if source array is empty.
	 */
	public static boolean isNotEmpty(Object[] source) {

		return !isNullOrEmpty(source);
	}

	public static String getXml(Object message) {

		try {
			StringWriter writer = new StringWriter();
			String xmlString = "";

			JAXBContext jaxbContext = JAXBContext.newInstance(message.getClass());
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			jaxbMarshaller.marshal(message, writer);
			xmlString = writer.toString();
			return xmlString;
		} catch (JAXBException e) {
			throw new ExecutionException("runtime exception", "runtime exception", false);
		}

	}

	public static Object getObject(String xmlMessage, Class<?> clazz) {

		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			return unmarshaller.unmarshal(new StringReader(xmlMessage));
		} catch (JAXBException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * This method checks whether the source Object[] is not empty.
	 *
	 * @param source Object
	 * @return Object[] if source array irrespective of primitive or other object
	 *         array, If source is not an object return null;
	 */
	public static Object[] toObjectArray(Object arrayObj) {
		if (arrayObj.getClass().isArray()) {
			if (arrayObj instanceof Object[]) {
				return (Object[]) arrayObj;
			} else {
				int length = Array.getLength(arrayObj);
				Object[] ret = new Object[length];
				for (int i = 0; i < length; i++)
					ret[i] = Array.get(arrayObj, i);
				return ret;
			}

		}
		return null;
	}

	/**
	 * This method will display the content of the passed java bean. <br/>
	 * It will return a String which contains name and value of all properties of
	 * that bean.
	 *
	 * @param bean object to be displayed
	 * @return String
	 * @author Suman(Cognizant)
	 */

	private static String getIndentString(int indent) {
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < indent; i++) {
			buf.append("\t");
		}
		return buf.toString();
	}

	@SuppressWarnings("rawtypes")
	private static String displayBean(Object bean, int indent) {
		StringBuffer buf = new StringBuffer(256);
		String indentString = getIndentString(indent);
		if (null == bean) {
			return "Input Bean object is null";
		}

		if (bean.getClass().isPrimitive()) {
			return indentString + bean;
		} else if (bean instanceof String) {
			return indentString + (String) bean;
		} else if (isCollection(bean)) {
			return displayCollectionBean((Collection<?>) bean, indent);
		} else if (isArray(bean)) {
			return displayArrayBean((Object[]) bean, indent);
		} else if (isMap(bean)) {
			return displayMapBean((Map) bean, indent);
		}

		Class<?> beanClass = bean.getClass();
		String beanName = beanClass.getSimpleName();
		BeanInfo sourceBeanInfo = null;

		try {
			sourceBeanInfo = Introspector.getBeanInfo(beanClass);
		} catch (IntrospectionException e) {
			// TODO: Log error
		}

		PropertyDescriptor[] beanPropDescArr = sourceBeanInfo.getPropertyDescriptors();
		Method getterMethod = null;
		Method setterMethod = null;
		String beanPropertyName = null;

		buf.append(indentString + "[ " + beanName + ": \n");
		for (int i = 0; i < beanPropDescArr.length; i++) {
			getterMethod = beanPropDescArr[i].getReadMethod();
			setterMethod = beanPropDescArr[i].getWriteMethod();
			beanPropertyName = beanPropDescArr[i].getName();
			// ApplicationLogger.getInstance().trace("sourcePropDescArr[i].getReadMethod()
			// :"+getterMethod);
			// ApplicationLogger.getInstance().trace("targetPropDescArr[i].getWriteMethod()
			// :"+setterMethod);
			// ApplicationLogger.getInstance().trace("sourcePropDescArr["+i+"].getName()
			// :"+beanPropertyName);

			if (beanPropertyName != null && getterMethod != null && setterMethod != null) {
				try {
					buf.append(getIndentString(indent + 1) + beanPropertyName + "=");

					Object beanPropertyValue = null;
					try {
						beanPropertyValue = getterMethod.invoke(bean);
					} catch (InvocationTargetException e) {

						// TODO: Log error
					}

					if (beanPropertyValue != null) {

						if (beanPropertyValue.getClass().isPrimitive()) {
							buf.append(beanPropertyValue).append("\n");
						} else if (isBean(beanPropertyValue)) {
							buf.append(displayBean(beanPropertyValue, indent + 1) + "\n");
						} else if (isCollection(beanPropertyValue)) {
							buf.append(displayCollectionBean((Collection<?>) beanPropertyValue, indent + 1));
						} else if (isMap(beanPropertyValue)) {
							buf.append(displayMapBean((Map) beanPropertyValue, indent + 1));
						} else if (isArray(beanPropertyValue)) {
							buf.append("\n[");
							for (int j = 0; j < Array.getLength(beanPropertyValue); j++) {
								Object arrayElement = Array.get(beanPropertyValue, j);
								if (isBean(arrayElement)) {
									buf.append(displayBean(arrayElement, indent + 1));
								} else {
									buf.append(arrayElement);
								}
								buf.append(getIndentString(indent + 1) + "\n, ");
							}
							buf.append("]\n ");
						} else
							buf.append(beanPropertyValue + "\n");
					} else {
						buf.append(beanPropertyValue + "\n");
					}
				} catch (IllegalAccessException e) {
					throw new RuntimeException(e);
				}
			}
//            buf.append(" \n");
		}

		buf.append("]\n");
		return buf.toString();
	}

	public static String displayBean(Object bean) {
		return displayBean(bean, 0);
	}

	/**
	 * This method will display the content of the passed array of Objects. <br/>
	 * It will return a String which contains name and value of all properties of
	 * each object of the array.
	 *
	 * @param objArray i.e array of Object to be displayed
	 * @return String
	 * @author Suman(Cognizant)
	 */
	public static String displayArrayBean(Object[] objArray, int indent) {
		StringBuffer buf = new StringBuffer(256);

		if (isNotEmpty(objArray)) {
			buf.append(getIndentString(indent) + "{\n");
			for (Object arrayElement : objArray) {
				if (isBean(arrayElement)) {
					buf.append(displayBean(arrayElement, indent + 1));
				} else {
					buf.append(getIndentString(indent + 1) + arrayElement);
				}
				buf.append(getIndentString(indent + 1) + "\n, ");
			}
			buf.append(getIndentString(indent) + "}\n");
		} else {
			return "Input array object provided is null or empty";
		}

		return buf.toString();
	}

	/**
	 * This method will display the content of the passed collection of Objects.
	 * <br/>
	 * It will return a String which contains name and value of all properties of
	 * each object of the collection.
	 *
	 * @param collection i.e Collection of Object to be displayed
	 * @return String
	 * @author Suman(Cognizant)
	 */
	private static String displayCollectionBean(Collection<?> collection, int indent) {
		StringBuffer buf = new StringBuffer(256);

		int index = 0;
		if (isNotEmpty(collection)) {
			buf.append(getIndentString(indent) + "{");
			Iterator<?> itr = collection.iterator();
			Object element = null;

			while (itr.hasNext()) {
				element = itr.next();
				if (isNotEmpty(element)) {
					if (isBean(element)) {
						buf.append("\n" + displayBean(element, indent + 1));
					} else if (isCollection(element)) {
						buf.append("\n" + displayCollectionBean((Collection<?>) element, indent + 1));
					} else {
						buf.append("\n" + getIndentString(indent + 1) + (index > 0 ? "," : "") + element);
					}

				}
				index++;
			}
			buf.append("\n}\n");
		} else {
			return "Input Collection object provided is null or empty";
		}

		return buf.toString();
	}

	@SuppressWarnings("rawtypes")
	private static String displayMapBean(Map<?, ?> map, int indent) {
		StringBuffer buf = new StringBuffer(256);

		if (isNotEmpty(map)) {
			buf.append(getIndentString(indent) + "{\n");
			Iterator<?> itr = map.entrySet().iterator();
			Entry element = null;
			int index = 0;
			while (itr.hasNext()) {
				element = (Entry) itr.next();

				if (index > 0) {
					buf.append(getIndentString(indent + 1));
					buf.append(",\n");
					buf.append(getIndentString(indent + 1));
				} else {
					buf.append(getIndentString(indent + 1));
				}
				buf.append("[\n " + getIndentString(indent + 1) + "KEY : " + element.getKey() + "\n");
				buf.append(getIndentString(indent + 1));
				buf.append("VALUE : \n" + displayBean(element.getValue(), indent + 1)).append("\n")
						.append(getIndentString(indent + 1)).append("]\n");
				index++;
//
			}
			buf.append(getIndentString(indent) + "}\n");
		} else {
			return "Input Map object provided is null or empty";
		}

		return buf.toString();
	}

	/**
	 * This will check whether the passed object is a Java Bean or not.
	 *
	 * @param bean Object
	 * @return isBean - boolean
	 * @author Suman(Cognizant)
	 */
	private static boolean isBean(Object bean) {
		boolean isBean = false;
		BeanInfo sourceBeanInfo = null;

		try {
			sourceBeanInfo = Introspector.getBeanInfo(bean.getClass());
			PropertyDescriptor[] beanPropDescArr = sourceBeanInfo.getPropertyDescriptors();
			Method getterMethod = null;
			Method setterMethod = null;
			String beanPropertyName = null;

			for (int i = 0; i < beanPropDescArr.length; i++) {
				getterMethod = beanPropDescArr[i].getReadMethod();
				setterMethod = beanPropDescArr[i].getWriteMethod();
				beanPropertyName = beanPropDescArr[i].getName();

				if (!beanPropertyName.equals("class")) {
					if (getterMethod == null || setterMethod == null) {
						isBean = false;
					} else {
						isBean = true;
						break;
					}
				}
			}
		} catch (IntrospectionException e) {
			// TODO: Log error
		}

		return isBean;
	}

	/**
	 * This will check whether the source object is an Collection or not.
	 *
	 * @param source Object
	 * @return isCollection - boolean
	 * @author Suman(Cognizant)
	 */
	private static boolean isCollection(Object source) {
		boolean isCollection = false;
		isCollection = (source instanceof Collection) ? Boolean.TRUE : Boolean.FALSE;
		return isCollection;
	}

	private static boolean isMap(Object source) {
		boolean isMap = false;
		isMap = (source instanceof Map<?, ?>) ? Boolean.TRUE : Boolean.FALSE;
		return isMap;
	}

	/**
	 * This will check whether the source object is an Array or not.
	 *
	 * @param source Object
	 * @return isArray - boolean
	 * @author Suman(Cognizant)
	 */
	public static boolean isArray(Object source) {
		boolean isArray = false;
		isArray = source.getClass().isArray();
		return isArray;
	}

	public static String serializeObject(Object obj) {
		String result = null;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		XMLEncoder encoder = new XMLEncoder(bos);
		encoder.writeObject(obj);
		encoder.flush();
		encoder.close();
		result = bos.toString();
		return result;
	}

	public static String encryptAES(String plainText) throws Exception {
		// AES defaults to AES/ECB/PKCS5Padding in Java 7
		Cipher aesCipher = Cipher.getInstance("AES");
		aesCipher.init(Cipher.ENCRYPT_MODE, secKey);
		byte[] byteCipherText = aesCipher.doFinal(plainText.getBytes());
		return DatatypeConverter.printBase64Binary(byteCipherText);
	}

	public static String decryptAES(String cipherText) throws GeneralSecurityException {
		// AES defaults to AES/ECB/PKCS5Padding in Java 7
		Cipher aesCipher = Cipher.getInstance("AES");
		aesCipher.init(Cipher.DECRYPT_MODE, secKey);
		byte[] byteCipherText = DatatypeConverter.parseBase64Binary(cipherText);
		byte[] bytePlainText = aesCipher.doFinal(byteCipherText);
		return new String(bytePlainText);
	}

	public static String dateTimeFormator(Date validUpto) {
		return new SimpleDateFormat(GenericConstants.PATTERN).format(validUpto);
	}

	public static String dateFormator(Date date) {
		return new SimpleDateFormat(GenericConstants.PATTERN_YYYY_MM_DD).format(date);
	}
}
