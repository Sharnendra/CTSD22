package com.rnlic.hrapp.service;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.bean.response.UpdateLearningCompletionResBean;
import com.rnlic.hrapp.security.UserDetailsBean;
//import com.rnlic.hrapp.security.ValidateRegistry;
import com.rnlic.hrapp.util.RequestLogDeatils;

@Service
public class LearningService {

	private static final Logger log = LogManager.getLogger(LearningService.class);
	
	@Autowired
	private RnlicService rnlicService;
	
	@Autowired
	private RequestLogDeatils requestLog;
	
	//@ValidateRegistry
	/**
	 * This service call rnlic service to get mandatory learnings details
	 * @param UserDetailsBean empReqBean
	 * @return MandatoryLearningResBean mandatoryLearningResBean
	 */
	public ResponseData getMandatoryLearning() {
		log.info(requestLog+ "== getMandatoryLearning service start :=====");
		//call rnlic getMandatoryLearnings service
		return rnlicService.getMandatoryLearning();
	}

	//@ValidateRegistry
	/**
	 * method return current learning status.
	 * @param UserDetailsBean empReqBean
	 * @return ResponseData ResponseData
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	public ResponseData getMandatoryLearningStatus(UserDetailsBean empReqBean) throws JsonParseException, JsonMappingException, IOException {
		log.info(requestLog+ "== getMandatoryLearningStatus service start :=====");
		//call rnlic getMandatoryLearnings service
		return rnlicService.getMandatoryLearningStatus(empReqBean);
	}

	//@ValidateRegistry
	/**
	 * it will call RNLIC service to update learning status.
	 * @param UserDetailsBean empReqBean
	 * @param String learningId
	 * @return UpdateLearningCompletionResBean response
	 */
	public ResponseData updateLearningCompletionStatus(UserDetailsBean empReqBean, String learningId) {
		log.info(requestLog+ "== updateLearningCompletionStatus service start :=====");
		UpdateLearningCompletionResBean response = new UpdateLearningCompletionResBean();
		response.setHasUpdated(rnlicService.updateLearningCompletion(empReqBean, learningId));
		response.setLearningId(learningId);
		log.info(requestLog+ "== updateLearningCompletionStatus service end :=====");
		return response;
	}
	

	
}
