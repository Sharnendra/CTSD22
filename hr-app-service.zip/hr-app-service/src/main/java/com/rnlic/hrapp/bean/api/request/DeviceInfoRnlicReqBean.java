package com.rnlic.hrapp.bean.api.request;

public class DeviceInfoRnlicReqBean {
	
	private String SAPCode;
	private String MobileNo;
	private String DeviceIdentifier;
	private String FCMToken;
	public String getFCMToken() {
		return FCMToken;
	}
	public void setFCMToken(String fCMToken) {
		FCMToken = fCMToken;
	}
	public String getSAPCode() {
		return SAPCode;
	}
	public void setSAPCode(String sAPCode) {
		SAPCode = sAPCode;
	}
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}
	public String getDeviceIdentifier() {
		return DeviceIdentifier;
	}
	public void setDeviceIdentifier(String deviceIdentifier) {
		DeviceIdentifier = deviceIdentifier;
	}
	

}
