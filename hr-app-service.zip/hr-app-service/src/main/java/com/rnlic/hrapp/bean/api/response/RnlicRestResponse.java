package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class RnlicRestResponse implements RnlicResponse{
	
	@JsonProperty(value = "Status")
	private String status;
	@JsonProperty(value = "Message")
	private String message;
	public RnlicRestResponse() {
		super();
	}
	public RnlicRestResponse(String status, String message) {
		super();
		this.status = status;
		this.message = message;
	}
	public String getStatus() {
		return this.status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return this.message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "RNLICRestResponse [status=" + status + ", message=" + message + "]";
	}
}
