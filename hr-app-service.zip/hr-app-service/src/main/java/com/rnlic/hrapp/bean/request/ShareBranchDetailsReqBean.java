package com.rnlic.hrapp.bean.request;

import com.rnlic.hrapp.bean.response.LocateBranches;

public class ShareBranchDetailsReqBean {

	private String mobileNo;
	private String emailAddress;
	private LocateBranches locateBranches;
	
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public LocateBranches getLocateBranches() {
		return locateBranches;
	}
	public void setLocateBranches(LocateBranches locateBranches) {
		this.locateBranches = locateBranches;
	}
}
