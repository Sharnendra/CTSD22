package com.rnlic.hrapp.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.rnlic.hrapp.constant.QueryConstants;
import com.rnlic.hrapp.entity.OtpMasterModel;

@Repository
public interface OtpRepository extends JpaRepository<OtpMasterModel, Long>{

//	@Query(QueryConstants.OTPREPO_FIND_BY_USER_ID)
//	OtpMasterModel findByUserId(@Param("mobile_number") String mobile_number, @Param("otp_value") int otp_value);
	
	@Query(QueryConstants.OTPREPO_GET_OTP_DETAILS)
	OtpMasterModel getOtpDetails(@Param("sap_code") String sap_code, @Param("mobile_number")String mobile_number,@Param("action") String action, @Param("device_identifier") String device_identifier,@Param("currentTime") Date currentTime);
	
	@Transactional
	@Query(QueryConstants.OTPREPO_UPDATE_RESEND_COUNT)
	void updateResendCount(@Param("resend_count") int resend_count );

	@Transactional
	@Modifying
	@Query(QueryConstants.OTPREPO_DELETE_EXPIRED_OTP_RECORD)
	void deleteExpiredOTPRecord();
	
	@Query(value = QueryConstants.OTPREPO_GET_OTP,nativeQuery = true)
	List<Object[]> getOtp(@Param("sapCode") String sapCode,@Param("mobileNumber") String mobileNumber);
}
