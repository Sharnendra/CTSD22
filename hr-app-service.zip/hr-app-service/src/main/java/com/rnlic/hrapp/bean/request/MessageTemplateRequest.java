package com.rnlic.hrapp.bean.request;

public class MessageTemplateRequest {

	private String wishFor;
	private String wishType;
	public String getWishFor() {
		return wishFor;
	}
	public void setWishFor(String wishFor) {
		this.wishFor = wishFor;
	}
	public String getWishType() {
		return wishType;
	}
	public void setWishType(String wishType) {
		this.wishType = wishType;
	}
}
