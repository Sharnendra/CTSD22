package com.rnlic.hrapp.service;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import com.rnlic.hrapp.bean.request.AuthReqBean;
import com.rnlic.hrapp.bean.response.AuthResBean;
import com.rnlic.hrapp.bean.response.CheckForDeviceRegistrationResBean;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.bean.response.User;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.exception.DeviceRegistrationException;
import com.rnlic.hrapp.exception.NoSuchUserExists;
import com.rnlic.hrapp.exception.RnlicResponseException;
import com.rnlic.hrapp.exception.UserDetailsDoesNotExist;
import com.rnlic.hrapp.security.JwtGenerator;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestLogDeatils;

@Service
public class AuthenticationAuthorizationService {

	private static final Logger log = LogManager.getLogger(AuthenticationAuthorizationService.class);

	public AuthenticationAuthorizationService(JwtGenerator jwtGenerator) {
		this.jwtGenerator = jwtGenerator;
	}

	private JwtGenerator jwtGenerator;

	@Autowired
	private RnlicService rnlicService;

	@Autowired
	private DeviceRegistrationService deviceService;

	@Autowired
	private MessagesConstants messagesConstants;

	@Autowired
	private RequestLogDeatils requestLog;

	public ResponseData getEmployeeDetails(UserDetailsBean empReqBean) throws RestClientException, IOException {
		User userDetails = null;
		if (empReqBean.isCandidate()) {
			log.info(requestLog+messagesConstants.getServiceForCandidateDetailsMsg());
			userDetails = rnlicService.getCandidateDtlsFromRnlic(empReqBean);
		} else {
			log.info(requestLog+messagesConstants.getServiceForEmployeeDetailsMsg());
			userDetails = rnlicService.getEmpDetailsFromRnlic(empReqBean);

		}
		return userDetails;
	}

	// Sharnendra: Used to acces reliance DB and get candidate/ Employee details
	// before generating JWT token....
	private UserDetailsBean getAuthenticationData(AuthReqBean authReqBean, AuthResBean authRes) throws RestClientException, IOException {

		UserDetailsBean userDetailsBean =  createUserDetailsBean(authReqBean);
		User userDetails = null;
		if (authReqBean.getIsCandidate()) {

			if (rnlicService.getCandidateAuthentication(authReqBean)) {
				log.info(requestLog+"After Calling RnlicService to Authenticate candidate ");
				/*
				 * Getting inside this Block means Candidate is Authorized and it's Status is
				 * returned as Success from the Service.
				 * This function will return the Candidate Details
				 */
				userDetails = (User) getEmployeeDetails(userDetailsBean);
				log.info(requestLog+"After Calling RnlicService to get candidate Details ");
				createUserDetailsBean(userDetailsBean, userDetails,authRes);
				if(!userDetails.getMobileNo().equalsIgnoreCase(authReqBean.getMobileNumber())) {
					log.info(requestLog+messagesConstants.getDataNotUpdated());
					throw new RnlicResponseException(GenericConstants.EXCEPTION,messagesConstants.getDataNotUpdated());
				}
			}
		} else {
			log.info(requestLog+"Before Calling RnlicService to Authenticate Employee ");
			if (rnlicService.getEmployeeAuthentication(authReqBean)) {
				log.info(requestLog+"After Calling RnlicService to Authenticate Employee ");
				/*
				 * Getting inside this Block means Employee is Authorized and it's Status is
				 * returned as Success from the Service.
				 * This function will return the Employee Details
				 */
				userDetails = (User) getEmployeeDetails(userDetailsBean);
				log.info(requestLog+"======After getting employee Details===");
				createUserDetailsBean(userDetailsBean, userDetails,authRes);
			}
		}
		return userDetailsBean;
	}

	/*
	 * This Function is Responsible for Creating JWT Token and the response
	 * structure for Authenticate Service.
	 */
	private void createAuthResponse(final UserDetailsBean jwtUser, AuthResBean authRes) {
		log.info(requestLog+ "== createAuthResponse Creating Authorize token:=====");
		authRes.setToken(jwtGenerator.generate(jwtUser));
	}

	private UserDetailsBean createUserDetailsBean(AuthReqBean authReqBean) {
		log.info(requestLog+ "== createUserDetailsBean Creating User details:=====");
		UserDetailsBean userDetailsBean = new UserDetailsBean();
		userDetailsBean.setCandidate(authReqBean.getIsCandidate());
		userDetailsBean.setDeviceIdentifier(authReqBean.getDeviceIdentifier());
		userDetailsBean.setFcmToken(authReqBean.getFcmToken());
		if(authReqBean.getIsCandidate()) {
			userDetailsBean.setMobileNumber(authReqBean.getMobileNumber());
			userDetailsBean.setPanNumber(authReqBean.getPanNumber());
		}else {
			userDetailsBean.setSapCode(authReqBean.getSapCode());
		}
		return userDetailsBean;
	}

	private void createUserDetailsBean(UserDetailsBean userDetailsBean, User userDetails, AuthResBean authRes) {
		if (userDetails == null) {
			/*
			 * Getting inside this Block means Employee Details Does Not Exist After hitting
			 * the RNLIC Service.
			 */
			throw new UserDetailsDoesNotExist();
		}else {
			authRes.setUserInfo(userDetails);
		}
		userDetailsBean.setFristName(userDetails.getFirstName());
		userDetailsBean.setLastName(userDetails.getLastName());
		userDetailsBean.setHasReportee(userDetails.isHasReportee());
		userDetailsBean.setLevel(userDetails.getLevel());
		userDetailsBean.setManagerSapCode(userDetails.getManagerSapCode());
		userDetailsBean.setRole(userDetails.getOrgRoles());
		userDetailsBean.setMobileNumber(HrAppUtil.isNullOrEmpty(userDetails.getMobileNo())?GenericConstants.EMPTY_STRING:userDetails.getMobileNo());
		userDetailsBean.setPanNumber(HrAppUtil.isNullOrEmpty(userDetails.getPanNo())?GenericConstants.EMPTY_STRING:userDetails.getPanNo());
		userDetailsBean.setSapCode(HrAppUtil.isNullOrEmpty(userDetails.getSapCode())?GenericConstants.EMPTY_STRING:userDetails.getSapCode());
		userDetailsBean.setEmail(HrAppUtil.isNullOrEmpty(userDetails.getEmail())?GenericConstants.EMPTY_STRING:userDetails.getEmail());
	}

	/**
	 * This method will authenticate user and generate JWT_Token
	 * 
	 * @param AuthReqBean authReqBean
	 * @return ResponseData authRes
	 * @throws RestClientException
	 * @throws IOException
	 */
	public ResponseData authenticateAndGenerateToken(AuthReqBean authReqBean) throws RestClientException, IOException {

		log.info(requestLog+"== authenticateAndGenerateToken service Before Device Registration ==");

		CheckForDeviceRegistrationResBean deviceRegisBean = (CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(
				HrAppUtil.returnBlankWhenNull(authReqBean.getDeviceIdentifier()), 
				HrAppUtil.returnBlankWhenNull(authReqBean.getSapCode()), 
				HrAppUtil.returnBlankWhenNull(authReqBean.getMobileNumber()));
		log.info(requestLog+"== authenticateAndGenerateToken service after device registration ==");

		AuthResBean authRes = new AuthResBean();
		setDeviceRegistrationInformation(deviceRegisBean, authRes);
		if (!deviceRegisBean.isDeviceRegisterWithOthers()) {
			log.info(requestLog+"Before Authenticate User");

			final UserDetailsBean jwtUser = getAuthenticationData(authReqBean,authRes);
			log.info(requestLog+ " After Authenticate User");

			if (jwtUser == null) {
				log.info(requestLog+messagesConstants.getNoSuchUserFoundMsg());
				throw new NoSuchUserExists(messagesConstants.getNoSuchUserFoundMsg());
			} else {
				createAuthResponse(jwtUser, authRes);
			}
		} else {
			log.info(requestLog+messagesConstants.getDeviceRegisteredWithOtherDevice());
			throw new DeviceRegistrationException(messagesConstants.getDeviceRegisteredWithOtherDevice());
		}
		return authRes;
	}

	private void setDeviceRegistrationInformation(CheckForDeviceRegistrationResBean deviceRegisBean,
			AuthResBean authRes) {
		log.info(requestLog+ "== setDeviceRegistrationInformation setting device registration:=====");
		CheckForDeviceRegistrationResBean deviceReg = authRes.getDeviceRegInfo();
		deviceReg.setAllowed(deviceRegisBean.isAllowed());
		deviceReg.setDeviceRegisterWithOthers(deviceRegisBean.isDeviceRegisterWithOthers());
		deviceReg.setMobileNumberUpdated(deviceRegisBean.isMobileNumberUpdated());
		deviceReg.setRegisterdWithOtherDevice(deviceRegisBean.isRegisterdWithOtherDevice());
		deviceReg.setSapCodeUpdated(deviceRegisBean.isSapCodeUpdated());
		deviceReg.setDeviceRegDetails(deviceRegisBean.getDeviceRegDetails());
		deviceReg.setAlreadyRegistered(deviceRegisBean.isAlreadyRegistered());
		authRes.setDeviceRegInfo(deviceReg);
		log.info(requestLog+ "== setDeviceRegistrationInformation device registration completed:=====");
	}

	public ResponseData getResponseForTroubleInLogin() {
		return rnlicService.getResponseForTroubleInLogin();
	}
}
