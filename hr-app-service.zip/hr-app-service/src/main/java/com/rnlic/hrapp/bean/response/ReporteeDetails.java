package com.rnlic.hrapp.bean.response;

public class ReporteeDetails {
	
	private String sapCode;
	private String name;
	private String managerSapCode;
	private String managerName;
	private boolean hasAnyReportee;
	public String getSapCode() {
		return sapCode;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getManagerSapCode() {
		return managerSapCode;
	}
	public void setManagerSapCode(String managerSapCode) {
		this.managerSapCode = managerSapCode;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public boolean isHasAnyReportee() {
		return hasAnyReportee;
	}
	public void setHasAnyReportee(boolean hasAnyReportee) {
		this.hasAnyReportee = hasAnyReportee;
	}
}
