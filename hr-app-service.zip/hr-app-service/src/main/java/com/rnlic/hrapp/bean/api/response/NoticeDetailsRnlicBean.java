package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NoticeDetailsRnlicBean implements RnlicResponseData{
	
	 @JsonProperty(value = "AutoId") 
	 private String autoId;
	 @JsonProperty(value = "DocumentType") 
	 private String documentType;
	 @JsonProperty(value = "ShortDescription") 
	 private String shortDescription;
	 @JsonProperty(value = "Description") 
	 private String description;
	 @JsonProperty(value = "LINK") 
	 private String link;
	 @JsonProperty(value = "CreatedOn") 
	 private String createdOn;
	public String getAutoId() {
		return autoId;
	}
	public void setAutoId(String autoId) {
		this.autoId = autoId;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
}
