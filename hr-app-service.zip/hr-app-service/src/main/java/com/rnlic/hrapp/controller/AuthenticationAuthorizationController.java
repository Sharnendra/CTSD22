package com.rnlic.hrapp.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rnlic.hrapp.bean.request.AuthReqBean;
import com.rnlic.hrapp.bean.request.DeRegisterDeviceReqBean;
import com.rnlic.hrapp.bean.request.OtpReqBean;
import com.rnlic.hrapp.bean.request.OtpValidateReqBean;
import com.rnlic.hrapp.bean.request.RegisterDeviceReqBean;
import com.rnlic.hrapp.bean.request.UpdateDeviceRegistrationReqBean;
import com.rnlic.hrapp.bean.request.UpdateInstalledAppReqBean;
import com.rnlic.hrapp.bean.response.RestResponse;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.constant.UrlConstants;
import com.rnlic.hrapp.exception.BadRequestException;
import com.rnlic.hrapp.exception.HrAppException;
import com.rnlic.hrapp.exception.MandatoryFieldsNotAvailable;
import com.rnlic.hrapp.exception.UnhandledException;
import com.rnlic.hrapp.security.JwtDecriptor;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.AuthenticationAuthorizationService;
import com.rnlic.hrapp.service.CommunicationService;
import com.rnlic.hrapp.service.DeviceRegistrationService;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestValidator;
import com.rnlic.hrapp.util.RequestValidatorResponse;

/**
 * @author HRMSAPP
 *
 */
@RestController
public class AuthenticationAuthorizationController extends BaseController {

	private static final Logger log = LogManager.getLogger(AuthenticationAuthorizationController.class);
	private ObjectMapper objectToJson = new ObjectMapper();

	@Autowired
	private AuthenticationAuthorizationService authService;

	@Autowired
	private CommunicationService messageService;
	
	@Autowired
	private DeviceRegistrationService deviceService;
	
	@Autowired 
	private MessagesConstants messagesConstants;
	
	@Autowired
	private JwtDecriptor jwtDecriptor;
	

	/**
	 * This end-point is to authenticate Employee and to generate Token to them
	 * 
	 * @param AuthReqBean authReqBean
	 * @return RestResponse restResponse
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.AUTHENTICATE_URL)
	public RestResponse authenticateAndGenerateJwtToken(@RequestBody AuthReqBean authReqBean) throws JsonProcessingException {

		RestResponse restResponse = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,restResponse.getRequestId(),authReqBean.getSapCode(),authReqBean.getMobileNumber(),authReqBean.getDeviceIdentifier(),"Authenticate");
		log.info(requestLog.toString()+ "== AuthenticateAndGenerateJwtToken :=====");
		try {
			/*
			 * First Check All the mandatory fields are filled for both Candidate and
			 * Employees.
			 **/
			RequestValidatorResponse reqRes = RequestValidator.requestValidator(authReqBean);
			if (!reqRes.isValid()) {
				log.info(requestLog.toString()+ "== AuthenticateAndGenerateJwtToken Request Validation failed :====="+ reqRes.getMessage());
				throw new MandatoryFieldsNotAvailable(messagesConstants.getMissingMandatoryFieldMsg() + reqRes.getMessage());
			} else {
				log.info(requestLog.toString()+"== Before Calling Service AuthenticateAndGenerateToken Method:==");
				restResponse.setData(authService.authenticateAndGenerateToken(authReqBean));
				log.info(requestLog.toString()+"== After Calling Service AuthenticateAndGenerateToken Method:==");

			}
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ GenericConstants.NEW_LINE + GenericConstants.EXCEPTION , e);
			restResponse.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ GenericConstants.NEW_LINE + GenericConstants.EXCEPTION , t);
			restResponse.setError(new UnhandledException());
		}
		return restResponse;
	}

	

	/**
	 * This end-point to generate OTP and save and send to Users
	 * 
	 * @param OtpReqBean otpReqBean
	 * @param String     jwt_token
	 * @return RestResponse restResponse
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.SEND_OTP_URL)
	public RestResponse sendOtpOnMobile(@RequestBody OtpReqBean otpReqBean,
			@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) throws JsonProcessingException {

		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"Send Otp");
		log.info(requestLog.toString()+ "== sendOtpOnMobile :=====");
		try {
			// Step 1. need to verify request.
			RequestValidatorResponse requestValidator = RequestValidator.requestValidator(otpReqBean);
			// Step 2. If request is valid than decrypt token and send otp.
			if (requestValidator.isValid()) {
				// Step 3. for valid request decrypt token
				UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
				// Step 4. Call service to generate otp and send to mobile.
				setRequestLog(requestLog,response.getRequestId(),userDetailsBean.getSapCode(),null,userDetailsBean.getDeviceIdentifier(),"Send Otp");
				log.info(requestLog.toString()+ "== sendOtpOnMobile  request valid:=====");
				response.setData(messageService.sendOtpOnMobile(otpReqBean, userDetailsBean));
			} else {
				log.info(requestLog.toString()+ "== sendOtpOnMobile  request Invalid:=====");
				throw new BadRequestException(requestValidator.getMessage());
			}
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== sendOtpOnMobile  HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== sendOtpOnMobile  UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}

	/**
	 * This end point will validate OTP
	 * 
	 * @param OtpValidateReqBean otpValidateReqBean
	 * @param String             jwt_token
	 * @return RestResponse restResponse
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.VALIDATE_OTP_URL)
	public RestResponse validateOtp(@RequestBody OtpValidateReqBean otpValidateReqBean,
			@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) throws JsonProcessingException {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"Validate Otp");
		try {
			// Step 1. need to verify request.
			RequestValidatorResponse requestValidator = RequestValidator.requestValidator(otpValidateReqBean);
			if (requestValidator.isValid()) {
				// Step 2. If request is valid than decrypt token and validate otp.
				UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
				setRequestLog(requestLog,response.getRequestId(),userDetailsBean.getSapCode(),userDetailsBean.getMobileNumber(),userDetailsBean.getDeviceIdentifier(),"Validate Otp");
				response.setData(messageService.validateOtp(userDetailsBean, otpValidateReqBean));
				log.info(requestLog.toString()+ "== Validate Otp request valid:=====");
			} else {
				log.info(requestLog.toString()+ "== Validate Otp request Invalid:=====");
				throw new BadRequestException(requestValidator.getMessage());
			}
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== Validate Otp HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== Validate Otp UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}

	/**
	 * This Method will give employee details from rnlic service
	 * 
	 * @param String jwt_token
	 * @return RestResponse restResponse
	 */
//	@GetMapping(UrlConstants.GET_EMPLOYEE_DETAILS_URL)
//	public RestResponse getEmpDetalis(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) {
//
//		RestResponse restResponse = new RestResponse(HrAppUtil.generateRequestId());
//		try {
//			UserDetailsBean empReqBean = jwtDecriptor.jwtDecript(jwtToken);
//			ResponseData empDetails = authService.getEmployeeDetails(empReqBean);
//			if (HrAppUtil.isNotEmpty(empDetails)) {
//				restResponse.setData(empDetails);
//			} else {
//				NoSuchUserExists noUser = new NoSuchUserExists(messagesConstants.getNoEmployeeDetailsMsg());
//				restResponse.setError(noUser);
//			}
//
//		} catch (HrAppException e) {
//			log.error(GenericConstants.REQUEST_ID + restResponse.getRequestId() + GenericConstants.EXCEPTION , e);
//			restResponse.setError(e);
//		} catch (Exception t) {
//			log.error(GenericConstants.REQUEST_ID + restResponse.getRequestId() + GenericConstants.EXCEPTION , t);
//			restResponse.setError(new UnhandledException());
//		}
//		return restResponse;
//	}

	/**
	 * This Method will give employee details from rnlic service
	 * 
	 * @param String jwt_token
	 * @return RestResponse restResponse
	 */
	@PostMapping(UrlConstants.GET_REGISTRATION_INFORMATION_URL)
	public RestResponse checkRegistrationInfomation(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) {

		RestResponse restResponse = new RestResponse(HrAppUtil.generateRequestId());
		try {
			UserDetailsBean empReqBean = jwtDecriptor.jwtDecript(jwtToken);
			restResponse.setData(deviceService.checkRegistrationInfomation(empReqBean.getDeviceIdentifier(),
					empReqBean.getSapCode(), empReqBean.getMobileNumber()));
		} catch (HrAppException e) {
			log.error(GenericConstants.REQUEST_ID + restResponse.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, e);
			restResponse.setError(e);
		} catch (Exception t) {
			log.error(GenericConstants.REQUEST_ID + restResponse.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, t);
			restResponse.setError(new UnhandledException());
		}
		return restResponse;
	}

	/**
	 * This end point will register device
	 * 
	 * @param RegisterDeviceReqBean registerDeviceReqBean
	 * @param String                jwt_token
	 * @return RestResponse restResponse
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.REGISTER_DEVICE)
	public RestResponse registerDevice(@RequestBody RegisterDeviceReqBean registerDeviceReqBean,
			@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) throws JsonProcessingException {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());

		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			response.setData(deviceService.registerDevice(userDetailsBean, registerDeviceReqBean));
			log.info(GenericConstants.REQUEST_ID + response.getRequestId());
		} catch (HrAppException e) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(registerDeviceReqBean) + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, e);
			response.setError(e);
		} catch (Exception t) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(registerDeviceReqBean) + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, t);
			response.setError(new UnhandledException());
		}
		return response;
	}

	/**
	 * This end point will update device registration
	 * 
	 * @param UpdateDeviceRegistrationReqBean updateDeviceRegReqBean
	 * @param String                          jwt_token
	 * @return RestResponse restResponse
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.UPDATE_DEVICE_REGISTRATION)
	public RestResponse updateDeviceRegistration(@RequestBody UpdateDeviceRegistrationReqBean updateDeviceRegReqBean,
			@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) throws JsonProcessingException {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());

		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			response.setData(deviceService.updateDeviceReg(userDetailsBean, updateDeviceRegReqBean));
			log.info(GenericConstants.REQUEST_ID + response.getRequestId());
		} catch (HrAppException e) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(updateDeviceRegReqBean) + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, e);
			response.setError(e);
		} catch (Exception t) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(updateDeviceRegReqBean) + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, t);
			response.setError(new UnhandledException());
		}
		return response;
	}

	/**
	 * This end point will de-register device
	 * 
	 * @param DeRegisterDeviceReqBean deregDeviceReqBean
	 * @param String                  jwt_token
	 * @return RestResponse restResponse
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.DEREGISTER_DEVICE)
	public RestResponse deRegisterDevice(@RequestBody DeRegisterDeviceReqBean deregDeviceReqBean,
			@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) throws JsonProcessingException {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());

		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			response.setData(deviceService.deRegDevice(userDetailsBean, deregDeviceReqBean));
			log.info(GenericConstants.REQUEST_ID + response.getRequestId());
		} catch (HrAppException e) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(deregDeviceReqBean) + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, e);
			response.setError(e);
		} catch (Exception t) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(deregDeviceReqBean) + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, t);
			response.setError(new UnhandledException());
		}
		return response;
	}

	/**
	 * This end point will update linked application for registered device
	 * 
	 * @param RegisterDeviceReqBean registerDeviceReqBean
	 * @param String                jwt_token
	 * @return RestResponse restResponse
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.UPDATE_LINKED_APP_FOR_REGISTER_DEVICE)
	public RestResponse updateLinkedAppForRegisteredDevice(@RequestBody UpdateInstalledAppReqBean updateInstalledAppReqBean,
			@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) throws JsonProcessingException {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());

		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			response.setData(deviceService.updateLinkedAppForRegisteredDevice(userDetailsBean, updateInstalledAppReqBean));
			log.info(GenericConstants.REQUEST_ID + response.getRequestId());
		} catch (HrAppException e) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(updateInstalledAppReqBean) + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, e);
			response.setError(e);
		} catch (Exception t) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(updateInstalledAppReqBean) + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, t);
			response.setError(new UnhandledException());
		}
		return response;
	}
		
	/**
	 * This end point will provide response when there is any issue with login
	 * 
	 * @return RestResponse restResponse
	 */
	@PostMapping(UrlConstants.GET_TROUBLE_WITH_LOGIN_URL)
	public RestResponse getResponseForTroubleInLogin() {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());

		try {
			response.setData(authService.getResponseForTroubleInLogin());
			log.info(GenericConstants.REQUEST_ID + response.getRequestId());
		} catch (HrAppException e) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, e);
			response.setError(e);
		} catch (Exception t) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, t);
			response.setError(new UnhandledException());
		}
		return response;
	}
	
	/**
	 * This end point will validate OTP
	 * 
	 * @param OtpValidateReqBean otpValidateReqBean
	 * @param String             jwt_token
	 * @return RestResponse restResponse
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.REGISTER_DEVICE_WITH_OTP_URL)
	public RestResponse validateOtpAndRegisterDevice(@RequestBody RegisterDeviceReqBean registerReqBean,
			@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) throws JsonProcessingException {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());

		try {
			// Step 1. need to verify request.
			RequestValidatorResponse requestValidator = RequestValidator.requestValidator(registerReqBean);
			if (requestValidator.isValid()) {
				// Step 2. If request is valid than decrypt token and validate otp.
				UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
				response.setData(messageService.validateOtpAndRegisterDevice(userDetailsBean, registerReqBean));
				log.info(GenericConstants.REQUEST_ID + response.getRequestId());
			} else {
				throw new BadRequestException(requestValidator.getMessage());
			}
		} catch (HrAppException e) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(registerReqBean) + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, e);
			response.setError(e);
		} catch (Exception t) {
			log.error(GenericConstants.REQUEST_ID + response.getRequestId() + GenericConstants.NEW_LINE 
					+ GenericConstants.JWT_TOKEN + jwtToken + GenericConstants.NEW_LINE
					+ GenericConstants.REQUEST_BODY + objectToJson.writeValueAsString(registerReqBean) + GenericConstants.NEW_LINE
					+ GenericConstants.EXCEPTION + GenericConstants.NEW_LINE, t);
			response.setError(new UnhandledException());
		}
		return response;
	}
	
}
