package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class OtpException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public OtpException() {
		super(ErrorConstants.OTP_EXCEPTION_CODE,ErrorConstants.BAD_REQUEST,false,false);
	}
	public OtpException(String message) {
		super(ErrorConstants.OTP_EXCEPTION_CODE,message,false,false);
	}
}
