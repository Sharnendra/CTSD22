package com.rnlic.hrapp.bean.response;

public class UpdateDeviceRegistrationResBean implements ResponseData{
	
	private boolean isUpdated;
	private String  message;
	public boolean isUpdated() {
		return isUpdated;
	}
	public void setUpdated(boolean isUpdated) {
		this.isUpdated = isUpdated;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

}
