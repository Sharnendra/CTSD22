package com.rnlic.hrapp.bean.request;

public class TestOtpReq {
	
	private String sapOrMobile;

	public String getSapOrMobile() {
		return sapOrMobile;
	}

	public void setSapOrMobile(String sapOrMobile) {
		this.sapOrMobile = sapOrMobile;
	}
	

}
