package com.rnlic.hrapp.bean.response;

public class LearningDetails {
	
	private String learningId;
	private String learningName;
	private String documentName;
	private String learningLink;
	private String documentUploadDate;
	private String completedOn;
	private String status;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLearningId() {
		return learningId;
	}
	public void setLearningId(String learningId) {
		this.learningId = learningId;
	}
	public String getLearningName() {
		return learningName;
	}
	public void setLearningName(String learningName) {
		this.learningName = learningName;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getLearningLink() {
		return learningLink;
	}
	public void setLearningLink(String learningLink) {
		this.learningLink = learningLink;
	}
	public String getDocumentUploadDate() {
		return documentUploadDate;
	}
	public void setDocumentUploadDate(String documentUploadDate) {
		this.documentUploadDate = documentUploadDate;
	}
	public String getCompletedOn() {
		return completedOn;
	}
	public void setCompletedOn(String completedOn) {
		this.completedOn = completedOn;
	}
	
}
