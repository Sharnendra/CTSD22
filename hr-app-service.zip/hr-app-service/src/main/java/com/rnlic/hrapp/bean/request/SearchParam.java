package com.rnlic.hrapp.bean.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchParam {

	private String nameOrSapOrDepartmet;

	public String getNameOrSapOrDepartmet() {
		return nameOrSapOrDepartmet;
	}

	public void setNameOrSapOrDepartmet(String nameOrSapOrDepartmet) {
		this.nameOrSapOrDepartmet = nameOrSapOrDepartmet;
	}
	
}
