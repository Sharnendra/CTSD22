package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ReporteeInformationRnlicResponseBean {

	@JsonProperty(value="SAPCode")
	private String sapCode;
	
	@JsonProperty(value="Name")
	private String name;
	
	@JsonProperty(value="ManagerSAPCode")
	private String managerSapCode;
	
	@JsonProperty(value="ManagerName")
	private String managerName;
	
	@JsonProperty(value="HasAnyReportee")
	private String hasAnyReportee;

	public String getSapCode() {
		return sapCode;
	}

	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}

	public String getManagerSapCode() {
		return managerSapCode;
	}

	public void setManagerSapCode(String managerSapCode) {
		this.managerSapCode = managerSapCode;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getHasAnyReportee() {
		return hasAnyReportee;
	}

	public void setHasAnyReportee(String hasAnyReportee) {
		this.hasAnyReportee = hasAnyReportee;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
