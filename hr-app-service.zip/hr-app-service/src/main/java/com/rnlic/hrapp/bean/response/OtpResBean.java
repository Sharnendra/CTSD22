package com.rnlic.hrapp.bean.response;

public class OtpResBean implements ResponseData{
	
	private Boolean data;

	public Boolean getData() {
		return data;
	}

	public void setData(Boolean data) {
		this.data = data;
	}
	
	

}
