package com.rnlic.hrapp.constant;

import java.nio.charset.Charset;

import org.springframework.http.MediaType;

public class UrlConstants {

	public static final MediaType APPLICATION_JSON_UTF8= new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(),Charset.forName("utf8"));
	
	public static final String AUTH_ALL_SERVICE = "/service/**";
	public static final String AUTH_ANT_MATCHER = "**/service/**";
	public static final String AUTHENTICATE_URL = "/authenticate";
	public static final String GET_EMPLOYEE_DETAILS_URL = "/service/getEmployeeDetails";
	public static final String SEND_OTP_URL = "/service/sendOTP";
	public static final String VALIDATE_OTP_URL = "/service/validateOTP";
	public static final String REGISTER_DEVICE_WITH_OTP_URL = "/service/registerDeviceWithOtp";
	public static final String SERVICE = "/service";
	public static final String SEARCH_BIRTHDAY_ANNIVERSARY_URL = "/searchBirthdayOrAnniversary";
	public static final String WISH_EMPLOYEE_URL = "/wishEmployee";
	public static final String GET_BIRTHDAY_URL = "/getBirthday";
	public static final String GET_ANNIVERSARY_URL = "/getAnniversary";
	public static final String GET_ATTENDANCE_DETAILS_URL = "/service/getAttendanceDetails";
	public static final String GET_CHECKIN_INFORMATION_URL = "/getCheckInInformation";
	public static final String EMPLOYEE_CHECKIN_CHECKOUT_URL = "/service/employeeCheckInCheckOut";
	public static final String GET_MANDATORY_LEARNING_URL = "/getMandatoryLearning";
	public static final String GET_MANDATORY_LEARNING_STATUS_URL = "/service/getMandatoryLearningStatus";
	public static final String UPDATE_LEARNING_COMPLETION_STATUS_URL = "/service/updateLearningCompletionStatus";
	public static final String GET_STATE_CITY_MASTER_URL = "/getStateCityMaster";
	public static final String LOCATE_BRANCH_URL = "/locateBranch";
	public static final String SHARE_BRANCH_INFO_URL = "/shareBranchInformation";
	public static final String GET_NOTICES_URL = "/getNotices";
	public static final String CHANGE_PASSWORD_URL = "/changePassword";
	public static final String UPDATE_PASSWORD_URL = "/updatePassword";
	public static final String GET_NOTIFICATION_URL = "/getNotifications";
	public static final String GET_REPORTEE_LIST_URL = "/service/getReporteeList";

	public static final String GET_REGISTRATION_INFORMATION_URL = "/service/checkForDeviceRegistration";
	public static final String GET_LINKED_APPLICATION_CONFIG_URL = "/getLinkedApplicationConfiguration";
	public static final String UPDATE_APPLICATION_CONFIGURATION_URL = "/updateApplicationConfiguration";
	public static final String GET_LINKED_APPLICATION_CONFIG_VERSION_URL = "/getApplicationConfigurationVersion";
	public static final String REGISTER_DEVICE = "/service/registerDevice";
	public static final String UPDATE_DEVICE_REGISTRATION = "/service/updateDeviceRegistration";
	public static final String DEREGISTER_DEVICE = "/service/deRegisterDevice";
	public static final String UPDATE_LINKED_APP_FOR_REGISTER_DEVICE = "/service/updateLinkedApp";

	public static final String GET_REPORTEE_BIRTHDAY_URL = "/getReporteeBirthday";
	public static final String GET_REPORTEE_ANNIVERSARY_URL = "/getReporteeAnniversary";

	public static final String GET_OTP_URL = "/getOtp";
	public static final String SEND_MAIL_URL = "/sendMail";
	public static final String GET_TROUBLE_WITH_LOGIN_URL = "/havingTroubleWithLogin";
	
	public static final String GET_SUBSCRIPTION_LIST = "/service/getSubscriptionList";
	public static final String UPDATE_NOTIFICATION_DETAILS = "/service/updateNotificatonDetails";
	public static final String GET_MESSAGE_TEMPLATE = "/service/messageTemplate";
}
