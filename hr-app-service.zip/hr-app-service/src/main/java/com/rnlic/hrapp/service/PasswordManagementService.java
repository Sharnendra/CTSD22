package com.rnlic.hrapp.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rnlic.hrapp.bean.request.ChangePasswordReqBean;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.util.RequestLogDeatils;

/**
 * This service class responsible to password management
 */
@Service
public class PasswordManagementService {

	private static final Logger log = LogManager.getLogger(PasswordManagementService.class);
	
	@Autowired
	private RnlicService rnlicService;
	
	@Autowired
	private RequestLogDeatils requestLog;

	/**
	 * This method will call RNLIC service to get Response 
	 * @param ChangePasswordReqBean changePasswordReqBean
	 * @return ResponseData responseData
	 */
	public ResponseData requestForChangePassword(ChangePasswordReqBean changePasswordReqBean) {
		log.info(requestLog+ "== requestForChangePassword Calling RNLIC service to request change password :=====");
		return rnlicService.changePasswordRequest(changePasswordReqBean);
	}
	
//	/**
//	 * This method will call RNLIC service to get Response 
//	 * @param ChangePasswordReqBean changePasswordReqBean
//	 * @return ResponseData responseData
//	 */
//	public ResponseData updatePassword(ChangePasswordReqBean changePasswordReqBean) {
//		log.info("Calling RNLIC service to request change password");
//		return rnlicService.updatePassword(changePasswordReqBean);
//	}
}
