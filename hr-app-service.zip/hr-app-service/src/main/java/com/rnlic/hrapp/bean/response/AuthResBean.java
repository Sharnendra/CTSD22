package com.rnlic.hrapp.bean.response;

public class AuthResBean implements ResponseData{
	
	private String token;
	private User userInfo;
	private CheckForDeviceRegistrationResBean deviceRegInfo;
	public AuthResBean() {
		this.userInfo = new User();
		this.deviceRegInfo = new CheckForDeviceRegistrationResBean();
	}
	public CheckForDeviceRegistrationResBean getDeviceRegInfo() {
		return deviceRegInfo;
	}
	public void setDeviceRegInfo(CheckForDeviceRegistrationResBean deviceRegInfo) {
		this.deviceRegInfo = deviceRegInfo;
	}
	
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public User getUserInfo() {
		return userInfo;
	}
	public void setUserInfo(User userInfo) {
		this.userInfo = userInfo;
	}
	
}
