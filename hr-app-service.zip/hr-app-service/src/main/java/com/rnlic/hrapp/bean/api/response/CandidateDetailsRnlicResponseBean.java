package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CandidateDetailsRnlicResponseBean implements RnlicResponseData{
	
	 @JsonProperty(value = "Name") 
	 private String name;
	 @JsonProperty(value = "MobileNo") 
	 private String mobileNo;
	 @JsonProperty(value = "Email") 
	 private String email;
	 @JsonProperty(value = "Channel") 
	 private String channel;
	 @JsonProperty(value = "Role") 
	 private String role;
	 @JsonProperty(value = "Level") 
	 private String level;
	 @JsonProperty(value = "ManagerSAPCode") 
	 private String managerSAPCode;
	 @JsonProperty(value = "ManagerName") 
	 private String managerName;
	 @JsonProperty(value = "LocationCode") 
	 private String locationCode;
	 @JsonProperty(value = "LocationName") 
	 private String locationName;
	 @JsonProperty(value = "Category") 
	 private String category;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getManagerSAPCode() {
		return managerSAPCode;
	}
	public void setManagerSAPCode(String managerSAPCode) {
		this.managerSAPCode = managerSAPCode;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	 
}
