package com.rnlic.hrapp.bean.api.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CheckInCheckOutRnlicResponseBean extends RnlicRestResponse{
	
	@JsonProperty(value = "Response")
	List<CheckInCheckOutDateTimeResponseBean> response = new ArrayList<>();
	
	@JsonProperty(value="Errors")
	private List<ErrorRnlicResponseBean> errors = new ArrayList<>();

	public CheckInCheckOutRnlicResponseBean() {
		super();
	}

	public CheckInCheckOutRnlicResponseBean(List<CheckInCheckOutDateTimeResponseBean> response) {
		super();
		this.response = response;
	}

	public List<CheckInCheckOutDateTimeResponseBean> getResponse() {
		return response;
	}

	public void setResponse(List<CheckInCheckOutDateTimeResponseBean> response) {
		this.response = response;
	}

	public List<ErrorRnlicResponseBean> getErrors() {
		return errors;
	}

	public void setErrors(List<ErrorRnlicResponseBean> errors) {
		this.errors = errors;
	}	
	
}
