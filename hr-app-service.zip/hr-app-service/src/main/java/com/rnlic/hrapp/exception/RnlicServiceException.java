package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class RnlicServiceException extends HrAppException {

	private static final long serialVersionUID = 1L;
	
	public RnlicServiceException() {
		super(ErrorConstants.RNLIC_SERVICE_DOWN_CODE,ErrorConstants.RNLIC_SERVICE_DOWN_MESSAGE,false,false);
	}
	public RnlicServiceException(String message) {
		super(ErrorConstants.RNLIC_SERVICE_DOWN_CODE,message,false,false);
	}
}
