package com.rnlic.hrapp.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.rnlic.hrapp.constant.QueryConstants;
import com.rnlic.hrapp.entity.LinkedAppConfigrationModel;

@Repository
@Transactional
public interface LinkedAppConfigrationRepository extends JpaRepository<LinkedAppConfigrationModel, Integer>{

	@Query(QueryConstants.LINKEDAPPREPO_GET_LINKED_APP_CONFIG)
	LinkedAppConfigrationModel getLinkedAppConfigration();
	/*
	 * This Function will be used when you want to update 
	 * all the entries of the table to be de-active before 
	 * inserting a new configuration and activate it.
	 * */
	@Query(QueryConstants.LINKEDAPPREPO_UPDATE_LINKED_APP_CONFIG_ENTRIES)
	@Modifying
	void updateLinkedAppConfigrationEntries();
	
	@Query(value =  QueryConstants.LINKEDAPPREPO_GET_LINKED_APP_CONFIG_VERSION, nativeQuery = true)
	List<Object[]> getLinkedAppConfigrationVersion();
	
	/*
	 * This Function will be used when you to add
	 * sequence from database for your application
	 * version.
	 * */
	@Query(value = QueryConstants.REQUEST_FOR_VERSION_SEQUENCE, nativeQuery = true)
	String getSequence();
}
