package com.rnlic.hrapp.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rnlic.hrapp.bean.request.LocalBranchReqBean;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.security.UserDetailsBean;
//import com.rnlic.hrapp.security.ValidateRegistry;
import com.rnlic.hrapp.util.RequestLogDeatils;

@Service
public class LocationDirectoryService {

	private static final Logger log = LogManager.getLogger(LocationDirectoryService.class);
	
	@SuppressWarnings("unused")
	private UserDetailsBean empReqBean;

	@Autowired
	private RnlicService rnlicService;
	
	@Autowired
	private RequestLogDeatils requestLog;

	//@ValidateRegistry
	public ResponseData getBrachDetails(UserDetailsBean empReqBean, LocalBranchReqBean localBranchReqBean) {
		// Use data to call reliance data
		log.info(requestLog+ "== getBrachDetails service start :=====");
		return rnlicService.getBranchDetails(localBranchReqBean);
	}

	//@ValidateRegistry
	public ResponseData getStateCityMaster(UserDetailsBean empReqBean) {
		log.info(requestLog+ "== getStateCityMaster service start :=====");
		return rnlicService.getStateCityMaster();
	}
}
