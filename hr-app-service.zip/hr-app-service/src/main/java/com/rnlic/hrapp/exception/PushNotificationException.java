package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class PushNotificationException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public PushNotificationException() {
		super(ErrorConstants.PUSH_NOTIFICATION_EXCEPTION_CODE,ErrorConstants.PUSH_NOTIFICATION_EXCEPTION_MESSAGE,false,false);
	}
	public PushNotificationException(String message) {
		super(ErrorConstants.PUSH_NOTIFICATION_EXCEPTION_CODE,message,false,false);
	}
}
