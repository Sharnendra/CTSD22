package com.rnlic.hrapp.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rnlic.hrapp.bean.request.LocalBranchReqBean;
import com.rnlic.hrapp.bean.request.ShareBranchDetailsReqBean;
import com.rnlic.hrapp.bean.response.RestResponse;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.UrlConstants;
import com.rnlic.hrapp.exception.HrAppException;
import com.rnlic.hrapp.exception.UnhandledException;
import com.rnlic.hrapp.security.JwtDecriptor;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.CommunicationService;
import com.rnlic.hrapp.service.LocationDirectoryService;
import com.rnlic.hrapp.util.HrAppUtil;

@RestController
@RequestMapping(UrlConstants.SERVICE)
public class LocationDirectoryController extends BaseController {
	
	private static final Logger log = LogManager.getLogger(LocationDirectoryController.class);
	
	@Autowired 
	private LocationDirectoryService locationService;
	
	@Autowired
	private CommunicationService communicationService;
	
	@Autowired
	private JwtDecriptor jwtDecriptor;
	
	@PostMapping(UrlConstants.GET_STATE_CITY_MASTER_URL)
	public RestResponse getStateCityMaster(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) {

		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"getStateCityMaster");
		log.info(requestLog.toString()+ "== getStateCityMaster :=====");
		try {
			UserDetailsBean empReqBean = jwtDecriptor.jwtDecript(jwtToken);
			setRequestLog(requestLog,response.getRequestId(),empReqBean.getSapCode(),empReqBean.getMobileNumber(),empReqBean.getDeviceIdentifier(),"getStateCityMaster");
			response.setData(locationService.getStateCityMaster(empReqBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== getStateCityMaster HrAppException:=====", e);
			response.setError(e);
		}
		catch(Exception t) {
			log.error(requestLog.toString()+ "== getStateCityMaster UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
		
	}
	
	@PostMapping(UrlConstants.LOCATE_BRANCH_URL)
	public RestResponse locateBranch(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken,@RequestBody LocalBranchReqBean localBranchReqBean) throws JsonProcessingException
	{
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"locateBranch");
		log.info(requestLog.toString()+ "== locateBranch :=====");
		try {
			UserDetailsBean empReqBean = jwtDecriptor.jwtDecript(jwtToken);
			setRequestLog(requestLog,response.getRequestId(),empReqBean.getSapCode(),empReqBean.getMobileNumber(),empReqBean.getDeviceIdentifier(),"locateBranch");
			response.setData(locationService.getBrachDetails(empReqBean,localBranchReqBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== locateBranch HrAppException:=====", e);
			response.setError(e);
		}
		catch(Exception t) {
			log.error(requestLog.toString()+ "== locateBranch UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}
	
	@PostMapping(UrlConstants.SHARE_BRANCH_INFO_URL)
	public RestResponse shareBranchInformation(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken,@RequestBody ShareBranchDetailsReqBean shareBranchDetailsReqBean) throws JsonProcessingException
	{
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"shareBranchInformation");
		log.info(requestLog.toString()+ "== shareBranchInformation :=====");
		try {
			UserDetailsBean empReqBean = jwtDecriptor.jwtDecript(jwtToken);
			setRequestLog(requestLog,response.getRequestId(),empReqBean.getSapCode(),empReqBean.getMobileNumber(),empReqBean.getDeviceIdentifier(),"shareBranchInformation");
			response.setData(communicationService.shareBrachDetails(empReqBean,shareBranchDetailsReqBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== shareBranchInformation HrAppException:=====", e);
			response.setError(e);
		}
		catch(Exception t) {
			log.error(requestLog.toString()+ "== shareBranchInformation UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}
}
