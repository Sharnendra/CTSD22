package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class MailingServiceException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MailingServiceException() {
		super(ErrorConstants.MAIL_SERVICE_CODE,ErrorConstants.MAIL_SERVICE_MESSAGE,false,false);
	}
	
	public MailingServiceException(String message) {
		super(ErrorConstants.MAIL_SERVICE_CODE,message,false,false);
	}
}
