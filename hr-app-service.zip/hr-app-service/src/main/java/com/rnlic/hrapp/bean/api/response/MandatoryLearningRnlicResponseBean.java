package com.rnlic.hrapp.bean.api.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MandatoryLearningRnlicResponseBean extends RnlicRestResponse{
	
	@JsonProperty(value = "Response")
	List<MandatoryLearningDetailsRnlicResponseBean> response;

	public MandatoryLearningRnlicResponseBean() {
		super();
	}

	public MandatoryLearningRnlicResponseBean(List<MandatoryLearningDetailsRnlicResponseBean> response) {
		super();
		this.response = response;
	}

	public List<MandatoryLearningDetailsRnlicResponseBean> getResponse() {
		return response;
	}

	public void setResponse(List<MandatoryLearningDetailsRnlicResponseBean> response) {
		this.response = response;
	}	
}
