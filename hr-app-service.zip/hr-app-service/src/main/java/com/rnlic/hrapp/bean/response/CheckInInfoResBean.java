package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

import com.rnlic.hrapp.bean.request.Branches;

public class CheckInInfoResBean implements ResponseData{
	
	public CheckInInfoResBean(String checkInDate, Boolean locationCheckRequired, String allowedCheckInTime,
			String allowedCheckOutTime, List<Branches> allowedBranches) {
		this.checkInDate = checkInDate;
		this.locationCheckRequired = locationCheckRequired;
		this.allowedCheckInTime = allowedCheckInTime;
		this.allowedCheckOutTime = allowedCheckOutTime;
		this.allowedBranches = allowedBranches;
	}
	
	private String checkInDate;
	private Boolean locationCheckRequired;
	private String allowedCheckInTime;
	private String allowedCheckOutTime;
	private List<Branches> allowedBranches=new ArrayList<>();
	public String getCheckInDate() {
		return checkInDate;
	}
	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}
	public Boolean getLocationCheckRequired() {
		return locationCheckRequired;
	}
	public void setLocationCheckRequired(Boolean locationCheckRequired) {
		this.locationCheckRequired = locationCheckRequired;
	}
	public String getAllowedCheckInTime() {
		return allowedCheckInTime;
	}
	public void setAllowedCheckInTime(String allowedCheckInTime) {
		this.allowedCheckInTime = allowedCheckInTime;
	}
	public String getAllowedCheckOutTime() {
		return allowedCheckOutTime;
	}
	public void setAllowedCheckOutTime(String allowedCheckOutTime) {
		this.allowedCheckOutTime = allowedCheckOutTime;
	}
	public List<Branches> getAllowedBranches() {
		return allowedBranches;
	}
	public void setAllowedBranches(List<Branches> allowedBranches) {
		this.allowedBranches = allowedBranches;
	}
	
	

}
