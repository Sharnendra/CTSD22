package com.rnlic.hrapp.bean.response;

import com.rnlic.hrapp.exception.HrAppException;

public interface Response {
	String getRequestId();
	ResponseData getData();
	HrAppException getError();
}
