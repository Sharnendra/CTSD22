package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class UserDetailsDoesNotExist extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public UserDetailsDoesNotExist() {
		super(ErrorConstants.USER_DETAILS_DOES_NOT_EXIST_CODE,ErrorConstants.USER_DETAILS_DOES_NOT_EXIST_MESSAGE,false,false);
	}
	public UserDetailsDoesNotExist(String message) {
		super(ErrorConstants.USER_DETAILS_DOES_NOT_EXIST_CODE,message,false,false);
	}
}
