package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

public class AnniversaryResBean implements ResponseData{

	public AnniversaryResBean(List<Anniversary> anniversary) {
		this.anniversary = anniversary;
	}

	private List<Anniversary> anniversary=new ArrayList<>();

	public List<Anniversary> getAnniversary() {
		return anniversary;
	}

	public void setAnniversary(List<Anniversary> anniversary) {
		this.anniversary = anniversary;
	}
	
}
