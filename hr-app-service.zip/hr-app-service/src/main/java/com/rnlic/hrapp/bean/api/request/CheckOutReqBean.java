package com.rnlic.hrapp.bean.api.request;

public class CheckOutReqBean {

	private String SAPCode;
	private String SourceFrom;
	private String IMEINo;
	private String CheckOutLatitude;
	private String CheckOutLongitude;
	private String CheckOutAddress;
	public String getSAPCode() {
		return SAPCode;
	}
	public void setSAPCode(String sAPCode) {
		SAPCode = sAPCode;
	}
	public String getSourceFrom() {
		return SourceFrom;
	}
	public void setSourceFrom(String sourceFrom) {
		SourceFrom = sourceFrom;
	}
	public String getIMEINo() {
		return IMEINo;
	}
	public void setIMEINo(String iMEINo) {
		IMEINo = iMEINo;
	}
	public String getCheckOutLatitude() {
		return CheckOutLatitude;
	}
	public void setCheckOutLatitude(String checkInLatitude) {
		CheckOutLatitude = checkInLatitude;
	}
	public String getCheckInLongitude() {
		return getCheckOutLongitude();
	}
	public String getCheckOutLongitude() {
		return CheckOutLongitude;
	}
	public void setCheckOutLongitude(String checkInLongitude) {
		CheckOutLongitude = checkInLongitude;
	}
	public String getCheckOutAddress() {
		return CheckOutAddress;
	}
	public void setCheckOutAddress(String checkInAddress) {
		CheckOutAddress = checkInAddress;
	}
	@Override
	public String toString() {
		return "Latitude: " + CheckOutLatitude + ","+'\r'+'\n'+"Longitude: " + CheckOutLongitude +".";
	}
}
