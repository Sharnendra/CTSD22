package com.rnlic.hrapp.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rnlic.hrapp.bean.response.RestResponse;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.UrlConstants;
import com.rnlic.hrapp.exception.HrAppException;
import com.rnlic.hrapp.exception.UnhandledException;
import com.rnlic.hrapp.security.JwtDecriptor;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.NoticeBoardService;
import com.rnlic.hrapp.util.HrAppUtil;

/**
 * This controller responsible for notice mapping
 * @author HRMSAPP
 */

@RestController
@RequestMapping(UrlConstants.SERVICE)
public class NoticeBoardController extends BaseController {
	
	private static final Logger log = LogManager.getLogger(NoticeBoardController.class);
	
	@Autowired
	private NoticeBoardService noticeBoardService;
	
	@Autowired
	private JwtDecriptor jwtDecriptor;
	
	/**
	 * This end point to get notice from service
	 * @param String jwtToken
	 * @return RestResponse restResponse
	 */
	@PostMapping(UrlConstants.GET_NOTICES_URL)
	public RestResponse getNotices(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) {
		
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"getNotices");
		log.info(requestLog.toString()+ "== getNotices :=====");
		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			setRequestLog(requestLog,response.getRequestId(),userDetailsBean.getSapCode(),userDetailsBean.getMobileNumber(),userDetailsBean.getDeviceIdentifier(),"getNotices");
			response.setData(noticeBoardService.getNotices(userDetailsBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== getNotices HrAppException:=====", e);
			response.setError(e);
		}
		catch(Exception t) {
			log.error(requestLog.toString()+ "== getNotices UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
		
	}
}
