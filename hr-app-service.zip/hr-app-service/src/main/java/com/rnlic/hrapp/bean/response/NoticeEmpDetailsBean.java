package com.rnlic.hrapp.bean.response;

public class NoticeEmpDetailsBean {
	
	private String name;
	private long SapCode;
	private String managerName;
	private long managerSapCode;
	private String message;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getSapCode() {
		return SapCode;
	}
	public void setSapCode(long sapCode) {
		SapCode = sapCode;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public long getManagerSapCode() {
		return managerSapCode;
	}
	public void setManagerSapCode(long managerSapCode) {
		this.managerSapCode = managerSapCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
