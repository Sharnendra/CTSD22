package com.rnlic.hrapp.bean.request;

public class AnniversaryReqBean {

	private SearchParam searchParam;

	public SearchParam getSearchParam() {
		return searchParam;
	}

	public void setSearchParam(SearchParam searchParam) {
		this.searchParam = searchParam;
	}
	
}
