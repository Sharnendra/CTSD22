package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

import com.rnlic.hrapp.bean.api.response.SubscriptionResponse;

public class SubscriptionResponseList implements ResponseData{

	private List<SubscriptionResponse> subscriptionList = new ArrayList<>();

	public List<SubscriptionResponse> getSubscriptionList() {
		return subscriptionList;
	}

	public void setSubscriptionList(List<SubscriptionResponse> subscriptionList) {
		this.subscriptionList = subscriptionList;
	}

	@Override
	public String toString() {
		return "[" + subscriptionList + "]";
	}
	
	
}
