package com.rnlic.hrapp.bean.api.request;

public class CandidateDetailsRnlicReqBean {
	private String moblieNo;
	private String panNo;
	public String getMoblieNo() {
		return moblieNo;
	}
	public void setMoblieNo(String moblieNo) {
		this.moblieNo = moblieNo;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	
}
