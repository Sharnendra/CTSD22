package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class ReporteeNotFoundException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ReporteeNotFoundException() {
		super(ErrorConstants.REPORTEE_NOT_FOUND_CODE,ErrorConstants.REPORTEE_NOT_FOUND_MESSAGE,false,false);
	}
	
	public ReporteeNotFoundException(String message) {
		super(ErrorConstants.REPORTEE_NOT_FOUND_CODE,message,false,false);
	}
}
