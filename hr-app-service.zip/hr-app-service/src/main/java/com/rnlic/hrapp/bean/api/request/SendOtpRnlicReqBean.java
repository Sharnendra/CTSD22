package com.rnlic.hrapp.bean.api.request;

public class SendOtpRnlicReqBean {
	private String mobile;
	private String text;
	public String getMobile() {
		return this.mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getText() {
		return this.text;
	}
	public void setText(String text) {
		this.text = text;
	} 

}
