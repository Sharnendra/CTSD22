package com.rnlic.hrapp.constant;

/**
 * this class contain all error message
 */
public class ErrorConstants {
	
	public static final String REMOTE_SERVICE_NOT_AVAILABLE_CODE = "CODE0000001";
	public static final String REMOTE_SERVICE_NOT_AVAILABLE_MESSAGE = "Remote Service Not Available";
	public static final String UNKNOWN_ERROR_CODE = "UNKNOWNERROR";
	public static final String UNKNOWN_ERROR_MESSAGE = "Something went wrong please try again after some time.";
	public static final String MANDATORY_FIELDS_NOT_AVAILABLE_CODE = "CODE0000002";
	public static final String MANDATORY_FIELDS_NOT_AVAILABLE_MESSAGE = "Mandatory Fields Not Available";
	public static final String NO_SUCH_USER_EXIST_CODE = "CODE0000004";
	public static final String NO_SUCH_USER_EXIST_MESSAGE = "No Such User Found";
	public static final String USER_DETAILS_DOES_NOT_EXIST_CODE = "CODE0000003";
	public static final String USER_DETAILS_DOES_NOT_EXIST_MESSAGE = "User Details Does Not Exists";
	public static final String BAD_REQUEST = "Bad Request!!";
	public static final String USER_NOT_AUTHORIZED_CODE = "CODE0000005";
	public static final String USER_NOT_AUTHORIZED_MESSAGE = "User Name and Password provide does not have any rights to access this method";
	public static final String SERVICE_ASPECT_ERROR_CODE = "CODE0000006";
	public static final String SERVICE_ASPECT_ERROR_MESSAGE = "Service Apect has Error";
	public static final String DEVICE_REGWITH_OTHER_CODE = "CODE0000007";
	public static final String DEVICE_REGWITH_OTHER_MESSAGE = "Your login is registered on another device";
	public static final String CHECK_IN_CHECK_OUT_CODE= "CODE0000008";
	public static final String CHECK_IN_CHECK_OUT_MESSAGE= "The Service not able to determine weather to perform 'check-in' or 'check-out'. Please Specify any one of these two.";
	public static final String BAD_REQUEST_CODE = "CODE0000009";
	public static final String OTP_EXCEPTION_CODE = "CODE0000010";
	public static final String RNLIC_SERVICE_DOWN_CODE = "CODE0000011";
	public static final String RNLIC_SERVICE_DOWN_MESSAGE = "Temporarily service is not available. Please try after sometime.";
	public static final String NO_DEVICE_REHISTERED = "There is no device registred for this user.";
	public static final String REPORTEE_NOT_FOUND_CODE = "CODE0000012";
	public static final String REPORTEE_NOT_FOUND_MESSAGE = "Reportees not found";
	public static final String STATE_DETAILS_NOT_FOUND_CODE = "CODE0000013";
	public static final String STATE_DETAILS_NOT_FOUND_MESSAGE = "No Details Found From State City Details Master";
	public static final String RNLIC_RESPONSE_EXCEPTION_CODE = "CODE0000014";
	public static final String RNLIC_RESPONSE_EXCEPTION_MESSAGE = "RNLIC service returns with HttpStatus : ";
	public static final String MAIL_SERVICE_CODE= "CODE0000015";
	public static final String MAIL_SERVICE_MESSAGE= "Sending Email failed due to invalid email id";
	public static final String COMMUNICATION_CODE = "CODE0000016";
	public static final String COMMUNICATION_MESSAGE = "Not a Valid Communication Channel";
	public static final String JWT_TOKEN_EXPIRED_CODE = "CODE0000017";
	public static final String JWT_TOKEN_EXPIRED_MESSAGE = "Your current device has been de-registered, Please log out and login again to register this device. ";
	public static final String JWT_TOKEN_NOT_VALIDATED_MESSAGE = "JWT Token is not valid";
	public static final String NOTIFICATION_FAILED_MESSAGE = "In-App Notification failed ";
	public static final String NOTIFICATION_SUCESS_MESSAGE = "In-App Notification success ";
	public static final String NOTIFY_PHONE_OR_EMAIL = "Please specify either phone number or email address or both";
	public static final String OTP_GENERATION_ERROR_CODE = "CODE0000018";
	public static final String PASSWORD_UPDATE_ERROR_CODE = "CODE0000019";
	public static final String PUSH_NOTIFICATION_EXCEPTION_CODE = "CODE0000020";	
	public static final String PUSH_NOTIFICATION_EXCEPTION_MESSAGE = "Notification does not exist";
}
