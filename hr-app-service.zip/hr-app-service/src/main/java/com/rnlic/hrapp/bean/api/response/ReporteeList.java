package com.rnlic.hrapp.bean.api.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ReporteeList {

	@JsonProperty(value = "ReporteeInformation")
	private List<ReporteeInformationRnlicResponseBean> reporteeInformation=new ArrayList<>();

	public List<ReporteeInformationRnlicResponseBean> getReporteeInformation() {
		return reporteeInformation;
	}

	public void setReporteeInformation(List<ReporteeInformationRnlicResponseBean> reporteeInformation) {
		this.reporteeInformation = reporteeInformation;
	}
}
