package com.rnlic.hrapp.bean.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AndroidResBean {

	private String packageId;
	private String androidScheme;
	private String storeUrl;
	public String getPackageId() {
		return packageId;
	}
	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}
	public String getAndroidScheme() {
		return androidScheme;
	}
	public void setAndroidScheme(String androidScheme) {
		this.androidScheme = androidScheme;
	}
	public String getStoreUrl() {
		return storeUrl;
	}
	public void setStoreUrl(String storeUrl) {
		this.storeUrl = storeUrl;
	}
	@Override
	public String toString() {
		return "AndroidResBean [packageId=" + packageId + ", androidScheme=" + androidScheme + "]";
	}
	
	
}
