package com.rnlic.hrapp.bean.api.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionRnlicResBean extends RnlicRestResponse{
	
	@JsonProperty(value = "Response")
	List<SubscriptionResponse> response = new ArrayList<>();

	public SubscriptionRnlicResBean() {
		super();
	}

	public SubscriptionRnlicResBean(List<SubscriptionResponse> response) {
		super();
		this.response = response;
	}

	public List<SubscriptionResponse> getResponse() {
		return response;
	}

	public void setResponse(List<SubscriptionResponse> response) {
		this.response = response;
	}	
}
