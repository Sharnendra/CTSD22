package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class StateDetailsNotFoundException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public StateDetailsNotFoundException() {
		super(ErrorConstants.STATE_DETAILS_NOT_FOUND_CODE,ErrorConstants.STATE_DETAILS_NOT_FOUND_MESSAGE,false,false);
	}
	
	public StateDetailsNotFoundException(String message) {
		super(ErrorConstants.STATE_DETAILS_NOT_FOUND_CODE,message,false,false);
	}
}
