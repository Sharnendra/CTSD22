package com.rnlic.hrapp.security;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.exception.JWTTokenException;
import com.rnlic.hrapp.util.HrAppUtil;

@Component
public class JwtAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider {

    @Autowired
    private JwtValidator validator;
    
    @Autowired
    private MessagesConstants messagesConstants;

    @Override
    protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken) throws AuthenticationException {

    }

    @Override
    protected UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken) throws AuthenticationException {

        JwtAuthenticationToken jwtAuthenticationToken = (JwtAuthenticationToken) usernamePasswordAuthenticationToken;
        String token = jwtAuthenticationToken.getToken();

        UserDetailsBean jwtUser = validator.validate(token);
        if (jwtUser == null) {
            throw new JWTTokenException(String.valueOf(HttpStatus.OK),messagesConstants.getIncorrectJwtTokenMsg(),false);
        }

        List<GrantedAuthority> grantedAuthorities =AuthorityUtils.createAuthorityList(HrAppUtil.roleMapper(jwtUser.getRole()));
        return new JwtUserDetails(jwtUser,
                token,
                grantedAuthorities);
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return (JwtAuthenticationToken.class.isAssignableFrom(aClass));
    }
}
