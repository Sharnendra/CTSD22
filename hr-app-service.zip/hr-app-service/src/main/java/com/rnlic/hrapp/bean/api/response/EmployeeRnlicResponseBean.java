package com.rnlic.hrapp.bean.api.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeeRnlicResponseBean extends RnlicRestResponse{
	
	@JsonProperty(value = "Response")
	List<EmployeeDetailsRnlicResponseBean> response;

	public EmployeeRnlicResponseBean() {
		super();
	}

	public EmployeeRnlicResponseBean(List<EmployeeDetailsRnlicResponseBean> response) {
		super();
		this.response = response;
	}

	public List<EmployeeDetailsRnlicResponseBean> getResponse() {
		return response;
	}

	public void setResponse(List<EmployeeDetailsRnlicResponseBean> response) {
		this.response = response;
	}	
}
