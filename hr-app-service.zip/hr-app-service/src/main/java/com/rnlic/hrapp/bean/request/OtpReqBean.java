package com.rnlic.hrapp.bean.request;

public class OtpReqBean {
	
	private String action;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
}
