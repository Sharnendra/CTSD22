package com.rnlic.hrapp.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rnlic.hrapp.bean.request.BirthdayReqBean;
import com.rnlic.hrapp.bean.request.WishEmpReqBean;
import com.rnlic.hrapp.bean.response.RestResponse;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.UrlConstants;
import com.rnlic.hrapp.exception.BadRequestException;
import com.rnlic.hrapp.exception.HrAppException;
import com.rnlic.hrapp.exception.UnhandledException;
import com.rnlic.hrapp.security.JwtDecriptor;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.BirthdayWishService;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestValidator;
import com.rnlic.hrapp.util.RequestValidatorResponse;

@RestController
@RequestMapping(UrlConstants.SERVICE)
public class BirthdayWishController extends BaseController {
	
	private static final Logger log = LogManager.getLogger(BirthdayWishController.class);
	
	@Autowired
	private BirthdayWishService birthdayWishService;
	
	@Autowired
	private JwtDecriptor jwtDecriptor;
	
	/**
	 * This Function will search for birthdays.
	 * 
	 * @author HRMSAPP
	 * @param Authorization   token
	 * @param BirthdayReqBean birthdayReqBean
	 * @return ResponseData BirthdayResBean
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.SEARCH_BIRTHDAY_ANNIVERSARY_URL)
	public RestResponse searchBirthday(@RequestBody BirthdayReqBean birthdayReqBean,
			@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) throws JsonProcessingException {
		
		RestResponse restResponse = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,restResponse.getRequestId(),null,null,null,"searchBirthday");
		log.info(requestLog.toString()+ "== searchBirthday :=====");
		try {
			RequestValidatorResponse reqRes = RequestValidator.requestValidator(birthdayReqBean);
			if(reqRes.isValid()) {
				UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
				restResponse.setData(birthdayWishService.searchBirthdayAnniversary(userDetailsBean,birthdayReqBean));
			}else {
				throw new BadRequestException(reqRes.getMessage());
			}
			
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== searchBirthday HrAppException:=====", e);
			restResponse.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== searchBirthday UnhandledException:=====", t);
			restResponse.setError(new UnhandledException());
		}
		return restResponse;
	}
	
	
	
	/**
	 * This Function will wish the employee on the occasions like birthday/
	 * anniversaries.
	 * 
	 * @author HRMSAPP
	 * @param Authorization  token
	 * @param WishEmpReqBean wishEmpReqBean as the details of employee whom to wish.
	 * @return ResponseData AnniversaryResBean
	 * @throws JsonProcessingException 
	 */
	@PostMapping(UrlConstants.WISH_EMPLOYEE_URL)
	public RestResponse wishEmployee(@RequestBody WishEmpReqBean wishEmpReqBean,
			@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) throws JsonProcessingException {
		
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"wishEmployee");
		log.info(requestLog.toString()+ "== searchBirthday :=====");
		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			response.setData(birthdayWishService.wishEmployee(userDetailsBean,wishEmpReqBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== wishEmployee HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== wishEmployee UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}
	
	/**
	 * This URL will return list of todays birthday
	 * 
	 * @param String jwtToken
	 * @return RestResponse listOfbirthday
	 */
	@PostMapping(UrlConstants.GET_BIRTHDAY_URL)
	public RestResponse getBirthday(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) {
		
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"getBirthday");
		log.info(requestLog.toString()+ "== getBirthday :=====");
		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			response.setData(birthdayWishService.getBirthday(userDetailsBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== getBirthday HrAppException:=====", e);
			response.setError(e);
		}catch(Exception t) {
			log.error(requestLog.toString()+ "== getBirthday UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}
	
	/**
	 * This URL will return list of todays Reportee birthday
	 * @param String jwtToken
	 * @return RestResponse listOfbirthday
	 */
	@PostMapping(UrlConstants.GET_REPORTEE_BIRTHDAY_URL)
	public RestResponse getReporteeBirthday(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) {
		
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"getReporteeBirthday");
		log.info(requestLog.toString()+ "== getReporteeBirthday :=====");
		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			response.setData(birthdayWishService.getReporteeBirthday(userDetailsBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== getReporteeBirthday HrAppException:=====", e);
			response.setError(e);
		}
		catch(Exception t) {
			log.error(requestLog.toString()+ "== getReporteeBirthday UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}
	
	/**
	 * This URL will return list of todays Anniversary
	 * 
	 * @param String jwtToken
	 * @return RestResponse listOfAnniversary
	 */
	@PostMapping(UrlConstants.GET_ANNIVERSARY_URL)
	public RestResponse getAnniversary(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) {
		
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"getAnniversary");
		log.info(requestLog.toString()+ "== getAnniversary :=====");
		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			response.setData(birthdayWishService.getAnniversary(userDetailsBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== getAnniversary HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== getAnniversary UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}
	
	/**
	 * This URL will return list of todays Reportee Anniversary
	 * @param String jwtToken
	 * @return RestResponse listOfbirthday
	 */
	@PostMapping(UrlConstants.GET_REPORTEE_ANNIVERSARY_URL)
	public RestResponse getReporteeAnniversary(@RequestHeader(GenericConstants.AUTHORIZATION) String jwtToken) {
		
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"getReporteeAnniversary");
		log.info(requestLog.toString()+ "== getReporteeAnniversary :=====");
		try {
			UserDetailsBean userDetailsBean = jwtDecriptor.jwtDecript(jwtToken);
			response.setData(birthdayWishService.getReporteeAnniversary(userDetailsBean));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== getReporteeAnniversary HrAppException:=====", e);
			response.setError(e);
		}
		catch(Exception t) {
			log.error(requestLog.toString()+ "== getReporteeAnniversary UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}
	

}
