package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ReporteeListRnlicResponseBean extends RnlicRestResponse{

	@JsonProperty(value = "Response")
	private ReporteeList response;

	public ReporteeList getResponse() {
		return response;
	}

	public void setResponse(ReporteeList response) {
		this.response = response;
	}
	
}
