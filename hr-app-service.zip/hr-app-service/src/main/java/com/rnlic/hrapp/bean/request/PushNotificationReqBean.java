package com.rnlic.hrapp.bean.request;

import com.rnlic.hrapp.entity.PushDataModal;

public class PushNotificationReqBean {

	private String to;
	private boolean content_available;
	private String priority;
	private PushNotification notification;
	private PushDataModal data;
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public boolean isContent_available() {
		return content_available;
	}
	public void setContent_available(boolean content_available) {
		this.content_available = content_available;
	}
	public PushNotification getNotification() {
		return notification;
	}
	public void setNotification(PushNotification notification) {
		this.notification = notification;
	}
	public PushDataModal getData() {
		return data;
	}
	public void setData(PushDataModal data) {
		this.data = data;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
}
