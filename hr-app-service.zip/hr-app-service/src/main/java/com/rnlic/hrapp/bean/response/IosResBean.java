package com.rnlic.hrapp.bean.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class IosResBean {

	private String bundleId;
	private String uriScheme;
	private String storeUrl;
	public String getBundleId() {
		return bundleId;
	}
	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}
	public String getUriScheme() {
		return uriScheme;
	}
	public void setUriScheme(String uriScheme) {
		this.uriScheme = uriScheme;
	}
	public String getStoreUrl() {
		return storeUrl;
	}
	public void setStoreUrl(String storeUrl) {
		this.storeUrl = storeUrl;
	}
	@Override
	public String toString() {
		return "IosResBean [bundleId=" + bundleId + ", uriScheme=" + uriScheme + "]";
	}
	
	
}
