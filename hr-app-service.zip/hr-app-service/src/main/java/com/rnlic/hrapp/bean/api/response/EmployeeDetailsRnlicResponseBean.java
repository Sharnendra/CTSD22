package com.rnlic.hrapp.bean.api.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeeDetailsRnlicResponseBean implements RnlicResponseData{
	
	@JsonProperty (value = "Name") 
	private String name; 
	@JsonProperty (value = "SAPCode") 
	private String sapCode; 
	@JsonProperty (value = "MobileNo") 
	private String mobileNo; 
	@JsonProperty (value = "EmailID") 
	private String emailID; 
	@JsonProperty (value = "Channel") 
	private String channel; 
	@JsonProperty (value = "JobRole") 
	private String role; 
	@JsonProperty (value = "Level") 
	private String level;
	@JsonProperty (value = "ManagerSAPCode") 
	private String managerSAPCode; 
	@JsonProperty (value = "ManagerName") 
	private String managerName; 
	@JsonProperty (value = "LocationCode") 
	private String locationCode;
	@JsonProperty (value = "LocationName") 
	private String locationName;
	@JsonProperty (value = "UserRole") 
	private String userRole;
	@JsonProperty (value = "ZoneCode") 
	private String zoneCode;
	@JsonProperty (value = "ZoneName") 
	private String zoneName;
	@JsonProperty (value = "PANNumber")
	private String panNumber;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSapCode() {
		return sapCode;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getManagerSAPCode() {
		return managerSAPCode;
	}
	public void setManagerSAPCode(String managerSAPCode) {
		this.managerSAPCode = managerSAPCode;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getZoneCode() {
		return zoneCode;
	}
	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}
	public String getZoneName() {
		return zoneName;
	}
	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	
	
}
