package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class ServiceAspectException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ServiceAspectException() {
		super(ErrorConstants.SERVICE_ASPECT_ERROR_CODE,ErrorConstants.SERVICE_ASPECT_ERROR_MESSAGE,false,false);
	}
	public ServiceAspectException(String message) {
		super(ErrorConstants.SERVICE_ASPECT_ERROR_CODE,message,false,false);
	}
}
