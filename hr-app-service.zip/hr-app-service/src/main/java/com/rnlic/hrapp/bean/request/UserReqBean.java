package com.rnlic.hrapp.bean.request;

import java.util.ArrayList;
import java.util.List;

public class UserReqBean {
    private String fristName;
    private String lastName;
    private String sapCode;
    private String mobileNumber;
    private String panNumber;
    private boolean hasReportee;
    private boolean isCandidate;
    public boolean isCandidate() {
		return isCandidate;
	}
	public void setCandidate(boolean isCandidate) {
		this.isCandidate = isCandidate;
	}
	private String managerSapCode;
    private List<String> role=new ArrayList<>();
    private String level;
	public String getFristName() {
		return fristName;
	}
	public void setFristName(String fristName) {
		this.fristName = fristName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSapCode() {
		return sapCode;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public boolean isHasReportee() {
		return hasReportee;
	}
	public void setHasReportee(boolean hasReportee) {
		this.hasReportee = hasReportee;
	}
	public String getManagerSapCode() {
		return managerSapCode;
	}
	public void setManagerSapCode(String managerScope) {
		this.managerSapCode = managerScope;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public List<String> getRole() {
		return role;
	}
	public void setRole(List<String> role) {
		this.role = role;
	}
	
    
}
