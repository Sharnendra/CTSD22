package com.rnlic.hrapp.security;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.rnlic.hrapp.bean.response.CheckForDeviceRegistrationResBean;
import com.rnlic.hrapp.constant.ErrorConstants;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;
import com.rnlic.hrapp.exception.DeviceRegistrationException;
import com.rnlic.hrapp.repository.DeviceRegistrationRepository;
import com.rnlic.hrapp.service.DeviceRegistrationService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@Aspect
@Component
public class ServiceAspect {

	@Autowired
	private GenericConstants genericConstants;
	
	@Autowired
	private DeviceRegistrationService deviceRegistrationService;
	
	@Autowired
	private DeviceRegistrationRepository deviceRegistrationRepository;
	
	@Before(value = "@annotation(com.rnlic.hrapp.security.ValidateRegistry)") // in parameter list
	public void afterAdviceValidateRegistry(JoinPoint joinPoint) {
		MethodSignature signature = (MethodSignature) joinPoint.getSignature();
		Method method = signature.getMethod();
		if (method.isAnnotationPresent(ValidateRegistry.class)) {
			ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		    HttpServletRequest httpServletRequest = attributes.getRequest();
			String header = httpServletRequest.getHeader(GenericConstants.AUTHORIZATION);
			header = header.replace("Bearer ", "");
			Claims body = Jwts.parser().setSigningKey(genericConstants.getSigningKeyValue()).parseClaimsJws(header)
					.getBody();
			CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceRegistrationService.checkRegistrationInfomation(
					(String) body.get(GenericConstants.JWT_DEVICE_ID),
					(String) body.get(GenericConstants.JWT_USER_ID),
					(String) body.get(GenericConstants.JWT_MOBILE_NUMBER));
			
			DeviceRegistrationModel deviceRegistrationModel=deviceRegistrationRepository.findByDeviceIdentifier((String)body.get(GenericConstants.JWT_DEVICE_ID));
			
			if(null==deviceRegistrationModel) {
				throw new DeviceRegistrationException(ErrorConstants.JWT_TOKEN_EXPIRED_MESSAGE,true);
			}
			if(deviceRegisBean.isDeviceRegisterWithOthers()) {
				throw new DeviceRegistrationException(ErrorConstants.JWT_TOKEN_EXPIRED_MESSAGE,true);
			}
		}
	}
}
