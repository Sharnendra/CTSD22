package com.rnlic.hrapp.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.rnlic.hrapp.bean.api.request.ApplicationConfigReqBean;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.bean.response.RestResponse;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.UrlConstants;
import com.rnlic.hrapp.exception.HrAppException;
import com.rnlic.hrapp.exception.UnAuthorizedAdminException;
import com.rnlic.hrapp.exception.UnhandledException;
import com.rnlic.hrapp.service.ApplicationEnablementService;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestValidator;

@RestController
public class ApplicationEnablementController extends BaseController {

	private static final Logger log = LogManager.getLogger(ApplicationEnablementController.class);

	@Autowired
	private ApplicationEnablementService applicationEnablementService;
	
	/**
	 * This Function will return the active application configuration.
	 * 
	 * @author HRMSAPP
	 * @param none
	 * @return ResponseData LinkedAppConfigRes
	 */
	@PostMapping(UrlConstants.GET_LINKED_APPLICATION_CONFIG_URL)
	public RestResponse getApplicationConfiguration() {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"GetApplicationConfiguration");
		log.info(requestLog.toString()+ "== GetApplicationConfiguration :=====");
		try {
			response.setData(applicationEnablementService.getLinkedAppConfiguration());
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== GetApplicationConfiguration  HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== GetApplicationConfiguration  UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}

	/**
	 * This Function will de-activate all previous application configuration then
	 * add new application configuration and update the same.
	 * 
	 * @author HRMSAPP
	 * @param SYSTEM_ADMIN_USER        as user name
	 * @param SYSTEM_ADMIN_PASSWORD    as password
	 * @param ApplicationConfigReqBean appconfig for application configurations
	 * @return ResponseData LinkedAppConfigRes
	 */
	@PostMapping(UrlConstants.UPDATE_APPLICATION_CONFIGURATION_URL)
	public RestResponse updateApplicationConfiguration(
			@RequestHeader(GenericConstants.SYSTEM_ADMIN_USER) String userName,
			@RequestHeader(GenericConstants.SYSTEM_ADMIN_PASSWORD) String userPassword,
			@RequestBody ApplicationConfigReqBean appconfig) {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"UpdateApplicationConfiguration");
		log.info(requestLog.toString()+ "== UpdateApplicationConfiguration :=====");
		try {
			// Step1: Check wether the user is Authorized to perform this task or not.
			if (!RequestValidator.requestValidator(userName, userPassword).isValid()) {
				// Step2: Throw Error Message for Un-Authorized Admin.
				log.info(requestLog.toString()+ "== UpdateApplicationConfiguration the username and password provided is not valid:=====");
				throw new UnAuthorizedAdminException();
			} else {
				response.setData(applicationEnablementService.updateLinkedAppConfiguration(appconfig));
				log.info(requestLog.toString()+ "== UpdateApplicationConfiguration configuration is updated:=====");
			}
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== UpdateApplicationConfiguration HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== UpdateApplicationConfiguration UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}

	/**
	 * This Function will return the active application configuration.
	 * 
	 * @author HRMSAPP
	 * @param none
	 * @return ResponseData String
	 */
	@PostMapping(UrlConstants.GET_LINKED_APPLICATION_CONFIG_VERSION_URL)
	public RestResponse getApplicationConfigurationVersion() {
		RestResponse response = new RestResponse(HrAppUtil.generateRequestId());
		setRequestLog(requestLog,response.getRequestId(),null,null,null,"GetApplicationConfigurationVersion");
		log.info(requestLog.toString()+ "== UpdateApplicationConfiguration :=====");
		log.info(GenericConstants.REQUEST_ID + response.getRequestId());
		try {
			response.setData(new VersionResponse(applicationEnablementService.getLinkedAppConfigurationVersion()));
		} catch (HrAppException e) {
			log.error(requestLog.toString()+ "== GetApplicationConfigurationVersion HrAppException:=====", e);
			response.setError(e);
		} catch (Exception t) {
			log.error(requestLog.toString()+ "== GetApplicationConfigurationVersion UnhandledException:=====", t);
			response.setError(new UnhandledException());
		}
		return response;
	}

	protected class VersionResponse implements ResponseData {
		private String version;

		public VersionResponse(String version) {
			this.version = version;
		}

		public String getVersion() {
			return version;
		}
	}
}
