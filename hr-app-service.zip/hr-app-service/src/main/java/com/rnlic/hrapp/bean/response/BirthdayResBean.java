package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

public class BirthdayResBean implements ResponseData{

	public BirthdayResBean(List<Birthday> birthday) {
		this.birthday = birthday;
	}

	private List<Birthday> birthday=new ArrayList<>();

	public List<Birthday> getBirthday() {
		return birthday;
	}

	public void setBirthday(List<Birthday> birthday) {
		this.birthday = birthday;
	}
	
}
