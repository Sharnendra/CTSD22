package com.rnlic.hrapp.bean.response;

import java.util.ArrayList;
import java.util.List;

public class NotificationsResBean implements ResponseData{
	
	List<NoticeDetails> notifications = new ArrayList<>();

	public List<NoticeDetails> getNotifications() {
		return notifications;
	}

	public void setNotifications(List<NoticeDetails> notifications) {
		this.notifications = notifications;
	}

}
