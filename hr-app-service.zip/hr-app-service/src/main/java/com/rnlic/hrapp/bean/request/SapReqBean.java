package com.rnlic.hrapp.bean.request;

public class SapReqBean {

	private String sapCode;

	public String getSapCode() {
		return sapCode;
	}

	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}

}
