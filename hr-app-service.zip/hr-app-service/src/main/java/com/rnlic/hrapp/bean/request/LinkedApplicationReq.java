package com.rnlic.hrapp.bean.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class LinkedApplicationReq {
	
	private String version;
	private String description;
	private String applicationVersion;
	private String applicationId;
	private String applicationPackage;
	private List<ApplicationGroups> applicationGroups;	
	
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getApplicationVersion() {
		return applicationVersion;
	}
	public void setApplicationVersion(String applicationVersion) {
		this.applicationVersion = applicationVersion;
	}
	public List<ApplicationGroups> getApplicationGroups() {
		return applicationGroups;
	}
	public void setApplicationGroups(List<ApplicationGroups> applicationGroups) {
		this.applicationGroups = applicationGroups;
	}
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getApplicationPackage() {
		return applicationPackage;
	}
	public void setApplicationPackage(String applicationPackage) {
		this.applicationPackage = applicationPackage;
	}
	@Override
	public String toString() {
		return "LinkedApplicationReq [version=" + version + ", description=" + description + ", applicationVersion="
				+ applicationVersion + ", applicationId=" + applicationId + ", applicationPackage=" + applicationPackage
				+ ", applicationGroups=" + applicationGroups + "]";
	}
}
