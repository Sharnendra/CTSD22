package com.rnlic.hrapp.constant;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.rnlic.hrapp.exception.RestTemplateResponseErrorHandler;

@Component
public class GenericConstants implements InitializingBean{

	public static final RestTemplate REST_TEMPLATE =new RestTemplate();
	static
	{
		REST_TEMPLATE.setErrorHandler(new RestTemplateResponseErrorHandler());
	}
	
	private static final Logger log = LogManager.getLogger(GenericConstants.class);
	
	public static final String EMPTY_STRING = "";
	public static final boolean TRUE = true;
	public static final boolean FALSE = false;
	public static final int INTEGER_ONE = 1;
	public static final int INTEGER_ZERO = 0;
	public static final int INTEGER_TWO = 2;
	public static final int MILISECOND = 1000;
	public static final int SECOND = 60;
	public static final int INTEGER_FOUR = 4;
	
	public static final String APPLICATION = "APPLICATION";
	public static final String MOBILE = "Mobile";
	public static final String AUTHORIZATION = "Authorization";
	public static final String REQUEST_ID = "REQUEST_ID: ";
	public static final String VALID_UPTO = " valid upto: ";
	public static final String WHITE_SPACE = " ";
	public static final String EXCEPTION = "Exception is : ";
	public static final String MOBILE_NO = "Mobile Number";
	public static final String PAN_NO = "PAN Number";
	public static final String DEVICE_IDENTIFIER = "Device Identifier";
	public static final String DOMAIN_PASSWORD = "Domain Password";
	public static final String SAP_CODE = "SAP Code";
	public static final String IS_EMPTY = " is Empty";
	public static final String COMMA = ", ";
	public static final String SUCESS="Sucess";
	public static final String UNAUTHORIZED="UNAUTHORIZED";
	public static final String BEARER="Bearer ";
	public static final String JWT_USER_ID="userId";
	public static final String JWT_DEVICE_ID="deviceIdentifier";
	public static final String JWT_FIRST_NAME="fristName";
	public static final String JWT_LAST_NAME="lastName";
	public static final String JWT_SAP_CODE="sapCode";
	public static final String JWT_MOBILE_NUMBER="mobileNumber";
	public static final String JWT_PAN_NUMBER="panNumber";
	public static final String JWT_HAS_REPORTEE="hasReportee";
	public static final String JWT_IS_CANDIDATE="isCandidate";
	public static final String JWT_MANAGER_SAP_CODE="managerSapCode";
	public static final String JWT_ROLE="role";
	public static final String JWT_LEVEL="level";
	public static final String SYSTEM_ADMIN_USER = "admin-user";
	public static final String SYSTEM_ADMIN_PASSWORD = "admin-pass";
	public static final String PLEASE_PROVIDE = "Please provide ";

	public static final String PATTERN = "dd-MM-yyyy HH:mm:ss";
	public static final String ALREADY_REGISTERED = "Device is already registered.";
	public static final String PATTERN_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String PATTERN_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	public static final String FAILURE = "Failure";
	public static final String HYPHEN = "-";
	public static final String PATTERN_HH_MM_SS = "HH:mm:ss";
	public static final String TRUE_STRING = "true";
	public static final String FALSE_STRING = "false";
	public static final String FAILED = "Failed";
	public static final String SUCCESS = "Success";

	public static final Set<String> DEFAULT_PRODUCES_AND_CONSUMES = new HashSet<>(Arrays.asList("application/json"));
	public static final String DATA_FOUND = "Data Found.";
	public static final String NO_DATA_FOUND = "No Data Found.";
	public static final String DATA_LOADED_SUCCESS = "Data loaded successfully.";
	public static final String REST_EXCEPTION_RESPONSE=" Returning Response : ";
	public static final String MAIL_HOST = "mail.smtp.host";
	public static final String MAIL_POST = "mail.smtp.port";
	public static final String MAIL_DEBUG = "mail.debug";
	public static final String MAIL_CONTENT_TYPE = "Content-type";
	public static final String MAIL_FORMAT = "format";
	public static final String MAIL_CONTENT_TRANSFER_ENCODING = "Content-Transfer-Encoding";
	public static final String MAIL_EMAIL_FROM = "Rnlife.headcustomercare@reliancelife.com";
	public static final String MAIL_UTF = "UTF-8";
	public static final String MAIL_BIT8 = "8bit";
	public static final String MAIL_CHARSET_UTF = "text/HTML; charset=UTF-8";
	public static final String MAIL_FLOWED = "flowed";
	public static final String MAIL_NO_REPLY = "Rnlife.headcustomercare@reliancelife.com";
	public static final String COLLON_SPACE = ": ";
	public static final String CAP_FOR = "For ";
	public static final String FOR = "for ";
	public static final String AND = " and "; 
	public static final String SPACE = " ";
	public static final char SERVICE_TYPE_S = 'S';
	public static final char SERVICE_TYPE_E = 'E';
	public static final char SERVICE_TYPE_P = 'P';
	public static final String FIELD = "FIELD: ";
	public static final String MESSAGE = " MESSAGE: ";

	public static final String IS_CANDIDATE = "is_candidate";

	public static final String FCM_TOKEN = "fcmToken";

	public static final String EMAIL = "email";
	
	public static final String NAME = "name";

	public static final String STRING_P = "P";

	public static final String STRING_A = "A";

	public static final String STRING_L = "L";

	public static final String STRING_H = "H";

	public static final String STRING_WL = "WL";

	public static final String STRING_OD = "OD";

	public static final String STRING_S = "S";

	public static final int INTEGER_SEVEN = 7;

	public static final String PATTERN_YYYY_M_D = "yyyy-M-d";

	public static final String PATTERN_YYYY_MM_DD_T_HH_MM_SS = "yyyy-MM-dd'T'HH:mm:ss";

	public static final String DOUBLE_SPACE = "  ";

	public static final String PATTERN_MMM_D_YYYY_H_MM_A = "MMM d yyyy h:ma";

	public static final int INTEGER_SIXY = 60;

	public static final int INTEGER_THOUSAND = 1000;
	
	public static final String PATTERN_CHECK_IN_CHECK_OUT = "M/d/yy h:m:s a";
	public static final String LOCATION_LONGITUDE = "Location longitude: ";
	public static final String LOCATION_LATITUDE = "Location latitude: ";
	public static final String BRANCH_EMAIL = "Branch email: ";
	public static final String CONTACT_PERSON = "Contact person: ";
	public static final String CONTACT_NUMBER = "Contact number: ";
	public static final String BRANCH_CODE = "Branch code: ";
	public static final String BRANCH_ADDRESS = "Branch address: ";
	public static final String BRANCH_NAME = "Branch name: ";
	public static final String NULL_STRING = "NULL";
	//public static final String ACTION = "fcm.ACTION.RNLIC-HRAPP";
	public static final String TITLE = "RNLIC-HRAPP";
	public static final String JWT_TOKEN = "JWT_TOKEN: ";
	public static final String NEW_LINE = "\r\n";
	public static final String REQUEST_BODY = "Request Body: ";
	public static final String RNLIC_BRANCH_DETAILS = "RNLIC Branch Details";
	public static final String OTP_EKONNECT_MAIL = "OTP for eKonnect verification";
	public static final String INCORRECT_VALUES = "Incorrect Values: ";

	public static final String SATURDAY_OFF = "Saturday Off";

	public static final String STRING_SO = "SO";

	public static final String ALERT = "Alert";

	public static final String RETURN_MESSAGE = "returnMessage";

	public static final String OTP_GENERATED_SUCCESS = "OTP GENERATED SUCCESSFULLY";
	public static final String PASSWORD_CHANGED_SUCCESS = "Password Changed Successfully";
	
	public static String ADMIN_USER;
	public static String ADMIN_PASSWORD;

	public static Map<Character,String> wishServiceMapError= new LinkedHashMap<Character,String>() {
		private static final long serialVersionUID = 1L;
	{
        put(SERVICE_TYPE_S, "Sending SMS");
        put(SERVICE_TYPE_E, "Sending Email");
        put(SERVICE_TYPE_P, "Sending Push Notification");
    }};

	@Value("${resend-count}")
	private int resendCountValue;
	@Value("${signing-key}")
	private String signingKeyValue;
	@Value("${retry-count}")
	private int retryCountValue;
	
	@Value("${otp-validity}")
	private int otpValidityValue;
	@Value("${otp-length}")
	private int otpLengthValue;
	
	@Value("${otp-lock}")
	private int otpLock;
	
	public int getOtpLock() {
		return otpLock;
	}

	public void setOtpLock(int otpLock) {
		this.otpLock = otpLock;
	}

	@Value("${scheduler.task.hours}")
	private int schedulerHours;
	@Value("${scheduler.task.minutes}")
	private int schedulerMinutes;
	@Value("${scheduler.task.second}")
	private int schedulerSecond;
	@Value("${scheduler.task.miliseconds}")
	private int schedulerMiliSeconds;
	
	@Value("${admin-user}")
	private String adminUser;
	@Value("${admin-pass}")	
	private String adminPass;
	
	@Value("${pushNotificationServerKey}")	
	private String pushNotificationServerKey;
	
	public int getResendCountValue() {
		return resendCountValue;
	}

	public void setResendCountValue(int resendCountValue) {
		this.resendCountValue = resendCountValue;
	}

	public String getSigningKeyValue() {
		return signingKeyValue;
	}

	public void setSigningKeyValue(String signingKeyValue) {
		this.signingKeyValue = signingKeyValue;
	}

	public int getRetryCountValue() {
		return retryCountValue;
	}
	
	public void setRetryCountValue(int retryCountValue) {
		this.retryCountValue = retryCountValue;
	}
	
	public int getOtpValidityValue() {
		return otpValidityValue;
	}

	public void setOtpValidityValue(int otpValidityValue) {
		this.otpValidityValue = otpValidityValue;
	}

	public int getOtpLengthValue() {
		return otpLengthValue;
	}

	public void setOtpLengthValue(int otpLengthValue) {
		this.otpLengthValue = otpLengthValue;
	}

	public int getSchedulerHours() {
		return schedulerHours;
	}

	public void setSchedulerHours(int schedulerHours) {
		this.schedulerHours = schedulerHours;
	}

	public int getSchedulerMinutes() {
		return schedulerMinutes;
	}

	public void setSchedulerMinutes(int schedulerMinutes) {
		this.schedulerMinutes = schedulerMinutes;
	}

	public int getSchedulerSecond() {
		return schedulerSecond;
	}

	public void setSchedulerSecond(int schedulerSecond) {
		this.schedulerSecond = schedulerSecond;
	}

	public int getSchedulerMiliSeconds() {
		return schedulerMiliSeconds;
	}

	public void setSchedulerMiliSeconds(int schedulerMiliSeconds) {
		this.schedulerMiliSeconds = schedulerMiliSeconds;
	}

	public String getAdminUser() {
		return adminUser;
	}

	public void setAdminUser(String adminUser) {
		ADMIN_USER = adminUser;
		this.adminUser = adminUser;
	}

	public String getAdminPass() {
		return adminPass;
	}

	public void setAdminPass(String adminPass) {
		ADMIN_PASSWORD = adminPass;
		this.adminPass = adminPass;
	}

	public String getPushNotificationServerKey() {
		return pushNotificationServerKey;
	}

	public void setPushNotificationServerKey(String pushNotificationServerKey) {
		this.pushNotificationServerKey = pushNotificationServerKey;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		setResendCountValue(resendCountValue);
		setSigningKeyValue(signingKeyValue);
		setRetryCountValue(retryCountValue);
		setSchedulerHours(schedulerHours);
		setSchedulerMinutes(schedulerMinutes);
		setSchedulerSecond(schedulerSecond);
		setSchedulerMiliSeconds(schedulerMiliSeconds);
		setAdminUser(adminUser);
		setAdminPass(adminPass);
		setOtpValidityValue(otpValidityValue);
		setOtpLengthValue(otpLengthValue);
		setOtpLock(otpLock);
		log.info("resendCount "+resendCountValue+" signingKey "+signingKeyValue+" retryCount "+retryCountValue);
	}

}
