package com.rnlic.hrapp.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.microsoft.sqlserver.jdbc.StringUtils;
import com.rnlic.hrapp.bean.request.AttendanceReqBean;
import com.rnlic.hrapp.bean.request.AuthReqBean;
import com.rnlic.hrapp.bean.request.BirthdayReqBean;
import com.rnlic.hrapp.bean.request.OtpReqBean;
import com.rnlic.hrapp.bean.request.OtpValidateReqBean;
import com.rnlic.hrapp.bean.request.RegisterDeviceReqBean;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.RequestValidatorConstants;

public class RequestValidator {

	public enum ACTION_ENUM {
		MOBILE_VARIFICATION, EMAIL_VARIFICATION,MOBILE_VERIFICATION, EMAIL_VERIFICATION
	}

//	public enum MONTH_ENUM {
//		JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,SEPT,OCT,NOV,DEC,JANUARY,FEBRUARY,MARCH,APRIL,JUNE,JULY,AUGUST,SEPTEMBER,OCTOBER,NOVEMBER,DECEMBER
//	}


	public static RequestValidatorResponse requestValidator(RegisterDeviceReqBean otpReqBean) {
		RequestValidatorResponse reqRes = new RequestValidatorResponse();
		if (!HrAppUtil.isNullOrEmpty(otpReqBean)) {
			if (!HrAppUtil.isNullOrEmpty(otpReqBean.getAction())) {
				if (otpReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.MOBILE_VARIFICATION))
						|| otpReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.EMAIL_VARIFICATION))
						|| otpReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.MOBILE_VERIFICATION))
						|| otpReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.EMAIL_VERIFICATION))) {
					reqRes.setValid(GenericConstants.TRUE);
					reqRes.setMessage(RequestValidatorConstants.VALID_REQUEST);
				}else {
					reqRes.setValid(GenericConstants.FALSE);
					reqRes.setMessage(RequestValidatorConstants.INVALID_ACTION);
				}
			}else {
				reqRes.setValid(GenericConstants.FALSE);
				reqRes.setMessage(RequestValidatorConstants.INVALID_ACTION_BLANK);
			}
		} else {
			reqRes.setValid(GenericConstants.FALSE);
			reqRes.setMessage(RequestValidatorConstants.INVALID_REQUEST);
		}
		return reqRes;
	}
	
	public static RequestValidatorResponse requestValidator(OtpReqBean otpReqBean) {
		RequestValidatorResponse reqRes = new RequestValidatorResponse();
		if (!HrAppUtil.isNullOrEmpty(otpReqBean)) {
			if (!HrAppUtil.isNullOrEmpty(otpReqBean.getAction())) {
				if (otpReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.MOBILE_VARIFICATION))
						|| otpReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.EMAIL_VARIFICATION))
						|| otpReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.MOBILE_VERIFICATION))
						|| otpReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.EMAIL_VERIFICATION))) {
					reqRes.setValid(GenericConstants.TRUE);
					reqRes.setMessage(RequestValidatorConstants.VALID_REQUEST);
				}else {
					reqRes.setValid(GenericConstants.FALSE);
					reqRes.setMessage(RequestValidatorConstants.INVALID_ACTION);
				}
			}else {
				reqRes.setValid(GenericConstants.FALSE);
				reqRes.setMessage(RequestValidatorConstants.INVALID_ACTION_BLANK);
			}
		} else {
			reqRes.setValid(GenericConstants.FALSE);
			reqRes.setMessage(RequestValidatorConstants.INVALID_REQUEST);
		}
		return reqRes;
	}

	public static RequestValidatorResponse requestValidator(AuthReqBean authReqBean) 
	{
		RequestValidatorResponse reqRes = new RequestValidatorResponse();
		List<String> errorFields=new ArrayList<>();
		if(authReqBean.getIsCandidate()) 
		{
			if(!(null!=authReqBean.getMobileNumber() && !(authReqBean.getMobileNumber()).equalsIgnoreCase(""))) 
			{
				errorFields.add(GenericConstants.MOBILE_NO);
			}

			if(!(null!=authReqBean.getPanNumber() && !(authReqBean.getPanNumber()).equalsIgnoreCase("")))
			{
				errorFields.add(GenericConstants.PAN_NO);
			}
			performCommonValidation(authReqBean, errorFields);
		}
		else 
		{
			if(!(null!=authReqBean.getSapCode() && !(authReqBean.getSapCode()).equalsIgnoreCase("")))
			{
				errorFields.add(GenericConstants.SAP_CODE);
			}
			if(!(null!=authReqBean.getDomainPassword() && !(authReqBean.getDomainPassword()).equalsIgnoreCase("")))
			{
				errorFields.add(GenericConstants.DOMAIN_PASSWORD);
			}
			performCommonValidation(authReqBean, errorFields);
		}

		if(!errorFields.isEmpty())
		{
			reqRes.setValid(GenericConstants.FALSE);
			errorFields.forEach(errorElement->{
				if(reqRes.getMessage().isEmpty())
				{
					reqRes.setMessage(errorElement);
				}
				else
				{
					reqRes.setMessage(reqRes.getMessage()+GenericConstants.COMMA+errorElement);
				}
			});
			reqRes.setMessage(GenericConstants.PLEASE_PROVIDE+reqRes.getMessage());
		}
		else
		{
			reqRes.setValid(GenericConstants.TRUE);
			reqRes.setMessage(RequestValidatorConstants.VALID_REQUEST);
		}
		return reqRes;
	}

	public static RequestValidatorResponse requestValidator(OtpValidateReqBean otpValidateReqBean) {

		RequestValidatorResponse reqRes = new RequestValidatorResponse();
		if (!HrAppUtil.isNullOrEmpty(otpValidateReqBean)) {
			if (!HrAppUtil.isNullOrEmpty(otpValidateReqBean.getAction()) && !HrAppUtil.isNullOrEmpty(otpValidateReqBean.getOtp())) {
				if (otpValidateReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.MOBILE_VARIFICATION))
						|| otpValidateReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.EMAIL_VARIFICATION))
						|| otpValidateReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.MOBILE_VERIFICATION))
						|| otpValidateReqBean.getAction().equalsIgnoreCase(String.valueOf(ACTION_ENUM.EMAIL_VERIFICATION))) {
					if(StringUtils.isNumeric(otpValidateReqBean.getOtp()) && isFourdigit(otpValidateReqBean.getOtp())) {
						reqRes.setValid(GenericConstants.TRUE);
						reqRes.setMessage(RequestValidatorConstants.VALID_REQUEST);
					}else {
						reqRes.setValid(GenericConstants.FALSE);
						reqRes.setMessage(RequestValidatorConstants.INVALID_REQUEST_OTP_SIX_DIGIT);
					}
				}else {
					reqRes.setValid(GenericConstants.FALSE);
					reqRes.setMessage(RequestValidatorConstants.INVALID_ACTION);
				}
			}else {
				reqRes.setValid(GenericConstants.FALSE);
				reqRes.setMessage(RequestValidatorConstants.INVALID_REQUEST_ACTION_OTP_BALNK);
			}
		} else {
			reqRes.setValid(GenericConstants.FALSE);
			reqRes.setMessage(RequestValidatorConstants.INVALID_REQUEST);
		}
		return reqRes;
	}

	public static RequestValidatorResponse requestValidator(String userName,String password)
	{
		RequestValidatorResponse reqRes = new RequestValidatorResponse();
		if(userName.equalsIgnoreCase(GenericConstants.ADMIN_USER)
				&& password.equalsIgnoreCase(GenericConstants.ADMIN_PASSWORD))
		{
			reqRes.setValid(true);
			reqRes.setMessage(RequestValidatorConstants.USERNAME_PASSWORD_VALID);
		}
		else
		{
			reqRes.setValid(false);
			reqRes.setMessage(RequestValidatorConstants.INVALID_USERNAME_PASSWORD);
		}
		return reqRes;
	}


	private static boolean isFourdigit(String otp) {
		return String.valueOf(otp).length() == GenericConstants.INTEGER_FOUR;
	}

	private static void performCommonValidation(AuthReqBean authReqBean,List<String> errorFields)
	{
		if(!(null!=authReqBean.getDeviceIdentifier() && !(authReqBean.getDeviceIdentifier()).equalsIgnoreCase(""))) 
		{
			errorFields.add(GenericConstants.DEVICE_IDENTIFIER);
		}

	}


	public static RequestValidatorResponse requestValidator(AttendanceReqBean attendanceReqBean) {
		RequestValidatorResponse reqRes = new RequestValidatorResponse();
		if (!HrAppUtil.isNullOrEmpty(attendanceReqBean)) {
			if (!HrAppUtil.isNullOrEmpty(attendanceReqBean.getSapCode()) && StringUtils.isNumeric(attendanceReqBean.getSapCode())) {
				if (!HrAppUtil.isNullOrEmpty(attendanceReqBean.getYear()) && StringUtils.isNumeric(attendanceReqBean.getYear())) {
					if (!HrAppUtil.isNullOrEmpty(attendanceReqBean.getMonth()) && StringUtils.isNumeric(attendanceReqBean.getMonth()) && isValidMonth(attendanceReqBean.getMonth())) {
							reqRes.setValid(GenericConstants.TRUE);
							reqRes.setMessage(RequestValidatorConstants.VALID_REQUEST);
					}else {
						reqRes.setValid(GenericConstants.FALSE);
						reqRes.setMessage(RequestValidatorConstants.INVALID_MONTH);
					}
				}else {
					reqRes.setValid(GenericConstants.FALSE);
					reqRes.setMessage(RequestValidatorConstants.INVALID_YEAR);
				}
			}else {
				reqRes.setValid(GenericConstants.FALSE);
				reqRes.setMessage(RequestValidatorConstants.INVALID_SAPCODE);
			}
		} else {
			reqRes.setValid(GenericConstants.FALSE);
			reqRes.setMessage(RequestValidatorConstants.INVALID_REQUEST);
		}
		return reqRes;
	}

	private static boolean isValidMonth(String month) {
		boolean isValid=false;
		if(StringUtils.isNumeric(month) && Integer.valueOf(month)>0 && Integer.valueOf(month)<13) {
			isValid=true;
		}
		return isValid;
	}


	public static RequestValidatorResponse requestValidator(BirthdayReqBean birthdayReqBean) {
		RequestValidatorResponse reqRes = new RequestValidatorResponse();
		String field="";
		if(HrAppUtil.isNullOrEmpty(birthdayReqBean)) {
			reqRes.setValid(GenericConstants.FALSE);
			reqRes.setMessage(RequestValidatorConstants.INVALID_REQUEST);
		}else {
			if (HrAppUtil.isNullOrEmpty(birthdayReqBean.getSapCode())&& HrAppUtil.isNullOrEmpty(birthdayReqBean.getName())){
				field=GenericConstants.SAP_CODE +GenericConstants.AND +GenericConstants.NAME;
				reqRes.setValid(GenericConstants.FALSE);
				reqRes.setMessage(String.format(RequestValidatorConstants.INVALID_REQUEST_SAPCODE_NAME,field));
			}else if(!HrAppUtil.isNullOrEmpty(birthdayReqBean.getSapCode()) && !StringUtils.isNumeric(birthdayReqBean.getSapCode())) {
				field=GenericConstants.SAP_CODE;
				reqRes.setValid(GenericConstants.FALSE);
				reqRes.setMessage(String.format(RequestValidatorConstants.INVALID_REQUEST_SAPCODE_NAME,field));
			}else {
				reqRes.setValid(GenericConstants.TRUE);
 			    reqRes.setMessage(RequestValidatorConstants.VALID_REQUEST);
			}
		}
		return reqRes;
	}
	
	public static Boolean requestValidatorForMail(String email)
	{	
        Pattern p = Pattern.compile("^(.+)@(.+)$"); 
        Matcher m = p.matcher(email); 
        return (m.find() && m.group().equals(email)); 
	}
	
	public static Boolean requestValidatorForPhoneNumber(String mobileNumber)
	{	
        Pattern p = Pattern.compile("[0-9]+"); 
        Matcher m = p.matcher(mobileNumber); 
        return (m.find() && m.group().equals(mobileNumber)); 
	}

}