package com.rnlic.hrapp.constant;

/**
 * This class contain all constant related to Request validation
 *
 */
public class RequestValidatorConstants {
	public static final String VALID_REQUEST =  "Valid Request.";
	public static final String INVALID_ACTION = "Please provide valid action. Action either be MOBLIE_VERIFICATION or EMAIL_VARIFICATION";
	public static final String INVALID_ACTION_BLANK = "Please provide valid action";
	public static final String INVALID_REQUEST = "Bad Request";
	public static final String INVALID_REQUEST_OTP_SIX_DIGIT = "The submitted OTP is not valid.";
	public static final String INVALID_REQUEST_ACTION_OTP_BALNK = "The submitted OTP/Action is not valid.";
	public static final String USERNAME_PASSWORD_VALID = "User name and Password is valid";
	public static final String INVALID_USERNAME_PASSWORD = "User name and Password are not valid";
	public static final String INVALID_SAPCODE = "Please provide valid sapcode";
	public static final String INVALID_YEAR = "Please provide valid year";
	public static final String INVALID_MONTH = "Please provide valid month";
	public static final String INVALID_FUTUREDATE = "Please provide current/previous month and year";
	public static final String INVALID_REQUEST_SAPCODE_NAME = "Please provide valid %s";
	public static final String INVALID_LEARNINGID = "Please provide valid learningId";

}
