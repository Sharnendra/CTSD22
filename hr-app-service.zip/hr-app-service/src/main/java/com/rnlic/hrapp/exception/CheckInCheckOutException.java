package com.rnlic.hrapp.exception;

import com.rnlic.hrapp.constant.ErrorConstants;

public class CheckInCheckOutException extends HrAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CheckInCheckOutException() {
		super(ErrorConstants.CHECK_IN_CHECK_OUT_CODE,ErrorConstants.CHECK_IN_CHECK_OUT_MESSAGE,false,false);
	}
	
	public CheckInCheckOutException(String message) {
		super(ErrorConstants.CHECK_IN_CHECK_OUT_CODE,message,false,false);
	}
}
