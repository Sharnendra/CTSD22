package com.rnlic.hrapp.constant;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
@Configuration
@ConfigurationProperties(prefix="rnlicconstant")
@EnableConfigurationProperties
@Component
public class RnlicUrlConstants implements InitializingBean{
	
	private URLConstruct urls;
	
	@Override
	public String toString() {
		return "RnlicUrlConstants [urls=" + urls + "]";
	}

	public URLConstruct getUrls() {
		return urls;
	}

	public void setUrls(URLConstruct urls) {
		this.urls = urls;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
//		System.err.println(toString());
	}
}