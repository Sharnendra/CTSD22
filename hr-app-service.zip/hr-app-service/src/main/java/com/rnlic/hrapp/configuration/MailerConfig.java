package com.rnlic.hrapp.configuration;

import java.util.Properties;

import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.rnlic.hrapp.constant.GenericConstants;

@Component
public class MailerConfig implements InitializingBean{
	
	@Value("${mail.smtp.host}")
	private String host;
	
	@Value("${mail.smtp.port}")
	private String port;
	
	@Value("${proxy.ip}")
	private String proxyIp;
	
	@Value("${proxy.port}")
	private String poxyPort;
	
	public String getProxyIp() {
		return proxyIp;
	}


	public String getPoxyPort() {
		return poxyPort;
	}


	private MimeMessage mimeMessage;
	
	
	public MimeMessage getMimeMessage() {
		return mimeMessage;
	}


	public void setMimeMessage(MimeMessage mimeMessage) {
		this.mimeMessage = mimeMessage;
	}


	@Override
	public void afterPropertiesSet() throws Exception {
		Properties props = new Properties();
	    props.put(GenericConstants.MAIL_HOST, host);
	    props.put(GenericConstants.MAIL_DEBUG, GenericConstants.TRUE_STRING);
	    Session session=Session.getInstance(props, null);
	    mimeMessage = new MimeMessage(session);
		//set message headers
	    mimeMessage.addHeader(GenericConstants.MAIL_CONTENT_TYPE, GenericConstants.MAIL_CHARSET_UTF);
	    mimeMessage.addHeader(GenericConstants.MAIL_FORMAT, GenericConstants.MAIL_FLOWED);
	    mimeMessage.addHeader(GenericConstants.MAIL_CONTENT_TRANSFER_ENCODING, GenericConstants.MAIL_BIT8);
	    mimeMessage.setFrom(new InternetAddress(GenericConstants.MAIL_EMAIL_FROM, GenericConstants.MAIL_NO_REPLY));
	    mimeMessage.setReplyTo(InternetAddress.parse(GenericConstants.MAIL_EMAIL_FROM, GenericConstants.FALSE));
	}
	
	

}
