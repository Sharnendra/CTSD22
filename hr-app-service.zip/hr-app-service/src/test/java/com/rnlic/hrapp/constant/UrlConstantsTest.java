package com.rnlic.hrapp.constant;

import static org.junit.Assert.*;

import org.junit.Test;

public class UrlConstantsTest {

	@Test
	public void testObject() {
		assertNotNull(new UrlConstants());
	}

}
