package com.rnlic.hrapp.constant;

import static org.junit.Assert.*;

import org.junit.Test;

public class MessagesConstantsTest {

	@Test
	public void test() {
		assertNotNull(new MessagesConstants());
	}

}
