package com.rnlic.hrapp.constant;

import static org.junit.Assert.*;

import org.junit.Test;

public class GenericConstantsTest {

	@Test
	public void testObject() {
		assertNotNull(new GenericConstants());
	}

}
