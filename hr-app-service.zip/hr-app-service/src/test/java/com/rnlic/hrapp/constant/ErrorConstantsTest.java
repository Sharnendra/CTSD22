/**
 * 
 */
package com.rnlic.hrapp.constant;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author HRMSAPP
 *
 */
public class ErrorConstantsTest {

	@Test
	public void testInstance() {
		assertNotNull(new ErrorConstants());
	}

}
