package com.rnlic.hraapp.test.constants;

public class TestConstant {

	public static final boolean FALSE = false;
	public static final String GET_DEVICE_INFORMATION_ENDPOINT = "/service/checkForDeviceRegistration";
	public static final String ATTENDANCE_REQ_JSON = "{\"sapCode\":\"70285945\",\"year\":\"2019\",\"month\":\"07\"}";
	//Attendance End point
	public static final String GET_ATTENDANCE_ENDPOINT = "/service/getAttendanceDetails";
	public static final String CHECKIN_CHECKOUT_ENDPOINT = "/service/employeeCheckInCheckOut";
	public static final String GET_MANDATORY_LEARNING_URL = "/service/getMandatoryLearning";
	public static final String GET_MANDATORY_LEARNING_STATUS_URL = "/service/getMandatoryLearningStatus";
	public static final String UPDATE_LEARNING_COMPLETION_STATUS_URL = "/service/updateLearningCompletionStatus";
	public static final String GET_REPORTEE_LIST_URL = "/service/getReporteeList";
	//wish end point
	public static final String SEARCH_BIRTHDAY_ANNIVERSARY_URL = "/service/searchBirthdayOrAnniversary";
	public static final String WISH_EMPLOYEE_URL = "/service/wishEmployee";
	public static final String GET_BIRTHDAY_URL = "/service/getBirthday";
	public static final String GET_ANNIVERSARY_URL = "/service/getAnniversary";
	public static final String GET_REPORTEE_BIRTHDAY_URL = "/service/getReporteeBirthday";
	public static final String GET_REPORTEE_ANNIVERSARY_URL = "/service/getReporteeAnniversary";
	//Authenticate and Authorize
	public static final String AUTHENTICATE_URL = "/authenticate";
	public static final String SEND_OTP_URL = "/service/sendOTP";
	public static final String VALIDATE_OTP_URL = "/service/validateOTP";
	public static final String REGISTER_DEVICE = "/service/registerDevice";
	public static final String UPDATE_DEVICE_REGISTRATION = "/service/updateDeviceRegistration";
	public static final String DEREGISTER_DEVICE = "/service/deRegisterDevice";
	public static final String UPDATE_LINKED_APP_FOR_REGISTER_DEVICE = "/service/updateLinkedApp";
	public static final String GET_TROUBLE_WITH_LOGIN_URL = "/havingTroubleWithLogin";
	public static final String CHANGE_PASSWORD_REQUEST_URL = "/changePasswordRequest";
	public static final String UPDATE_PASSWORD_URL = "/updatePassword";
	//Authenticate Request JSON
	public static final String AUTHENTICATE_REQ_JSON = "{\"isCandidate\":\"false\",\"sapCode\":\"70175419\",\"domainPassword\":\"pass@123\",\"mobileNumber\":\"\",\"panNumber\":\"\",\"deviceIdentifier\":\"290b754632c6ddd0\",\"fcmToken\":\"123345\"}";
	public static final String AUTHENTICATE_REQ_JSON1 = "{\"isCandidate\":\"true\",\"sapCode\":\"70175419\",\"domainPassword\":\"pass@123\",\"mobileNumber\":\"\",\"panNumber\":\"\",\"deviceIdentifier\":\"290b754632c6ddd0\",\"fcmToken\":\"123345\"}";
	public static final String SEND_OTP_REQ_JSON = "{\"action\":\"Mobile_varification\"}";
	public static final String SEND_OTP_REQ_JSON1 = "{\"action\":\"\"}";
	public static final String VALIDATE_OTP_REQ_JSON = "{\"action\":\"Mobile_varification\",\"otp\":\"7033\"}";
	public static final String VALIDATE_OTP_REQ_JSON1 = "{\"action\":\"\",\"otp\":\"703339\"}";
	public static final String REGISTER_DEVICE_REQ_JSON = "{\"appVersion\":\"1.0\",\"deviceType\":\"ANRIOD\",\"installedLinkedApps\":[{\"applicationName\":\"AHA\",\"applicationDescription\":\"STORE\",\"applicationVersion\":\"1.0\"},{\"applicationName\":\"\",\"applicationDescription\":\"\",\"applicationVersion\":\"1.0\"}]}";
	public static final String UPDATE_REG_DEVICE_REQ_JSON = "{}";
	public static final String DEREGISTER_DEVICE_REQ_JSON = "{}";
	public static final String UPDATE_LINKED_FOR_REGISTER_DEVICE_REQ_JSON = "{\"installedLinkedApps\":[{\"applicationName\":\"AHA\",\"applicationDescription\":\"STORE\",\"applicationVersion\":\"1.0\"},{\"applicationName\":\"\",\"applicationDescription\":\"\",\"applicationVersion\":\"1.0\"}]}";
	public static final String HAVING_TROBLE_LOGIN_REQ_JSON = null;
	//Location END point
	public static final String GET_STATE_CITY_MASTER_URL = "/service/getStateCityMaster";
	public static final String LOCATE_BRANCH_URL = "/service/locateBranch";
	public static final String SHARE_BRANCH_INFO_URL = "/service/shareBranchInformation";
	//Location request json
	public static final String LOCATE_BRANCH_REQ_JSON = "{\"stateName\":\"West Bengal\",\"cityName\":\"Kolkata\"}";
	public static final String SHARED_BRANCH_INFO_REQ_JSON = "{\"mobileNo\": \"8375939142\",\"emailAddress\": \"sharnendradey1993@gmail.com\",\"locateBranches\": {\"name\": \"\",\"address\": null,\"code\": \"\",\"contactPerson\": null,\"contactNumber\": null,\"email\": null,\"location\": {\"latitude\": \"\",\"longitude\": \"\"}}}";
	//Notice end point
	public static final String GET_NOTICES_URL = "/service/getNotices";
	public static final String GET_NOTIFICATION_URL = "/service/getNotifications";
	//Notice Request JSON
	public static final String GET_LINKED_APPLICATION_CONFIG_VERSION_URL = "/getApplicationConfigurationVersion";
	public static final String GET_LINKED_APPLICATION_CONFIG_URL = "/getLinkedApplicationConfiguration";
	public static final String UPDATE_APPLICATION_CONFIGURATION_URL = "/updateApplicationConfiguration";
	public static final String CHECKIN_CHECKOUT_REQ_JSON= "{\"userLocation\":{\"latitude\":\"22.5697368\",\"longitude\":\"88.4328451\"},\"type\":\"check-out\"}";
	public static final String GET_MANDATORY_LEARNING_JSON = "{}";
	public static final String UPDATE_LEARNI_STATUS_REQ_JSON = "{\"learningId\":\"ULIP\"}";
	public static final String SEARCH_REQ_JSON = "{\"sapCode\":\"70009002\",\"name\":\"\"}";
	public static final String SEARCH_REQ_JSON1 = "{\"sapCode\":\"\",\"name\":\"\"}";
	public static final String WISH_REQ_JSON = "{\"wishTo\": {\"type\":\"birthday\",\"communicationChannel\":\"SE\",\"sapCode\":\"70009002\",\"name\":\"Sned\",\"mobile\":\"8981414565\",\"email\":\"sharnendra.dey@outlook.com\"}}";
	public static final String EMP_DETAILS_JSON = "{\r\n" + 
			"    \"Status\": \"Sucess\",\r\n" + 
			"    \"Message\": \"Data Found.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"Name\": \"Shyam Madhukar Shendre\",\r\n" + 
			"            \"SAPCode\": \"70109281\",\r\n" + 
			"            \"PANNumber\": null,\r\n" + 
			"            \"MobileNo\": \"8670899251\",\r\n" + 
			"            \"EmailID\": \"Ananya.Dutta@cognizant.com\",\r\n" + 
			"            \"Channel\": \"Agency\",\r\n" + 
			"            \"JobRole\": \"TERRITORY MANAGER\",\r\n" + 
			"            \"Level\": \"IL5B (E3)\",\r\n" + 
			"            \"ManagerSAPCode\": \"70055996\",\r\n" + 
			"            \"ManagerName\": \"Zafar Ahmed Sheikh\",\r\n" + 
			"            \"LocationCode\": \"MA69      \",\r\n" + 
			"            \"LocationName\": \"MH - Sakoli\",\r\n" + 
			"            \"UserRole\": \"SALES MANAGEMEN\",\r\n" + 
			"            \"ZoneName\": \"CENTRAL\"\r\n" + 
			"        }\r\n" + 
			"    ]\r\n" + 
			"}";
	public static final String CANDIDATE_DETAILS_JSON = "{\r\n" + 
			"    \"Status\": \"Sucess\",\r\n" + 
			"    \"Message\": \"Data Found.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"Name\": \"PALLAVI  SARKAR\",\r\n" + 
			"            \"MobileNo\": \"7033482793\",\r\n" + 
			"            \"Email\": null,\r\n" + 
			"            \"Channel\": \"Agency\",\r\n" + 
			"            \"Role\": \"AGENCY RECRUITMENT & DEVELOPMENT MGR\",\r\n" + 
			"            \"Level\": \"IL5A (E1) FLS\",\r\n" + 
			"            \"ManagerSAPCode\": \"9035269\",\r\n" + 
			"            \"ManagerName\": \"ShilpaSawant\",\r\n" + 
			"            \"LocationCode\": \"GT56\",\r\n" + 
			"            \"LocationName\": \"GJ - Baroda Ao 2\",\r\n" + 
			"            \"Category\": \"Employee-Front-line Sales\"\r\n" + 
			"        }\r\n" + 
			"    ]\r\n" + 
			"}";
	public static final String BIRTHDAY_JSON = "{\r\n" + 
			"    \"Status\": \"Success\",\r\n" + 
			"    \"Message\": \"Data loaded successfully.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"EmployeeCode\": \"70009002\",\r\n" + 
			"            \"EmployeeName\": \"Joylee Olwin Dias\",\r\n" + 
			"            \"DOB\": \"1981-12-15T00:00:00\",\r\n" + 
			"            \"MobileNumber\": \"+91-9321402007\",\r\n" + 
			"            \"Email\": \"JOYLEE.DIAS@RELIANCEADA.COM\",\r\n" + 
			"            \"ManagerSapCode\": \"70315599\",\r\n" + 
			"            \"ManagerName\": \"Chinmay Ashok Bhatia\",\r\n" + 
			"            \"Channel\": \"IT\",\r\n" + 
			"            \"ZoneCode\": \"\",\r\n" + 
			"            \"ZoneName\": \"CORPORATE\",\r\n" + 
			"            \"RegionCode\": \"\",\r\n" + 
			"            \"RegionName\": \"\",\r\n" + 
			"            \"DOJ\": \"2007-02-15T00:00:00\"\r\n" + 
			"        }\r\n" + 
			"    ]\r\n" + 
			"}";
	public static final String ANNIVERSARY_JSON = "{\r\n" + 
			"    \"Status\": \"Success\",\r\n" + 
			"    \"Message\": \"Data loaded successfully.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"EmployeeCode\": \"70279787\",\r\n" + 
			"            \"EmployeeName\": \"Ramakrishna Bijja\",\r\n" + 
			"            \"DOJ\": \"2016-08-30T00:00:00\",\r\n" + 
			"            \"MobileNumber\": \"+91-9052253119\",\r\n" + 
			"            \"Email\": \"RAMAKRISHNA.BIJJA@RELIANCEADA.COM\",\r\n" + 
			"            \"ManagerSapCode\": \"70256538\",\r\n" + 
			"            \"ManagerName\": \"Abdhul Aleem Farookhy Md\",\r\n" + 
			"            \"Channel\": \"DM Priority-OM\",\r\n" + 
			"            \"ZoneCode\": \"\",\r\n" + 
			"            \"ZoneName\": \"SOUTH CENTRAL\",\r\n" + 
			"            \"RegionCode\": \"\",\r\n" + 
			"            \"RegionName\": \"\"\r\n" + 
			"        }\r\n" + 
			"	]\r\n" + 
			"}";
	public static final String REPORTEE_JSON = "{\r\n" + 
			"    \"Status\": \"Success\",\r\n" + 
			"    \"Message\": \"Reportees found.\",\r\n" + 
			"    \"Response\": {\r\n" + 
			"        \"ReporteeInformation\": [\r\n" + 
			"            {\r\n" + 
			"                \"SAPCode\": \"9028941\",\r\n" + 
			"                \"Name\": \"Vishal Singh\",\r\n" + 
			"                \"ManagerSAPCode\": \"70285945\",\r\n" + 
			"                \"ManagerName\": \"Reshma Ankush Chougule\",\r\n" + 
			"                \"HasAnyReportee\": \"true\"\r\n" + 
			"            }\r\n" + 
			"        ]\r\n" + 
			"    }\r\n" + 
			"}";
	public static final String STATE_CITY_JSON = "{\r\n" + 
			"    \"Status\": \"Sucess\",\r\n" + 
			"    \"Message\": \"Data Found.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"State\": \"Andhra Pradesh\",\r\n" + 
			"            \"City\": \"Adoni\"\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"State\": \"Andhra Pradesh\",\r\n" + 
			"            \"City\": \"Amalapuram\"\r\n" + 
			"        }\r\n" + 
			"	]\r\n" + 
			"}";
	public static final String CHECKIN_CHECKOUT_JSON = "{\r\n" + 
			"    \"Status\": \"Success\",\r\n" + 
			"    \"Message\": \"CheckIn marked successfully.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"CheckInTime\": \"08/30/19  3:59:05 PM\",\r\n" + 
			"            \"CheckOutTime\": null\r\n" + 
			"        }\r\n" + 
			"    ]\r\n" + 
			"}";
	public static final String LOCATE_BRANCH_JSON = "{\r\n" + 
			"    \"Status\": \"Sucess\",\r\n" + 
			"    \"Message\": \"Data Found.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"Branch\": \"WB - ZO-Kolkata\",\r\n" + 
			"            \"Branch_Code\": \"ZWB8\",\r\n" + 
			"            \"Address\": \"NULL\",\r\n" + 
			"            \"Latitude\": \"NULL\",\r\n" + 
			"            \"Longitude\": \"NULL\"\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"Branch\": \"WB - Baruipur\",\r\n" + 
			"            \"Branch_Code\": \"WB36\",\r\n" + 
			"            \"Address\": \"1st Floor, Sanghamitra Complex, 44, Kulpi Road, Karachi Bazar, (Padmapukar), Kolkata,Baruipur700144\",\r\n" + 
			"            \"Latitude\": \"22.36868\",\r\n" + 
			"            \"Longitude\": \"88.42718\"\r\n" + 
			"        }\r\n" + 
			"	]\r\n" + 
			"}";
	public static final String ATTENDANCE_JSON = "{\r\n" + 
			"    \"Status\": \"Success\",\r\n" + 
			"    \"Message\": \"Attendance Data found.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 1,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 2,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 3,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 4,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 5,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 6,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 7,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 8,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 9,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 10,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 11,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 12,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 13,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 14,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 15,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": true,\r\n" + 
			"            \"HolidayName\": \"Independence Day\",\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 16,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 17,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 18,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 19,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 20,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": true,\r\n" + 
			"            \"InTime\": \"Aug 20 2019 12:20PM\",\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 21,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": true,\r\n" + 
			"            \"InTime\": \"Aug 21 2019  3:40PM\",\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 22,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 23,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": true,\r\n" + 
			"            \"InTime\": \"Aug 23 2019 12:09PM\",\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 24,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 25,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 26,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 27,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": true,\r\n" + 
			"            \"InTime\": \"Aug 27 2019  3:25PM\",\r\n" + 
			"            \"OutTime\": \"Aug 27 2019  3:25PM\",\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 28,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": true,\r\n" + 
			"            \"InTime\": \"Aug 28 2019  8:17PM\",\r\n" + 
			"            \"OutTime\": \"Aug 28 2019  8:18PM\",\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 29,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": true,\r\n" + 
			"            \"InTime\": \"Aug 29 2019 12:46PM\",\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 30,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": true,\r\n" + 
			"            \"InTime\": \"Aug 30 2019 11:46AM\",\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        },\r\n" + 
			"        {\r\n" + 
			"            \"EmpCode\": \"70009002\",\r\n" + 
			"            \"Date\": 31,\r\n" + 
			"            \"Month\": 8,\r\n" + 
			"            \"Year\": 2019,\r\n" + 
			"            \"IsHoliday\": null,\r\n" + 
			"            \"HolidayName\": null,\r\n" + 
			"            \"IsLeave\": null,\r\n" + 
			"            \"LeaveType\": null,\r\n" + 
			"            \"IsPresent\": null,\r\n" + 
			"            \"InTime\": null,\r\n" + 
			"            \"OutTime\": null,\r\n" + 
			"            \"IsWaiting\": null,\r\n" + 
			"            \"IsRejected\": null,\r\n" + 
			"            \"LeaveDescript\": null,\r\n" + 
			"            \"Official_Reason\": null\r\n" + 
			"        }\r\n" + 
			"    ]\r\n" + 
			"}";
	public static final String CHECKIN_CHECKOUT_JSON1 = "{\r\n" + 
			"    \"Status\": \"Failed\",\r\n" + 
			"    \"Message\": \"Sorry! Your CheckIn is already marked for the day.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"CheckInTime\": \"08/30/19  3:59:05 PM\",\r\n" + 
			"            \"CheckOutTime\": null\r\n" + 
			"        }\r\n" + 
			"    ]\r\n" + 
			"}";
	public static final String CHECKIN_CHECKOUT_JSON2 = "{\r\n" + 
			"    \"Status\": \"Success\",\r\n" + 
			"    \"Message\": \"CheckOut marked successfully.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"CheckInTime\": \"08/30/19  3:59:05 PM\",\r\n" + 
			"            \"CheckOutTime\": \"08/30/19  5:37:45 PM\"\r\n" + 
			"        }\r\n" + 
			"    ]\r\n" + 
			"}";
	public static final String CHECKIN_CHECKOUT_JSON3 = "{\r\n" + 
			"    \"Status\": \"Failed\",\r\n" + 
			"    \"Message\": \"Sorry! Your CheckOut is already marked for the day\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"CheckInTime\": \"08/30/19  3:59:05 PM\",\r\n" + 
			"            \"CheckOutTime\": \"08/30/19  5:37:45 PM\"\r\n" + 
			"        }\r\n" + 
			"    ]\r\n" + 
			"}";
	public static final String MANDATORY_JSON = "{\r\n" + 
			"    \"Status\": \"Success\",\r\n" + 
			"    \"Message\": \"Record found.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"LearningId\": \"ULIP\",\r\n" + 
			"            \"LearningName\": \"Financial Markets And ULIP Concepts\",\r\n" + 
			"            \"DocumentName\": \"Financial Markets And ULIP Concepts-Dec16_old.pdf\",\r\n" + 
			"            \"UploadDate\": \"2019-07-23T11:14:28.617\",\r\n" + 
			"            \"LearningLink\": \"http://124.124.218.139/HRAppWebAPI/api/EmpAttendence/getMandatoryLearningFile?DocumentName=Financial%20Markets%20And%20ULIP%20Concepts-Dec16_old.pdf\"\r\n" + 
			"        }\r\n" + 
			"    ]\r\n" + 
			"}";
	public static final String MANDATORY_STATUS_JSON = "{\r\n" + 
			"    \"Status\": \"Success\",\r\n" + 
			"    \"Message\": \"Record found.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"AML_KYC\": \"COMPLETED\",\r\n" + 
			"            \"ULIP\": \"COMPLETED\",\r\n" + 
			"            \"Infosec\": \"COMPLETED\"\r\n" + 
			"        }\r\n" + 
			"    ]\r\n" + 
			"}";
	public static final String TROUBLE_LOGIN_JSON = "{\r\n" + 
			"    \"Status\": \"Success\",\r\n" + 
			"    \"Message\": \"Data found.\",\r\n" + 
			"    \"Response\": [\r\n" + 
			"        {\r\n" + 
			"            \"HelpMessage\": \"In case of any issues please connect with helpdesk.\",\r\n" + 
			"            \"ContactNumber\": \"+91634563780\",\r\n" + 
			"            \"ContactEmail\": \"helpdesk@relianceada.com\"\r\n" + 
			"        }\r\n" + 
			"    ]\r\n" + 
			"}";
	
	
	
	public static String GET_TOKEN = "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZXNobWEiLCJ1c2VySWQiOiI3MDI4NTk0NSIsImRldmljZUlkZW50aWZpZXIiOiI3NDgxNTIiLCJsYXN0TmFtZSI6IkNob3VndWxlIiwibGV2ZWwiOiJJTDVCIChFMykiLCJtYW5hZ2VyU2FwQ29kZSI6IjcwMDA5MDAyIiwibW9iaWxlTnVtYmVyIjoiOTgyMTYxMTAyMiIsInBhbk51bWJlciI6IiAiLCJyb2xlIjpbIkFTU0lTVEFOVCBNQU5BR0VSIl19.3O_kNxrHnuYkSu-Mr6tmC1VwWuOvNPtDOHJtLcidhhtxil0Q2i_hSonCSnVTVIQu2M8tbq34UkWnlqhW7cZ12A";
	public static StringBuffer GET_CONFIG = new StringBuffer("{\r\n" + 
			"  \"comment\": \"iBelong has been added. Name fields updated\",\r\n" + 
			"  \"appConfig\": {\r\n" + 
			"    \"version\": \"V22\",\r\n" + 
			"    \"description\": \"Latest app config\",\r\n" + 
			"    \"applicationVersion\": \"1.0.0\",\r\n" + 
			"    \"applicationGroups\": [\r\n" + 
			"      {\r\n" + 
			"        \"groupName\": \"Communications\",\r\n" + 
			"        \"groupTitle\": \"Communications\",\r\n" + 
			"        \"showAsTile\": true,\r\n" + 
			"        \"showAsRow\": true,\r\n" + 
			"        \"groupIcon\": \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJIAAACACAYAAADgZTAeAAAACXBIWXMAAAsTAAALEwEAmpwYAAAHD2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEzLTE2OjQwOjIyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDE5LTA2LTE3VDEyOjUxOjQ4KzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDE5LTA2LTE3VDEyOjUxOjQ4KzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAxOS0wNi0xN1QxMjo1MTo0OCswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoyMWIxMTczMy00Y2M4LTZkNDItOGVlYi1lN2NlN2MwN2I0NmMiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDplNWJiODNhNy04ZjBkLTlkNGQtOTA3MC05ZDlkZmVlMjFlZjYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpiMmQzNDhlYi1jOTY3LTAxNDctYTMxZC1kZDE3OThmZWNiYjIiIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpiMmQzNDhlYi1jOTY3LTAxNDctYTMxZC1kZDE3OThmZWNiYjIiIHN0RXZ0OndoZW49IjIwMTktMDYtMTdUMTI6NTE6NDgrMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDQyAyMDE5IChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6MjFiMTE3MzMtNGNjOC02ZDQyLThlZWItZTdjZTdjMDdiNDZjIiBzdEV2dDp3aGVuPSIyMDE5LTA2LTE3VDEyOjUxOjQ4KzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDxwaG90b3Nob3A6RG9jdW1lbnRBbmNlc3RvcnM+IDxyZGY6QmFnPiA8cmRmOmxpPnhtcC5kaWQ6MTE3NmU2MGMtODNkMi0xYzRlLThhYzQtOWE0MGY4MDA4N2JhPC9yZGY6bGk+IDxyZGY6bGk+eG1wLmRpZDoyN0E5N0NBMEMwQThFNzExOUMwNkMwQjEyMkZGQUFDQzwvcmRmOmxpPiA8cmRmOmxpPnhtcC5kaWQ6NkJBMkU3NzE5QjZDRTkxMUEzNzJGMjQ4N0M0ODg5NDA8L3JkZjpsaT4gPHJkZjpsaT54bXAuZGlkOkVFOTdERTM5Nzg3RTExRTk5NTIzOTZGM0M3MkQxMTFGPC9yZGY6bGk+IDwvcmRmOkJhZz4gPC9waG90b3Nob3A6RG9jdW1lbnRBbmNlc3RvcnM+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+Z94m7AAABnZJREFUeJzt3V2IFWUcx/Hv2RdTCSy6kcIKta4KqVAhjdLIi8gMsRfTigI1gohS80ZqUwwzwurC9KZXU7wxUiMSqSg08gWUujFfsjLTRBNDZV316eKZrbNnZ3Zmdv9zdp7T7wPenHl85pn16+4c3Z2n4pwjwQRgOnAHMBJoSRooDe0CsB/4FlgLfBU3qBIT0m3ACmBMkauTYG0HngF2Vb/YVDNoNvAdikiSjcE3Mrv6xerPSHOAlXVelITtaWAV/BfSaGAbug+SfC4AtwM7Ks65CrADf28U5xdgI/Ar0FGf9UlJtALXApOB6xLG7AJGV5xzdwNbYgZcAl4CXsOXJ/9fLcACYBHd76sB7mnBv8WP8zKwpKCFSVgu4FuoAItjjj9Scc7tBW6sOXAYGI6+lElXrcABYFjN6z81ASNifsMmFJF01wF8FvP6iCagOebAsWLXIwGLa6M57sZJJDeFJCYUkphQSGJCIYkJhSQmFJKYUEhiQiGJCYUkJhSSmFBIYkIhiQmFJCYUkphQSGJCIYkJhSQmFJKYUEhiQiGJCYUkJhSSmFBIYkIhiQmFJCYUkphQSGJCIYkJhSQmFJKYUEhiQiGJiUYNqbXE81mvrRQaKaT7gc3AGeA8cBJYh38YfW9Mwj8v8e9ovlPAevwmP3mNjtZyIprrTLTWKb1cW/m4eG3OOQL5NcA5tybhOjotzDFfs3NuVcp8y5xzlYzzLUyZa010Df39ccz6qy3uIhrhM9LbJD8rvNNiYFbG+V6lZsOWGPOBeRnmmkX8c6mrTcdfQ9BCD+kW/GY8WbwODEkZcwMwN+N8i4ChPRwfEp0zizn4awlW6CE9kWPsENLvSWYQ/7joOAOBB3s4PoX0cKvluZbSCT2km4zH553vZsO58o4vldBDGmg83nI+67WVWugh7cs5fn8d50s7V1/PXSqhh/RJjrEXgQ2G84H/d6UkG6JzZpX33KUSekgb8TtfZrESOJQy5hvg84zzrQZ+7OH4IeCdjHNtw19LsEIPyQHTgL0p4zYDL2SccyawO2XMVvx+rmnmRufuyV78NXTb7jwkoYcE8AcwFngL/18P1Y4BLwL34v9rIouTwHhgKXC65tgJ/K6aE2POFed8dO75dN9V6Ey05rHRNQSt4pyL+5vwCtBW57VYuAwYBVwJHAV+wG+p2lut0XxXAceBPeS776nWhP/ngqHAX9Fc7X1YW39pw+8u2kWj7ardDmw3nK8D2Gk01yV8PHuM5iuVRvjSJiWgkMSEQhITCklMKCQxoZDEhEISEwpJTCgkMaGQxIRCEhMKSUwoJDGhkMSEQhITCklMKCQxoZDEhEISEwpJTCgkMaGQxIRCEhMKSUwoJDGhkMSEQhITCklMKCQxoZDEhEISEwpJTCgkMaGQxERSSJfXdRUSktg2moDDMa9PKHYtErC4Nn5vIv5hm7cCk4tdjwRoMr6NWjubSN664ENgXGFLktCMwzcRZ33FOTcIOEj8JnYXgbX4PTd+Ay7kPPlZ4AC9fzZ1bwwGhgGD6njORtWC/1hOxe90GbeX3VFgeCV6XvtM4KOCFnMSv5PiMvr28PQ0DwDPAnehd6P19BiwulL14P93gScLPOF7wFMFzDsY+BgfktTXv3+m1SG14j8rPVzgiScAXxvONwC/m9FEwzklm3XA40R7vFR/CejAfx18Hn9vU4Se9oDNqxl//6aI6ussvpHpVG0UVHsv4YA3gZHAEuBn40VcYzRPM/4dxFSj+STdQXwTI/GNdNkMqRK/OVIXVwPDgSvItwnOcuD6mtc+pe/3Mp0RPZpw/Ah+d6c/+3ge8e/ST+EjOtLTwCxhHEmbJEFbL35PmrSIjgN3kn8/WemjkN4mp0V0GpiEIuoXoYRUAT4gPaLd9VqQdBVCSBVgBTAj4XhnRN/XbUXSTdlD6owoaSNiRVQSZQ5JEQWkrCEposCUMaS0iM7ht0BXRCVStpCyRHQfsLVuK5JMyhRS1oi+rNuKJLMyhbQcRRSssoS0FHgu4ZgiCkAZQloKLEg4pogC0d8hKaIG0Z8hKaIG0l8h9RRRB/AQiigo/RFSWkTTgE31W45YyPIdkr21GxhV89o5kn/erDOiDUUtSIpT789IiqhBFRlSe8ZxiqgBFBnSvgxjFFGDKDKk91OOK6IGUmRIW4A3Eo5dxP/MuCJqEEXfbM/Df6/1Tnw87cAXwHj8j/xKg/gHnqAKIh9SFAMAAAAASUVORK5CYII=\",\r\n" + 
			"        \"applicableFor\": [\r\n" + 
			"          \"*\"\r\n" + 
			"        ],\r\n" + 
			"        \"applications\": [\r\n" + 
			"          {\r\n" + 
			"            \"name\": \"workplace\",\r\n" + 
			"            \"title\": \"Workplace\",\r\n" + 
			"            \"description\": \"Workplace by Facebook\",\r\n" + 
			"            \"isApp\": true,\r\n" + 
			"            \"link\": \"\",\r\n" + 
			"            \"ios\": {\r\n" + 
			"              \"bundleId\": \"com.facebook.atwork\",\r\n" + 
			"              \"uriScheme\": \"fbatwork://\",\r\n" + 
			"              \"storeUrl\": \"https://apps.apple.com/in/app/workplace-by-facebook/id944921229\"\r\n" + 
			"            },\r\n" + 
			"            \"android\": {\r\n" + 
			"              \"packageId\": \"com.facebook.work\",\r\n" + 
			"              \"androidScheme\": \"fb-work://\",\r\n" + 
			"              \"storeUrl\": \"https://play.google.com/store/apps/details?id=com.facebook.work\"\r\n" + 
			"            },\r\n" + 
			"            \"icon\": \"\",\r\n" + 
			"            \"showAsRow\": false,\r\n" + 
			"            \"applicableFor\": [\r\n" + 
			"              \"FLS\",\r\n" + 
			"              \"NON SALES\",\r\n" + 
			"              \"SALES MANAGEMENT\",\r\n" + 
			"              \"SALES SUPPORT\"\r\n" + 
			"            ],\r\n" + 
			"            \"mandatoryFor\": [\r\n" + 
			"              \"FLS\",\r\n" + 
			"              \"SALES MANAGEMENT\"\r\n" + 
			"            ]\r\n" + 
			"          }\r\n" + 
			"        ]\r\n" + 
			"      }\r\n" + 
			"    ]\r\n" + 
			"  }\r\n" + 
			"}");

}
