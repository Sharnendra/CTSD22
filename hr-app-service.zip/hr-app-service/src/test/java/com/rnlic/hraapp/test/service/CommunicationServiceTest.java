package com.rnlic.hraapp.test.service;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.web.client.RestClientException;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.api.response.RnlicServicesDataTranslator;
import com.rnlic.hrapp.bean.request.MailingReqBean;
import com.rnlic.hrapp.bean.request.OtpReqBean;
import com.rnlic.hrapp.bean.request.OtpValidateReqBean;
import com.rnlic.hrapp.bean.request.RegisterDeviceReqBean;
import com.rnlic.hrapp.bean.request.ShareBranchDetailsReqBean;
import com.rnlic.hrapp.bean.response.ShareBrachDetailsResBean;
import com.rnlic.hrapp.configuration.MailerConfig;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.entity.OtpMasterModel;
import com.rnlic.hrapp.exception.CommunicationException;
import com.rnlic.hrapp.exception.OtpException;
import com.rnlic.hrapp.repository.OtpRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.CommunicationService;
import com.rnlic.hrapp.service.DeviceRegistrationService;
import com.rnlic.hrapp.service.RnlicService;

public class CommunicationServiceTest extends HraServiceTests {

	@Mock
	private MailerConfig mailerConfig;
	
	@Mock
	private RnlicService rnlicService;
	
	@Mock
	private OtpRepository otpRepo;
	
	@Mock
	private GenericConstants genericConstants;

	@Mock
	private RnlicServicesDataTranslator rnlicServicesDataTranslator;
	
	@Mock
	private MessagesConstants messagesConstants;
	
	@Mock
	private DeviceRegistrationService deviceService;
	
	@InjectMocks
	private CommunicationService communicationService;
	
	@Test(expected=CommunicationException.class)
	public void shareBrachDetailsTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = HrappTestUtil.prepareShareBranchDetailsReqBean();
		shareBranchDetailsReqBean.setEmailAddress(null);
		shareBranchDetailsReqBean.setMobileNo(null);
		communicationService.shareBrachDetails(empReqBean, shareBranchDetailsReqBean);
	}
	
	@Test
	public void shareBrachDetailsMobileTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		ShareBrachDetailsResBean shareBrachDetailsResBean = new ShareBrachDetailsResBean();
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = HrappTestUtil.prepareShareBranchDetailsReqBean();
		shareBranchDetailsReqBean.setEmailAddress(null);
		shareBrachDetailsResBean.setMessage("SMS Send Successfuly");
		shareBrachDetailsResBean.setStatus(GenericConstants.SUCCESS);
		Mockito.when(rnlicService.shareBrachDetails(Mockito.any(String.class),Mockito.any(ShareBranchDetailsReqBean.class))).thenReturn(true);
		Mockito.when(rnlicService.getShareBrachDetailsMessage(empReqBean, shareBranchDetailsReqBean)).thenReturn("Hi");
		Mockito.when(rnlicServicesDataTranslator.generateShareBrachDetailsResponse(1,shareBranchDetailsReqBean,true,false,new LinkedHashMap<String,String>()))
		.thenReturn(shareBrachDetailsResBean);
		ShareBrachDetailsResBean response = (ShareBrachDetailsResBean) communicationService.shareBrachDetails(empReqBean, shareBranchDetailsReqBean);
		assertNotNull(response);
	}
	
	@Test (expected = NullPointerException.class)
	public void shareBrachDetailsEmailTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		ShareBrachDetailsResBean shareBrachDetailsResBean = new ShareBrachDetailsResBean();
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = HrappTestUtil.prepareShareBranchDetailsReqBean();
		shareBranchDetailsReqBean.setMobileNo(null);
		shareBrachDetailsResBean.setMessage("Mail Send Successfuly");
		shareBrachDetailsResBean.setStatus(GenericConstants.SUCCESS);
		Mockito.when(rnlicService.shareBrachDetails("data",shareBranchDetailsReqBean)).thenReturn(true);
		Mockito.when(rnlicServicesDataTranslator.generateShareBrachDetailsResponse(1,shareBranchDetailsReqBean,true,false,new LinkedHashMap<String,String>()))
		.thenReturn(shareBrachDetailsResBean);
		Mockito.when(rnlicService.sendMail(Mockito.any(MailingReqBean.class))).thenReturn(GenericConstants.SUCCESS);
		Mockito.when(rnlicService.getShareBrachDetailsMessage(Mockito.any(UserDetailsBean.class), Mockito.any(ShareBranchDetailsReqBean.class))).thenReturn("TEST RESPONSE");
		communicationService.shareBrachDetails(empReqBean, shareBranchDetailsReqBean);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void shareBrachDetailsEmailFailedTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		ShareBrachDetailsResBean shareBrachDetailsResBean = new ShareBrachDetailsResBean();
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = HrappTestUtil.prepareShareBranchDetailsReqBean();
		shareBranchDetailsReqBean.setMobileNo(null);
		shareBrachDetailsResBean.setMessage("Mail Send Successfuly");
		shareBrachDetailsResBean.setStatus(GenericConstants.SUCCESS);
		Mockito.when(rnlicService.shareBrachDetails("data",shareBranchDetailsReqBean)).thenReturn(true);
		Mockito.when(rnlicServicesDataTranslator.generateShareBrachDetailsResponse(Mockito.any(Integer.class),Mockito.any(ShareBranchDetailsReqBean.class),Mockito.any(Boolean.class),Mockito.any(Boolean.class),Mockito.any(Map.class)))
		.thenReturn(shareBrachDetailsResBean);
		Mockito.when(rnlicService.sendMail(Mockito.any(MailingReqBean.class))).thenReturn(GenericConstants.FAILURE);
		Mockito.when(rnlicService.getShareBrachDetailsMessage(Mockito.any(UserDetailsBean.class), Mockito.any(ShareBranchDetailsReqBean.class))).thenReturn("TEST RESPONSE");
		communicationService.shareBrachDetails(empReqBean, shareBranchDetailsReqBean);
	}
	
	@SuppressWarnings("unchecked")
	@Test (expected = CommunicationException.class)
	public void shareBrachDetailsEmailCompleteFailedTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		ShareBrachDetailsResBean shareBrachDetailsResBean = new ShareBrachDetailsResBean();
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = HrappTestUtil.prepareShareBranchDetailsReqBean();
		shareBranchDetailsReqBean.setMobileNo(null);
		shareBrachDetailsResBean.setMessage("Mail Send Successfuly");
		shareBrachDetailsResBean.setStatus(GenericConstants.FAILED);
		Mockito.when(rnlicService.shareBrachDetails("data",shareBranchDetailsReqBean)).thenReturn(true);
		Mockito.when(rnlicServicesDataTranslator.generateShareBrachDetailsResponse(Mockito.any(Integer.class),Mockito.any(ShareBranchDetailsReqBean.class),Mockito.any(Boolean.class),Mockito.any(Boolean.class),Mockito.any(Map.class)))
		.thenReturn(shareBrachDetailsResBean);
		Mockito.when(rnlicService.sendMail(Mockito.any(MailingReqBean.class))).thenReturn(GenericConstants.FAILED);
		Mockito.when(rnlicService.getShareBrachDetailsMessage(Mockito.any(UserDetailsBean.class), Mockito.any(ShareBranchDetailsReqBean.class))).thenReturn("TEST RESPONSE");
		communicationService.shareBrachDetails(empReqBean, shareBranchDetailsReqBean);
	}
	
	@Test
	public void validateOtpTest() throws RestClientException, IOException {
		OtpValidateReqBean otpValidateReqBean = new OtpValidateReqBean();
		otpValidateReqBean.setAction("Mobile");
		otpValidateReqBean.setOtp("1255");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		Mockito.doReturn(HrappTestUtil.prepareOtpMasterModel()).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
		Mockito.doReturn(3).when(genericConstants).getRetryCountValue();
		Mockito.when(otpRepo.save(Mockito.any(OtpMasterModel.class))).thenReturn(HrappTestUtil.prepareOtpMasterModel());
		Mockito.when(messagesConstants.getValidateOtpSuccessMsg()).thenReturn("Valid");
		communicationService.validateOtp(userDetailsBean, otpValidateReqBean);
	}
	
	@Test (expected = OtpException.class)
	public void validateOtpNotValidTest() throws RestClientException, IOException {
		OtpValidateReqBean otpValidateReqBean = new OtpValidateReqBean();
		otpValidateReqBean.setAction("Mobile");
		otpValidateReqBean.setOtp("1256");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		Mockito.doReturn(HrappTestUtil.prepareOtpMasterModel()).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
		Mockito.doReturn(3).when(genericConstants).getRetryCountValue();
		Mockito.when(otpRepo.save(Mockito.any(OtpMasterModel.class))).thenReturn(HrappTestUtil.prepareOtpMasterModel());
		Mockito.when(messagesConstants.getInvalidOtpMsg()).thenReturn("Un-Valid");
		communicationService.validateOtp(userDetailsBean, otpValidateReqBean);
	}
	
	@Test (expected = OtpException.class)
	public void validateOtpExceptionTest() throws RestClientException, IOException {
		OtpValidateReqBean otpValidateReqBean = new OtpValidateReqBean();
		otpValidateReqBean.setAction("Mobile");
		otpValidateReqBean.setOtp("1256");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		Mockito.doReturn(HrappTestUtil.prepareOtpMasterModel()).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
		Mockito.doReturn(0).when(genericConstants).getRetryCountValue();
		Mockito.when(otpRepo.save(Mockito.any(OtpMasterModel.class))).thenReturn(HrappTestUtil.prepareOtpMasterModel());
		Mockito.when(messagesConstants.getMultipleReqOtpMsg()).thenReturn("Exception");
		communicationService.validateOtp(userDetailsBean, otpValidateReqBean);
	}
	
	@Test (expected = OtpException.class)
	public void validateOtpNullEntityTest() throws RestClientException, IOException {
		OtpValidateReqBean otpValidateReqBean = new OtpValidateReqBean();
		otpValidateReqBean.setAction("Mobile");
		otpValidateReqBean.setOtp("1256");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		Mockito.doReturn(null).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
		Mockito.doReturn(3).when(genericConstants).getRetryCountValue();
		Mockito.when(otpRepo.save(Mockito.any(OtpMasterModel.class))).thenReturn(HrappTestUtil.prepareOtpMasterModel());
		Mockito.when(messagesConstants.getBlankOtpMsg()).thenReturn("Null Data");
		communicationService.validateOtp(userDetailsBean, otpValidateReqBean);
	}
	
//	@Test
//	public void sendOtpOnMobileTest() throws RestClientException, IOException {
//		OtpReqBean otpReqBean =new OtpReqBean();
//		otpReqBean.setAction("Mobile_verification");
//		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
//		Mockito.doReturn(HrappTestUtil.prepareOtpMasterModel()).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
//				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
//		Mockito.doReturn(3).when(genericConstants).getResendCountValue();
//		Mockito.when(otpRepo.save(Mockito.any(OtpMasterModel.class))).thenReturn(HrappTestUtil.prepareOtpMasterModel());
//		Mockito.when(rnlicService.sendOtpMobile(Mockito.any(UserDetailsBean.class), Mockito.any(OtpMasterModel.class))).thenReturn(true);
//		Mockito.when(messagesConstants.getSentOtpSuccessMsg()).thenReturn("Valid");
//		communicationService.sendOtpOnMobile(otpReqBean, userDetailsBean);
//	}
	
	@Test 
	public void sendOtpOnMobileResendCountMoreTest() throws RestClientException, IOException {
		OtpReqBean otpReqBean =new OtpReqBean();
		otpReqBean.setAction("Mobile_verification");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		Mockito.doReturn(HrappTestUtil.prepareOtpMasterModel()).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
		Mockito.doReturn(0).when(genericConstants).getResendCountValue();
		Mockito.when(messagesConstants.getMultipleReqOtpMsg()).thenReturn("Failed");
		communicationService.sendOtpOnMobile(otpReqBean, userDetailsBean);
	}
	
//	@Test
//	public void sendOtpOnMobileSaveDataTest() throws RestClientException, IOException {
//		OtpReqBean otpReqBean =new OtpReqBean();
//		otpReqBean.setAction("Mobile_verification");
//		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
//		Mockito.doReturn(null).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
//				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
//		Mockito.doReturn(3).when(genericConstants).getResendCountValue();
//		Mockito.when(otpRepo.save(Mockito.any(OtpMasterModel.class))).thenReturn(HrappTestUtil.prepareOtpMasterModel());
//		Mockito.when(rnlicService.sendOtpMobile(Mockito.any(UserDetailsBean.class), Mockito.any(OtpMasterModel.class))).thenReturn(true);
//		Mockito.when(messagesConstants.getSentOtpSuccessMsg()).thenReturn("Valid");
//		communicationService.sendOtpOnMobile(otpReqBean, userDetailsBean);
//	}
	
//	@Test (expected = OtpException.class)
//	public void sendOtpOnMobileSaveDataFailedTest() throws RestClientException, IOException {
//		OtpReqBean otpReqBean =new OtpReqBean();
//		otpReqBean.setAction("Mobile_verification");
//		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
//		Mockito.doReturn(null).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
//				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
//		Mockito.doReturn(4).when(genericConstants).getResendCountValue();
//		Mockito.when(otpRepo.save(Mockito.any(OtpMasterModel.class))).thenReturn(null);
//		Mockito.when(rnlicService.sendOtpMobile(Mockito.any(UserDetailsBean.class), Mockito.any(OtpMasterModel.class))).thenReturn(true);
//		Mockito.when(messagesConstants.getInternaErrorOtpMsg()).thenReturn("Failed");
//		communicationService.sendOtpOnMobile(otpReqBean, userDetailsBean);
//	}
	
	@Test (expected = OtpException.class)
	public void sendOtpOnMobileMultiTryTest() throws RestClientException, IOException {
		OtpReqBean otpReqBean =new OtpReqBean();
		otpReqBean.setAction("Mobile_verification");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		Mockito.doReturn(HrappTestUtil.prepareOtpMasterMultiTryFalseModel()).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
		Mockito.when(messagesConstants.getMultipleReqOtpMsg()).thenReturn("Test");
		communicationService.sendOtpOnMobile(otpReqBean, userDetailsBean);
	}
	
//	@Test
//	public void sendOtpOnMobileMultiTest() throws RestClientException, IOException {
//		OtpReqBean otpReqBean =new OtpReqBean();
//		otpReqBean.setAction("Mobile_verification");
//		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
//		Mockito.doReturn(HrappTestUtil.prepareOtpMasterMultiTryModel()).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
//				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
//		Mockito.doReturn(4).when(genericConstants).getResendCountValue();
//		Mockito.when(otpRepo.save(Mockito.any(OtpMasterModel.class))).thenReturn(HrappTestUtil.prepareOtpMasterModel());
//		Mockito.when(rnlicService.sendOtpMobile(Mockito.any(UserDetailsBean.class), Mockito.any(OtpMasterModel.class))).thenReturn(true);
//		Mockito.when(messagesConstants.getSentOtpSuccessMsg()).thenReturn("Valid");
//		communicationService.sendOtpOnMobile(otpReqBean, userDetailsBean);
//	}
	
	@Test (expected = OtpException.class)
	public void validateOtpMultiTryExceptionTest() throws RestClientException, IOException {
		OtpValidateReqBean otpValidateReqBean = new OtpValidateReqBean();
		otpValidateReqBean.setAction("Mobile");
		otpValidateReqBean.setOtp("1255");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		Mockito.doReturn(HrappTestUtil.prepareOtpMasterMultiTryFalseModel()).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
		Mockito.when(messagesConstants.getMultipleReqOtpMsg()).thenReturn("In-Valid");
		communicationService.validateOtp(userDetailsBean, otpValidateReqBean);
	}
	
	@Test (expected = OtpException.class)
	public void validateOtpInValidTest() throws RestClientException, IOException {
		OtpValidateReqBean otpValidateReqBean = new OtpValidateReqBean();
		otpValidateReqBean.setAction("Mobile");
		otpValidateReqBean.setOtp("1250");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		Mockito.doReturn(HrappTestUtil.prepareOtpMasterMultiTryModel()).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
		Mockito.doReturn(1).when(genericConstants).getRetryCountValue();
		Mockito.when(otpRepo.save(Mockito.any(OtpMasterModel.class))).thenReturn(HrappTestUtil.prepareOtpMasterModel());
		Mockito.when(messagesConstants.getInvalidOtpMsg()).thenReturn("In-Valid");
		communicationService.validateOtp(userDetailsBean, otpValidateReqBean);
	}
	
	@Test
	public void validateOtpInValidAndRegisterTest() throws RestClientException, IOException {
		OtpValidateReqBean otpValidateReqBean = new OtpValidateReqBean();
		otpValidateReqBean.setAction("Mobile");
		otpValidateReqBean.setOtp("1255");
		RegisterDeviceReqBean registerReqBean = new RegisterDeviceReqBean();
		registerReqBean.setAction("Mobile");
		registerReqBean.setAppVersion("V1");
		registerReqBean.setDeviceType("Android");
		registerReqBean.setInstalledLinkedApps(null);
		registerReqBean.setOtp("1255");;
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		Mockito.doReturn(HrappTestUtil.prepareOtpMasterModel()).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
		Mockito.doReturn(3).when(genericConstants).getRetryCountValue();
		Mockito.when(otpRepo.save(Mockito.any(OtpMasterModel.class))).thenReturn(HrappTestUtil.prepareOtpMasterModel());
		Mockito.when(messagesConstants.getValidateOtpSuccessMsg()).thenReturn("Valid");
		Mockito.doReturn(HrappTestUtil.prepareOtpMasterMultiTryModel()).when(otpRepo).getOtpDetails(Mockito.any(String.class), Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class),Mockito.any(Date.class));
		Mockito.doReturn(null).when(deviceService).registerDevice(Mockito.any(UserDetailsBean.class), Mockito.any(RegisterDeviceReqBean.class));
		communicationService.validateOtpAndRegisterDevice(userDetailsBean, registerReqBean);
	}
}
