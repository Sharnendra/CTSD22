package com.rnlic.hraapp.test.service;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.ChangePasswordReqBean;
import com.rnlic.hrapp.service.PasswordManagementService;
import com.rnlic.hrapp.service.RnlicService;

public class PasswordManagementServiceTest  extends HraServiceTests {

	@Mock
	private RnlicService rnlicService;
	
	@InjectMocks
	private PasswordManagementService passwordManagement;
	
	@Test
	public void requestForChangePasswordTest() {
		ChangePasswordReqBean changePasswordReqBean=null;
		Mockito.when(rnlicService.changePasswordRequest(Mockito.any(ChangePasswordReqBean.class))).thenReturn(HrappTestUtil.prepareChangePasswordResBean());
		passwordManagement.requestForChangePassword(changePasswordReqBean);
	}
	
//	@Test
//	public void updatePasswordTest() {
//		ChangePasswordReqBean changePasswordReqBean=null;
//		Mockito.when(rnlicService.updatePassword(Mockito.any(ChangePasswordReqBean.class))).thenReturn(HrappTestUtil.prepareChangePasswordResBean());
//		passwordManagement.updatePassword(changePasswordReqBean);
//	}
}
