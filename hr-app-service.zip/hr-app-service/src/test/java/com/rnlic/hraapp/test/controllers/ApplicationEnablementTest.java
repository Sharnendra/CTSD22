package com.rnlic.hraapp.test.controllers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.rnlic.hraapp.test.constants.TestConstant;
import com.rnlic.hrapp.bean.api.request.ApplicationConfigReqBean;
import com.rnlic.hrapp.constant.UrlConstants;
import com.rnlic.hrapp.controller.ApplicationEnablementController;
import com.rnlic.hrapp.exception.UnhandledException;
import com.rnlic.hrapp.service.ApplicationEnablementService;
import com.rnlic.hrapp.util.LogUtil;
import com.rnlic.hrapp.util.RequestLogDeatils;
import com.rnlic.hrapp.util.RequestValidator;

@RunWith(SpringJUnit4ClassRunner.class)
public class ApplicationEnablementTest {

	private MockMvc mockMvc;

	@Mock
	private ApplicationEnablementService applicationEnablementService;
	
	@Mock
	private RequestValidator requestValidator;
	
	@Mock
	private LogUtil logger;
	
	@Mock
	private RequestLogDeatils requestLog;

	@InjectMocks
	private ApplicationEnablementController applicationEnablementController;

	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(applicationEnablementController).build();
	}
	
	@Test
	public void integrationTestGetApplicationConfiguration() throws Exception {
		mockMvc.perform(post(UrlConstants.GET_LINKED_APPLICATION_CONFIG_URL)
				.contentType(UrlConstants.APPLICATION_JSON_UTF8))
				.andExpect(status().isOk());
	}
	
	@Test
	public void integrationTestGetApplicationConfigurationExp() throws Exception {
		Mockito.when(applicationEnablementService.getLinkedAppConfiguration()).thenThrow(new UnhandledException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_LINKED_APPLICATION_CONFIG_URL).contentType(MediaType.APPLICATION_JSON);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void integrationTestGetApplicationConfigurationExp1() throws Exception {
		Mockito.when(applicationEnablementService.getLinkedAppConfiguration()).thenThrow(new RuntimeException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_LINKED_APPLICATION_CONFIG_URL).contentType(MediaType.APPLICATION_JSON);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
	@Test
	public void testGetApplicationConfigurationVersion() throws Exception {
		Mockito.when(applicationEnablementService.getLinkedAppConfigurationVersion()).thenReturn("01");
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_LINKED_APPLICATION_CONFIG_VERSION_URL).contentType(MediaType.APPLICATION_JSON);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetApplicationConfigurationVersionExp() throws Exception {
		Mockito.when(applicationEnablementService.getLinkedAppConfigurationVersion()).thenThrow(new UnhandledException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_LINKED_APPLICATION_CONFIG_VERSION_URL).contentType(MediaType.APPLICATION_JSON);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetApplicationConfigurationVersionExp1() throws Exception {
		Mockito.when(applicationEnablementService.getLinkedAppConfigurationVersion()).thenThrow(new RuntimeException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_LINKED_APPLICATION_CONFIG_VERSION_URL).contentType(MediaType.APPLICATION_JSON);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
	@Test
	public void testUpdateApplicationConfiguration() throws Exception {
		String expectedReq = TestConstant.GET_CONFIG.toString();
		ApplicationConfigReqBean appconfig = new ApplicationConfigReqBean();
		Mockito.when(applicationEnablementService.updateLinkedAppConfiguration(appconfig)).thenThrow(new RuntimeException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.UPDATE_APPLICATION_CONFIGURATION_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("admin-user","admin").header("admin-pass", "pass");
		mockMvc.perform(requestBuilder).andReturn();
		
	}
}
