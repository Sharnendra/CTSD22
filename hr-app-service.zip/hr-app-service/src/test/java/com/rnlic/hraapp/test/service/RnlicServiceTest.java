package com.rnlic.hraapp.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.api.response.AnniversaryListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.BirthdayListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.BirthdaySmsResBean;
import com.rnlic.hrapp.bean.api.response.CandidateRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.ChangePasswordRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.CheckInCheckOutRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.EmployeeRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.MandatoryLearningRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.MandatoryLearningStatusRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.MonthlyAttendanceDetailsRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.NoticesRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.ReporteeListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.RnlicAuthRes;
import com.rnlic.hrapp.bean.api.response.RnlicBranchDetailsListResponseBean;
import com.rnlic.hrapp.bean.api.response.RnlicServicesDataTranslator;
import com.rnlic.hrapp.bean.api.response.StateCityMasterRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.TroubleWithLoginRnlicResponseBean;
import com.rnlic.hrapp.bean.request.AttendanceReqBean;
import com.rnlic.hrapp.bean.request.AuthReqBean;
import com.rnlic.hrapp.bean.request.BirthdayReqBean;
import com.rnlic.hrapp.bean.request.ChangePasswordReqBean;
import com.rnlic.hrapp.bean.request.EmployeeCheckInCheckOutReqBean;
import com.rnlic.hrapp.bean.request.LocalBranchReqBean;
import com.rnlic.hrapp.bean.request.MailingReqBean;
import com.rnlic.hrapp.bean.request.ShareBranchDetailsReqBean;
import com.rnlic.hrapp.bean.request.WishesReq;
import com.rnlic.hrapp.bean.response.EmployeeCheckInCheckOutResBean;
import com.rnlic.hrapp.bean.response.LocateBranchResBean;
import com.rnlic.hrapp.bean.response.LocateBranches;
import com.rnlic.hrapp.bean.response.ReporteeDetails;
import com.rnlic.hrapp.bean.response.User;
import com.rnlic.hrapp.configuration.MailerConfig;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.constant.RnlicUrlConstants;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;
import com.rnlic.hrapp.entity.OtpMasterModel;
import com.rnlic.hrapp.entity.PushDataModal;
import com.rnlic.hrapp.exception.CheckInCheckOutException;
import com.rnlic.hrapp.exception.RnlicServiceException;
import com.rnlic.hrapp.exception.StateDetailsNotFoundException;
import com.rnlic.hrapp.repository.PushDataRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.RnlicApiExchange;
import com.rnlic.hrapp.service.RnlicService;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestLogDeatils;

@SuppressWarnings("unchecked")
public class RnlicServiceTest extends HraServiceTests {

	@Mock
	private RnlicUrlConstants rnlicUrlConstants;
	
	@Mock
	private RnlicServicesDataTranslator rnlicDataTranslator;
	
	@Mock
	private MessagesConstants messagesConstants;
	
	@InjectMocks
	private RnlicService rnlicService;
	
	@Mock
	private RnlicApiExchange rnlicApiExchange;
	
	@Mock
	private MailerConfig mailerConfig;
	
	@Mock
	private GenericConstants genericConstants;
	
	@Mock
	private RequestLogDeatils requestLog;
	
	@Mock
	private PushDataRepository pushDataRepository;
	
	/*-------------------------------------------getCandidateDtlsFromRnlicTest test cases Start-------------------------------------------------------------*/
	@Test
	public void getCandidateDtlsFromRnlicTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsCandidateBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getCandidateDtlsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareCandidateRnlicResponseBean('A'));
		Mockito.when(rnlicDataTranslator.getCandidateDetails(Mockito.any(CandidateRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareUserdetails());
		User user = rnlicService.getCandidateDtlsFromRnlic(empReqBean);
		assertNotNull(user);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getCandidateDtlsFromRnlicExceptionTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsCandidateBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getCandidateDtlsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.getCandidateDtlsFromRnlic(empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getCandidateDtlsFromRnlicNoDataTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsCandidateBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getCandidateDtlsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareCandidateRnlicResponseBean('B'));
		rnlicService.getCandidateDtlsFromRnlic(empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getCandidateDtlsFromRnlicFailedTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsCandidateBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getCandidateDtlsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareCandidateRnlicResponseBean('C'));
		rnlicService.getCandidateDtlsFromRnlic(empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getCandidateDtlsFromRnlicFailureTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsCandidateBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getCandidateDtlsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareCandidateRnlicResponseBean('D'));
		rnlicService.getCandidateDtlsFromRnlic(empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getCandidateDtlsFromRnlicUnknownTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsCandidateBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getCandidateDtlsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareCandidateRnlicResponseBean('E'));
		rnlicService.getCandidateDtlsFromRnlic(empReqBean);
	}
	/*-------------------------------------------getCandidateDtlsFromRnlicTest test cases End-------------------------------------------------------------*/
	
	/*-------------------------------------------getEmpDetailsFromRnlic test cases Start-------------------------------------------------------------*/
	@Test
	public void getEmpDetailsFromRnlicTest() throws JsonParseException, JsonMappingException, IOException{
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsBean("455eeex892td452dd", "+91-9856325854", "CBHPD4221P", "70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getEmpDetailsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareEmployeeRnlicResponseBean());
		Mockito.when(rnlicDataTranslator.getEmpDetails(Mockito.any(EmployeeRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareUserdetails());
		User user = rnlicService.getEmpDetailsFromRnlic(empReqBean);
		assertNotNull(user);
	} 
	
	@Test(expected = RnlicServiceException.class)
	public void getEmpDetailsFromRnlicRnlicServiceExceptionTest() throws JsonParseException, JsonMappingException, IOException{
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsBean("455eeex892td452dd", "+91-9856325854", "CBHPD4221P", "70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getEmpDetailsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.getEmpDetailsFromRnlic(empReqBean);
	} 
	
	@Test(expected = RnlicServiceException.class)
	public void getEmpDetailsFromRnlicNoDataFoundTest() throws JsonParseException, JsonMappingException, IOException{
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsBean("455eeex892td452dd", "+91-9856325854", "CBHPD4221P", "70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getEmpDetailsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareEmployeeRnlicResponseNoDataFoundBean());
		rnlicService.getEmpDetailsFromRnlic(empReqBean);
	} 
	
	@Test (expected = RnlicServiceException.class)
	public void getEmpDetailsFromRnlicFailedTest() throws JsonParseException, JsonMappingException, IOException{
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsBean("455eeex892td452dd", "+91-9856325854", "CBHPD4221P", "70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getEmpDetailsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareEmployeeRnlicResponseFailedBean());
		rnlicService.getEmpDetailsFromRnlic(empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getEmpDetailsFromRnlicFailureTest() throws JsonParseException, JsonMappingException, IOException{
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsBean("455eeex892td452dd", "+91-9856325854", "CBHPD4221P", "70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getEmpDetailsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareEmployeeRnlicResponseFailureBean());
		rnlicService.getEmpDetailsFromRnlic(empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getEmpDetailsFromRnlicUnknownTest() throws JsonParseException, JsonMappingException, IOException{
		UserDetailsBean empReqBean =HrappTestUtil.prepareUserDtlsBean("455eeex892td452dd", "+91-9856325854", "CBHPD4221P", "70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getEmpDetailsFromRnlicUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareEmployeeRnlicResponseUnknownBean());
		rnlicService.getEmpDetailsFromRnlic(empReqBean);
	}
	/*-------------------------------------------getEmpDetailsFromRnlic test cases End-------------------------------------------------------------*/
	
	/*-------------------------------------------getEmployeeAuthentication test cases Start--------------------------------------------------------*/
	@Test
	public void getEmployeeAuthenticationTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getEmployeeAuthenticationUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicAuthRes());
		boolean value = rnlicService.getEmployeeAuthentication(authReqBean);
		assertEquals(true, value);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getEmployeeAuthenticationNullTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getEmployeeAuthenticationUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		boolean value = rnlicService.getEmployeeAuthentication(authReqBean);
		assertEquals(true, value);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getEmployeeAuthenticationFailureTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getEmployeeAuthenticationUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicAuthResFailure());
		rnlicService.getEmployeeAuthentication(authReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getEmployeeAuthenticationFailedTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getEmployeeAuthenticationUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicAuthResFailed());
		rnlicService.getEmployeeAuthentication(authReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getEmployeeAuthenticationUnknownTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getEmployeeAuthenticationUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicAuthResUnknown());
		rnlicService.getEmployeeAuthentication(authReqBean);
	}
	/*-------------------------------------------getEmployeeAuthentication test cases End--------------------------------------------------------*/
	
	/*-------------------------------------------getCandidateAuthentication test cases Start-----------------------------------------------------*/
	@Test
	public void getCandidateAuthenticationTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getCandidateAuthenticationUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicAuthRes());
		boolean value = rnlicService.getCandidateAuthentication(authReqBean);
		assertEquals(true, value);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getCandidateAuthenticationNullTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getCandidateAuthenticationUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		boolean value = rnlicService.getCandidateAuthentication(authReqBean);
		assertEquals(true, value);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getCandidateAuthenticationFailedTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getCandidateAuthenticationUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicAuthResFailed());
		rnlicService.getCandidateAuthentication(authReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getCandidateAuthenticationFailureTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getCandidateAuthenticationUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicAuthResFailure());
		rnlicService.getCandidateAuthentication(authReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getCandidateAuthenticationUnknownTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getCandidateAuthenticationUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicAuthResUnknown());
		rnlicService.getCandidateAuthentication(authReqBean);
	}
	/*-------------------------------------------getCandidateAuthentication test cases Start-----------------------------------------------------*/
	
	/*------------------------------------------------sendOtpMobileTest test cases Start---------------------------------------------------------*/
//	@Test
//	public void sendOtpMobileTest() throws RestClientException, IOException {
//		UserDetailsBean empReqBean = new UserDetailsBean();
//		OtpMasterModel otpEntity = new OtpMasterModel();
//		otpEntity.setMobileNumber("9321402007");
//		otpEntity.setOtpValue(652254);
//		otpEntity.setValidUpto(new Date());
//		otpEntity.setAction("Mobile_verification");
//		Mockito.when(messagesConstants.getOtpSecureText()).thenReturn(String.format("%s is the OTP for mobile verification on RNLIC HRAPP. OTP will valid upto %s. Please do not share it with anyone.",String.valueOf(otpEntity.getOtpValue()), HrAppUtil.dateTimeFormator(otpEntity.getValidUpto())));
//		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
//		Mockito.when(rnlicApiExchange.sendOtpMobileUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareSendOtpRnlicResponseBean());
//		boolean value = rnlicService.sendOtpMobile(empReqBean, otpEntity);
//		assertNotNull(value);
//		assertEquals(true, value);
//	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendOtpMobileFailureTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean = new UserDetailsBean();
		OtpMasterModel otpEntity = new OtpMasterModel();
		otpEntity.setMobileNumber("9321402007");
		otpEntity.setOtpValue(652254);
		otpEntity.setValidUpto(new Date());
		otpEntity.setAction("Mobile_verification");
		Mockito.when(messagesConstants.getOtpSecureText()).thenReturn(String.format("%s is the OTP for mobile verification on RNLIC HRAPP. OTP will valid upto %s. Please do not share it with anyone.",String.valueOf(otpEntity.getOtpValue()), HrAppUtil.dateTimeFormator(otpEntity.getValidUpto())));
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.sendOtpMobileUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareSendOtpRnlicFailureResponseBean());
		rnlicService.sendOtpMobile(empReqBean, otpEntity);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendOtpMobileFailedTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean = new UserDetailsBean();
		OtpMasterModel otpEntity = new OtpMasterModel();
		otpEntity.setMobileNumber("9321402007");
		otpEntity.setOtpValue(652254);
		otpEntity.setValidUpto(new Date());
		otpEntity.setAction("Mobile_verification");
		Mockito.when(messagesConstants.getOtpSecureText()).thenReturn(String.format("%s is the OTP for mobile verification on RNLIC HRAPP. OTP will valid upto %s. Please do not share it with anyone.",String.valueOf(otpEntity.getOtpValue()), HrAppUtil.dateTimeFormator(otpEntity.getValidUpto())));
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.sendOtpMobileUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareSendOtpRnlicFailedResponseBean());
		rnlicService.sendOtpMobile(empReqBean, otpEntity);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendOtpMobileNullTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean = new UserDetailsBean();
		OtpMasterModel otpEntity = new OtpMasterModel();
		otpEntity.setMobileNumber("9321402007");
		otpEntity.setOtpValue(652254);
		otpEntity.setValidUpto(new Date());
		otpEntity.setAction("Mobile_verification");
		Mockito.when(messagesConstants.getOtpSecureText()).thenReturn(String.format("%s is the OTP for mobile verification on RNLIC HRAPP. OTP will valid upto %s. Please do not share it with anyone.",String.valueOf(otpEntity.getOtpValue()), HrAppUtil.dateTimeFormator(otpEntity.getValidUpto())));
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.sendOtpMobileUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.sendOtpMobile(empReqBean, otpEntity);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendOtpMobileUnknownTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean = new UserDetailsBean();
		OtpMasterModel otpEntity = new OtpMasterModel();
		otpEntity.setMobileNumber("9321402007");
		otpEntity.setOtpValue(652254);
		otpEntity.setValidUpto(new Date());
		otpEntity.setAction("Mobile_verification");
		Mockito.when(messagesConstants.getOtpSecureText()).thenReturn(String.format("%s is the OTP for mobile verification on RNLIC HRAPP. OTP will valid upto %s. Please do not share it with anyone.",String.valueOf(otpEntity.getOtpValue()), HrAppUtil.dateTimeFormator(otpEntity.getValidUpto())));
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.sendOtpMobileUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareSendOtpRnlicUnknownResponseBean());
		rnlicService.sendOtpMobile(empReqBean, otpEntity);
	}
	/*------------------------------------------------sendOtpMobileTest test cases End---------------------------------------------------------*/
	
	/*-------------------------------------------performCheckInCheckOuTest test cases Start----------------------------------------------------*/
	@Test(expected = CheckInCheckOutException.class)
	public void performCheckInCheckOuTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	
	@Test
	public void performCheckInTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-in");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckInResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckInUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(rnlicDataTranslator.getEmployeeCheckInCheckOutRes(Mockito.any(EmployeeCheckInCheckOutReqBean.class), Mockito.any(CheckInCheckOutRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareEmployeeCheckInCheckOutRes(employeeCheckInCheckOutReqBean.getType(), req));
		EmployeeCheckInCheckOutResBean res= rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
		assertNotNull(res);
		assertEquals(GenericConstants.SUCCESS, res.getStatus());
	}
	
	@Test
	public void performCheckInAlreadyMarkedTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-in");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckInAlreadyMarkedResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckInUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(messagesConstants.getCheckInAlreadyMarked()).thenReturn("Sorry! Your Attendance is already marked for the day");
		Mockito.when(rnlicDataTranslator.getEmployeeCheckInCheckOutRes(Mockito.any(EmployeeCheckInCheckOutReqBean.class), Mockito.any(CheckInCheckOutRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareEmployeeCheckInCheckOutRes(employeeCheckInCheckOutReqBean.getType(), req));
		EmployeeCheckInCheckOutResBean res= rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
		assertNotNull(res);
		assertEquals(GenericConstants.FAILED, res.getStatus());
	}
	
	@Test (expected = RnlicServiceException.class)
	public void performCheckInAlreadyMarkedExceptionTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-in");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckInAlreadyMarkedErrorResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckInUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(messagesConstants.getCheckInAlreadyMarked()).thenReturn("Exception has occured");
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void performCheckInFailedTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-in");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckInAlreadyMarkedResponseExceptionBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckInUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(messagesConstants.getCheckInAlreadyMarked()).thenReturn("XX YY ZZ");
		Mockito.when(messagesConstants.getCheckingInFailedNoError()).thenReturn("Check-in failed for your request -> %s , Please try after some time.");
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void performCheckInFailedDataTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-in");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckInAlreadyMarkedDataResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckInUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(messagesConstants.getCheckInAlreadyMarked()).thenReturn("XX YY ZZ");
		Mockito.when(messagesConstants.getCheckingInFailedNoError()).thenReturn("Check-in failed for your request -> %s , Please try after some time.");
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void performCheckInFailureTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-in");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckFailureResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckInUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(messagesConstants.getCheckInAlreadyMarked()).thenReturn("XX YY ZZ");
		Mockito.when(messagesConstants.getCheckingInFailedNoError()).thenReturn("Check-in failed for your request -> %s , Please try after some time.");
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void performCheckInUnknownTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-in");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckUnknownResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckInUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(messagesConstants.getCheckingInFailedNoError()).thenReturn("Check-in failed for your request -> %s , Please try after some time.");
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void performCheckInNullTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-in");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckInUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	
	@Test
	public void performCheckOutTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-out");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckOutResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckOutUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(rnlicDataTranslator.getEmployeeCheckInCheckOutRes(Mockito.any(EmployeeCheckInCheckOutReqBean.class), Mockito.any(CheckInCheckOutRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareEmployeeCheckInCheckOutRes(employeeCheckInCheckOutReqBean.getType(), req));
		EmployeeCheckInCheckOutResBean res= rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
		assertNotNull(res);
		assertEquals(GenericConstants.SUCCESS, res.getStatus());
	}
	
	@Test
	public void performCheckOutAlreadyMarkedTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-out");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckOutAlreadyMarkedResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckOutUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(messagesConstants.getCheckOutAlreadyMarked()).thenReturn("Your CheckOut is already marked for the day");
		Mockito.when(rnlicDataTranslator.getEmployeeCheckInCheckOutRes(Mockito.any(EmployeeCheckInCheckOutReqBean.class), Mockito.any(CheckInCheckOutRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareEmployeeCheckInCheckOutRes(employeeCheckInCheckOutReqBean.getType(), req));
		EmployeeCheckInCheckOutResBean res= rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
		assertNotNull(res);
		assertEquals(GenericConstants.FAILED, res.getStatus());
	}
	
	@Test (expected = RnlicServiceException.class)
	public void performCheckOutFailedTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-out");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckOutAlreadyMarkedExceptionResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckOutUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(messagesConstants.getCheckOutAlreadyMarked()).thenReturn("XX YY ZZ");
		Mockito.when(messagesConstants.getCheckingOutFailedNoError()).thenReturn("Check-out failed for your request -> %s , Please try after some time.");
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void performCheckOutFailedDataTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-out");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckOutAlreadyMarkedResponseDataBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckOutUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(messagesConstants.getCheckOutAlreadyMarked()).thenReturn("XX YY ZZ");
		Mockito.when(messagesConstants.getCheckingOutFailedNoError()).thenReturn("Check-out failed for your request -> %s , Please try after some time.");
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void performCheckOutFailureTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-out");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckFailureResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckOutUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(messagesConstants.getCheckOutAlreadyMarked()).thenReturn("XX YY ZZ");
		Mockito.when(messagesConstants.getCheckingOutFailedNoError()).thenReturn("Check-out failed for your request -> %s , Please try after some time.");
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void performCheckOutUnknownTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-out");
		CheckInCheckOutRnlicResponseBean req = HrappTestUtil.prepareCheckUnknownResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckOutUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(req);
		Mockito.when(messagesConstants.getCheckingOutFailedNoError()).thenReturn("Check-out failed for your request -> %s , Please try after some time.");
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void performCheckOutNullTest() {
		List<String> role =new ArrayList<>();
		role.add("TERRITORY MANAGER");
		UserDetailsBean empReqBean =new UserDetailsBean("Shyam", "Shendre", "70109281", "8670899251", null, "152455654523", true, false, "70055996", role, "IL5B (E3)");
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		employeeCheckInCheckOutReqBean.setType("check-out");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performCheckOutUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.performCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
	}
	/*-------------------------------------------performCheckInCheckOuTest test cases End------------------------------------------------------*/
	
	/*--------------------------------------------getTodayBirthdayTest test cases Start--------------------------------------------------------*/
	@Test (expected = RnlicServiceException.class)
	public void getTodayBirthdayNullTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayBirthdayUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(null);
		rnlicService.getTodayBirthday();
	}
	
	@Test
	public void getTodayBirthdayTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayBirthdayUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareBirthdayListRnlicResponseBean());
		Mockito.when(rnlicDataTranslator.getBirthdayList(Mockito.any(BirthdayListRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareBirthdayList());
		rnlicService.getTodayBirthday();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getTodayBirthdayNoDataTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayBirthdayUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareBirthdayListRnlicNoDataResponseBean());
		rnlicService.getTodayBirthday();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getTodayBirthdayFailureTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayBirthdayUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareBirthdayListRnlicFailureResponseBean());
		rnlicService.getTodayBirthday();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getTodayBirthdayFailedTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayBirthdayUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareBirthdayListRnlicFailedResponseBean());
		rnlicService.getTodayBirthday();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getTodayBirthdayUnknownTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayBirthdayUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareBirthdayListRnlicUnknownResponseBean());
		rnlicService.getTodayBirthday();
	}
	/*--------------------------------------------getTodayBirthdayTest test cases End--------------------------------------------------------*/
	
	/*-----------------------------------------getTodayAnniversaryTest test cases Start------------------------------------------------------*/
	@Test (expected = RnlicServiceException.class)
	public void getTodayAnniversaryNullTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayAnniversaryUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(null);
		rnlicService.getTodayAnniversary();
	}
	
	@Test
	public void getTodayAnniversaryTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayAnniversaryUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareAnniversaryListRnlicResponseBean());
		Mockito.when(rnlicDataTranslator.getAnniversaryList(Mockito.any(AnniversaryListRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareAnniversaryList());
		rnlicService.getTodayAnniversary();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getTodayAnniversaryNoDataTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayAnniversaryUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareAnniversaryListRnlicNoDataResponseBean());
		rnlicService.getTodayAnniversary();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getTodayAnniversaryFailureTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayAnniversaryUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareAnniversaryListRnlicFailureResponseBean());
		rnlicService.getTodayAnniversary();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getTodayAnniversaryFailedTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayAnniversaryUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareAnniversaryListRnlicFailedResponseBean());
		rnlicService.getTodayAnniversary();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getTodayAnniversaryUnknownTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetTodayAnniversaryUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareAnniversaryListRnlicUnknownResponseBean());
		rnlicService.getTodayAnniversary();
	}
	/*-----------------------------------------getTodayAnniversaryTest test cases End--------------------------------------------------------*/
	
	/*-----------------------------------------getListOfReporteesTest test cases Start-------------------------------------------------------*/
	@Test
	public void getListOfReporteesTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetListOfReporteesUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareReporteeListRnlicResponseBean());
		Mockito.when(rnlicDataTranslator.getReporteeList(Mockito.any(ReporteeListRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareReporteeList());
		rnlicService.getListOfReportees("70009002");
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getListOfReporteesNullTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetListOfReporteesUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(null);
		rnlicService.getListOfReportees("70009002");
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getListOfReporteesFailureTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetListOfReporteesUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareReporteeListRnlicFailureResponseBean());
		rnlicService.getListOfReportees("70009002");
	}
	
	@Test
	public void getListOfReporteesFailedTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetListOfReporteesUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareReporteeListRnlicFailedResponseBean());
		Mockito.when(rnlicDataTranslator.getReporteeList(Mockito.any(ReporteeListRnlicResponseBean.class))).thenReturn(null);
		List<ReporteeDetails> reporteeList = rnlicService.getListOfReportees("70009002");
		assertNull(reporteeList);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getListOfReporteesUnknownTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performGetListOfReporteesUrl(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareReporteeListRnlicUnknownResponseBean());
		List<ReporteeDetails> reporteeList = rnlicService.getListOfReportees("70009002");
		assertNull(reporteeList);
	}
	/*------------------------------------------getListOfReporteesTest test cases End--------------------------------------------------------*/
	
	/*------------------------------------------sendBirthdaySmsTest test cases Start---------------------------------------------------------*/
	@Test
	public void sendBirthdaySmsTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendBirthdaySmsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareSMSResponse());
		BirthdaySmsResBean rnlicAuthRes = rnlicService.sendBirthdaySms(wishTo,"78588");
		assertEquals(GenericConstants.SUCCESS, rnlicAuthRes.getStatus());
	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendBirthdaySmsNullTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendBirthdaySmsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.sendBirthdaySms(wishTo,"78588");
	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendBirthdaySmsNullStatusTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendBirthdaySmsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareSMSNullStatusResponse());
		rnlicService.sendBirthdaySms(wishTo,"78588");
	}
	/*------------------------------------------sendBirthdaySmsTest test cases End----------------------------------------------------------*/
	
	/*------------------------------------------sendAnniversarySmsTest test cases Start----------------------------------------------------------*/
	@Test
	public void sendAnniversarySmsTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendBirthdaySmsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareSMSResponse());
		BirthdaySmsResBean rnlicAuthRes = rnlicService.sendAnniversarySms(wishTo,"78588");
		assertEquals(GenericConstants.SUCCESS, rnlicAuthRes.getStatus());
	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendAnniversarySmsNullTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendBirthdaySmsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.sendAnniversarySms(wishTo,"78588");
	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendAnniversarySmsNullStatusTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendBirthdaySmsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareSMSNullStatusResponse());
		rnlicService.sendAnniversarySms(wishTo,"78588");
	}
	/*------------------------------------------sendAnniversarySmsTest test cases End----------------------------------------------------------*/
	
	/*------------------------------------------sendBirthdayEmailTest test cases Start--------------------------------------------------------*/
	@Test
	public void sendBirthdayEmailTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendBirthdayEmailUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareEmaiResponse());
		RnlicAuthRes rnlicAuthRes = rnlicService.sendBirthdayEmail(wishTo,"78588");
		assertEquals(GenericConstants.SUCCESS, rnlicAuthRes.getStatus());
	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendBirthdayEmailNullTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendBirthdayEmailUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		RnlicAuthRes rnlicAuthRes = rnlicService.sendBirthdayEmail(wishTo,"78588");
		assertEquals(GenericConstants.SUCCESS, rnlicAuthRes.getStatus());
	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendBirthdayEmailNullStatusTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendBirthdayEmailUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareEmaiNullStatusResponse());
		rnlicService.sendBirthdayEmail(wishTo,"78588");
	}
	/*------------------------------------------sendBirthdayEmailTest test cases End---------------------------------------------------------*/
	
	/*--------------------------------------sendAnniversaryEmailTest test cases Start---------------------------------------------------------*/
	@Test
	public void sendAnniversaryEmailTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendAnniversaryEmailUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareEmaiResponse());
		RnlicAuthRes rnlicAuthRes = rnlicService.sendAnniversaryEmail(wishTo,"78588");
		assertEquals(GenericConstants.SUCCESS, rnlicAuthRes.getStatus());
	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendAnniversaryEmailNullTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendAnniversaryEmailUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.sendAnniversaryEmail(wishTo,"78588");
	}
	
	@Test (expected = RnlicServiceException.class)
	public void sendAnniversaryEmailNullStatusTest() {
		WishesReq wishTo=new WishesReq();
		wishTo.setSapCode("70009002");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.performSendAnniversaryEmailUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareEmaiNullStatusResponse());
		rnlicService.sendAnniversaryEmail(wishTo,"78588");
	}
	/*--------------------------------------sendAnniversaryEmailTest test cases End---------------------------------------------------------*/
	
	/*-----------------------------------------searchBirthdayTest test cases Start----------------------------------------------------------*/
	@Test
	public void searchBirthdayTest() {
		BirthdayReqBean birthdayReqBean =new BirthdayReqBean();
		birthdayReqBean.setSapCode("70109281");
		birthdayReqBean.setName("Shyam Madhukar Shendre");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.searchBirthdayUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareBirthdayListRnlicResponseBean());
		Mockito.when(rnlicDataTranslator.getBirthdayList(Mockito.any(BirthdayListRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareBirthdayList());
		rnlicService.searchBirthday(birthdayReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void searchBirthdayNullTest() {
		BirthdayReqBean birthdayReqBean =new BirthdayReqBean();
		birthdayReqBean.setSapCode("70109281");
		birthdayReqBean.setName("Shyam Madhukar Shendre");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.searchBirthdayUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.searchBirthday(birthdayReqBean);
	}
	
	@Test (expected = StateDetailsNotFoundException.class)
	public void searchBirthdayFailedTest() {
		BirthdayReqBean birthdayReqBean =new BirthdayReqBean();
		birthdayReqBean.setSapCode("70109281");
		birthdayReqBean.setName("Shyam Madhukar Shendre");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.searchBirthdayUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareBirthdayListRnlicFailedResponseBean());
		rnlicService.searchBirthday(birthdayReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void searchBirthdayFailureTest() {
		BirthdayReqBean birthdayReqBean =new BirthdayReqBean();
		birthdayReqBean.setSapCode("70109281");
		birthdayReqBean.setName("Shyam Madhukar Shendre");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.searchBirthdayUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareBirthdayListRnlicFailureResponseBean());
		rnlicService.searchBirthday(birthdayReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void searchBirthdayUnknownTest() {
		BirthdayReqBean birthdayReqBean =new BirthdayReqBean();
		birthdayReqBean.setSapCode("70109281");
		birthdayReqBean.setName("Shyam Madhukar Shendre");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.searchBirthdayUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareBirthdayListRnlicUnknownResponseBean());
		rnlicService.searchBirthday(birthdayReqBean);
	}	
	/*-----------------------------------------searchBirthdayTest test cases End----------------------------------------------------------*/
	
	/*-----------------------------------------getStateCityMasterTest test cases Start----------------------------------------------------------*/
	@Test
	public void getStateCityMasterTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getStateCityMasterUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareStateCityMasterRnlicResponseBean());
		Mockito.when(rnlicDataTranslator.getStateCityMasteList(Mockito.any(StateCityMasterRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareStateCityMasterDetails());
		rnlicService.getStateCityMaster();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getStateCityMasterNullTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getStateCityMasterUrl(Mockito.any(String.class))).thenReturn(null);
		rnlicService.getStateCityMaster();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getStateCityMasterFailureTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getStateCityMasterUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareStateCityMasterRnlicFailureResponseBean());
		rnlicService.getStateCityMaster();
	}
	
	@Test (expected = StateDetailsNotFoundException.class)
	public void getStateCityMasterFailedTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getStateCityMasterUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareStateCityMasterRnlicFailedResponseBean());
		rnlicService.getStateCityMaster();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getStateCityMasterUnknownTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getStateCityMasterUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareStateCityMasterRnlicUnknownResponseBean());
		rnlicService.getStateCityMaster();
	}
	/*-----------------------------------------getStateCityMasterTest test cases End----------------------------------------------------------*/
	
	/*-----------------------------------------getBranchDetailsTest test cases Start----------------------------------------------------------*/
	@Test
	public void getBranchDetailsTest() {
		LocalBranchReqBean localBranchReqBean=new LocalBranchReqBean();
		localBranchReqBean.setCityName("Kolkata");
		localBranchReqBean.setStateName("West Bengal");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getBranchDetailsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicBranchDetailsListResponseBean());
		Mockito.when(rnlicDataTranslator.getBranchDetails(Mockito.any(RnlicBranchDetailsListResponseBean.class),Mockito.any(LocateBranchResBean.class))).thenReturn(HrappTestUtil.prepareBranchDetails());
		rnlicService.getBranchDetails(localBranchReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getBranchDetailsNullTest() {
		LocalBranchReqBean localBranchReqBean=new LocalBranchReqBean();
		localBranchReqBean.setCityName("Kolkata");
		localBranchReqBean.setStateName("West Bengal");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getBranchDetailsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.getBranchDetails(localBranchReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getBranchDetailsFailureTest() {
		LocalBranchReqBean localBranchReqBean=new LocalBranchReqBean();
		localBranchReqBean.setCityName("Kolkata");
		localBranchReqBean.setStateName("West Bengal");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getBranchDetailsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicBranchDetailsListFailureResponseBean());
		rnlicService.getBranchDetails(localBranchReqBean);
	}
	
	@Test (expected = StateDetailsNotFoundException.class)
	public void getBranchDetailsFailedTest() {
		LocalBranchReqBean localBranchReqBean=new LocalBranchReqBean();
		localBranchReqBean.setCityName("Kolkata");
		localBranchReqBean.setStateName("West Bengal");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getBranchDetailsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicBranchDetailsListFailedResponseBean());
		rnlicService.getBranchDetails(localBranchReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getBranchDetailsUnknownTest() {
		LocalBranchReqBean localBranchReqBean=new LocalBranchReqBean();
		localBranchReqBean.setCityName("Kolkata");
		localBranchReqBean.setStateName("West Bengal");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getBranchDetailsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareRnlicBranchDetailsListUnknownResponseBean());
		rnlicService.getBranchDetails(localBranchReqBean);
	}
	/*-----------------------------------------getBranchDetailsTest test cases End----------------------------------------------------------*/
	
	/*-----------------------------------------updateDeviceRegInfoTest test cases Start----------------------------------------------------------*/
	@Test
	public void updateDeviceRegInfoTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.updateDeviceRegInfoUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareDeviceRegInfoResponseBean('A'));
		boolean value = rnlicService.updateDeviceRegInfo("7547eeffde45748ed", "8317509142", "9041185", "fgfgyggvfh");
		assertNotNull(value);
		assertEquals(true, value);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void updateDeviceRegInfoNullTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.updateDeviceRegInfoUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.updateDeviceRegInfo("7547eeffde45748ed", "8317509142", "9041185", "fgfgyggvfh");
	}
	
	@Test
	public void updateDeviceRegInfoFailedTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.updateDeviceRegInfoUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareDeviceRegInfoResponseBean('B'));
		boolean value = rnlicService.updateDeviceRegInfo("7547eeffde45748ed", "8317509142", "9041185", "fgfgyggvfh");
		assertNotNull(value);
		assertEquals(false, value);
	}
	
	@Test
	public void updateDeviceRegInfoFailureTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.updateDeviceRegInfoUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareDeviceRegInfoResponseBean('C'));
		boolean value = rnlicService.updateDeviceRegInfo("7547eeffde45748ed", "8317509142", "9041185", "fgfgyggvfh");
		assertNotNull(value);
		assertEquals(false, value);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void updateDeviceRegInfoUnknownTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.updateDeviceRegInfoUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareDeviceRegInfoResponseBean('D'));
		rnlicService.updateDeviceRegInfo("7547eeffde45748ed", "8317509142", "9041185", "fgfgyggvfh");
	}
	/*-----------------------------------------updateDeviceRegInfoTest test cases End----------------------------------------------------------*/
	
	/*-----------------------------------------getAttendanceDtlsTest test cases Start----------------------------------------------------------*/
	@Test
	public void getAttendanceDtlsTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getAttendanceDtlsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareMonthlyAttendanceDetailsRnlicResponseBean('A'));
		Mockito.when(rnlicDataTranslator.getAttendanceDtls(Mockito.any(MonthlyAttendanceDetailsRnlicResponseBean.class), Mockito.any(AttendanceReqBean.class), Mockito.any(UserDetailsBean.class))).thenReturn(HrappTestUtil.prepareAttendanceDtls());
		AttendanceReqBean attendanceReqBean = new AttendanceReqBean(); 
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getAttendanceDtls(attendanceReqBean, empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getAttendanceDtlsNullTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getAttendanceDtlsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(null);
		AttendanceReqBean attendanceReqBean = new AttendanceReqBean(); 
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getAttendanceDtls(attendanceReqBean, empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getAttendanceDtlsFailedTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getAttendanceDtlsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareMonthlyAttendanceDetailsRnlicResponseBean('B'));
		AttendanceReqBean attendanceReqBean = new AttendanceReqBean(); 
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getAttendanceDtls(attendanceReqBean, empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getAttendanceDtlsFailureTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getAttendanceDtlsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareMonthlyAttendanceDetailsRnlicResponseBean('C'));
		AttendanceReqBean attendanceReqBean = new AttendanceReqBean(); 
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getAttendanceDtls(attendanceReqBean, empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getAttendanceDtlsUnknownTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getAttendanceDtlsUrl(Mockito.any(String.class), Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareMonthlyAttendanceDetailsRnlicResponseBean('D'));
		AttendanceReqBean attendanceReqBean = new AttendanceReqBean(); 
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getAttendanceDtls(attendanceReqBean, empReqBean);
	}
	/*-----------------------------------------getAttendanceDtlsTest test cases End----------------------------------------------------------*/
	
	/*-----------------------------------------getMandatoryLearningTest test cases Start----------------------------------------------------------*/
	@Test
	public void getMandatoryLearningTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getMandatoryLearningUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareMandatoryLearningRnlicResponseBean('A'));
		Mockito.when(rnlicDataTranslator.getMandatoryLearning(Mockito.any(MandatoryLearningRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareMandatoryLearning());
		rnlicService.getMandatoryLearning();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getMandatoryLearningNullTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getMandatoryLearningUrl(Mockito.any(String.class))).thenReturn(null);
		rnlicService.getMandatoryLearning();
	}
	
	@Test (expected = StateDetailsNotFoundException.class)
	public void getMandatoryLearningFailedTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getMandatoryLearningUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareMandatoryLearningRnlicResponseBean('B'));
		rnlicService.getMandatoryLearning();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getMandatoryLearningFailureTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getMandatoryLearningUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareMandatoryLearningRnlicResponseBean('C'));
		rnlicService.getMandatoryLearning();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getMandatoryLearningUnknownTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getMandatoryLearningUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareMandatoryLearningRnlicResponseBean('D'));
		rnlicService.getMandatoryLearning();
	}
	/*-----------------------------------------getMandatoryLearningTest test cases End----------------------------------------------------------*/
	
	/*-----------------------------------------getMandatoryLearningStatusTest test cases Start----------------------------------------------------------*/
	@Test
	public void getMandatoryLearningStatusTest() throws JsonParseException, JsonMappingException, IOException {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getMandatoryLearningStatusUrl(Mockito.any(String.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareMandatoryLearningStatusString('A'));
		Mockito.when(rnlicDataTranslator.getMandatoryLearningStatus(Mockito.any(MandatoryLearningStatusRnlicResponseBean.class),Mockito.any(Map.class))).thenReturn(HrappTestUtil.prepareMandatoryLearningStatus());
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getMandatoryLearningStatus(empReqBean);
	}
	
	@Test (expected = StateDetailsNotFoundException.class)
	public void getMandatoryLearningStatusFailedTest() throws JsonParseException, JsonMappingException, IOException {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getMandatoryLearningStatusUrl(Mockito.any(String.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareMandatoryLearningStatusString('B'));
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getMandatoryLearningStatus(empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getMandatoryLearningStatusFailureTest() throws JsonParseException, JsonMappingException, IOException {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getMandatoryLearningStatusUrl(Mockito.any(String.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareMandatoryLearningStatusString('C'));
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getMandatoryLearningStatus(empReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getMandatoryLearningStatusUnknownTest() throws JsonParseException, JsonMappingException, IOException {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getMandatoryLearningStatusUrl(Mockito.any(String.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareMandatoryLearningStatusString('D'));
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getMandatoryLearningStatus(empReqBean);
	}
	/*-----------------------------------------getMandatoryLearningStatusTest test cases End----------------------------------------------------------*/
	
	/*-----------------------------------------getResponseForTroubleInLoginTest test cases Start----------------------------------------------------------*/
	@Test
	public void getResponseForTroubleInLoginTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getResponseForTroubleInLoginUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareTroubleWithLoginRnlicResponseBean('A'));
		Mockito.when(rnlicDataTranslator.getTroubleWithLoginDetails(Mockito.any(TroubleWithLoginRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareTroubleWithLoginDetails());
		rnlicService.getResponseForTroubleInLogin();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getResponseForTroubleInLoginNoListTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getResponseForTroubleInLoginUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareTroubleWithLoginRnlicResponseBean('B'));
		rnlicService.getResponseForTroubleInLogin();
	}
	
	@Test (expected = StateDetailsNotFoundException.class)
	public void getResponseForTroubleInFailedTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getResponseForTroubleInLoginUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareTroubleWithLoginRnlicResponseBean('C'));
		rnlicService.getResponseForTroubleInLogin();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getResponseForTroubleInLoginFailureTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getResponseForTroubleInLoginUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareTroubleWithLoginRnlicResponseBean('D'));
		rnlicService.getResponseForTroubleInLogin();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getResponseForTroubleInLoginUnknownTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getResponseForTroubleInLoginUrl(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareTroubleWithLoginRnlicResponseBean('E'));
		rnlicService.getResponseForTroubleInLogin();
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getResponseForTroubleInLoginNullTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getResponseForTroubleInLoginUrl(Mockito.any(String.class))).thenReturn(null);
		rnlicService.getResponseForTroubleInLogin();
	}
	/*-----------------------------------------getResponseForTroubleInLoginTest test cases End----------------------------------------------------------*/
	
	/*-----------------------------------------shareBrachDetailsTest test cases Start----------------------------------------------------------*/
	@Test
	public void shareBrachDetailsTest() throws RestClientException, IOException {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.sendMessagesViaSMSUrl(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareSendOtpRnlicResponseBean());
		Mockito.when(rnlicDataTranslator.generateSharedMessage(Mockito.any(LocateBranches.class))).thenReturn("Custom Message");
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = new ShareBranchDetailsReqBean();
		shareBranchDetailsReqBean.setMobileNo("XXXXXXXXXX");
		rnlicService.shareBrachDetails("data", shareBranchDetailsReqBean);
	}
	/*-----------------------------------------shareBrachDetailsTest test cases End----------------------------------------------------------*/
	
	/*--------------------------------------updateLearningCompletionTest test cases Start---------------------------------------------------------*/
	@Test (expected = RnlicServiceException.class)
	public void updateLearningCompletionExceptionTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "32565566");
		Mockito.when(rnlicApiExchange.updateLearningCompletionUrl(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.updateLearningCompletion(empReqBean, "89868586585685");
	}
	
	@Test
	public void updateLearningCompletionTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "32565566");
		Mockito.when(rnlicApiExchange.updateLearningCompletionUrl(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareLearningStatusUpdateResponseBean());
		boolean val = rnlicService.updateLearningCompletion(empReqBean, "89868586585685");
		assertEquals(true, val);
	}
	
	@Test
	public void updateLearningCompletionFailedTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "32565566");
		Mockito.when(rnlicApiExchange.updateLearningCompletionUrl(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareLearningStatusUpdateFailedResponseBean());
		boolean val = rnlicService.updateLearningCompletion(empReqBean, "89868586585685");
		assertEquals(false, val);
	}
	
	@Test
	public void updateLearningCompletionFailureTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "32565566");
		Mockito.when(rnlicApiExchange.updateLearningCompletionUrl(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareLearningStatusUpdateFailureResponseBean());
		boolean val = rnlicService.updateLearningCompletion(empReqBean, "89868586585685");
		assertEquals(false, val);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void updateLearningCompletionUnknownTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "32565566");
		Mockito.when(rnlicApiExchange.updateLearningCompletionUrl(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareLearningStatusUpdateUnknownResponseBean());
		rnlicService.updateLearningCompletion(empReqBean, "89868586585685");
	}
	/*--------------------------------------updateLearningCompletionTest test cases End---------------------------------------------------------*/
	
	/*--------------------------------------sendMailTest test cases Start---------------------------------------------------------*/
	@Test
	public void sendMailTest() throws MessagingException, UnsupportedEncodingException {
		MailingReqBean mailingReqBean = new MailingReqBean();
		mailingReqBean.setMailId("abc@gmail.com");
		mailingReqBean.setMessage(new StringBuilder("Test Mail"));
		mailingReqBean.setSubject("subject");
		Mockito.when(mailerConfig.getMimeMessage()).thenReturn(HrappTestUtil.prepareMimeMessage());
		Mockito.doNothing().when(rnlicApiExchange).sendMailToUser(Mockito.any(MimeMessage.class));
		rnlicService.sendMail(mailingReqBean);
	}
	
	@Test
	public void sendMailExceptionTest() throws MessagingException, UnsupportedEncodingException {
		MailingReqBean mailingReqBean = new MailingReqBean();
		mailingReqBean.setMailId("abc@gmail.com");
		mailingReqBean.setMessage(new StringBuilder("Test Mail"));
		mailingReqBean.setSubject("subject");
		Mockito.when(mailerConfig.getMimeMessage()).thenReturn(HrappTestUtil.prepareMimeMessage());
		Mockito.doThrow(new MessagingException()).when(rnlicApiExchange).sendMailToUser(Mockito.any(MimeMessage.class));
		rnlicService.sendMail(mailingReqBean);
	}
	/*--------------------------------------sendMailTest test cases End---------------------------------------------------------*/
	
	/*--------------------------------------changePasswordRequestTest test cases Start---------------------------------------------------------*/
	@Test
	public void changePasswordRequestTest() {
		ChangePasswordReqBean changePasswordReqBean = new ChangePasswordReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.changePasswordRequest(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareChangePasswordRnlicResponseBean());
		Mockito.when(rnlicDataTranslator.getChangePasswordResponse(Mockito.any(ChangePasswordRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareChangePasswordResBean());
		rnlicService.changePasswordRequest(changePasswordReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void changePasswordRequestNullTest() {
		ChangePasswordReqBean changePasswordReqBean = new ChangePasswordReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.changePasswordRequest(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(null);
		rnlicService.changePasswordRequest(changePasswordReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void changePasswordRequestFailureTest() {
		ChangePasswordReqBean changePasswordReqBean = new ChangePasswordReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.changePasswordRequest(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareChangePasswordRnlicFailureResponseBean());
		rnlicService.changePasswordRequest(changePasswordReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void changePasswordRequestFailedTest() {
		ChangePasswordReqBean changePasswordReqBean = new ChangePasswordReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.changePasswordRequest(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareChangePasswordRnlicFailedResponseBean());
		rnlicService.changePasswordRequest(changePasswordReqBean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void changePasswordRequestUnknownTest() {
		ChangePasswordReqBean changePasswordReqBean = new ChangePasswordReqBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.changePasswordRequest(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareChangePasswordRnlicUnknownResponseBean());
		rnlicService.changePasswordRequest(changePasswordReqBean);
	}
	/*--------------------------------------changePasswordRequestTest test cases End---------------------------------------------------------*/
	
	/*--------------------------------------updatePasswordTest test cases Start---------------------------------------------------------*/
//	@Test
//	public void updatePasswordTest() {
//		ChangePasswordReqBean changePasswordReqBean = new ChangePasswordReqBean();
//		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
//		Mockito.when(rnlicApiExchange.changePasswordRequest(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareChangePasswordRnlicResponseBean());
//		Mockito.when(rnlicDataTranslator.getChangePasswordResponse(Mockito.any(ChangePasswordRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareChangePasswordResBean());
//		rnlicService.updatePassword(changePasswordReqBean);
//	}
//	
//	@Test (expected = RnlicServiceException.class)
//	public void updatePasswordNullTest() {
//		ChangePasswordReqBean changePasswordReqBean = new ChangePasswordReqBean();
//		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
//		Mockito.when(rnlicApiExchange.changePasswordRequest(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(null);
//		rnlicService.updatePassword(changePasswordReqBean);
//	}
//	
//	@Test (expected = RnlicServiceException.class)
//	public void updatePasswordFailureTest() {
//		ChangePasswordReqBean changePasswordReqBean = new ChangePasswordReqBean();
//		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
//		Mockito.when(rnlicApiExchange.changePasswordRequest(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareChangePasswordRnlicFailureResponseBean());
//		rnlicService.updatePassword(changePasswordReqBean);
//	}
//	
//	@Test (expected = RnlicServiceException.class)
//	public void updatePasswordFailedTest() {
//		ChangePasswordReqBean changePasswordReqBean = new ChangePasswordReqBean();
//		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
//		Mockito.when(rnlicApiExchange.changePasswordRequest(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareChangePasswordRnlicFailedResponseBean());
//		rnlicService.updatePassword(changePasswordReqBean);
//	}
//	
//	@Test (expected = RnlicServiceException.class)
//	public void updatePasswordUnknownTest() {
//		ChangePasswordReqBean changePasswordReqBean = new ChangePasswordReqBean();
//		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
//		Mockito.when(rnlicApiExchange.changePasswordRequest(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.prepareChangePasswordRnlicUnknownResponseBean());
//		rnlicService.updatePassword(changePasswordReqBean);
//	}
	/*--------------------------------------updatePasswordTest test cases End---------------------------------------------------------*/
	
	/*--------------------------------------getNoticesTest test cases Start---------------------------------------------------------*/
	@Test
	public void getNoticesTest() {
		NoticesRnlicResponseBean response = HrappTestUtil.prepareNoticesRnlicResponseBean();
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getNotices(Mockito.any(String.class),Mockito.any(String.class))).thenReturn(response);
		Mockito.when(rnlicDataTranslator.getNotices(Mockito.any(NoticesRnlicResponseBean.class))).thenReturn(HrappTestUtil.prepareGetNotices(response));
		UserDetailsBean userbean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getNotices(userbean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getNoticesNullTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getNotices(Mockito.any(String.class),Mockito.any(String.class))).thenReturn(null);
		UserDetailsBean userbean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getNotices(userbean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getNoticesFailureTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getNotices(Mockito.any(String.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareNoticesRnlicResponseFailureBean());
		UserDetailsBean userbean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getNotices(userbean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getNoticesFailedTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getNotices(Mockito.any(String.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareNoticesRnlicResponseFailedBean());
		UserDetailsBean userbean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getNotices(userbean);
	}
	
	@Test (expected = RnlicServiceException.class)
	public void getNoticesUnknownTest() {
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.getNotices(Mockito.any(String.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareNoticesRnlicResponseUnknownBean());
		UserDetailsBean userbean = HrappTestUtil.prepareUserDtlsBean("152455654523", "8670899251", "CBHPD2334X", "70109281");
		rnlicService.getNotices(userbean);
	}
	/*--------------------------------------getNoticesTest test cases End---------------------------------------------------------*/
	
	/*--------------------------------------sendPushNotificationTest test cases Start---------------------------------------------------------*/
	@Test
	public void sendPushNotificationBirthdayTest() {
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("54446568", "8375939142", "CBHPD14254", "5552875");
		WishesReq wishTo=new WishesReq();
		wishTo.setType("birthday");
		
		PushDataModal pushData = new PushDataModal();
		pushData.setNotifiedBySapCode("45548");
		pushData.setNotifiedByName("Sap");
		pushData.setNotificationType("birthday");
		pushData.setTimeStamp(LocalDateTime.now());
		pushData.setNotificationRead('N');
		
		DeviceRegistrationModel data = new DeviceRegistrationModel();
		Mockito.when(messagesConstants.getPushHappyBirthdayMsg()).thenReturn("xyz");
		Mockito.when(genericConstants.getPushNotificationServerKey()).thenReturn("xyz");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.sendPushNotificationUrl(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.preparePushNotificationResponse());
		Mockito.when(pushDataRepository.save(Mockito.any(PushDataModal.class))).thenReturn(pushData);
		rnlicService.sendPushNotification(wishTo, data,userDetailsBean);
	}
	
	@Test
	public void sendPushNotificationAnniversaryTest() {
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("54446568", "8375939142", "CBHPD14254", "5552875");
		WishesReq wishTo=new WishesReq();
		wishTo.setType("anniversary");
		DeviceRegistrationModel data = new DeviceRegistrationModel();
		Mockito.when(messagesConstants.getPushHappyAnniversaryMsg()).thenReturn("xyz");
		Mockito.when(genericConstants.getPushNotificationServerKey()).thenReturn("xyz");
		Mockito.when(rnlicUrlConstants.getUrls()).thenReturn(HrappTestUtil.getListOfUrls());
		Mockito.when(rnlicApiExchange.sendPushNotificationUrl(Mockito.any(String.class),Mockito.any(HttpEntity.class))).thenReturn(HrappTestUtil.preparePushNotificationResponse());
		rnlicService.sendPushNotification(wishTo, data, userDetailsBean);
	}
	/*--------------------------------------sendPushNotificationTest test cases End---------------------------------------------------------*/
}
