package com.rnlic.hraapp.test.api.response;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rnlic.hraapp.test.constants.TestConstant;
import com.rnlic.hrapp.bean.api.response.AnniversaryListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.BirthdayListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.CandidateRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.CheckInCheckOutRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.EmployeeRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.MandatoryLearningRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.MandatoryLearningStatusRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.MonthlyAttendanceDetailsRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.ReporteeListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.RnlicBranchDetailsListResponseBean;
import com.rnlic.hrapp.bean.api.response.RnlicServicesDataTranslator;
import com.rnlic.hrapp.bean.api.response.StateCityMasterRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.TroubleWithLoginRnlicResponseBean;
import com.rnlic.hrapp.bean.request.AttendanceReqBean;
import com.rnlic.hrapp.bean.request.EmployeeCheckInCheckOutReqBean;
import com.rnlic.hrapp.bean.request.ShareBranchDetailsReqBean;
import com.rnlic.hrapp.bean.request.UserLocation;
import com.rnlic.hrapp.bean.response.LocateBranchResBean;
import com.rnlic.hrapp.bean.response.LocateBranches;
import com.rnlic.hrapp.bean.response.ReporteeDetails;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.RnlicService;

@RunWith(SpringJUnit4ClassRunner.class)
public class RnlicResponseTranslatorTest {
	
	@Mock
	private RnlicService rnlicService;
	
	@Mock
	private MessagesConstants messageConstants;
	
	@InjectMocks
	private RnlicServicesDataTranslator rnlicServicesDataTranslator;
	
	@Test
	public void testGetEmpDetails() throws Exception{
		String empJson = TestConstant.EMP_DETAILS_JSON;
		ObjectMapper mapper = new ObjectMapper();
		EmployeeRnlicResponseBean response = mapper.readValue(empJson , EmployeeRnlicResponseBean.class);
		List<ReporteeDetails> value = new  ArrayList<>();
		ReporteeDetails reportee = new ReporteeDetails();
		value.add(reportee);
		Mockito.when(rnlicService.getListOfReportees("70009002")).thenReturn(value);
		rnlicServicesDataTranslator.getEmpDetails(response);
	}
	@Test
	public void testGetCandidateDetails() throws Exception{
		String empJson = TestConstant.CANDIDATE_DETAILS_JSON;
		ObjectMapper mapper = new ObjectMapper();
		CandidateRnlicResponseBean response = mapper.readValue(empJson , CandidateRnlicResponseBean.class);
		rnlicServicesDataTranslator.getCandidateDetails(response);
		
	}
	@Test
	public void testGetBirthdayList() throws Exception{
		String birthDayJson = TestConstant.BIRTHDAY_JSON;
		ObjectMapper mapper = new ObjectMapper();
		BirthdayListRnlicResponseBean response = mapper.readValue(birthDayJson , BirthdayListRnlicResponseBean.class);
		rnlicServicesDataTranslator.getBirthdayList(response);
	}
	@Test
	public void testGetAnniversaryList() throws Exception{
		String anniversaryJson = TestConstant.ANNIVERSARY_JSON;
		ObjectMapper mapper = new ObjectMapper();
		AnniversaryListRnlicResponseBean response = mapper.readValue(anniversaryJson , AnniversaryListRnlicResponseBean.class);
		rnlicServicesDataTranslator.getAnniversaryList(response);
	}
	@Test
	public void testGetReporteeList() throws Exception{
		String reporteeJson = TestConstant.REPORTEE_JSON;
		ObjectMapper mapper = new ObjectMapper();
		ReporteeListRnlicResponseBean response = mapper.readValue(reporteeJson , ReporteeListRnlicResponseBean.class);
		rnlicServicesDataTranslator.getReporteeList(response);
	}
	@Test
	public void testGetStateCityMasteList() throws Exception{
		String satateCityJson = TestConstant.STATE_CITY_JSON;
		ObjectMapper mapper = new ObjectMapper();
		StateCityMasterRnlicResponseBean response = mapper.readValue(satateCityJson , StateCityMasterRnlicResponseBean.class);
		rnlicServicesDataTranslator.getStateCityMasteList(response);
	}
	@Test
	public void testGetEmployeeCheckInCheckOutRes() throws Exception{
		String checkinJson = TestConstant.CHECKIN_CHECKOUT_JSON;
		EmployeeCheckInCheckOutReqBean req = new EmployeeCheckInCheckOutReqBean();
		req.setType("check-in");
		ObjectMapper mapper = new ObjectMapper();
		CheckInCheckOutRnlicResponseBean response = mapper.readValue(checkinJson , CheckInCheckOutRnlicResponseBean.class);
		rnlicServicesDataTranslator.getEmployeeCheckInCheckOutRes(req,response);
	}
	@Test
	public void testGetEmployeeCheckInCheckOutRes1() throws Exception{
		String checkinJson = TestConstant.CHECKIN_CHECKOUT_JSON1;
		EmployeeCheckInCheckOutReqBean req = new EmployeeCheckInCheckOutReqBean();
		req.setType("check-in");
		ObjectMapper mapper = new ObjectMapper();
		CheckInCheckOutRnlicResponseBean response = mapper.readValue(checkinJson , CheckInCheckOutRnlicResponseBean.class);
		rnlicServicesDataTranslator.getEmployeeCheckInCheckOutRes(req,response);
	}
	@Test
	public void testGetEmployeeCheckInCheckOutRes2() throws Exception{
		String checkinJson = TestConstant.CHECKIN_CHECKOUT_JSON2;
		EmployeeCheckInCheckOutReqBean req = new EmployeeCheckInCheckOutReqBean();
		req.setType("check-out");
		ObjectMapper mapper = new ObjectMapper();
		CheckInCheckOutRnlicResponseBean response = mapper.readValue(checkinJson , CheckInCheckOutRnlicResponseBean.class);
		rnlicServicesDataTranslator.getEmployeeCheckInCheckOutRes(req,response);
	}
	
	@Test
	public void testGetEmployeeCheckInCheckOutRes3() throws Exception{
		String checkinJson = TestConstant.CHECKIN_CHECKOUT_JSON3;
		EmployeeCheckInCheckOutReqBean req = new EmployeeCheckInCheckOutReqBean();
		req.setType("check-out");
		ObjectMapper mapper = new ObjectMapper();
		CheckInCheckOutRnlicResponseBean response = mapper.readValue(checkinJson , CheckInCheckOutRnlicResponseBean.class);
		rnlicServicesDataTranslator.getEmployeeCheckInCheckOutRes(req,response);
	}
	@Test
	public void testGetEmployeeCheckInCheckOutRes4() throws Exception{
		String checkinJson = TestConstant.CHECKIN_CHECKOUT_JSON3;
		EmployeeCheckInCheckOutReqBean req = new EmployeeCheckInCheckOutReqBean();
		req.setType("check");
		ObjectMapper mapper = new ObjectMapper();
		CheckInCheckOutRnlicResponseBean response = mapper.readValue(checkinJson , CheckInCheckOutRnlicResponseBean.class);
		rnlicServicesDataTranslator.getEmployeeCheckInCheckOutRes(req,response);
	}
	
	
	@Test
	public void testGetBranchDetails() throws Exception{
		String locateJson = TestConstant.LOCATE_BRANCH_JSON;
		LocateBranchResBean res = new LocateBranchResBean();
		ObjectMapper mapper = new ObjectMapper();
		RnlicBranchDetailsListResponseBean response = mapper.readValue(locateJson , RnlicBranchDetailsListResponseBean.class);
		rnlicServicesDataTranslator.getBranchDetails(response,res);
	}
	@Test
	public void testGetAttendanceDtls() throws Exception{
		String attendanceJson = TestConstant.ATTENDANCE_JSON;
		AttendanceReqBean req = new AttendanceReqBean();
		UserDetailsBean user = new UserDetailsBean();
		ObjectMapper mapper = new ObjectMapper();
		MonthlyAttendanceDetailsRnlicResponseBean response = mapper.readValue(attendanceJson , MonthlyAttendanceDetailsRnlicResponseBean.class);
		rnlicServicesDataTranslator.getAttendanceDtls(response,req,user);
	}
	@Test
	public void testGetMandatoryLearning() throws Exception{
		String mandatoryJson = TestConstant.MANDATORY_JSON;
		ObjectMapper mapper = new ObjectMapper();
		MandatoryLearningRnlicResponseBean response = mapper.readValue(mandatoryJson , MandatoryLearningRnlicResponseBean.class);
		rnlicServicesDataTranslator.getMandatoryLearning(response);
	}
	@SuppressWarnings("unchecked")
	@Test
	public void testGetMandatoryLearningStatus() throws Exception{
		String mandatoryStatusJson = TestConstant.MANDATORY_STATUS_JSON;
		ObjectMapper mapper = new ObjectMapper();
		String autoritiesRole="\"[{\"AML_KYC\":\"COMPLETED\",\"ULIP\":\"COMPLETED\",\"Infosec\":\"COMPLETED\"}]";
		String data =new String(autoritiesRole.substring(autoritiesRole.indexOf("[", 0)+1, autoritiesRole.indexOf("]", 0)));
		Map<String,String> result =	mapper.readValue(data, LinkedHashMap.class);
		MandatoryLearningStatusRnlicResponseBean response = mapper.readValue(mandatoryStatusJson , MandatoryLearningStatusRnlicResponseBean.class);
		rnlicServicesDataTranslator.getMandatoryLearningStatus(response, result);
	}
	@Test
	public void testGetTroubleWithLoginDetails() throws Exception{
		String mandatoryJson = TestConstant.TROUBLE_LOGIN_JSON;
		ObjectMapper mapper = new ObjectMapper();
		TroubleWithLoginRnlicResponseBean response = mapper.readValue(mandatoryJson , TroubleWithLoginRnlicResponseBean.class);
		rnlicServicesDataTranslator.getTroubleWithLoginDetails(response);
	}
	@Test
	public void testGenerateSharedMessage() throws Exception{
		UserLocation userLocation = new UserLocation();
		userLocation.setLatitude("10.2315");
		userLocation.setLongitude("12.0123");
		LocateBranches locate = new LocateBranches();
		locate.setAddress("BIPL");
		locate.setCode("01");
		locate.setContactNumber("898");
		locate.setContactPerson("Person");
		locate.setEmail("zbc@xyz.com");
		locate.setLocation(userLocation);
		locate.setName("Name");
		rnlicServicesDataTranslator.generateSharedMessage(locate);
	}
	@Test
	public void testGenerateShareBrachDetailsResponse() throws Exception{
		UserLocation userLocation = new UserLocation();
		ShareBranchDetailsReqBean bean = new ShareBranchDetailsReqBean();
		LocateBranches locate = new LocateBranches();
		userLocation.setLatitude("10.2315");
		userLocation.setLongitude("12.0123");
		locate.setAddress("BIPL");
		locate.setCode("01");
		locate.setContactNumber("898");
		locate.setContactPerson("Person");
		locate.setEmail("zbc@xyz.com");
		locate.setLocation(userLocation);
		locate.setName("Name");
		bean.setEmailAddress("zbc@xyz.com");
		bean.setMobileNo("8981414565");
		bean.setLocateBranches(locate);
		rnlicServicesDataTranslator.generateShareBrachDetailsResponse(1, bean, true, true,new LinkedHashMap<>());
		rnlicServicesDataTranslator.generateShareBrachDetailsResponse(1, bean, false, true,new LinkedHashMap<>());
		bean.setMobileNo("");
		rnlicServicesDataTranslator.generateShareBrachDetailsResponse(1, bean, true, false,new LinkedHashMap<>());
		
	}
	@Test
	public void testGenerateShareBrachDetailsResponse1() throws Exception{
		UserLocation userLocation = new UserLocation();
		ShareBranchDetailsReqBean bean = new ShareBranchDetailsReqBean();
		LocateBranches locate = new LocateBranches();
		userLocation.setLatitude("10.2315");
		userLocation.setLongitude("12.0123");
		locate.setAddress("BIPL");
		locate.setCode("01");
		locate.setContactNumber("898");
		locate.setContactPerson("Person");
		locate.setEmail("zbc@xyz.com");
		locate.setLocation(userLocation);
		locate.setName("Name");
		bean.setEmailAddress("zbc@xyz.com");
		bean.setMobileNo("8981414565");
		bean.setLocateBranches(locate);
		rnlicServicesDataTranslator.generateShareBrachDetailsResponse(2, bean, true, true,new LinkedHashMap<>());
		rnlicServicesDataTranslator.generateShareBrachDetailsResponse(2, bean, true, false,new LinkedHashMap<>());
		rnlicServicesDataTranslator.generateShareBrachDetailsResponse(2, bean, false, false,new LinkedHashMap<>());
		rnlicServicesDataTranslator.generateShareBrachDetailsResponse(2, bean, false, true,new LinkedHashMap<>());
		
	}
}
