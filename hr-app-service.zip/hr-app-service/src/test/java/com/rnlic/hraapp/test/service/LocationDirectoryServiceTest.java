package com.rnlic.hraapp.test.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.LocalBranchReqBean;
import com.rnlic.hrapp.bean.response.LocateBranchResBean;
import com.rnlic.hrapp.bean.response.StateCityMasterResBean;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.LocationDirectoryService;
import com.rnlic.hrapp.service.RnlicService;

public class LocationDirectoryServiceTest extends HraServiceTests {

	@Mock
	private RnlicService rnlicService;
	
	@InjectMocks
	private LocationDirectoryService locationDirectoryService;
	
	//@Ignore
	@Test
	public void getBrachDetailsTest() {
		LocalBranchReqBean localBranchReqBean =new LocalBranchReqBean();
		UserDetailsBean empReqBean =new UserDetailsBean();
		Mockito.when(rnlicService.getBranchDetails(localBranchReqBean)).thenReturn(HrappTestUtil.prepareLocateBranchResBean());
		LocateBranchResBean locateBranchResBean = (LocateBranchResBean) locationDirectoryService.getBrachDetails(empReqBean, localBranchReqBean);
		assertNotNull(locateBranchResBean);
	}
	
	//@Ignore
	@Test
	public void getStateCityMasterTest(){
		UserDetailsBean empReqBean =new UserDetailsBean();
		Mockito.when(rnlicService.getStateCityMaster()).thenReturn(HrappTestUtil.prepareStateCityMasterDetails());
		StateCityMasterResBean stateCityMasterResBean = (StateCityMasterResBean) locationDirectoryService.getStateCityMaster(empReqBean);
		assertNotNull(stateCityMasterResBean);
	}
}
