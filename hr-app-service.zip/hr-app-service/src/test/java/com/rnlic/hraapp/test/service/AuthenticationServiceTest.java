package com.rnlic.hraapp.test.service;

import java.io.IOException;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.web.client.RestClientException;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.AuthReqBean;
import com.rnlic.hrapp.bean.response.RestResponse;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.exception.DeviceRegistrationException;
import com.rnlic.hrapp.exception.RnlicResponseException;
import com.rnlic.hrapp.security.JwtGenerator;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.AuthenticationAuthorizationService;
import com.rnlic.hrapp.service.DeviceRegistrationService;
import com.rnlic.hrapp.service.RnlicService;
import com.rnlic.hrapp.util.HrAppUtil;

public class AuthenticationServiceTest extends HraServiceTests {

	@Mock
	private DeviceRegistrationService deviceService;
	
	@Mock
	private RnlicService rnlicService;
	
	@Mock
	private MessagesConstants messagesConstants;
	
	@Mock
	private JwtGenerator jwtGenerator;
	
	@Mock
	private RestResponse restResponse;
	
	@InjectMocks
	private AuthenticationAuthorizationService authService;
	
	@Test (expected = RnlicResponseException.class)
	public void authenticateAndGenerateTokenCandidateTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		authReqBean.setDeviceIdentifier("55552856dd74f85");
		authReqBean.setDomainPassword("abc123");
		authReqBean.setFcmToken("gdsgh554638565");
		authReqBean.setIsCandidate(true);
		authReqBean.setMobileNumber("524566245696");
		authReqBean.setPanNumber("CFDGGH552748");
		Mockito.when(restResponse.getRequestId()).thenReturn("test request");
		
		Mockito.when(deviceService.checkRegistrationInfomation(
				HrAppUtil.returnBlankWhenNull(Mockito.any(String.class)), 
				HrAppUtil.returnBlankWhenNull(Mockito.any(String.class)), 
				HrAppUtil.returnBlankWhenNull(Mockito.any(String.class)))).thenReturn(HrappTestUtil.prepareCheckForDeviceRegistrationResBean());
		Mockito.when(rnlicService.getCandidateAuthentication(Mockito.any(AuthReqBean.class))).thenReturn(true);
		Mockito.when(messagesConstants.getServiceForCandidateDetailsMsg()).thenReturn("Test");
		Mockito.when(rnlicService.getCandidateDtlsFromRnlic(Mockito.any(UserDetailsBean.class))).thenReturn(HrappTestUtil.prepareUserdetails());
		Mockito.when(jwtGenerator.generate(Mockito.any(UserDetailsBean.class))).thenReturn("bghbdsghsjhgvbjkh-25615645436jdfdfgf-6556dgdgfdDgnbedff");
		authService.authenticateAndGenerateToken(authReqBean);
	}
	
	@Test
	public void authenticateAndGenerateTokenEmployeeTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		authReqBean.setDeviceIdentifier("55552856dd74f85");
		authReqBean.setDomainPassword("abc123");
		authReqBean.setFcmToken("gdsgh554638565");
		authReqBean.setIsCandidate(false);
		authReqBean.setMobileNumber("524566245696");
		authReqBean.setPanNumber("CFDGGH552748");
		
		Mockito.when(deviceService.checkRegistrationInfomation(
				HrAppUtil.returnBlankWhenNull(Mockito.any(String.class)), 
				HrAppUtil.returnBlankWhenNull(Mockito.any(String.class)), 
				HrAppUtil.returnBlankWhenNull(Mockito.any(String.class)))).thenReturn(HrappTestUtil.prepareCheckForDeviceRegistrationResBean());
		Mockito.when(rnlicService.getEmployeeAuthentication(Mockito.any(AuthReqBean.class))).thenReturn(true);
		Mockito.when(messagesConstants.getServiceForEmployeeDetailsMsg()).thenReturn("Test");
		Mockito.when(rnlicService.getEmpDetailsFromRnlic(Mockito.any(UserDetailsBean.class))).thenReturn(HrappTestUtil.prepareUserdetails());
		Mockito.when(jwtGenerator.generate(Mockito.any(UserDetailsBean.class))).thenReturn("bghbdsghsjhgvbjkh-25615645436jdfdfgf-6556dgdgfdDgnbedff");
		authService.authenticateAndGenerateToken(authReqBean);
	}
	
	@Test (expected = DeviceRegistrationException.class)
	public void authenticateAndGenerateTokenDeviceRegistrationTest() throws RestClientException, IOException {
		AuthReqBean authReqBean = new AuthReqBean();
		authReqBean.setDeviceIdentifier("55552856dd74f85");
		authReqBean.setDomainPassword("abc123");
		authReqBean.setFcmToken("gdsgh554638565");
		authReqBean.setIsCandidate(false);
		authReqBean.setMobileNumber("524566245696");
		authReqBean.setPanNumber("CFDGGH552748");
		
		Mockito.when(deviceService.checkRegistrationInfomation(
				HrAppUtil.returnBlankWhenNull(Mockito.any(String.class)), 
				HrAppUtil.returnBlankWhenNull(Mockito.any(String.class)), 
				HrAppUtil.returnBlankWhenNull(Mockito.any(String.class)))).thenReturn(HrappTestUtil.prepareCheckForDeviceRegistrationDoneResBean());
		Mockito.when(rnlicService.getEmployeeAuthentication(Mockito.any(AuthReqBean.class))).thenReturn(true);
		Mockito.when(messagesConstants.getServiceForEmployeeDetailsMsg()).thenReturn("Test");
		Mockito.when(rnlicService.getEmpDetailsFromRnlic(Mockito.any(UserDetailsBean.class))).thenReturn(HrappTestUtil.prepareUserdetails());
		Mockito.when(jwtGenerator.generate(Mockito.any(UserDetailsBean.class))).thenReturn("bghbdsghsjhgvbjkh-25615645436jdfdfgf-6556dgdgfdDgnbedff");
		authService.authenticateAndGenerateToken(authReqBean);
	}
}