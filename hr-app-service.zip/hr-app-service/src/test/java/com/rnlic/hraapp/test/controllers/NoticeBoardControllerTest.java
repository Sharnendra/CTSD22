package com.rnlic.hraapp.test.controllers;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.constants.TestConstant;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.response.AttendanceDetailsResBean;
import com.rnlic.hrapp.controller.NoticeBoardController;
import com.rnlic.hrapp.exception.UnhandledException;
import com.rnlic.hrapp.security.JwtDecriptor;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.NoticeBoardService;
import com.rnlic.hrapp.util.RequestLogDeatils;

public class NoticeBoardControllerTest extends HraServiceTests{

	private MockMvc mockMvc;

	@Mock
	private JwtDecriptor jwtDecriptor;
	
	@Mock 
	private NoticeBoardService noticeBoardService;
	
	@Mock
	private RequestLogDeatils requestLog;
	
	@InjectMocks
	private NoticeBoardController noticeBoardController;
	
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(noticeBoardController).build();
	}
	
	@Test
	public void testGetNotices() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(noticeBoardService.getNotices(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_NOTICES_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
	@Test
	public void testGetNoticesException() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		//AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(noticeBoardService.getNotices(user)).thenThrow(new UnhandledException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_NOTICES_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetNoticesException1() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		//AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(noticeBoardService.getNotices(user)).thenThrow(new RuntimeException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_NOTICES_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
}
