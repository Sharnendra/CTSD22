package com.rnlic.hraapp.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.List;

import org.joda.time.LocalTime;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.exceptions.misusing.WrongTypeOfReturnValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestClientException;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.AuthReqBean;
import com.rnlic.hrapp.bean.response.CheckForDeviceRegistrationResBean;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.bean.response.TroubleWithLoginResBean;
import com.rnlic.hrapp.bean.response.User;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;
import com.rnlic.hrapp.exception.NoSuchUserExists;
import com.rnlic.hrapp.repository.DeviceRegistrationRepository;
import com.rnlic.hrapp.repository.OtpRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.AuthenticationAuthorizationService;
import com.rnlic.hrapp.service.DeviceRegistrationService;
import com.rnlic.hrapp.service.RnlicService;
import com.rnlic.hrapp.util.ScheduledTasks;
@SuppressWarnings("unused")
public class AuthenticationRegistrationServiceTest extends HraServiceTests{

	@Mock
	private DeviceRegistrationRepository deviceRepo;
	
	@Mock
	private GenericConstants genericConstants;
	
	@Mock
	private OtpRepository otpRepository;
	
	@InjectMocks
	private ScheduledTasks scheduledTasks;
	
	@Mock
	private RnlicService rnlicService;

	@InjectMocks
	private DeviceRegistrationService deviceService;
	
	@InjectMocks
	private AuthenticationAuthorizationService authenticationService;
	
	@Mock
	private MessagesConstants messagesConstants;

	//Employee not Registered 
	@Test
	public void testGetDeviceRegInfoForEmployeeNotRegistered() {
		List<DeviceRegistrationModel> deviceEntityList = null;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","8981414565","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(true, deviceRegisBean.isAllowed());
		assertEquals(false, deviceRegisBean.isAlreadyRegistered());
	}
	//Employee Already Registered with same Details
	@Test
	public void testGetDeviceRegInfoForEmployeeRegisteredSameDtls() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(true, deviceRegisBean.isAllowed());
		assertEquals(true, deviceRegisBean.isAlreadyRegistered());
	}
	//Employee Already Registered but update in Mobile Number
	@Test
	public void testGetDeviceRegInfoForEmployeeRegisteredMoblieNoUpdate() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO2","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(true, deviceRegisBean.isAllowed());
		assertEquals(true, deviceRegisBean.isMobileNumberUpdated());
		assertEquals(true, deviceRegisBean.isAlreadyRegistered());
	}
	//Employee Already Registered but trying with other device
	@Test
	public void testGetDeviceRegInfoForEmployeeRegisteredWithOtherDevice() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO1","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(true, deviceRegisBean.isAllowed());
		assertEquals(true, deviceRegisBean.isAlreadyRegistered());
		assertEquals(true, deviceRegisBean.isRegisterdWithOtherDevice());
	}

	//Employee Already Registered but trying with other device but mobile no update
	@Test
	public void testGetDeviceRegInfoForEmployeeRegisteredWithOtherDeviceMoblieNoUpdate() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO2","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(true, deviceRegisBean.isAllowed());
		assertEquals(true, deviceRegisBean.isAlreadyRegistered());
		assertEquals(true, deviceRegisBean.isRegisterdWithOtherDevice());
		assertEquals(true, deviceRegisBean.isMobileNumberUpdated());
	}
	//Employee Already Registered but trying with other device but mobile no update
	@Test
	public void testGetDeviceRegInfoForEmployeeRegisteredTryingWithDifferntInfo() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO2","PANNO2","SAPCODE2");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		@SuppressWarnings("unused")
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
	}
	//Employee Already Registered but trying with other registered device 
	@Test
	public void testGetDeviceRegInfoForEmployeeRegisteredWithOtherRegDevice() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityListTwoData("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1","DEVICE2","MOBLIENO2","PANNO2","SAPCODE2");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO1","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(false, deviceRegisBean.isAllowed());
		assertEquals(true, deviceRegisBean.isDeviceRegisterWithOthers());
	}
	//Candidate not Registered
	@Test
	public void testGetDeviceRegInfoForCandidateNotRegistered() {
		List<DeviceRegistrationModel> deviceEntityList = null;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIE1","PANNO1","");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(true, deviceRegisBean.isAllowed());
		assertEquals(false, deviceRegisBean.isAlreadyRegistered());
	}
	//Candidate Already Registered with same Details
	@Test
	public void testGetDeviceRegInfoForCandidateRegisteredSameDtls() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO1","PANNO1","");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(true, deviceRegisBean.isAllowed());
		assertEquals(true, deviceRegisBean.isAlreadyRegistered());
	}
	//Candidate Already Registered but update in Mobile Number
	@Test
	public void testGetDeviceRegInfoForCandidateRegisteredMoblieNoUpdate() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO2","PANNO1","");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(false, deviceRegisBean.isAllowed());
	}
	//Candidate Already Registered but trying with other device 
	@Test
	public void testGetDeviceRegInfoForCandidateRegisteredWithOtherDevice() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO1","PANNO1","");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(true, deviceRegisBean.isAllowed());
		assertEquals(true, deviceRegisBean.isAlreadyRegistered());
		assertEquals(true, deviceRegisBean.isRegisterdWithOtherDevice());
	}

	//Candidate Already Registered but trying with other device but mobile no update
	@Test
	public void testGetDeviceRegInfoForCandidateRegisteredWithOtherDeviceMoblieNoUpdate() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO2","PANNO1","");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(true, deviceRegisBean.isAllowed());
		assertEquals(true, deviceRegisBean.isAlreadyRegistered());
	}
	//Candidate Already Registered but trying with other registered device 
	@Test
	public void testGetDeviceRegInfoForCandidateRegisteredWithOtherRegDevice() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityListTwoData("DEVICE1","MOBLIENO1","PANNO1","","DEVICE2","MOBLIENO2","PANNO2","");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO1","PANNO1","");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(false, deviceRegisBean.isAllowed());
		assertEquals(true, deviceRegisBean.isDeviceRegisterWithOthers());
	}
	//Candidate Converted to employee

	@Test
	public void testGetDeviceRegInfoForCandidateRegisteredConvertedToEmp() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(true, deviceRegisBean.isAllowed());
		assertEquals(true, deviceRegisBean.isAlreadyRegistered());
		assertEquals(true, deviceRegisBean.isSapCodeUpdated());
	}

	//Candidate Converted to employee with mobile update
	@Test
	public void testGetDeviceRegInfoForCandidateRegisteredConvertedToEmpWithMoblieUpdate() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO2","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(false, deviceRegisBean.isAllowed());
	}

	//Candidate Converted to employee with mobile update with others device
	@Test
	public void testGetDeviceRegInfoForCandidateRegisteredConvertedToEmpButTryingWithOtherDevice() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO2","PANNO2","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
		assertEquals(false, deviceRegisBean.isAllowed());
	}

	//Candidate Converted to employee with mobile update with others device
	@Test
	public void testGetDeviceRegInfoForCandidateRegisteredTringwithDifferentDevice() {
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO2","PANNO2","");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		CheckForDeviceRegistrationResBean deviceRegisBean =(CheckForDeviceRegistrationResBean) deviceService.checkRegistrationInfomation(user.getDeviceIdentifier(), user.getSapCode(), user.getMobileNumber());
	}
	
	@Test
	public void reportCurrentTimeTest(){
		Mockito.doNothing().when(otpRepository).deleteExpiredOTPRecord();
		Mockito.doReturn(LocalTime.now().getHourOfDay()).when(genericConstants).getSchedulerHours();
		Mockito.doReturn(LocalTime.now().getMinuteOfHour()).when(genericConstants).getSchedulerMinutes();
		Mockito.doReturn(LocalTime.now().getSecondOfMinute()).when(genericConstants).getSchedulerSecond();
		Mockito.doReturn(LocalTime.now().getMillisOfSecond()).when(genericConstants).getSchedulerMiliSeconds();
		scheduledTasks.reportCurrentTime();
	}
	
	//When there is trouble in login
	@Test
	public void getResponseForTroubleInLoginTest() {
		TroubleWithLoginResBean troubleWithLoginResBean = HrappTestUtil.prepareTroubleWithLoginDetails();
		Mockito.when(rnlicService.getResponseForTroubleInLogin()).thenReturn(troubleWithLoginResBean);
		ResponseData responseData = authenticationService.getResponseForTroubleInLogin();
		assertNotNull(responseData);
	}
	
	@Test
	public void getEmployeeDetailsCandidateTest() throws RestClientException, IOException{
		UserDetailsBean empReqBean = new UserDetailsBean();
		empReqBean.setCandidate(true);
		Mockito.when(messagesConstants.getServiceForCandidateDetailsMsg()).thenReturn("Test");
		Mockito.when(rnlicService.getCandidateDtlsFromRnlic(Mockito.any(UserDetailsBean.class))).thenReturn(HrappTestUtil.prepareUserdetails());
		User userDetails =  (User) authenticationService.getEmployeeDetails(empReqBean);
		assertNotNull(userDetails);
	}
	
	@Test
	public void getEmployeeDetailsEmployeeTest() throws RestClientException, IOException{
		UserDetailsBean empReqBean = new UserDetailsBean();
		empReqBean.setCandidate(false);
		Mockito.when(messagesConstants.getServiceForCandidateDetailsMsg()).thenReturn("Test");
		Mockito.when(rnlicService.getEmpDetailsFromRnlic(Mockito.any(UserDetailsBean.class))).thenReturn(HrappTestUtil.prepareUserdetails());
		User userDetails =  (User) authenticationService.getEmployeeDetails(empReqBean);
		assertNotNull(userDetails);
	}

}
