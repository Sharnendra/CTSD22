package com.rnlic.hraapp.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.web.client.HttpClientErrorException;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.EmployeeCheckInCheckOutReqBean;
import com.rnlic.hrapp.bean.response.EmployeeCheckInCheckOutResBean;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;
import com.rnlic.hrapp.exception.CheckInCheckOutException;
import com.rnlic.hrapp.repository.DeviceRegistrationRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.CheckInCheckOutService;
import com.rnlic.hrapp.service.RnlicService;
@SuppressWarnings("unused")
public class CheckInCheckOutServiceTest extends HraServiceTests {
	
	@Mock
	private MessagesConstants messagesConstants;
	
	@Mock
	private RnlicService rnlicService;
	
	@Mock
	private DeviceRegistrationRepository deviceRepo;
	
	@InjectMocks
	private CheckInCheckOutService checkInCheckOutService;
	
	/**
	 *Test to perform Check In/ Check Out in Service Class
	 *@param UserDetailsBean empReqBean
	 *@param EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean
	 *@exception CheckInCheckOutException
	 *@author HRMSAPP
	 **/
	@Test
	public void testEmployeeCheckInCheckOut() {
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = null;
		EmployeeCheckInCheckOutResBean employeeCheckInCheckOutResBean=null;
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		DeviceRegistrationModel deviceRegistrationModel = HrappTestUtil.prepareDeviceRegistrationModalWhenSync("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.findByDeviceIdentifier("DEVICE1")).thenReturn(deviceRegistrationModel);
		Mockito.when(rnlicService.performCheckInCheckOut(Mockito.any(UserDetailsBean.class), Mockito.any(EmployeeCheckInCheckOutReqBean.class))).thenReturn(HrappTestUtil.prepareEmployeeCheckInCheckOutResForService("check-in"));
		try {
			employeeCheckInCheckOutReqBean=new EmployeeCheckInCheckOutReqBean();
			employeeCheckInCheckOutReqBean.setType("check-in");
			employeeCheckInCheckOutResBean=(EmployeeCheckInCheckOutResBean) checkInCheckOutService.employeeCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
		} catch (HttpClientErrorException e) {
			e.printStackTrace();
		}
		assertNotNull(employeeCheckInCheckOutResBean);
		assertEquals("true",employeeCheckInCheckOutResBean.getStatus());
	}
	
	/**
	 *Test to perform Check In/ Check Out in Service Class when service type is not chosen
	 *@param UserDetailsBean empReqBean
	 *@param EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean
	 *@exception CheckInCheckOutException
	 *@author HRMSAPP
	 **/
	@Test(expected=CheckInCheckOutException.class)
	public void testEmployeeCheckInCheckOutServiceTypeException() {
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = null;
		EmployeeCheckInCheckOutResBean employeeCheckInCheckOutResBean=null;
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		DeviceRegistrationModel deviceRegistrationModel = HrappTestUtil.prepareDeviceRegistrationModalWhenSync("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.findByDeviceIdentifier("DEVICE1")).thenReturn(deviceRegistrationModel);
		Mockito.when(rnlicService.performCheckInCheckOut(Mockito.any(UserDetailsBean.class), Mockito.any(EmployeeCheckInCheckOutReqBean.class))).thenThrow(new CheckInCheckOutException());
		try {
			employeeCheckInCheckOutReqBean=new EmployeeCheckInCheckOutReqBean();
			employeeCheckInCheckOutReqBean.setType("");
			employeeCheckInCheckOutResBean=(EmployeeCheckInCheckOutResBean) checkInCheckOutService.employeeCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
		} catch (HttpClientErrorException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 *Test to perform Check In/ Check Out in Service Class when device registered is out of sync
	 *@param UserDetailsBean empReqBean
	 *@param EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean
	 *@exception CheckInCheckOutException
	 *@author HRMSAPP
	 **/
	@Test
	public void testEmployeeCheckInCheckOutDeviceNotSync() {
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = null;
		EmployeeCheckInCheckOutResBean employeeCheckInCheckOutResBean=null;
		
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		empReqBean.setFcmToken("FCMTOKEN");
		DeviceRegistrationModel deviceRegistrationModel = HrappTestUtil.prepareDeviceRegistrationModalWhenNotSync("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.findByDeviceIdentifier("DEVICE1")).thenReturn(deviceRegistrationModel);
		Mockito.when(rnlicService.updateDeviceRegInfo("DEVICE1","MOBLIENO1","SAPCODE1","FCMTOKEN")).thenReturn(true);
		Mockito.when(deviceRepo.save(deviceRegistrationModel)).thenReturn(deviceRegistrationModel);
		Mockito.when(rnlicService.performCheckInCheckOut(Mockito.any(UserDetailsBean.class), Mockito.any(EmployeeCheckInCheckOutReqBean.class))).thenReturn(HrappTestUtil.prepareEmployeeCheckInCheckOutResForService("check-in"));
		try {
			employeeCheckInCheckOutReqBean=new EmployeeCheckInCheckOutReqBean();
			employeeCheckInCheckOutReqBean.setType("check-in");
			employeeCheckInCheckOutResBean=(EmployeeCheckInCheckOutResBean) checkInCheckOutService.employeeCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
		} catch (HttpClientErrorException e) {
			e.printStackTrace();
		}
		//assertNotNull(employeeCheckInCheckOutResBean);
		//assertEquals("true",employeeCheckInCheckOutResBean.getStatus());
	}
	
	/**
	 *Test to perform Check In/ Check Out in Service Class when device not registered
	 *@param UserDetailsBean empReqBean
	 *@param EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean
	 *@exception CheckInCheckOutException
	 *@author HRMSAPP
	 **/
	@Test(expected=CheckInCheckOutException.class)
	public void testEmployeeCheckInCheckOutDeviceNotRegistered() {
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = null;
		EmployeeCheckInCheckOutResBean employeeCheckInCheckOutResBean=null;
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.findByDeviceIdentifier("DEVICE1")).thenReturn(null);
		try {
			employeeCheckInCheckOutReqBean=new EmployeeCheckInCheckOutReqBean();
			employeeCheckInCheckOutReqBean.setType("check-in");
			employeeCheckInCheckOutResBean=(EmployeeCheckInCheckOutResBean) checkInCheckOutService.employeeCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
		} catch (HttpClientErrorException e) {
			e.printStackTrace();
		}
		Mockito.verifyNoMoreInteractions(deviceRepo);
	}
	
	@Test (expected=CheckInCheckOutException.class)
	public void testEmployeeCheckInCheckOutDeviceNotSyncException() {
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = null;
		EmployeeCheckInCheckOutResBean employeeCheckInCheckOutResBean=null;
		
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		empReqBean.setFcmToken("FCMTOKEN");
		DeviceRegistrationModel deviceRegistrationModel = HrappTestUtil.prepareDeviceRegistrationModalWhenNotSync("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.findByDeviceIdentifier("DEVICE1")).thenReturn(deviceRegistrationModel);
		Mockito.when(rnlicService.updateDeviceRegInfo("DEVICE1","MOBLIENO1","SAPCODE1","FCMTOKEN")).thenReturn(false);
		try {
			employeeCheckInCheckOutReqBean=new EmployeeCheckInCheckOutReqBean();
			employeeCheckInCheckOutReqBean.setType("check-in");
			employeeCheckInCheckOutResBean=(EmployeeCheckInCheckOutResBean) checkInCheckOutService.employeeCheckInCheckOut(empReqBean, employeeCheckInCheckOutReqBean);
		} catch (HttpClientErrorException e) {
			e.printStackTrace();
		}
		//assertNotNull(employeeCheckInCheckOutResBean);
		//assertEquals("true",employeeCheckInCheckOutResBean.getStatus());
	}
}
