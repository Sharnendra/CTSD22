package com.rnlic.hraapp.test.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.BirthdayReqBean;
import com.rnlic.hrapp.bean.request.WishEmpReqBean;
import com.rnlic.hrapp.bean.request.WishesReq;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;
import com.rnlic.hrapp.exception.CommunicationException;
import com.rnlic.hrapp.repository.DeviceRegistrationRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.BirthdayWishService;
import com.rnlic.hrapp.service.RnlicService;

public class BirthdayWishServiceTest extends HraServiceTests {

	@Mock
	private RnlicService rnlicService;
	
	@Mock
	private MessagesConstants messagesConstants;
	
	@Mock
	private DeviceRegistrationRepository deviceRepo;
	
	@InjectMocks
	private BirthdayWishService birthdayWishService;
	
	@Test
	public void getBirthdayTest() {
		UserDetailsBean userDetailsBean =null;
		Mockito.when(rnlicService.getTodayBirthday()).thenReturn(HrappTestUtil.prepareBirthdayList());
		ResponseData res = birthdayWishService.getBirthday(userDetailsBean);
		assertNotNull(res);
	}
	
	@Test
	public void getReporteeBirthdayTest() {
		UserDetailsBean userDetailsBean =HrappTestUtil.prepareUserDtlsBean("59456424", "55458564188", "CBHPR46567Q", "70086002");
		Mockito.when(rnlicService.getTodayBirthday()).thenReturn(HrappTestUtil.prepareBirthdayList());
		ResponseData res = birthdayWishService.getReporteeBirthday(userDetailsBean);
		assertNotNull(res);
	}
	
	@Test
	public void getAnniversaryTest() {
		UserDetailsBean userDetailsBean =null;
		Mockito.when(rnlicService.getTodayAnniversary()).thenReturn(HrappTestUtil.prepareAnniversaryList());
		ResponseData res = birthdayWishService.getAnniversary(userDetailsBean);
		assertNotNull(res);
	}
	
	@Test
	public void wishEmployeeBirthdayTest() {
		UserDetailsBean userDetailsBean =HrappTestUtil.prepareUserDtlsBean("852546322", "8375939142", "KTP5554D8", "837599");
		WishEmpReqBean wishEmpReqBean = HrappTestUtil.prepareBirthdayWishEmpReqBean();
		Mockito.when(rnlicService.sendBirthdaySms(Mockito.any(WishesReq.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareBirthdaySmsResBean());
		Mockito.when(rnlicService.sendAnniversarySms(Mockito.any(WishesReq.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareBirthdaySmsResBean());
		Mockito.when(rnlicService.sendBirthdayEmail(Mockito.any(WishesReq.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareRnlicAuthRes());
		Mockito.when(rnlicService.sendAnniversaryEmail(Mockito.any(WishesReq.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareRnlicAuthRes());
		Mockito.when(messagesConstants.getMessageSendSuccessfully()).thenReturn("Message send successfuly");
		ResponseData res = birthdayWishService.wishEmployee(userDetailsBean,wishEmpReqBean);
		assertNotNull(res);
	}
	
	@Test
	public void wishEmployeeAnniversaryTest() {
		UserDetailsBean userDetailsBean =HrappTestUtil.prepareUserDtlsBean("852546322", "8375939142", "KTP5554D8", "837599");
		WishEmpReqBean wishEmpReqBean = HrappTestUtil.prepareAnniversaryWishEmpReqBean();
		Mockito.when(rnlicService.sendAnniversarySms(Mockito.any(WishesReq.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareBirthdaySmsResBean());
		Mockito.when(rnlicService.sendAnniversaryEmail(Mockito.any(WishesReq.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareRnlicAuthRes());
		Mockito.when(messagesConstants.getMessageSendSuccessfully()).thenReturn("Message send successfuly");
		ResponseData res = birthdayWishService.wishEmployee(userDetailsBean,wishEmpReqBean);
		assertNotNull(res);
	}
	
	@Test (expected = CommunicationException.class)
	public void wishEmployeeUnknownTest() {
		UserDetailsBean userDetailsBean =HrappTestUtil.prepareUserDtlsBean("852546322", "8375939142", "KTP5554D8", "837599");
		WishEmpReqBean wishEmpReqBean = HrappTestUtil.prepareUnknownWishEmpReqBean();
		Mockito.when(messagesConstants.getMessageSendSuccessfully()).thenReturn("Message send successfuly");
		birthdayWishService.wishEmployee(userDetailsBean,wishEmpReqBean);
	}
	
	@Test (expected = CommunicationException.class)
	public void wishEmployeeNoCommunicationTest() {
		UserDetailsBean userDetailsBean =null;
		WishEmpReqBean wishEmpReqBean = HrappTestUtil.prepareNoCommunicationWishEmpReqBean();
		birthdayWishService.wishEmployee(userDetailsBean,wishEmpReqBean);
	}
	
	@Test (expected = CommunicationException.class)
	public void wishEmployeeAllServiceFailedCommunicationTest() {
		UserDetailsBean userDetailsBean =HrappTestUtil.prepareUserDtlsBean("852546322", "8375939142", "KTP5554D8", "837599");
		Mockito.when(rnlicService.sendAnniversarySms(Mockito.any(WishesReq.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareBirthdaySmsFailedResBean());
		Mockito.when(rnlicService.sendAnniversaryEmail(Mockito.any(WishesReq.class),Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareRnlicAuthResFailed());
		WishEmpReqBean wishEmpReqBean = HrappTestUtil.prepareAnniversaryWishEmpReqBean();
		birthdayWishService.wishEmployee(userDetailsBean,wishEmpReqBean);
	}
	
	@Test
	public void searchBirthdayAnniversaryTest() {
		UserDetailsBean userDetailsBean = null;
		BirthdayReqBean birthdayReqBean = null;
		Mockito.when(rnlicService.searchBirthday(Mockito.any(BirthdayReqBean.class))).thenReturn(HrappTestUtil.prepareBirthdayList());
		birthdayWishService.searchBirthdayAnniversary(userDetailsBean, birthdayReqBean);
	}
	
	@Test
	public void getReporteeAnniversaryTest() {
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("59456424", "55458564188", "CBHPR46567Q", "70086002");
		Mockito.when(rnlicService.getTodayAnniversary()).thenReturn(HrappTestUtil.prepareAnniversaryList());
		birthdayWishService.getReporteeAnniversary(userDetailsBean);
	}
	
	@Test
	public void wishEmployeeBirthdayPushTest() {
		UserDetailsBean userDetailsBean =HrappTestUtil.prepareUserDtlsBean("852546322", "8375939142", "KTP5554D8", "837599");
		WishEmpReqBean wishEmpReqBean = HrappTestUtil.prepareBirthdayWishEmpPushReqBean();
		Mockito.when(deviceRepo.findBySapCode(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareDeviceEntity());
		Mockito.when(rnlicService.sendPushNotification(Mockito.any(WishesReq.class),Mockito.any(DeviceRegistrationModel.class),Mockito.any(UserDetailsBean.class))).thenReturn(1);
		ResponseData res = birthdayWishService.wishEmployee(userDetailsBean,wishEmpReqBean);
		assertNotNull(res);
	}
	
	@Test (expected = CommunicationException.class)
	public void wishEmployeeBirthdayPushFailedTest() {
		UserDetailsBean userDetailsBean =HrappTestUtil.prepareUserDtlsBean("852546322", "8375939142", "KTP5554D8", "837599");
		WishEmpReqBean wishEmpReqBean = HrappTestUtil.prepareBirthdayWishEmpPushReqBean();
		Mockito.when(deviceRepo.findBySapCode(Mockito.any(String.class))).thenReturn(HrappTestUtil.prepareDeviceEntity());
		Mockito.when(rnlicService.sendPushNotification(Mockito.any(WishesReq.class),Mockito.any(DeviceRegistrationModel.class),Mockito.any(UserDetailsBean.class))).thenReturn(0);
		ResponseData res = birthdayWishService.wishEmployee(userDetailsBean,wishEmpReqBean);
		assertNotNull(res);
	}
	
	@Test (expected = CommunicationException.class)
	public void wishEmployeeBirthdayPushNullTest() {
		UserDetailsBean userDetailsBean =HrappTestUtil.prepareUserDtlsBean("852546322", "8375939142", "KTP5554D8", "837599");
		WishEmpReqBean wishEmpReqBean = HrappTestUtil.prepareBirthdayWishEmpPushReqBean();
		Mockito.when(deviceRepo.findBySapCode(Mockito.any(String.class))).thenReturn(null);
		ResponseData res = birthdayWishService.wishEmployee(userDetailsBean,wishEmpReqBean);
		assertNotNull(res);
	}
}
