package com.rnlic.hraapp.test.controllers;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.constants.TestConstant;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.AttendanceReqBean;
import com.rnlic.hrapp.bean.request.EmployeeCheckInCheckOutReqBean;
import com.rnlic.hrapp.bean.request.LearningStatusUpdateReqBean;
import com.rnlic.hrapp.bean.request.SapReqBean;
import com.rnlic.hrapp.bean.response.AttendanceDetailsResBean;
import com.rnlic.hrapp.controller.AttendanceController;
import com.rnlic.hrapp.exception.BadRequestException;
import com.rnlic.hrapp.exception.UnhandledException;
import com.rnlic.hrapp.security.JwtDecriptor;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.AttendanceDetailsService;
import com.rnlic.hrapp.service.CheckInCheckOutService;
import com.rnlic.hrapp.service.LearningService;
import com.rnlic.hrapp.util.LogUtil;
import com.rnlic.hrapp.util.RequestLogDeatils;


public class AttendanceControllerTest extends HraServiceTests {

	private MockMvc mockMvc;

	@Mock
	private AttendanceDetailsService attendanceDetailsService;

	@Mock
	private CheckInCheckOutService checkInCheckOutService;

	@Mock
	private LearningService learningService;
	
	@Mock
	private JwtDecriptor jwtDecriptor;
	
	@Mock
	private LogUtil logger;
	
	@Mock
	private RequestLogDeatils requestLog;

	@InjectMocks
	private AttendanceController attendanceController;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(attendanceController).build();
	}
	
	@Test
	public void testGetAttandanceEndpoint() throws Exception {
		String expectedReq = TestConstant.ATTENDANCE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		AttendanceReqBean attendanceReqBean = new AttendanceReqBean();
		attendanceReqBean.setSapCode("70009002");
		attendanceReqBean.setMonth("07");
		attendanceReqBean.setYear("2019");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(attendanceDetailsService.getAttendanceDetails(user, attendanceReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_ATTENDANCE_ENDPOINT).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
	@Test
	public void testGetAttandanceEndpointExp() throws Exception {
		String expectedReq = TestConstant.ATTENDANCE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		AttendanceReqBean attendanceReqBean = new AttendanceReqBean();
		attendanceReqBean.setSapCode("70009002");
		attendanceReqBean.setMonth("07");
		attendanceReqBean.setYear("2019");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new UnhandledException("Test Exp"));
		Mockito.when(attendanceDetailsService.getAttendanceDetails(user, attendanceReqBean)).thenThrow(new UnhandledException("Test Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_ATTENDANCE_ENDPOINT).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
	@Test
	public void testGetAttandanceEndpointExp1() throws Exception {
		String expectedReq = TestConstant.ATTENDANCE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		AttendanceReqBean attendanceReqBean = new AttendanceReqBean();
		attendanceReqBean.setSapCode("70009002");
		attendanceReqBean.setMonth("07");
		attendanceReqBean.setYear("2019");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException());
		Mockito.when(attendanceDetailsService.getAttendanceDetails(user, attendanceReqBean)).thenThrow(new RuntimeException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_ATTENDANCE_ENDPOINT).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
	@Test
	public void testEmployeeCheckInCheckOut() throws Exception {
		String expectedReq = TestConstant.CHECKIN_CHECKOUT_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(checkInCheckOutService.employeeCheckInCheckOut(user, employeeCheckInCheckOutReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.CHECKIN_CHECKOUT_ENDPOINT).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
	
	@Test
	public void testEmployeeCheckInCheckOutExp1() throws Exception {
		String expectedReq = TestConstant.CHECKIN_CHECKOUT_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new BadRequestException());
		Mockito.when(checkInCheckOutService.employeeCheckInCheckOut(user, employeeCheckInCheckOutReqBean)).thenThrow(new UnhandledException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.CHECKIN_CHECKOUT_ENDPOINT).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testEmployeeCheckInCheckOutExp() throws Exception {
		String expectedReq = TestConstant.CHECKIN_CHECKOUT_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		EmployeeCheckInCheckOutReqBean employeeCheckInCheckOutReqBean = new EmployeeCheckInCheckOutReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException());
		Mockito.when(checkInCheckOutService.employeeCheckInCheckOut(user, employeeCheckInCheckOutReqBean)).thenThrow(new RuntimeException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.CHECKIN_CHECKOUT_ENDPOINT).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetMandatoryLearning() throws Exception {
		String expectedReq = TestConstant.GET_MANDATORY_LEARNING_JSON;
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(learningService.getMandatoryLearning()).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_MANDATORY_LEARNING_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetMandatoryLearningExp() throws Exception {
		String expectedReq = TestConstant.GET_MANDATORY_LEARNING_JSON;
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(learningService.getMandatoryLearning()).thenThrow(new UnhandledException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_MANDATORY_LEARNING_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
	@Test
	public void testGetMandatoryLearningExp1() throws Exception {
		String expectedReq = TestConstant.GET_MANDATORY_LEARNING_JSON;
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(token)).thenReturn(user);
		Mockito.when(learningService.getMandatoryLearning()).thenThrow(new RuntimeException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_MANDATORY_LEARNING_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetMandatoryLearningStatus() throws Exception {
		String expectedReq = TestConstant.GET_MANDATORY_LEARNING_JSON;
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(learningService.getMandatoryLearningStatus(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_MANDATORY_LEARNING_STATUS_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
	@Test
	public void testGetMandatoryLearningStatusExp() throws Exception {
		String expectedReq = TestConstant.GET_MANDATORY_LEARNING_JSON;
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(learningService.getMandatoryLearningStatus(user)).thenThrow(new UnhandledException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_MANDATORY_LEARNING_STATUS_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
	@Test
	public void testGetMandatoryLearningStatusExp1() throws Exception {
		String expectedReq = TestConstant.GET_MANDATORY_LEARNING_JSON;
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(learningService.getMandatoryLearningStatus(user)).thenThrow(new RuntimeException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_MANDATORY_LEARNING_STATUS_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testupdateLearningCompletionStatus() throws Exception {
		String expectedReq = TestConstant.UPDATE_LEARNI_STATUS_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		LearningStatusUpdateReqBean learningId = new LearningStatusUpdateReqBean();
		learningId.setLearningId("ULIP");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(learningService.updateLearningCompletionStatus(user, learningId.getLearningId())).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.UPDATE_LEARNING_COMPLETION_STATUS_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testupdateLearningCompletionStatusExp() throws Exception {
		String expectedReq = TestConstant.UPDATE_LEARNI_STATUS_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		LearningStatusUpdateReqBean learningId = new LearningStatusUpdateReqBean();
		learningId.setLearningId("ULIP");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new UnhandledException());
		Mockito.when(learningService.updateLearningCompletionStatus(user, learningId.getLearningId())).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.UPDATE_LEARNING_COMPLETION_STATUS_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testupdateLearningCompletionStatusExp1() throws Exception {
		String expectedReq = TestConstant.UPDATE_LEARNI_STATUS_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		LearningStatusUpdateReqBean learningId = new LearningStatusUpdateReqBean();
		learningId.setLearningId("ULIP");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException());
		Mockito.when(learningService.updateLearningCompletionStatus(user, learningId.getLearningId())).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.UPDATE_LEARNING_COMPLETION_STATUS_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
	@Test
	public void testGetListOfReportees() throws Exception {
		String expectedReq = TestConstant.CHECKIN_CHECKOUT_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		SapReqBean sapReqBean = new SapReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(attendanceDetailsService.getReporteeList(user,sapReqBean.getSapCode())).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_REPORTEE_LIST_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetListOfReporteesExp() throws Exception {
		String expectedReq = TestConstant.CHECKIN_CHECKOUT_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		SapReqBean sapReqBean = new SapReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new UnhandledException());
		Mockito.when(attendanceDetailsService.getReporteeList(user,sapReqBean.getSapCode())).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_REPORTEE_LIST_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetListOfReporteesExp1() throws Exception {
		String expectedReq = TestConstant.CHECKIN_CHECKOUT_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		SapReqBean sapReqBean = new SapReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException());
		Mockito.when(attendanceDetailsService.getReporteeList(user,sapReqBean.getSapCode())).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_REPORTEE_LIST_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
}
