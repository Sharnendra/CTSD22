package com.rnlic.hraapp.test.controllers;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.constants.TestConstant;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.AuthReqBean;
import com.rnlic.hrapp.bean.request.DeRegisterDeviceReqBean;
import com.rnlic.hrapp.bean.request.OtpReqBean;
import com.rnlic.hrapp.bean.request.OtpValidateReqBean;
import com.rnlic.hrapp.bean.request.RegisterDeviceReqBean;
import com.rnlic.hrapp.bean.request.UpdateDeviceRegistrationReqBean;
import com.rnlic.hrapp.bean.request.UpdateInstalledAppReqBean;
import com.rnlic.hrapp.bean.response.AttendanceDetailsResBean;
import com.rnlic.hrapp.bean.response.ValidateOtpMobileResBean;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.controller.AuthenticationAuthorizationController;
import com.rnlic.hrapp.exception.BadRequestException;
import com.rnlic.hrapp.exception.CheckInCheckOutException;
import com.rnlic.hrapp.exception.CommunicationException;
import com.rnlic.hrapp.exception.DeviceRegistrationException;
import com.rnlic.hrapp.exception.RnlicServiceException;
import com.rnlic.hrapp.repository.OtpRepository;
import com.rnlic.hrapp.security.JwtDecriptor;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.AuthenticationAuthorizationService;
import com.rnlic.hrapp.service.CommunicationService;
import com.rnlic.hrapp.service.DeviceRegistrationService;
import com.rnlic.hrapp.util.RequestLogDeatils;


public class AuthenticationAuthorizationTest extends HraServiceTests{

	private MockMvc mockMvc;

	@Mock
	private AuthenticationAuthorizationService authService;

	@Mock
	private CommunicationService messageService;
	
	@Mock
	private DeviceRegistrationService deviceService;
	
	@Mock 
	private MessagesConstants messagesConstants;
	
	@Mock 
	private OtpRepository otpRepo;
	
	@Mock
	private JwtDecriptor jwtDecriptor;
	
	@Mock
	private ObjectMapper objectToJson;
	
	@Mock
	private RequestLogDeatils requestLog;
	
	@InjectMocks
	private AuthenticationAuthorizationController authenticationAuthorizationController;
	
	
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(authenticationAuthorizationController).build();
	}

	@Test
	public void testAuthenticateAndGenerateJwtToken() throws Exception {
		String expectedReq = TestConstant.AUTHENTICATE_REQ_JSON;
		AuthReqBean authReqBean = new AuthReqBean();
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(authService.authenticateAndGenerateToken(authReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.AUTHENTICATE_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testSendOtpOnMobile() throws Exception {
		String expectedReq = TestConstant.SEND_OTP_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		OtpReqBean otpReqBean = new OtpReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(messageService.sendOtpOnMobile(otpReqBean, user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.SEND_OTP_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testValidateOtp() throws Exception {
		String expectedReq = TestConstant.VALIDATE_OTP_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		OtpValidateReqBean otpValidateReqBean = new OtpValidateReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		ValidateOtpMobileResBean validateOtpMobileResBean = new ValidateOtpMobileResBean();
		validateOtpMobileResBean.setMessage("Verified");
		validateOtpMobileResBean.setStatus(true);
		Mockito.when(jwtDecriptor.jwtDecript(token)).thenReturn(user);
		Mockito.when(messageService.validateOtp(user, otpValidateReqBean)).thenReturn(validateOtpMobileResBean);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.VALIDATE_OTP_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
		
	}
	@Test
	public void testRegisterDevice() throws Exception {
		String expectedReq = TestConstant.REGISTER_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		RegisterDeviceReqBean registerDeviceReqBean = new RegisterDeviceReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(deviceService.registerDevice(user, registerDeviceReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.REGISTER_DEVICE).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testUpdateDeviceRegistration() throws Exception {
		String expectedReq = TestConstant.UPDATE_REG_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		UpdateDeviceRegistrationReqBean updateDeviceRegReqBean = new UpdateDeviceRegistrationReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(deviceService.updateDeviceReg(user, updateDeviceRegReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.UPDATE_DEVICE_REGISTRATION).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testDeRegisterDevice() throws Exception {
		String expectedReq = TestConstant.DEREGISTER_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		DeRegisterDeviceReqBean deregDeviceReqBean = new DeRegisterDeviceReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(deviceService.deRegDevice(user, deregDeviceReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.DEREGISTER_DEVICE).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testUpdateLinkedAppForRegisteredDevice() throws Exception {
		String expectedReq = TestConstant.UPDATE_LINKED_FOR_REGISTER_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		UpdateInstalledAppReqBean updateInstalledAppReqBean = new UpdateInstalledAppReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(deviceService.updateLinkedAppForRegisteredDevice(user, updateInstalledAppReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.UPDATE_LINKED_APP_FOR_REGISTER_DEVICE).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetResponseForTroubleInLogin() throws Exception {
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(authService.getResponseForTroubleInLogin()).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_TROUBLE_WITH_LOGIN_URL).contentType(MediaType.APPLICATION_JSON);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testAuthenticateAndGenerateJwtTokenExp() throws Exception {
		String expectedReq = TestConstant.AUTHENTICATE_REQ_JSON1;
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(authService.authenticateAndGenerateToken(authReqBean)).thenThrow(new BadRequestException("New Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.AUTHENTICATE_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testAuthenticateAndGenerateJwtTokenRuntimeExp() throws Exception {
		String expectedReq = TestConstant.AUTHENTICATE_REQ_JSON;
		Mockito.when(authService.authenticateAndGenerateToken(Mockito.any(AuthReqBean.class))).thenThrow(new RuntimeException("New Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.AUTHENTICATE_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testSendOtpOnMobileExp() throws Exception {
		String expectedReq = TestConstant.SEND_OTP_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		OtpReqBean otpReqBean = new OtpReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RnlicServiceException("New Exp"));
		Mockito.when(messageService.sendOtpOnMobile(otpReqBean, user)).thenThrow(new RnlicServiceException("New Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.SEND_OTP_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testValidateOtpExp() throws Exception {
		String expectedReq = TestConstant.VALIDATE_OTP_REQ_JSON1;
		String token = TestConstant.GET_TOKEN;
		OtpValidateReqBean otpValidateReqBean = new OtpValidateReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		ValidateOtpMobileResBean validateOtpMobileResBean = new ValidateOtpMobileResBean();
		validateOtpMobileResBean.setMessage("Verified");
		validateOtpMobileResBean.setStatus(true);
		Mockito.when(jwtDecriptor.jwtDecript(token)).thenReturn(user);
		Mockito.when(messageService.validateOtp(user, otpValidateReqBean)).thenThrow(new RnlicServiceException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.VALIDATE_OTP_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
		
	}
	@Test
	public void testRegisterDeviceExp() throws Exception {
		String expectedReq = TestConstant.REGISTER_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		RegisterDeviceReqBean registerDeviceReqBean = new RegisterDeviceReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new CheckInCheckOutException("New Exp"));
		Mockito.when(deviceService.registerDevice(user, registerDeviceReqBean)).thenThrow(new CheckInCheckOutException("New Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.REGISTER_DEVICE).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testUpdateDeviceRegistrationExp() throws Exception {
		String expectedReq = TestConstant.UPDATE_REG_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		UpdateDeviceRegistrationReqBean updateDeviceRegReqBean = new UpdateDeviceRegistrationReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new CheckInCheckOutException());
		Mockito.when(deviceService.updateDeviceReg(user, updateDeviceRegReqBean)).thenThrow(new CheckInCheckOutException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.UPDATE_DEVICE_REGISTRATION).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testUpdateDeviceRegistrationData() throws Exception {
		String expectedReq = TestConstant.UPDATE_REG_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(deviceService.updateDeviceReg(Mockito.any(UserDetailsBean.class), Mockito.any(UpdateDeviceRegistrationReqBean.class))).thenThrow(new NullPointerException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.UPDATE_DEVICE_REGISTRATION).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testDeRegisterDeviceExp() throws Exception {
		String expectedReq = TestConstant.DEREGISTER_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		DeRegisterDeviceReqBean deregDeviceReqBean = new DeRegisterDeviceReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new CommunicationException("New Exp"));
		Mockito.when(deviceService.deRegDevice(user, deregDeviceReqBean)).thenThrow(new CommunicationException("New Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.DEREGISTER_DEVICE).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testUpdateLinkedAppForRegisteredDeviceExp() throws Exception {
		String expectedReq = TestConstant.UPDATE_LINKED_FOR_REGISTER_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		UpdateInstalledAppReqBean updateInstalledAppReqBean = new UpdateInstalledAppReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new CommunicationException());
		Mockito.when(deviceService.updateLinkedAppForRegisteredDevice(user, updateInstalledAppReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.UPDATE_LINKED_APP_FOR_REGISTER_DEVICE).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetResponseForTroubleInLoginExp() throws Exception {
		Mockito.when(authService.getResponseForTroubleInLogin()).thenThrow(new DeviceRegistrationException());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_TROUBLE_WITH_LOGIN_URL).contentType(MediaType.APPLICATION_JSON);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testAuthenticateAndGenerateJwtTokenExp1() throws Exception {
		String expectedReq = TestConstant.AUTHENTICATE_REQ_JSON;
		AuthReqBean authReqBean = new AuthReqBean();
		Mockito.when(authService.authenticateAndGenerateToken(authReqBean)).thenThrow(new RuntimeException("Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.AUTHENTICATE_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testSendOtpOnMobileExp1() throws Exception {
		String expectedReq = TestConstant.SEND_OTP_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		OtpReqBean otpReqBean = new OtpReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException("Exp"));
		Mockito.when(messageService.sendOtpOnMobile(otpReqBean, user)).thenThrow(new RuntimeException("Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.SEND_OTP_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testSendOtpOnMobileExp2() throws Exception {
		String expectedReq = TestConstant.SEND_OTP_REQ_JSON1;
		String token = TestConstant.GET_TOKEN;
		OtpReqBean otpReqBean = new OtpReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new BadRequestException("Exp"));
		Mockito.when(messageService.sendOtpOnMobile(otpReqBean, user)).thenThrow(new BadRequestException("Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.SEND_OTP_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testValidateOtpExp1() throws Exception {
		String expectedReq = TestConstant.VALIDATE_OTP_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		OtpValidateReqBean otpValidateReqBean = new OtpValidateReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		ValidateOtpMobileResBean validateOtpMobileResBean = new ValidateOtpMobileResBean();
		validateOtpMobileResBean.setMessage("Verified");
		validateOtpMobileResBean.setStatus(true);
		Mockito.when(jwtDecriptor.jwtDecript(token)).thenThrow(new RuntimeException("Exp"));
		Mockito.when(messageService.validateOtp(user, otpValidateReqBean)).thenThrow(new RuntimeException("Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.VALIDATE_OTP_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
		
	}
	@Test
	public void testRegisterDeviceExp1() throws Exception {
		String expectedReq = TestConstant.REGISTER_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		RegisterDeviceReqBean registerDeviceReqBean = new RegisterDeviceReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException("Exp"));
		Mockito.when(deviceService.registerDevice(user, registerDeviceReqBean)).thenThrow(new RuntimeException("Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.REGISTER_DEVICE).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testUpdateDeviceRegistrationExp1() throws Exception {
		String expectedReq = TestConstant.UPDATE_REG_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		UpdateDeviceRegistrationReqBean updateDeviceRegReqBean = new UpdateDeviceRegistrationReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException("Exp"));
		Mockito.when(deviceService.updateDeviceReg(user, updateDeviceRegReqBean)).thenThrow(new RuntimeException("Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.UPDATE_DEVICE_REGISTRATION).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testDeRegisterDeviceExp2() throws Exception {
		String expectedReq = TestConstant.DEREGISTER_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		DeRegisterDeviceReqBean deregDeviceReqBean = new DeRegisterDeviceReqBean();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new BadRequestException());
		Mockito.when(objectToJson.writeValueAsString(deregDeviceReqBean)).thenReturn("df");
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.DEREGISTER_DEVICE).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testDeRegisterDeviceExp1() throws Exception {
		String expectedReq = TestConstant.DEREGISTER_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		DeRegisterDeviceReqBean deregDeviceReqBean = new DeRegisterDeviceReqBean();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException("Exp"));
		Mockito.when(objectToJson.writeValueAsString(deregDeviceReqBean)).thenReturn("df");
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.DEREGISTER_DEVICE).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testUpdateLinkedAppForRegisteredDeviceExp1() throws Exception {
		String expectedReq = TestConstant.UPDATE_LINKED_FOR_REGISTER_DEVICE_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		UpdateInstalledAppReqBean updateInstalledAppReqBean = new UpdateInstalledAppReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException("Exp"));
		Mockito.when(deviceService.updateLinkedAppForRegisteredDevice(user, updateInstalledAppReqBean)).thenThrow(new RuntimeException("Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.UPDATE_LINKED_APP_FOR_REGISTER_DEVICE).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetResponseForTroubleInLoginExp1() throws Exception {
		Mockito.when(authService.getResponseForTroubleInLogin()).thenThrow(new RuntimeException("Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_TROUBLE_WITH_LOGIN_URL).contentType(MediaType.APPLICATION_JSON);
		mockMvc.perform(requestBuilder).andReturn();
	}
}
