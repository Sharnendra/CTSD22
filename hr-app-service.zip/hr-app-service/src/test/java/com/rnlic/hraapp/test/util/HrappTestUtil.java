package com.rnlic.hraapp.test.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.joda.time.LocalDate;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rnlic.hraapp.test.constants.TestConstant;
import com.rnlic.hrapp.bean.api.request.StateCityMasterReqBean;
import com.rnlic.hrapp.bean.api.response.AnniversaryListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.BirthdayListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.BirthdaySms;
import com.rnlic.hrapp.bean.api.response.BirthdaySmsResBean;
import com.rnlic.hrapp.bean.api.response.CandidateDetailsRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.CandidateRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.ChangePasswordRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.CheckInCheckOutDateTimeResponseBean;
import com.rnlic.hrapp.bean.api.response.CheckInCheckOutRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.DeviceRegInfoResponseBean;
import com.rnlic.hrapp.bean.api.response.EmployeeDetailsRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.EmployeeRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.ErrorRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.LearningStatusUpdateResponseBean;
import com.rnlic.hrapp.bean.api.response.MandatoryLearningRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.MonthlyAttendanceDetailsRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.NoticeDetailsRnlicBean;
import com.rnlic.hrapp.bean.api.response.NoticesRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.ReporteeListRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.RnlicAuthRes;
import com.rnlic.hrapp.bean.api.response.RnlicBranchDetailBean;
import com.rnlic.hrapp.bean.api.response.RnlicBranchDetailsListResponseBean;
import com.rnlic.hrapp.bean.api.response.SendOtpRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.StateCityMasterRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.TroubleWithLoginApiResBean;
import com.rnlic.hrapp.bean.api.response.TroubleWithLoginRnlicResponseBean;
import com.rnlic.hrapp.bean.request.InstalledApplicationDetails;
import com.rnlic.hrapp.bean.request.LinkedApplicationReq;
import com.rnlic.hrapp.bean.request.RegisterDeviceReqBean;
import com.rnlic.hrapp.bean.request.ShareBranchDetailsReqBean;
import com.rnlic.hrapp.bean.request.UpdateInstalledAppReqBean;
import com.rnlic.hrapp.bean.request.UserLocation;
import com.rnlic.hrapp.bean.request.WishEmpReqBean;
import com.rnlic.hrapp.bean.request.WishesReq;
import com.rnlic.hrapp.bean.response.Anniversary;
import com.rnlic.hrapp.bean.response.AnniversaryResBean;
import com.rnlic.hrapp.bean.response.Attendance;
import com.rnlic.hrapp.bean.response.AttendanceDetailsResBean;
import com.rnlic.hrapp.bean.response.Birthday;
import com.rnlic.hrapp.bean.response.BirthdayResBean;
import com.rnlic.hrapp.bean.response.ChangePasswordResBean;
import com.rnlic.hrapp.bean.response.CheckForDeviceRegistrationResBean;
import com.rnlic.hrapp.bean.response.CityDetails;
import com.rnlic.hrapp.bean.response.EmployeeCheckInCheckOutResBean;
import com.rnlic.hrapp.bean.response.LearningDetails;
import com.rnlic.hrapp.bean.response.LinkedAppConfigRes;
import com.rnlic.hrapp.bean.response.LocateBranchResBean;
import com.rnlic.hrapp.bean.response.LocateBranches;
import com.rnlic.hrapp.bean.response.MandatoryLearningDetails;
import com.rnlic.hrapp.bean.response.MandatoryLearningResBean;
import com.rnlic.hrapp.bean.response.MandatoryLearningStatusResBean;
import com.rnlic.hrapp.bean.response.NoticeDetails;
import com.rnlic.hrapp.bean.response.NoticesResBean;
import com.rnlic.hrapp.bean.response.PushNotificationResponse;
import com.rnlic.hrapp.bean.response.ReporteeDetails;
import com.rnlic.hrapp.bean.response.StateCityMasterResBean;
import com.rnlic.hrapp.bean.response.StateDetails;
import com.rnlic.hrapp.bean.response.TroubleWithLoginResBean;
import com.rnlic.hrapp.bean.response.User;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.RequestValidatorConstants;
import com.rnlic.hrapp.constant.URLConstruct;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;
import com.rnlic.hrapp.entity.LinkedAppConfigrationModel;
import com.rnlic.hrapp.entity.OtpMasterModel;
import com.rnlic.hrapp.exception.CheckInCheckOutException;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.util.HrAppUtil;
import com.rnlic.hrapp.util.RequestValidatorResponse;

public class HrappTestUtil {

	public static OtpMasterModel prepareRuleDetailsEntityObj(String mobileVer) {
		// TODO Auto-generated method stub
		OtpMasterModel otpEntity = new OtpMasterModel();
		otpEntity.setAction(mobileVer);
		otpEntity.setCountryCode("+91");
		otpEntity.setDeviceIdentifier("989789");
		otpEntity.setMobileNumber("898789");
		otpEntity.setOtpId(1);
		otpEntity.setOtpValue(12345);
		otpEntity.setResendCount(3);
		otpEntity.setRetryCount(3);
		otpEntity.setSapCode("9041183");
		otpEntity.setValidUpto(new Date());
		otpEntity.setVerified(false);
		return null;
	}

	public static DeviceRegistrationModel prepareDeviceEntity() {
		DeviceRegistrationModel deviceEntity = new DeviceRegistrationModel();
		deviceEntity.setAppVersion("1.0");
		deviceEntity.setDeviceIdentifier("748152");
		deviceEntity.setDeviceType("ANRIOD");
		deviceEntity.setFcmToken("");
		deviceEntity.setIsActive(true);
		deviceEntity.setMobileNumber("9821611022");
		deviceEntity.setName("ReshmaChougule");
		deviceEntity.setPanNumber("");
		try {
			deviceEntity.setRegisteredOn(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse("2019-07-22 19:44:37.2220000"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		deviceEntity.setRequestId(190);
		deviceEntity.setSapCode("70285945");
		return deviceEntity;
	}

	public static List<DeviceRegistrationModel> prepareDeviceEntityList(String deviceIdentifier,String moblieNo,String panNo,String sapCode) {
		List<DeviceRegistrationModel> deviceList = new ArrayList<>();
		DeviceRegistrationModel deviceEntity = new DeviceRegistrationModel();
		deviceEntity.setAppVersion("1.0");
		deviceEntity.setDeviceIdentifier(deviceIdentifier);
		deviceEntity.setDeviceType("ANRIOD");
		deviceEntity.setFcmToken("");
		deviceEntity.setIsActive(true);
		deviceEntity.setMobileNumber(moblieNo);
		deviceEntity.setName("ReshmaChougule");
		deviceEntity.setPanNumber(panNo);
		try {
			deviceEntity.setRegisteredOn(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse("2019-07-22 19:44:37.2220000"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		deviceEntity.setRequestId(190);
		deviceEntity.setSapCode(sapCode);
		deviceList.add(deviceEntity);
		return deviceList;
	}

	public static UserDetailsBean prepareUserDtlsBean(String deviceIdentifier,String moblieNo,String panNo,String sapCode) {
		UserDetailsBean user = new UserDetailsBean("Reshma", "Chougale", sapCode, moblieNo, panNo, deviceIdentifier, true, false, "70009002", null, "ASM");
		return user;
	}
	
	public static UserDetailsBean prepareUserDtlsCandidateBean() {
		UserDetailsBean user = new UserDetailsBean("Reshma", "Chougale", "", "8981414565", "DILPK0000M", "748152", true, false, "70009002", null, "ASM");
		return user;
	}

	public static List<DeviceRegistrationModel> prepareDeviceEntityListForCandidate() {
		List<DeviceRegistrationModel> deviceList = new ArrayList<>();
		DeviceRegistrationModel deviceEntity = new DeviceRegistrationModel();
		deviceEntity.setAppVersion("1.0");
		deviceEntity.setDeviceIdentifier("748152");
		deviceEntity.setDeviceType("ANRIOD");
		deviceEntity.setFcmToken("");
		deviceEntity.setIsActive(true);
		deviceEntity.setMobileNumber("9821611022");
		deviceEntity.setName("ReshmaChougule");
		deviceEntity.setPanNumber("DILPK0000M");
		try {
			deviceEntity.setRegisteredOn(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse("2019-07-22 19:44:37.2220000"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		deviceEntity.setRequestId(190);
		deviceEntity.setSapCode("");
		deviceList.add(deviceEntity);
		return deviceList;
	}

	public static List<DeviceRegistrationModel> prepareDeviceEntityListTwoData(String deviceIdentifier,String moblieNo,String panNo,String sapCode,String deviceIdentifier2,String moblieNo2,String panNo2,String sapCode2) {
		List<DeviceRegistrationModel> deviceList = new ArrayList<>();
		DeviceRegistrationModel deviceEntity = new DeviceRegistrationModel();
		deviceEntity.setAppVersion("1.0");
		deviceEntity.setDeviceIdentifier(deviceIdentifier);
		deviceEntity.setDeviceType("ANRIOD");
		deviceEntity.setFcmToken("");
		deviceEntity.setIsActive(true);
		deviceEntity.setMobileNumber(moblieNo);
		deviceEntity.setName("ReshmaChougule");
		deviceEntity.setPanNumber(panNo);
		try {
			deviceEntity.setRegisteredOn(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse("2019-07-22 19:44:37.2220000"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		deviceEntity.setRequestId(190);
		deviceEntity.setSapCode(sapCode);
		deviceList.add(deviceEntity);
		DeviceRegistrationModel deviceEntity1 = new DeviceRegistrationModel();
		deviceEntity1.setAppVersion("1.0");
		deviceEntity1.setDeviceIdentifier(deviceIdentifier2);
		deviceEntity1.setDeviceType("ANRIOD");
		deviceEntity1.setFcmToken("");
		deviceEntity1.setIsActive(true);
		deviceEntity1.setMobileNumber(moblieNo2);
		deviceEntity1.setName("ReshmaChougule");
		deviceEntity1.setPanNumber(panNo2);
		try {
			deviceEntity1.setRegisteredOn(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse("2019-07-22 19:44:37.2220000"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		deviceEntity1.setRequestId(191);
		deviceEntity1.setSapCode(sapCode2);
		deviceList.add(deviceEntity1);
		return deviceList;
	}
	
	@SuppressWarnings("static-access")
	public static EmployeeCheckInCheckOutResBean prepareEmployeeCheckInCheckOutResForService(String type) 
	{
		if(type==null || type.equalsIgnoreCase(""))
		{
			throw new CheckInCheckOutException();
		}
		EmployeeCheckInCheckOutResBean employeeCheckInCheckOutResBean=new EmployeeCheckInCheckOutResBean();
		employeeCheckInCheckOutResBean.setDate(String.valueOf(new LocalDate().now()));
		employeeCheckInCheckOutResBean.setTime(String.valueOf(new SimpleDateFormat(GenericConstants.PATTERN_HH_MM_SS).format(new Date())));
		employeeCheckInCheckOutResBean.setType(type);
		employeeCheckInCheckOutResBean.setStatus("true");
		return employeeCheckInCheckOutResBean;
	}
	
	public static DeviceRegistrationModel prepareDeviceRegistrationModalWhenSync(String deviceIdentifier,String moblieNo,String panNo,String sapCode) {
		DeviceRegistrationModel deviceEntity = new DeviceRegistrationModel();
		deviceEntity.setAppVersion("1.0");
		deviceEntity.setDeviceIdentifier(deviceIdentifier);
		deviceEntity.setDeviceType("ANRIOD");
		deviceEntity.setFcmToken("");
		deviceEntity.setIsActive(true);
		deviceEntity.setMobileNumber(moblieNo);
		deviceEntity.setName("ReshmaChougule");
		deviceEntity.setPanNumber(panNo);
		try {
			deviceEntity.setRegisteredOn(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse("2019-07-22 19:44:37.2220000"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		deviceEntity.setRequestId(190);
		deviceEntity.setSapCode(sapCode);
		deviceEntity.setIsSync(true);
		return deviceEntity;
	}
	
	public static DeviceRegistrationModel prepareDeviceRegistrationModalWhenNotSync(String deviceIdentifier,String moblieNo,String panNo,String sapCode) {
		DeviceRegistrationModel deviceEntity = new DeviceRegistrationModel();
		deviceEntity.setAppVersion("1.0");
		deviceEntity.setDeviceIdentifier(deviceIdentifier);
		deviceEntity.setDeviceType("ANRIOD");
		deviceEntity.setFcmToken("");
		deviceEntity.setIsActive(true);
		deviceEntity.setMobileNumber(moblieNo);
		deviceEntity.setName("ReshmaChougule");
		deviceEntity.setPanNumber(panNo);
		try {
			deviceEntity.setRegisteredOn(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse("2019-07-22 19:44:37.2220000"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		deviceEntity.setRequestId(190);
		deviceEntity.setSapCode(sapCode);
		deviceEntity.setIsSync(false);
		return deviceEntity;
	}
	
	public static LinkedAppConfigrationModel prepareLinkedAppConfigrationModal() {
		LinkedAppConfigrationModel updatedValue=new LinkedAppConfigrationModel();
		updatedValue.setIsActive('1');
		updatedValue.setApplicationDescription("Description Test");
		updatedValue.setVersion("V1");
		updatedValue.setJsonConfig(TestConstant.GET_CONFIG.toString());
		updatedValue.setComment("Test Data");
		return updatedValue;
	}
	
	public static LinkedAppConfigRes prepareLinkedAppResponse() throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper=new ObjectMapper();
		LinkedAppConfigRes linkedAppConfigRes=new LinkedAppConfigRes();
		linkedAppConfigRes.setApplicationConfiguration(mapper.readValue(TestConstant.GET_CONFIG.toString(), LinkedApplicationReq.class));
		return linkedAppConfigRes;
	}
	
	public static LocateBranchResBean prepareLocateBranchResBean()
	{
		LocateBranchResBean locateBranchResBean=new LocateBranchResBean();
		for(int i=0;i<=5;i++)
		{
			LocateBranches localBranches=new LocateBranches();
			localBranches.setName("TEST NAME "+i);
			localBranches.setAddress("TEST ADDRESS "+i);
			localBranches.setCode("TEST CODE "+i);
			UserLocation userLocation=new UserLocation();
			userLocation.setLatitude("TEST LATITUDE "+i);
			userLocation.setLongitude("TEST LONGITUDE "+i);
			localBranches.setLocation(userLocation);
			locateBranchResBean.getBranches().add(localBranches);
			userLocation=null;
			localBranches=null;
		}
		return locateBranchResBean;
	}
	
	public static List<RnlicBranchDetailBean> prepareListOfRnlicBranchDetailBean(){
		List<RnlicBranchDetailBean> listOfBean=new ArrayList<>();
		for(int i=0;i<=5;i++)
		{
			RnlicBranchDetailBean rnlicBranchDetailBean=new RnlicBranchDetailBean();
			rnlicBranchDetailBean.setBranch("TEST BRANCH "+i);
			rnlicBranchDetailBean.setBranchCode("TEST CODE "+i);
			rnlicBranchDetailBean.setAddress("TEST ADDRESS "+i);
			rnlicBranchDetailBean.setLatitude("TEST LATITUDE "+i);
			rnlicBranchDetailBean.setLongitude("TEST LONGITUDE "+i);
			listOfBean.add(rnlicBranchDetailBean);
			rnlicBranchDetailBean=null;
		}
		return listOfBean;
	}
	
	public static StateCityMasterResBean prepareStateCityMasterDetails() {
		StateCityMasterResBean stateCityMasterResBean=new StateCityMasterResBean();
		StateDetails stateDetails=null;
		CityDetails cityDetails=null;
		for(int i=0;i<=5;i++)
		{
			stateDetails=new StateDetails();
			stateDetails.setStateCode("State0000"+i);
			stateDetails.setStateName("State Name - "+i);
			for(int j=i;j<=10;j++)
			{
				cityDetails = new CityDetails();
				cityDetails.setCityCode("City0000"+j);
				cityDetails.setCityName("City Name - "+j);
				stateDetails.getCities().add(cityDetails);
			}
			stateCityMasterResBean.getStates().add(stateDetails);
			stateDetails = null;
			cityDetails = null;
		}
		return stateCityMasterResBean;
	}
	
	public static AttendanceDetailsResBean prepareAttendanceDtls() {
		AttendanceDetailsResBean attendanceDetailsResBean = new  AttendanceDetailsResBean();
		attendanceDetailsResBean.setFirstName("Reshma");
		attendanceDetailsResBean.setLastName("Chougule");
		attendanceDetailsResBean.setMonth("7");
		attendanceDetailsResBean.setSapCode("70009002");
		attendanceDetailsResBean.setYear("2019");
		for(int i=0;i<=8;i++)
		{
				Attendance attendance = new Attendance();
				attendance.setAttendanceCode("AD7666789-485596BRT"+i);
				attendance.setCheckIn("9:0"+i+" AM");
				attendance.setCheckOut("6:0"+i+" PM");
				attendance.setDayOfWeek("5");
				attendance.setCheckInBranch("BIPL");
				attendance.setCheckInBranchAddress("Omega Building Sector-V Kolkata");
				attendance.setCheckOutBranch("BIPL");
				attendance.setCheckOutBranchAddress("Omega Building Sector-V Kolkata");
				attendance.setDate("2019-09-08");
				attendanceDetailsResBean.getAttendance().add(attendance);
		}
		return attendanceDetailsResBean;
	}
	
	public static List<ReporteeDetails> prepareReporteeList()
	{
		List<ReporteeDetails> reporteeList = new ArrayList<>();
		for (int i=1;i<=5;i++) {
			ReporteeDetails reporteeDtls = new ReporteeDetails();
			reporteeDtls.setHasAnyReportee(GenericConstants.TRUE);
			reporteeDtls.setManagerName("Manager-"+i);
			reporteeDtls.setManagerSapCode("7000900"+i);
			reporteeDtls.setName("Reportee-"+i);
			reporteeDtls.setSapCode("725821"+i);
			reporteeList.add(reporteeDtls);
		}
		return reporteeList;
	}
	
	public static BirthdayResBean prepareBirthdayList() {
		List<Birthday> birthDayList = new ArrayList<>();
		for (int i=1;i<=5;i++) {
			Birthday birthday = new Birthday();
			birthday.setChannel("Channel-"+i);
			birthday.setDateOfBirth("01-0"+i+"-200"+i);
			birthday.setEmail("EMAIL-"+i);
			birthday.setManagerSapcode("ManagerSapCode-"+i);
			birthday.setMobile("995578525"+i);
			birthday.setRegion("Region");
			birthday.setSapCode("7008600"+i);
			birthday.setZone("Zone");
			birthday.setName("Name-"+i);
			birthDayList.add(birthday);
		}
		return new BirthdayResBean(birthDayList);
	}
	
	public static AnniversaryResBean prepareAnniversaryList() {
		List<Anniversary> anniversaryList = new ArrayList<>();
		for (int i=1;i<=5;i++) {
			Anniversary anniversaryDtls = new Anniversary();
			anniversaryDtls.setChannel("Channel");
			anniversaryDtls.setJoinDate("01-0"+i+"-200"+i);
			anniversaryDtls.setEmail("EMAIL-"+i);
			anniversaryDtls.setManagerSapcode("ManagerSapCode-"+i);
			anniversaryDtls.setMobile("995578525"+i);
			anniversaryDtls.setRegion("Region");
			anniversaryDtls.setSapCode("7008600"+i);
			anniversaryDtls.setZone("Zone");
			anniversaryDtls.setName("Name-"+i);
			anniversaryList.add(anniversaryDtls);
		}
		return new AnniversaryResBean(anniversaryList);
	}
	
	public static OtpMasterModel prepareOtpDetails(String sapCode, String mobileNumber, String action, String deviceIdentifier) {
		OtpMasterModel otpMasterModel=new OtpMasterModel();
		otpMasterModel.setAction(action);
		otpMasterModel.setCountryCode("25");
		otpMasterModel.setDeviceIdentifier(deviceIdentifier);
		otpMasterModel.setGeneratedOn(new Date());
		otpMasterModel.setMobileNumber(mobileNumber);
		otpMasterModel.setOtpValue(585485);
		otpMasterModel.setResendCount(0);
		otpMasterModel.setRetryCount(0);
		otpMasterModel.setSapCode(sapCode);
		otpMasterModel.setValidUpto(new Date());
		otpMasterModel.setVerified(false);
		return otpMasterModel;
	}
	
	public static MandatoryLearningResBean preparetMandatoryLearning() {
		MandatoryLearningResBean  mandatoryLearningResBean = new MandatoryLearningResBean();
		LearningDetails learnings = null;
		for(int i=0;i<3;i++)
		{
			learnings = new LearningDetails();
			learnings.setDocumentName("abc"+i);
			learnings.setDocumentUploadDate("2019-07-23T11:14:28.617");
			learnings.setLearningId("AZZ"+(i+i)+"BB"+i);
			learnings.setLearningLink("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getMandatoryLearningFile?DocumentName=ISMS-%20RNLIC-%20Awareness.pdf");
			learnings.setLearningName("SERVADDTEST"+i+"00"+i);
			mandatoryLearningResBean.getMandatoryLearnings().add(learnings);
			learnings=null;
		}
		return mandatoryLearningResBean;
	}
	
	public static MandatoryLearningStatusResBean prepareMandatoryLearningStatus() {
		MandatoryLearningStatusResBean  mandatoryLearningResBean = new MandatoryLearningStatusResBean();
		MandatoryLearningDetails learnings = null;
		for(int i=0;i<3;i++)
		{
			learnings = new MandatoryLearningDetails();
			learnings.setLearningId("7866"+i);
			learnings.setStatus("AML_KYC"+i);
			mandatoryLearningResBean.getMandatoryLearnings().add(learnings);
		}
		return mandatoryLearningResBean;
	}
	
	public static ShareBranchDetailsReqBean prepareShareBranchDetailsReqBean() {
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = new ShareBranchDetailsReqBean();
		shareBranchDetailsReqBean.setEmailAddress("axxx@gmail.com");
		shareBranchDetailsReqBean.setMobileNo("9711695460");
		LocateBranches locateBranches = new LocateBranches();
		locateBranches.setAddress("Address");
		locateBranches.setCode("CODE");
		locateBranches.setContactNumber("Contact Number");
		locateBranches.setContactPerson("Contact Person");
		locateBranches.setEmail("Email");
		UserLocation userLocation =new UserLocation();
		userLocation.setLatitude("lattitude");
		userLocation.setLongitude("longitude");
		locateBranches.setLocation(userLocation);
		shareBranchDetailsReqBean.setLocateBranches(locateBranches);
		return shareBranchDetailsReqBean;
	}
	
	public static EmployeeRnlicResponseBean prepareEmployeeRnlicResponseBean() throws JsonParseException, JsonMappingException, IOException {
		EmployeeRnlicResponseBean employeeRnlicResponseBean = new EmployeeRnlicResponseBean();
		employeeRnlicResponseBean.setStatus("Sucess");	
		employeeRnlicResponseBean.setMessage("Data Found.");
		List<EmployeeDetailsRnlicResponseBean> response =new ArrayList<>();
		EmployeeDetailsRnlicResponseBean employeeDetailsRnlicResponseBean=new EmployeeDetailsRnlicResponseBean();
		employeeDetailsRnlicResponseBean.setChannel("IT");
		employeeDetailsRnlicResponseBean.setEmailID("RESHMA.CHOUGULE@RELIANCEADA.COM");
		employeeDetailsRnlicResponseBean.setLevel("IL5B (E3)");
		employeeDetailsRnlicResponseBean.setLocationCode("MUF7");
		employeeDetailsRnlicResponseBean.setLocationName("MU - Goregaon Office");
		employeeDetailsRnlicResponseBean.setManagerName("Joylee Olwin Dias");
		employeeDetailsRnlicResponseBean.setManagerSAPCode("70009002");
		employeeDetailsRnlicResponseBean.setMobileNo("+91-9821611022");
		employeeDetailsRnlicResponseBean.setName("Reshma Ankush Chougule");
		employeeDetailsRnlicResponseBean.setPanNumber(null);
		employeeDetailsRnlicResponseBean.setRole("ASSISTANT MANAGER");
		employeeDetailsRnlicResponseBean.setSapCode("70285945");
		employeeDetailsRnlicResponseBean.setUserRole("NON SALES");
		employeeDetailsRnlicResponseBean.setZoneCode("");
		employeeDetailsRnlicResponseBean.setZoneName("CORPORATE");
		response.add(employeeDetailsRnlicResponseBean);
		employeeRnlicResponseBean.setResponse(response);
		return employeeRnlicResponseBean;
	}
	
	public static URLConstruct getListOfUrls() {
		URLConstruct urlConstruct =new URLConstruct();
		urlConstruct.setEmployeeDetailsRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getEmployeeDetails");
		urlConstruct.setCandidateDetailsRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getCandidateDetails");
		urlConstruct.setEmployeeAuthServiceRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/employeeAuthService");
		urlConstruct.setCandidateAuthServiceRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/candidateAuthService");
		urlConstruct.setSendSmsRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/SMSOTP");
		urlConstruct.setEmployeeCheckInRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/employeeCheckin");
		urlConstruct.setEmployeeCheckOutRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/employeeCheckout");
		urlConstruct.setTodayBirthdayRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getEmpBirthdayList/Daywise/{strDate}");
		urlConstruct.setListOfReporteeRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getReporteeList/{sapCode}");
		urlConstruct.setSendBirthdaySmsRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/wishEmployee/Birthday/SMS/{sapCode}");
		urlConstruct.setSendBirthdayEmailRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/wishEmployee/Birthday/Email/{sapCode}");
		urlConstruct.setTodayAnniversaryRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getWorkAnniversaryList/Daywise/{strDate}");
		urlConstruct.setSearchBirthdayRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getEmpBirthdayDetails");
		urlConstruct.setAttendanceDetailsRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getEmpAttendanceDetailsMonthly");
		urlConstruct.setStateCityMaster("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getStateCityMaster");
		urlConstruct.setLocateBranch("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/locateBranch");
		urlConstruct.setGetDeviceRegistrationRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getRegDeviceInfo");
		urlConstruct.setUpdateDeviceRegistrationRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/updateRegDeviceInfo");
		urlConstruct.setHavingTroubleWithLogin("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/havingTroubleWithLogin");
		urlConstruct.setGetMandatoryLearnigsRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getMandatoryLearning");
		urlConstruct.setGetMandatoryLearnigsStatusRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getMandatoryLearningStatus/{sapCode}");
		urlConstruct.setUpdateMandatoryLearnigsStatusRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/updateLearningCompletionStatus");
		urlConstruct.setSendAnniversaryEmailRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/wishEmployee/Birthday/Email/{sapCode}");
		urlConstruct.setSendAnniversarySmsRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/wishEmployee/Birthday/SMS/{sapCode}");
		urlConstruct.setChangePassword("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/changePassword");
		urlConstruct.setChangePasswordRequestRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/changePasswordRequest");
		urlConstruct.setUpdatePasswordRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/updatePasswordRequest");
		urlConstruct.setNoticesRnlicUrl("http://10.126.248.47/HRAppWebAPI/api/EmpAttendence/getNotices");
		urlConstruct.setPushNotification("https://fcm.googleapis.com/fcm/send");
		return urlConstruct;
	}
	
	public static AttendanceDetailsResBean prepareAttandanceDtls() {
		AttendanceDetailsResBean temp = new AttendanceDetailsResBean();
		temp.setFirstName("Reshma");
		temp.setLastName("Chougle");
		temp.setMonth("07");
		temp.setSapCode("8748152");
		temp.setYear("2019");
		return temp;
	}
	
	public static TroubleWithLoginResBean prepareTroubleWithLoginDetails() {
		TroubleWithLoginResBean troubleWithLoginResBean = new TroubleWithLoginResBean();
		troubleWithLoginResBean.setContactEmail("abc@gmail.com");
		troubleWithLoginResBean.setContactNumber("+91-XXXXXXXXXX");
		troubleWithLoginResBean.setHelpMessage("Test Message");
		return troubleWithLoginResBean;
	}
	
	public static User prepareUserdetails() {
		List<String> role= new ArrayList<>();
		role.add("ASSISTANT MANAGER");
		User user=new User();
		user.setChannel("IT");
		user.setChannel("IT");
		user.setEmail("RESHMA.CHOUGULE@RELIANCEADA.COM");
		user.setLevel("IL5B (E3)");
		user.setLocationCode("MUF7");
		user.setLocationName("MU - Goregaon Office");
		user.setManagerName("Joylee Olwin Dias");
		user.setManagerSapCode("70009002");
		user.setMobileNo("+91-9821611022");
		user.setFirstName("Reshma Ankush Chougule");
		user.setPanNo(null);
		user.setOrgRoles(role);
		user.setSapCode("70285945");
		user.setUserRole("NON SALES");
		user.setZoneCode("");
		user.setZoneName("CORPORATE");
		return user;
	}
	
	public static EmployeeRnlicResponseBean prepareEmployeeRnlicResponseNoDataFoundBean() throws JsonParseException, JsonMappingException, IOException {
		EmployeeRnlicResponseBean employeeRnlicResponseBean = new EmployeeRnlicResponseBean();
		employeeRnlicResponseBean.setStatus("Sucess");	
		employeeRnlicResponseBean.setMessage("No Data Found.");
		List<EmployeeDetailsRnlicResponseBean> response = null;
		employeeRnlicResponseBean.setResponse(response);
		return employeeRnlicResponseBean;
	}
	
	public static EmployeeRnlicResponseBean prepareEmployeeRnlicResponseFailedBean() throws JsonParseException, JsonMappingException, IOException {
		EmployeeRnlicResponseBean employeeRnlicResponseBean = new EmployeeRnlicResponseBean();
		employeeRnlicResponseBean.setStatus(GenericConstants.FAILED);	
		employeeRnlicResponseBean.setMessage(GenericConstants.FAILED);
		List<EmployeeDetailsRnlicResponseBean> response = null;
		employeeRnlicResponseBean.setResponse(response);
		return employeeRnlicResponseBean;
	}
	
	public static EmployeeRnlicResponseBean prepareEmployeeRnlicResponseFailureBean() throws JsonParseException, JsonMappingException, IOException {
		EmployeeRnlicResponseBean employeeRnlicResponseBean = new EmployeeRnlicResponseBean();
		employeeRnlicResponseBean.setStatus(GenericConstants.FAILURE);	
		employeeRnlicResponseBean.setMessage(GenericConstants.FAILURE);
		List<EmployeeDetailsRnlicResponseBean> response = null;
		employeeRnlicResponseBean.setResponse(response);
		return employeeRnlicResponseBean;
	}
	
	public static EmployeeRnlicResponseBean prepareEmployeeRnlicResponseUnknownBean() throws JsonParseException, JsonMappingException, IOException {
		EmployeeRnlicResponseBean employeeRnlicResponseBean = new EmployeeRnlicResponseBean();
		employeeRnlicResponseBean.setStatus("Unknown");	
		employeeRnlicResponseBean.setMessage(GenericConstants.FAILURE);
		List<EmployeeDetailsRnlicResponseBean> response = null;
		employeeRnlicResponseBean.setResponse(response);
		return employeeRnlicResponseBean;
	}
	
	public static RnlicAuthRes prepareRnlicAuthRes() {
		RnlicAuthRes rnlicAuthRes = new RnlicAuthRes();
		rnlicAuthRes.setStatus(GenericConstants.SUCCESS);
		return rnlicAuthRes;
	}
	
	public static RnlicAuthRes prepareRnlicAuthResFailure() {
		RnlicAuthRes rnlicAuthRes = new RnlicAuthRes();
		rnlicAuthRes.setStatus(GenericConstants.FAILURE);
		return rnlicAuthRes;
	}
	
	public static RnlicAuthRes prepareRnlicAuthResUnknown() {
		RnlicAuthRes rnlicAuthRes = new RnlicAuthRes();
		rnlicAuthRes.setStatus("Unknown");
		return rnlicAuthRes;
	}
	
	public static RnlicAuthRes prepareRnlicAuthResFailed() {
		RnlicAuthRes rnlicAuthRes = new RnlicAuthRes();
		rnlicAuthRes.setStatus(GenericConstants.FAILED);
		return rnlicAuthRes;
	}
	
	public static SendOtpRnlicResponseBean prepareSendOtpRnlicResponseBean() {
		SendOtpRnlicResponseBean res= new SendOtpRnlicResponseBean();
		res.setMessage("Message send successfuly");
		res.setStatus(GenericConstants.SUCCESS);
		return res;
	}
	
	public static SendOtpRnlicResponseBean prepareSendOtpRnlicFailureResponseBean() {
		SendOtpRnlicResponseBean res= new SendOtpRnlicResponseBean();
		res.setMessage("Message sending failed");
		res.setStatus(GenericConstants.FAILURE);
		return res;
	}
	
	public static SendOtpRnlicResponseBean prepareSendOtpRnlicFailedResponseBean() {
		SendOtpRnlicResponseBean res= new SendOtpRnlicResponseBean();
		res.setMessage("Message sending failed");
		res.setStatus(GenericConstants.FAILED);
		return res;
	}
	
	public static SendOtpRnlicResponseBean prepareSendOtpRnlicUnknownResponseBean() {
		SendOtpRnlicResponseBean res= new SendOtpRnlicResponseBean();
		res.setMessage("Message sending failed");
		res.setStatus("fatal");
		return res;
	}
	
	public static CheckInCheckOutRnlicResponseBean prepareCheckInResponseBean() {
		CheckInCheckOutDateTimeResponseBean data = new CheckInCheckOutDateTimeResponseBean();
		data.setCheckInTime("08/30/19  1:55:46 PM");
		List<CheckInCheckOutDateTimeResponseBean> response = new ArrayList<>();
		response.add(data);
		CheckInCheckOutRnlicResponseBean res = new CheckInCheckOutRnlicResponseBean();
		res.setStatus(GenericConstants.SUCCESS);
		res.setMessage("CheckIn marked successfully.");
		res.setResponse(response);
		return res;
	}
	
	public static CheckInCheckOutRnlicResponseBean prepareCheckInAlreadyMarkedResponseBean() {
		CheckInCheckOutDateTimeResponseBean data = new CheckInCheckOutDateTimeResponseBean();
		data.setCheckInTime("08/30/19  1:55:46 PM");
		List<CheckInCheckOutDateTimeResponseBean> response = new ArrayList<>();
		response.add(data);
		CheckInCheckOutRnlicResponseBean res = new CheckInCheckOutRnlicResponseBean();
		res.setStatus(GenericConstants.FAILED);
		res.setMessage("Sorry! Your Attendance is already marked for the day");
		res.setResponse(response);
		return res;
	}
	
	public static CheckInCheckOutRnlicResponseBean prepareCheckInAlreadyMarkedResponseExceptionBean() {
		CheckInCheckOutRnlicResponseBean res = new CheckInCheckOutRnlicResponseBean();
		res.setStatus(GenericConstants.FAILED);
		res.setMessage("Failed");
		return res;
	}
	
	public static CheckInCheckOutRnlicResponseBean prepareCheckInAlreadyMarkedDataResponseBean() {
		CheckInCheckOutDateTimeResponseBean data = new CheckInCheckOutDateTimeResponseBean();
		data.setCheckInTime(null);
		List<CheckInCheckOutDateTimeResponseBean> response = new ArrayList<>();
		response.add(data);
		CheckInCheckOutRnlicResponseBean res = new CheckInCheckOutRnlicResponseBean();
		res.setStatus(GenericConstants.FAILED);
		res.setMessage("Sorry! Your Attendance is already marked for the day");
		res.setResponse(response);
		return res;
	}
	
	public static CheckInCheckOutRnlicResponseBean prepareCheckInAlreadyMarkedErrorResponseBean() {
		List<CheckInCheckOutDateTimeResponseBean> response = new ArrayList<>();
		ErrorRnlicResponseBean er=new ErrorRnlicResponseBean();
		er.setField("field");
		er.setMessage("field is missing");
		ErrorRnlicResponseBean er2=new ErrorRnlicResponseBean();
		er2.setField("field 2");
		er2.setMessage("field 2 is missing");
		List<ErrorRnlicResponseBean> errors = new ArrayList<>();
		errors.add(er);
		errors.add(er2);
		CheckInCheckOutRnlicResponseBean res = new CheckInCheckOutRnlicResponseBean();
		res.setStatus(GenericConstants.FAILED);
		res.setMessage("Sorry! Your CheckIn is already marked for the day.");
		res.setResponse(response);
		res.setErrors(errors);
		return res;
	}
	
	public static CheckInCheckOutRnlicResponseBean prepareCheckFailureResponseBean() {
		CheckInCheckOutRnlicResponseBean res = new CheckInCheckOutRnlicResponseBean();
		res.setStatus(GenericConstants.FAILURE);
		res.setMessage("Server Failure");
		res.setResponse(null);
		return res;
	}
	
	public static CheckInCheckOutRnlicResponseBean prepareCheckUnknownResponseBean() {
		CheckInCheckOutDateTimeResponseBean data = new CheckInCheckOutDateTimeResponseBean();
		List<CheckInCheckOutDateTimeResponseBean> response = new ArrayList<>();
		response.add(data);
		CheckInCheckOutRnlicResponseBean res = new CheckInCheckOutRnlicResponseBean();
		res.setStatus("XXXX");
		res.setMessage("Server Failure");
		res.setResponse(response);
		return res;
	}
	
	public static CheckInCheckOutRnlicResponseBean prepareCheckOutResponseBean() {
		CheckInCheckOutDateTimeResponseBean data = new CheckInCheckOutDateTimeResponseBean();
		data.setCheckInTime("08/30/19  1:55:46 PM");
		data.setCheckOutTime("08/30/19  1:59:16 PM");
		List<CheckInCheckOutDateTimeResponseBean> response = new ArrayList<>();
		response.add(data);
		CheckInCheckOutRnlicResponseBean res = new CheckInCheckOutRnlicResponseBean();
		res.setStatus(GenericConstants.SUCCESS);
		res.setMessage("CheckOut marked successfully.");
		res.setResponse(response);
		return res;
	}
	
	public static CheckInCheckOutRnlicResponseBean prepareCheckOutAlreadyMarkedResponseBean() {
		CheckInCheckOutDateTimeResponseBean data = new CheckInCheckOutDateTimeResponseBean();
		data.setCheckInTime("08/30/19  1:55:46 PM");
		data.setCheckOutTime("08/30/19  1:59:16 PM");
		List<CheckInCheckOutDateTimeResponseBean> response = new ArrayList<>();
		response.add(data);
		CheckInCheckOutRnlicResponseBean res = new CheckInCheckOutRnlicResponseBean();
		res.setStatus(GenericConstants.FAILED);
		res.setMessage("Sorry! Your CheckOut is already marked for the day");
		res.setResponse(response);
		return res;
	}
	
	public static CheckInCheckOutRnlicResponseBean prepareCheckOutAlreadyMarkedExceptionResponseBean() {
		CheckInCheckOutRnlicResponseBean res = new CheckInCheckOutRnlicResponseBean();
		res.setStatus(GenericConstants.FAILED);
		res.setMessage("Failed");
		return res;
	}
	
	public static CheckInCheckOutRnlicResponseBean prepareCheckOutAlreadyMarkedResponseDataBean() {
		CheckInCheckOutDateTimeResponseBean data = new CheckInCheckOutDateTimeResponseBean();
		data.setCheckInTime("08/30/19  1:55:46 PM");
		data.setCheckOutTime(null);
		List<CheckInCheckOutDateTimeResponseBean> response = new ArrayList<>();
		response.add(data);
		CheckInCheckOutRnlicResponseBean res = new CheckInCheckOutRnlicResponseBean();
		res.setStatus(GenericConstants.FAILED);
		res.setMessage("Sorry! Your CheckOut is already marked for the day");
		res.setResponse(response);
		return res;
	}
	
	public static EmployeeCheckInCheckOutResBean prepareEmployeeCheckInCheckOutRes(String type,
			CheckInCheckOutRnlicResponseBean response) 
	{
		EmployeeCheckInCheckOutResBean employeeCheckInCheckOutResBean = new EmployeeCheckInCheckOutResBean();
		CheckInCheckOutDateTimeResponseBean checkInCheckOutDateTimeResponseBean = response.getResponse().get(0);
		if(null!=checkInCheckOutDateTimeResponseBean && type.equalsIgnoreCase("check-in")) {
			employeeCheckInCheckOutResBean.setDate(generateDateForCheckInCheckout(checkInCheckOutDateTimeResponseBean.getCheckInTime()));
			employeeCheckInCheckOutResBean.setTime(generateTimeForCheckInCheckout(checkInCheckOutDateTimeResponseBean.getCheckInTime()));
		}
		else if(null!=checkInCheckOutDateTimeResponseBean && type.equalsIgnoreCase("check-out")) {
			employeeCheckInCheckOutResBean.setDate(generateDateForCheckInCheckout(checkInCheckOutDateTimeResponseBean.getCheckOutTime()));
			employeeCheckInCheckOutResBean.setTime(generateTimeForCheckInCheckout(checkInCheckOutDateTimeResponseBean.getCheckOutTime()));
		}
		employeeCheckInCheckOutResBean.setType(type);
		employeeCheckInCheckOutResBean.setStatus(response.getStatus());
		employeeCheckInCheckOutResBean.setMessage(response.getMessage());
		return employeeCheckInCheckOutResBean;
	}
	
	private static String generateDateForCheckInCheckout(String dateTime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(GenericConstants.PATTERN_CHECK_IN_CHECK_OUT);
		LocalDateTime date = LocalDateTime.parse(generateDateTimeFormatForCheckInCheckOut(dateTime), formatter);
		return String.valueOf(date.toLocalDate());
	}
	
	private static String generateTimeForCheckInCheckout(String dateTime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(GenericConstants.PATTERN_CHECK_IN_CHECK_OUT);
		LocalDateTime date = LocalDateTime.parse(generateDateTimeFormatForCheckInCheckOut(dateTime), formatter);
		return String.valueOf(date.toLocalTime());
	}
	
	private static String generateDateTimeFormatForCheckInCheckOut(String dateTime) {
		String[] dateParam = dateTime.split(" ");
		String data = "";
		for(int i=0;i<dateParam.length;i++){
			if(data.equals("") && !dateParam[i].equalsIgnoreCase("")){
				data = dateParam[i].trim();
			}
			else {
				if(!dateParam[i].equalsIgnoreCase(""))
				{
					data = data+" "+dateParam[i].trim();
				}
			}
		}
		return data;
	}
	
	public static BirthdayListRnlicResponseBean prepareBirthdayListRnlicResponseBean() {
		BirthdayListRnlicResponseBean res = new BirthdayListRnlicResponseBean();
		res.setStatus(GenericConstants.SUCCESS);
		res.setMessage(GenericConstants.DATA_FOUND);
		return res;
	}
	
	public static BirthdayListRnlicResponseBean prepareBirthdayListRnlicNoDataResponseBean() {
		BirthdayListRnlicResponseBean res = new BirthdayListRnlicResponseBean();
		res.setStatus(GenericConstants.SUCCESS);
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static BirthdayListRnlicResponseBean prepareBirthdayListRnlicFailureResponseBean() {
		BirthdayListRnlicResponseBean res = new BirthdayListRnlicResponseBean();
		res.setStatus(GenericConstants.FAILURE);
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static BirthdayListRnlicResponseBean prepareBirthdayListRnlicFailedResponseBean() {
		BirthdayListRnlicResponseBean res = new BirthdayListRnlicResponseBean();
		res.setStatus(GenericConstants.FAILED);
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static BirthdayListRnlicResponseBean prepareBirthdayListRnlicUnknownResponseBean() {
		BirthdayListRnlicResponseBean res = new BirthdayListRnlicResponseBean();
		res.setStatus("Unknown");
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static AnniversaryListRnlicResponseBean prepareAnniversaryListRnlicResponseBean() {
		AnniversaryListRnlicResponseBean res = new AnniversaryListRnlicResponseBean();
		res.setStatus(GenericConstants.SUCCESS);
		res.setMessage(GenericConstants.DATA_FOUND);
		return res;
	}
	
	public static AnniversaryListRnlicResponseBean prepareAnniversaryListRnlicNoDataResponseBean() {
		AnniversaryListRnlicResponseBean res = new AnniversaryListRnlicResponseBean();
		res.setStatus(GenericConstants.SUCCESS);
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static AnniversaryListRnlicResponseBean prepareAnniversaryListRnlicFailureResponseBean() {
		AnniversaryListRnlicResponseBean res = new AnniversaryListRnlicResponseBean();
		res.setStatus(GenericConstants.FAILURE);
		return res;
	}
	
	public static AnniversaryListRnlicResponseBean prepareAnniversaryListRnlicFailedResponseBean() {
		AnniversaryListRnlicResponseBean res = new AnniversaryListRnlicResponseBean();
		res.setStatus(GenericConstants.FAILED);
		return res;
	}
	
	public static AnniversaryListRnlicResponseBean prepareAnniversaryListRnlicUnknownResponseBean() {
		AnniversaryListRnlicResponseBean res = new AnniversaryListRnlicResponseBean();
		res.setStatus("Unknown");
		return res;
	}
	
	public static ReporteeListRnlicResponseBean prepareReporteeListRnlicResponseBean() {
		ReporteeListRnlicResponseBean response = new ReporteeListRnlicResponseBean();
		response.setStatus(GenericConstants.SUCCESS);
		return response;
	}
	
	public static ReporteeListRnlicResponseBean prepareReporteeListRnlicFailureResponseBean() {
		ReporteeListRnlicResponseBean response = new ReporteeListRnlicResponseBean();
		response.setStatus(GenericConstants.FAILURE);
		return response;
	}
	
	public static ReporteeListRnlicResponseBean prepareReporteeListRnlicFailedResponseBean() {
		ReporteeListRnlicResponseBean response = new ReporteeListRnlicResponseBean();
		response.setStatus(GenericConstants.FAILED);
		return response;
	}
	
	public static ReporteeListRnlicResponseBean prepareReporteeListRnlicUnknownResponseBean() {
		ReporteeListRnlicResponseBean response = new ReporteeListRnlicResponseBean();
		response.setStatus("Unknown");
		return response;
	}
	
	public static RnlicAuthRes prepareEmaiResponse() {
		RnlicAuthRes res = new RnlicAuthRes();
		res.setStatus(GenericConstants.SUCCESS);
		res.setResponse("Mail Send Successfuly");
		return res;
	}
	
	public static RnlicAuthRes prepareEmaiNullStatusResponse() {
		RnlicAuthRes res = new RnlicAuthRes();
		res.setResponse("Mail Send Successfuly");
		return res;
	}
	
	public static BirthdaySmsResBean prepareSMSResponse() {
		BirthdaySmsResBean res = new BirthdaySmsResBean();
		res.setStatus(GenericConstants.SUCCESS);
		res.setMessage("Message Send Successfuly");
		return res;
	}
	
	public static BirthdaySmsResBean prepareSMSNullStatusResponse() {
		BirthdaySmsResBean res = new BirthdaySmsResBean();
		res.setMessage("Message Send Successfuly");
		return res;
	}
	
	public static LearningStatusUpdateResponseBean prepareLearningStatusUpdateResponseBean() {
		LearningStatusUpdateResponseBean res =new LearningStatusUpdateResponseBean();
		res.setStatus(GenericConstants.SUCCESS);
		return res;
	}
	
	public static LearningStatusUpdateResponseBean prepareLearningStatusUpdateFailedResponseBean() {
		LearningStatusUpdateResponseBean res =new LearningStatusUpdateResponseBean();
		res.setStatus(GenericConstants.FAILED);
		return res;
	}
	
	public static LearningStatusUpdateResponseBean prepareLearningStatusUpdateFailureResponseBean() {
		LearningStatusUpdateResponseBean res =new LearningStatusUpdateResponseBean();
		res.setStatus(GenericConstants.FAILURE);
		return res;
	}
	
	public static LearningStatusUpdateResponseBean prepareLearningStatusUpdateUnknownResponseBean() {
		LearningStatusUpdateResponseBean res =new LearningStatusUpdateResponseBean();
		res.setStatus("Unknown");
		return res;
	}
	
	public static StateCityMasterRnlicResponseBean prepareStateCityMasterRnlicResponseBean() {
		StateCityMasterReqBean data = new StateCityMasterReqBean();
		data.setCity("Kokata");
		data.setState("West Bengal");
		List<StateCityMasterReqBean> stateCityReqBean=new ArrayList<>();
		stateCityReqBean.add(data);
		StateCityMasterRnlicResponseBean res = new StateCityMasterRnlicResponseBean();
		res.setStatus(GenericConstants.SUCCESS);
		res.setMessage(GenericConstants.DATA_FOUND);
		res.setStateCityReqBean(stateCityReqBean);
		return res;
	}
	
	public static StateCityMasterRnlicResponseBean prepareStateCityMasterRnlicFailureResponseBean() {
		StateCityMasterRnlicResponseBean res = new StateCityMasterRnlicResponseBean();
		res.setStatus(GenericConstants.FAILURE);
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static StateCityMasterRnlicResponseBean prepareStateCityMasterRnlicFailedResponseBean() {
		StateCityMasterRnlicResponseBean res = new StateCityMasterRnlicResponseBean();
		res.setStatus(GenericConstants.FAILED);
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static StateCityMasterRnlicResponseBean prepareStateCityMasterRnlicUnknownResponseBean() {
		StateCityMasterRnlicResponseBean res = new StateCityMasterRnlicResponseBean();
		res.setStatus("Unknown");
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static RnlicBranchDetailsListResponseBean prepareRnlicBranchDetailsListResponseBean() {
		RnlicBranchDetailBean data =new RnlicBranchDetailBean();
		data.setAddress("address");
		data.setBranch("branch");
		data.setBranchCode("branchCode");
		data.setLatitude("lattitude");
		data.setLongitude("longitude");
		List<RnlicBranchDetailBean> response =new ArrayList<>();
		response.add(data);
		RnlicBranchDetailsListResponseBean res = new RnlicBranchDetailsListResponseBean();
		res.setStatus(GenericConstants.SUCCESS);
		res.setMessage(GenericConstants.DATA_FOUND);
		res.setResponse(response);
		return res;
	}
	
	public static RnlicBranchDetailsListResponseBean prepareRnlicBranchDetailsListUnknownResponseBean() {
		RnlicBranchDetailsListResponseBean res = new RnlicBranchDetailsListResponseBean();
		res.setStatus("Unknown");
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static RnlicBranchDetailsListResponseBean prepareRnlicBranchDetailsListFailureResponseBean() {
		RnlicBranchDetailsListResponseBean res = new RnlicBranchDetailsListResponseBean();
		res.setStatus(GenericConstants.FAILURE);
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static RnlicBranchDetailsListResponseBean prepareRnlicBranchDetailsListFailedResponseBean() {
		RnlicBranchDetailsListResponseBean res = new RnlicBranchDetailsListResponseBean();
		res.setStatus(GenericConstants.FAILED);
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static LocateBranchResBean prepareBranchDetails() {
		LocateBranchResBean locateBranchResBean =new LocateBranchResBean();
		for(int i=0;i<5;i++)
		{
			LocateBranches localBranches=new LocateBranches();
			localBranches.setName("name"+i);
			localBranches.setAddress("address"+i);
			localBranches.setCode("01"+i);
			UserLocation userLocation=new UserLocation();
			userLocation.setLatitude("latitude"+i);
			userLocation.setLongitude("longitude"+i);
			localBranches.setLocation(userLocation);
			locateBranchResBean.getBranches().add(localBranches);
		};
		return locateBranchResBean;
	}
	
	public static DeviceRegInfoResponseBean prepareDeviceRegInfoResponseBean(char ch) {
		DeviceRegInfoResponseBean res = new DeviceRegInfoResponseBean();
		res.setResponse(GenericConstants.DATA_FOUND);
		if(ch=='A') {
			res.setStatus(GenericConstants.SUCCESS);
		}
		else if(ch=='B')
		{
			res.setStatus(GenericConstants.FAILED);
		}
		else if(ch=='C')
		{
			res.setStatus(GenericConstants.FAILURE);
		}
		else if(ch=='D')
		{
			res.setStatus("Unknown");
		}
		return res;
	}
	
	public static MonthlyAttendanceDetailsRnlicResponseBean prepareMonthlyAttendanceDetailsRnlicResponseBean(char ch) {
		MonthlyAttendanceDetailsRnlicResponseBean res = new MonthlyAttendanceDetailsRnlicResponseBean();
		if(ch=='A') {
			res.setStatus(GenericConstants.SUCCESS);
		}
		else if(ch=='B')
		{
			res.setStatus(GenericConstants.FAILED);
		}
		else if(ch=='C')
		{
			res.setStatus(GenericConstants.FAILURE);
		}
		else if(ch=='D')
		{
			res.setStatus("Unknown");
		}
		return res;
	}
	
	public static MandatoryLearningRnlicResponseBean prepareMandatoryLearningRnlicResponseBean(char ch) {
		MandatoryLearningRnlicResponseBean res = new MandatoryLearningRnlicResponseBean();
		if(ch=='A') {
			res.setStatus(GenericConstants.SUCCESS);
		}
		else if(ch=='B')
		{
			res.setStatus(GenericConstants.FAILED);
		}
		else if(ch=='C')
		{
			res.setStatus(GenericConstants.FAILURE);
		}
		else if(ch=='D')
		{
			res.setStatus("Unknown");
		}
		return res;
	}
	
	public static MandatoryLearningResBean prepareMandatoryLearning() {
		MandatoryLearningResBean  mandatoryLearningResBean = new MandatoryLearningResBean();
		for(int i = 0;i<5;i++) {
			LearningDetails learnings = new LearningDetails();
			learnings.setDocumentName("Doc-"+i);
			learnings.setDocumentUploadDate("08-10-201"+i);
			learnings.setLearningId("42852"+i);
			learnings.setLearningLink("55445");
			learnings.setLearningName("abc name");
			mandatoryLearningResBean.getMandatoryLearnings().add(learnings);
		}
		return mandatoryLearningResBean;
	}
	
	public static String prepareMandatoryLearningStatusString(char ch){
		String status="";
		if(ch=='A') {
			status = GenericConstants.SUCCESS;
		}
		else if(ch=='B')
		{
			status = GenericConstants.FAILED;
		}
		else if(ch=='C')
		{
			status = GenericConstants.FAILURE;
		}
		else if(ch=='D')
		{
			status = "Unknown";
		}
		String res = "{\r\n" + 
				"    \"Status\": \"Success\",\r\n" + 
				"    \"Message\": \"Record found.\",\r\n" + 
				"    \"Response\": [\r\n" + 
				"        {\r\n" + 
				"            \"AML_KYC\": \"COMPLETED\",\r\n" + 
				"            \"ULIP\": \"COMPLETED\",\r\n" + 
				"            \"Infosec\": \"COMPLETED\"\r\n" + 
				"        }\r\n" + 
				"    ]\r\n" + 
				"}";
		res = StringUtils.replace(res, "Success", status);
		return res;
	}
	
	public static TroubleWithLoginRnlicResponseBean prepareTroubleWithLoginRnlicResponseBean(char ch) {
		TroubleWithLoginRnlicResponseBean res = new TroubleWithLoginRnlicResponseBean();
		if(ch=='A') {
			res.setStatus(GenericConstants.SUCCESS);
			res.setMessage(GenericConstants.DATA_FOUND);
			TroubleWithLoginApiResBean data = new TroubleWithLoginApiResBean();
			data.setContactEmail("abc@gmail.com");
			data.setContactNumber("9958362596");
			data.setHelpMessage("Help");
			List<TroubleWithLoginApiResBean> troubleWithLoginResBean=new ArrayList<>();
			troubleWithLoginResBean.add(data);
			res.setTroubleWithLoginResBean(troubleWithLoginResBean);
		}
		else if(ch=='B')
		{
			res.setStatus(GenericConstants.SUCCESS);
			res.setMessage(GenericConstants.DATA_FOUND);
			List<TroubleWithLoginApiResBean> troubleWithLoginResBean=new ArrayList<>();
			res.setTroubleWithLoginResBean(troubleWithLoginResBean);
		}
		else if(ch=='C')
		{
			res.setStatus(GenericConstants.FAILED);
			res.setMessage(GenericConstants.NO_DATA_FOUND);
		}
		else if(ch=='D')
		{
			res.setStatus(GenericConstants.FAILURE);
			res.setMessage(GenericConstants.NO_DATA_FOUND);
		}
		else if(ch=='E')
		{
			res.setStatus("Unknown");
			res.setMessage(GenericConstants.NO_DATA_FOUND);
		}
		return res;
	}
	
	public static CandidateRnlicResponseBean prepareCandidateRnlicResponseBean(char ch) {
		CandidateRnlicResponseBean res = new CandidateRnlicResponseBean();
		if(ch=='A') {
			List<CandidateDetailsRnlicResponseBean> response = new ArrayList<>();
			res.setStatus(GenericConstants.SUCCESS);
			res.setMessage(GenericConstants.DATA_FOUND);
			res.setResponse(response);
		}
		else if(ch=='B')
		{
			res.setStatus(GenericConstants.SUCCESS);
			res.setMessage(GenericConstants.NO_DATA_FOUND);
		}
		else if(ch=='C')
		{
			res.setStatus(GenericConstants.FAILED);
			res.setMessage(GenericConstants.NO_DATA_FOUND);
		}
		else if(ch=='D')
		{
			res.setStatus(GenericConstants.FAILURE);
			res.setMessage(GenericConstants.NO_DATA_FOUND);
		}
		else if(ch=='E')
		{
			res.setStatus("Unknown");
			res.setMessage(GenericConstants.NO_DATA_FOUND);
		}
		return res;
	}

	public static BirthdaySmsResBean prepareBirthdaySmsResBean() {
		BirthdaySms data = new BirthdaySms();
		data.setBirthdaySMS("Birthday SMS Send");
		List<BirthdaySms> reponse=new ArrayList<>();
		reponse.add(data);
		BirthdaySmsResBean res = new BirthdaySmsResBean();
		res.setStatus(GenericConstants.SUCCESS);
		res.setMessage(GenericConstants.DATA_FOUND);
		res.setReponse(reponse);
		return res;
	}

	public static WishEmpReqBean prepareBirthdayWishEmpReqBean() {
		WishesReq wishTo =new WishesReq();
		wishTo.setCommunicationChannel("SE");
		wishTo.setType("Birthday");
		wishTo.setEmail("abc@gmail.com");
		wishTo.setMobile("8396959442");
		wishTo.setSapCode("70009002");
		WishEmpReqBean res = new WishEmpReqBean();
		res.setWishTo(wishTo);
		return res;
	}
	
	public static WishEmpReqBean prepareAnniversaryWishEmpReqBean() {
		WishesReq wishTo =new WishesReq();
		wishTo.setCommunicationChannel("SE");
		wishTo.setType("Anniversary");
		wishTo.setEmail("abc@gmail.com");
		wishTo.setMobile("8396959442");
		wishTo.setSapCode("70009002");
		WishEmpReqBean res = new WishEmpReqBean();
		res.setWishTo(wishTo);
		return res;
	}
	
	public static WishEmpReqBean prepareUnknownWishEmpReqBean() {
		WishesReq wishTo =new WishesReq();
		wishTo.setCommunicationChannel("D");
		wishTo.setType("Anniversary");
		wishTo.setEmail("abc@gmail.com");
		wishTo.setMobile("8396959442");
		wishTo.setSapCode("70009002");
		WishEmpReqBean res = new WishEmpReqBean();
		res.setWishTo(wishTo);
		return res;
	}
	
	public static WishEmpReqBean prepareNoCommunicationWishEmpReqBean() {
		WishesReq wishTo =new WishesReq();
		wishTo.setCommunicationChannel("");
		wishTo.setType("Anniversary");
		wishTo.setEmail("abc@gmail.com");
		wishTo.setMobile("8396959442");
		wishTo.setSapCode("70009002");
		WishEmpReqBean res = new WishEmpReqBean();
		res.setWishTo(wishTo);
		return res;
	}
	
	public static BirthdaySmsResBean prepareBirthdaySmsFailedResBean() {
		BirthdaySms data = new BirthdaySms();
		data.setBirthdaySMS("Birthday SMS not Send");
		List<BirthdaySms> reponse=new ArrayList<>();
		reponse.add(data);
		BirthdaySmsResBean res = new BirthdaySmsResBean();
		res.setStatus(GenericConstants.FAILED);
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		res.setReponse(reponse);
		return res;
	}
	
	public static RegisterDeviceReqBean prepareRegisterDeviceReqBean() {
		RegisterDeviceReqBean registerDeviceReqBean = new RegisterDeviceReqBean();
		Collection<InstalledApplicationDetails> installedLinkedApps = new ArrayList<>();
		InstalledApplicationDetails res = new InstalledApplicationDetails();
		res.setApplicationDescription("Application");
		res.setApplicationName("APP NAME");
		res.setApplicationVersion("V1");
		res.setStatusUpdatedOn(new Date());
		installedLinkedApps.add(res);
		registerDeviceReqBean.setAppVersion("V1");
		registerDeviceReqBean.setDeviceType("Mobile");
		registerDeviceReqBean.setInstalledLinkedApps(installedLinkedApps);
		return registerDeviceReqBean;
	}
	
	public static RegisterDeviceReqBean prepareRegisterDeviceReqNullBean() {
		RegisterDeviceReqBean registerDeviceReqBean = new RegisterDeviceReqBean();
		Collection<InstalledApplicationDetails> installedLinkedApps = new ArrayList<>();
		InstalledApplicationDetails res = new InstalledApplicationDetails();
		res.setApplicationDescription("Application");
		res.setApplicationName("APP NAME");
		res.setApplicationVersion(null);
		res.setStatusUpdatedOn(new Date());
		installedLinkedApps.add(res);
		registerDeviceReqBean.setAppVersion(null);
		registerDeviceReqBean.setDeviceType(null);
		registerDeviceReqBean.setInstalledLinkedApps(installedLinkedApps);
		return registerDeviceReqBean;
	}
	
	public static MimeMessage prepareMimeMessage() throws MessagingException, UnsupportedEncodingException{
		Properties props = new Properties();
	    props.put(GenericConstants.MAIL_HOST, "10.126.249.115");
	    props.put(GenericConstants.MAIL_DEBUG, GenericConstants.TRUE_STRING);
	    Session session=Session.getInstance(props, null);
	    MimeMessage mimeMessage = new MimeMessage(session);
		//set message headers
	    mimeMessage.addHeader(GenericConstants.MAIL_CONTENT_TYPE, GenericConstants.MAIL_CHARSET_UTF);
	    mimeMessage.addHeader(GenericConstants.MAIL_FORMAT, GenericConstants.MAIL_FLOWED);
	    mimeMessage.addHeader(GenericConstants.MAIL_CONTENT_TRANSFER_ENCODING, GenericConstants.MAIL_BIT8);
	    mimeMessage.setFrom(new InternetAddress(GenericConstants.MAIL_EMAIL_FROM, GenericConstants.MAIL_NO_REPLY));
	    mimeMessage.setReplyTo(InternetAddress.parse(GenericConstants.MAIL_EMAIL_FROM, GenericConstants.FALSE));
	    return mimeMessage;
	}
	
	public static ChangePasswordResBean prepareChangePasswordResBean() {
		ChangePasswordResBean changePassRes = new ChangePasswordResBean();
		changePassRes.setMessage(GenericConstants.DATA_FOUND);
		changePassRes.setStatus(GenericConstants.SUCCESS);
		return changePassRes;
	}
	
	public static RequestValidatorResponse prepareRequestValidator()
	{
		RequestValidatorResponse reqRes = new RequestValidatorResponse();
		reqRes.setMessage(GenericConstants.DATA_FOUND);
		reqRes.setValid(GenericConstants.TRUE);
		return reqRes;
	}
	
	public static UpdateInstalledAppReqBean prepareUpdateInstalledAppReqBean() {
		InstalledApplicationDetails data = new InstalledApplicationDetails();
		data.setApplicationDescription("Description");
		data.setApplicationName("Application Name");
		data.setApplicationVersion("V2");
		data.setStatusUpdatedOn(new Date());
		Collection<InstalledApplicationDetails> installedLinkedApps = new ArrayList<>();
		installedLinkedApps.add(data);
		UpdateInstalledAppReqBean updateInstalledAppReqBean = new UpdateInstalledAppReqBean();
		updateInstalledAppReqBean.setInstalledLinkedApps(installedLinkedApps);
		return updateInstalledAppReqBean;
	}
	
	public static ChangePasswordRnlicResponseBean prepareChangePasswordRnlicResponseBean() {
		ChangePasswordRnlicResponseBean res = new ChangePasswordRnlicResponseBean();
		res.setStatus(GenericConstants.SUCCESS);
		//res.setMessage(GenericConstants.DATA_FOUND);
		return res;
	}
	
	public static ChangePasswordRnlicResponseBean prepareChangePasswordRnlicFailureResponseBean() {
		ChangePasswordRnlicResponseBean res = new ChangePasswordRnlicResponseBean();
		res.setStatus(GenericConstants.FAILURE);
		//res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static ChangePasswordRnlicResponseBean prepareChangePasswordRnlicFailedResponseBean() {
		ChangePasswordRnlicResponseBean res = new ChangePasswordRnlicResponseBean();
		res.setStatus(GenericConstants.FAILED);
		//res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static ChangePasswordRnlicResponseBean prepareChangePasswordRnlicUnknownResponseBean() {
		ChangePasswordRnlicResponseBean res = new ChangePasswordRnlicResponseBean();
		res.setStatus("Unknown");
		//res.setMessage(GenericConstants.NO_DATA_FOUND);
		return res;
	}
	
	public static NoticesResBean prepareNoticesResBean() {
		List<NoticeDetails> notices = new ArrayList<>();
		NoticesResBean res = new NoticesResBean();
		res.setNotices(notices);
		return res;
	}

	public static OtpMasterModel prepareOtpMasterModel() {
		OtpMasterModel res = new OtpMasterModel();
		res.setResendCount(0);
		res.setMobileNumber("9585868698");
		res.setValidUpto(new Date());
		res.setAction("Mobile");
		res.setCountryCode("454D");
		res.setDeviceIdentifier("45475757");
		res.setGeneratedOn(new Date());
		res.setMobileNumber("8655485742");
		res.setOtpId(4564);
		res.setOtpValue(1255);
		res.setRetryCount(0);
		res.setSapCode("1154514");
		res.setVerified(false);
		return res;
	}
	
	public static OtpMasterModel prepareOtpMasterMultiTryModel() {
		OtpMasterModel res = new OtpMasterModel();
		res.setResendCount(3);
		res.setMobileNumber("9585868698");
		res.setValidUpto(new Date());
		res.setAction("Mobile");
		res.setCountryCode("454D");
		res.setDeviceIdentifier("45475757");
		res.setGeneratedOn(new Date());
		res.setMobileNumber("8655485742");
		res.setOtpId(4564);
		res.setOtpValue(1255);
		res.setRetryCount(0);
		res.setSapCode("1154514");
		res.setVerified(false);
		res.setMultipleTry(false);
		return res;
	}
	
	public static OtpMasterModel prepareOtpMasterMultiTryFalseModel() {
		OtpMasterModel res = new OtpMasterModel();
		res.setResendCount(3);
		res.setMobileNumber("9585868698");
		res.setValidUpto(new Date());
		res.setAction("Mobile");
		res.setCountryCode("454D");
		res.setDeviceIdentifier("45475757");
		res.setGeneratedOn(new Date());
		res.setMobileNumber("8655485742");
		res.setOtpId(4564);
		res.setOtpValue(1255);
		res.setRetryCount(0);
		res.setSapCode("1154514");
		res.setVerified(false);
		res.setMultipleTry(true);
		return res;
	}
	
	public static NoticesRnlicResponseBean prepareNoticesRnlicResponseBean() {
		NoticeDetailsRnlicBean data = new  NoticeDetailsRnlicBean();
		data.setAutoId("58N899BHER");
		data.setCreatedOn("18/09/2019");
		data.setDescription("Test description");
		data.setDocumentType("PDF");
		data.setLink("/test");
		data.setShortDescription("Short Description");
		List<NoticeDetailsRnlicBean> response = new ArrayList<>();
		response.add(data);
		NoticesRnlicResponseBean res = new NoticesRnlicResponseBean();
		res.setMessage(GenericConstants.DATA_FOUND);
		res.setStatus(GenericConstants.SUCCESS);
		res.setResponse(response);
		return res;
	}
	
	public static NoticesResBean prepareGetNotices(NoticesRnlicResponseBean response) {
		NoticesResBean notices = new NoticesResBean();
		if (!HrAppUtil.isNullOrEmpty(response) && !HrAppUtil.isNullOrEmpty(response.getResponse())) {
			response.getResponse().stream().forEach(noticeDetails ->{
				NoticeDetails notice = new NoticeDetails();
				notice.setCreatedOn(noticeDetails.getCreatedOn());
				notice.setLink(HrAppUtil.isNullOrEmpty(noticeDetails.getLink())?GenericConstants.EMPTY_STRING:noticeDetails.getLink());
				notice.setName(HrAppUtil.isNullOrEmpty(noticeDetails.getShortDescription())?GenericConstants.EMPTY_STRING:noticeDetails.getShortDescription());
				notice.setType(HrAppUtil.isNullOrEmpty(noticeDetails.getDocumentType())?GenericConstants.EMPTY_STRING:noticeDetails.getDocumentType());
				notice.setDescription(HrAppUtil.isNullOrEmpty(noticeDetails.getDescription())?GenericConstants.EMPTY_STRING:noticeDetails.getDescription());
				notices.getNotices().add(notice);
			});
		}
		return notices;
	}
	
	public static NoticesRnlicResponseBean prepareNoticesRnlicResponseFailureBean() {
		NoticesRnlicResponseBean res = new NoticesRnlicResponseBean();
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		res.setStatus(GenericConstants.FAILURE);
		return res;
	}
	
	public static NoticesRnlicResponseBean prepareNoticesRnlicResponseFailedBean() {
		NoticesRnlicResponseBean res = new NoticesRnlicResponseBean();
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		res.setStatus(GenericConstants.FAILED);
		return res;
	}
	
	public static NoticesRnlicResponseBean prepareNoticesRnlicResponseUnknownBean() {
		NoticesRnlicResponseBean res = new NoticesRnlicResponseBean();
		res.setMessage(GenericConstants.NO_DATA_FOUND);
		res.setStatus("Unknown");
		return res;
	}
	
	public static CheckForDeviceRegistrationResBean prepareCheckForDeviceRegistrationResBean() {
		DeviceRegistrationModel data = new DeviceRegistrationModel();
		CheckForDeviceRegistrationResBean res = new CheckForDeviceRegistrationResBean();
		res.setDeviceRegisterWithOthers(false);
		res.setAllowed(true);
		res.setMobileNumberUpdated(false);
		res.setRegisterdWithOtherDevice(false);
		res.setSapCodeUpdated(false);
		res.setDeviceRegDetails(data);
		return res;
	}
	
	public static CheckForDeviceRegistrationResBean prepareCheckForDeviceRegistrationDoneResBean() {
		DeviceRegistrationModel data = new DeviceRegistrationModel();
		CheckForDeviceRegistrationResBean res = new CheckForDeviceRegistrationResBean();
		res.setDeviceRegisterWithOthers(true);
		res.setAllowed(true);
		res.setMobileNumberUpdated(false);
		res.setRegisterdWithOtherDevice(false);
		res.setSapCodeUpdated(false);
		res.setDeviceRegDetails(data);
		return res;
	}
	
	public static PushNotificationResponse preparePushNotificationResponse() {
		PushNotificationResponse res =new PushNotificationResponse();
		res.setSuccess(0);
		return res;
	}
	
	public static WishEmpReqBean prepareBirthdayWishEmpPushReqBean() {
		WishesReq wishTo =new WishesReq();
		wishTo.setCommunicationChannel("P");
		wishTo.setType("Birthday");
		wishTo.setEmail("abc@gmail.com");
		wishTo.setMobile("8396959442");
		wishTo.setSapCode("70009002");
		WishEmpReqBean res = new WishEmpReqBean();
		res.setWishTo(wishTo);
		return res;
	}
	
	public static RequestValidatorResponse prepareRequestValidatorResponse() {
		RequestValidatorResponse reqRes = new RequestValidatorResponse();
		reqRes.setValid(true);
		reqRes.setMessage(RequestValidatorConstants.USERNAME_PASSWORD_VALID);
		return reqRes;
	}
}