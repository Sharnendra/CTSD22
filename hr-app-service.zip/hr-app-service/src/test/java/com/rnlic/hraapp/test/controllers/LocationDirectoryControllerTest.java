package com.rnlic.hraapp.test.controllers;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.constants.TestConstant;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.LocalBranchReqBean;
import com.rnlic.hrapp.bean.request.ShareBranchDetailsReqBean;
import com.rnlic.hrapp.bean.response.AttendanceDetailsResBean;
import com.rnlic.hrapp.controller.LocationDirectoryController;
import com.rnlic.hrapp.exception.MailingServiceException;
import com.rnlic.hrapp.exception.MandatoryFieldsNotAvailable;
import com.rnlic.hrapp.security.JwtDecriptor;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.CommunicationService;
import com.rnlic.hrapp.service.LocationDirectoryService;
import com.rnlic.hrapp.util.RequestLogDeatils;

public class LocationDirectoryControllerTest extends HraServiceTests{

	private MockMvc mockMvc;

	@Mock
	private JwtDecriptor jwtDecriptor;
	
	@Mock 
	private LocationDirectoryService locationService;
	
	@Mock
	private CommunicationService communicationService;
	
	@Mock
	private RequestLogDeatils requestLog;
	
	@InjectMocks
	private LocationDirectoryController locationDirectoryController;
	
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(locationDirectoryController).build();
	}
	
	@Test
	public void testGetStateCityMaster() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(locationService.getStateCityMaster(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_STATE_CITY_MASTER_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetStateCityMasterExp() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new MandatoryFieldsNotAvailable("Exp"));
		Mockito.when(locationService.getStateCityMaster(user)).thenThrow(new MandatoryFieldsNotAvailable("Exp"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_STATE_CITY_MASTER_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetStateCityMasterExp1() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException("Exp"));
		Mockito.when(locationService.getStateCityMaster(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_STATE_CITY_MASTER_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testLocateBranch() throws Exception {
		String expectedReq = TestConstant.LOCATE_BRANCH_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		LocalBranchReqBean localBranchReqBean = new LocalBranchReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(locationService.getBrachDetails(user, localBranchReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.LOCATE_BRANCH_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testLocateBranchExp() throws Exception {
		String expectedReq = TestConstant.LOCATE_BRANCH_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		LocalBranchReqBean localBranchReqBean = new LocalBranchReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new MailingServiceException());
		Mockito.when(locationService.getBrachDetails(user, localBranchReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.LOCATE_BRANCH_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testLocateBranchExp1() throws Exception {
		String expectedReq = TestConstant.LOCATE_BRANCH_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		LocalBranchReqBean localBranchReqBean = new LocalBranchReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException());
		Mockito.when(locationService.getBrachDetails(user, localBranchReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.LOCATE_BRANCH_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testShareBranchInformation() throws Exception {
		String expectedReq = TestConstant.SHARED_BRANCH_INFO_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = new ShareBranchDetailsReqBean();
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(communicationService.shareBrachDetails(user,shareBranchDetailsReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.SHARE_BRANCH_INFO_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testShareBranchInformationExp() throws Exception {
		String expectedReq = TestConstant.SHARED_BRANCH_INFO_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = new ShareBranchDetailsReqBean();
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new MailingServiceException("Exp"));
		Mockito.when(communicationService.shareBrachDetails(user,shareBranchDetailsReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.SHARE_BRANCH_INFO_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testShareBranchInformationExp1() throws Exception {
		String expectedReq = TestConstant.SHARED_BRANCH_INFO_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = new ShareBranchDetailsReqBean();
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException());
		Mockito.when(communicationService.shareBrachDetails(user,shareBranchDetailsReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.SHARE_BRANCH_INFO_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
}
