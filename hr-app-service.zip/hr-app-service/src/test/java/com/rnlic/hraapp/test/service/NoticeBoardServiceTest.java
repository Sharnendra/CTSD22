package com.rnlic.hraapp.test.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.response.NoticesResBean;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.NoticeBoardService;
import com.rnlic.hrapp.service.RnlicService;

public class NoticeBoardServiceTest extends HraServiceTests {

	@InjectMocks
	private NoticeBoardService noticeBoardService;
	
	@Mock
	private RnlicService rnlicService;

	@Test
	public void getNoticesTest() {
		UserDetailsBean userbean = new UserDetailsBean(); 
		Mockito.doReturn(HrappTestUtil.prepareNoticesResBean()).when(rnlicService).getNotices(Mockito.any(UserDetailsBean.class));
		NoticesResBean noticesResBean = (NoticesResBean) noticeBoardService.getNotices(userbean);
		assertNotNull(noticesResBean);
	}
}
