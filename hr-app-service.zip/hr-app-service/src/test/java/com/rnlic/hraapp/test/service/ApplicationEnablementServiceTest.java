package com.rnlic.hraapp.test.service;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.constants.TestConstant;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.api.request.ApplicationConfigReqBean;
import com.rnlic.hrapp.bean.api.response.RnlicServicesDataTranslator;
import com.rnlic.hrapp.bean.request.LinkedApplicationReq;
import com.rnlic.hrapp.bean.request.ShareBranchDetailsReqBean;
import com.rnlic.hrapp.bean.response.LinkedAppConfigRes;
import com.rnlic.hrapp.bean.response.ShareBrachDetailsResBean;
import com.rnlic.hrapp.configuration.MailerConfig;
import com.rnlic.hrapp.constant.GenericConstants;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.exception.CommunicationException;
import com.rnlic.hrapp.repository.LinkedAppConfigrationRepository;
import com.rnlic.hrapp.repository.OtpRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.ApplicationEnablementService;
import com.rnlic.hrapp.service.CommunicationService;
import com.rnlic.hrapp.service.RnlicService;

public class ApplicationEnablementServiceTest extends HraServiceTests {

	@Mock
	private LinkedAppConfigrationRepository linkedAppConfigrationRepository;
	
	@Mock
	private RnlicService rnlicService;

	@Mock
	private MessagesConstants messagesConstants;
	
	@Mock
	private MailerConfig mailerConfig;
	
	@Mock
	private RnlicServicesDataTranslator rnlicServicesDataTranslator;

	@Mock
	private OtpRepository otpRepo; 
	
	@InjectMocks
	private ApplicationEnablementService applicationEnablementService;
	
	@InjectMocks
	private CommunicationService communicationService;
	
	@Test
	public void getLinkedAppConfigurationTest() throws JsonParseException, JsonMappingException, IOException {
		LinkedAppConfigRes linkedAppConfigRes = null;
		Mockito.when(linkedAppConfigrationRepository.getLinkedAppConfigration()).thenReturn(HrappTestUtil.prepareLinkedAppConfigrationModal());
		linkedAppConfigRes = applicationEnablementService.getLinkedAppConfiguration();
		assertNotNull(linkedAppConfigRes);
	}
	
	@Test
	public void updateLinkedAppConfigurationTest() throws JsonParseException, JsonMappingException, JsonProcessingException, IOException {
		ApplicationConfigReqBean appconfig=new ApplicationConfigReqBean();
		ObjectMapper mapper=new ObjectMapper();
		appconfig.setAppConfig(mapper.readValue(TestConstant.GET_CONFIG.toString(), LinkedApplicationReq.class));
		Mockito.doNothing().when(linkedAppConfigrationRepository).updateLinkedAppConfigrationEntries();
		Mockito.when(applicationEnablementService.updateLinkedAppConfiguration(appconfig)).thenReturn(HrappTestUtil.prepareLinkedAppResponse());
		LinkedAppConfigRes linkedAppConfigRes=applicationEnablementService.updateLinkedAppConfiguration(appconfig);
		assertNotNull(linkedAppConfigRes);
	}
	
	@Test(expected=CommunicationException.class)
	public void shareBrachDetailsTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = HrappTestUtil.prepareShareBranchDetailsReqBean();
		shareBranchDetailsReqBean.setEmailAddress(null);
		shareBranchDetailsReqBean.setMobileNo(null);
		communicationService.shareBrachDetails(empReqBean, shareBranchDetailsReqBean);
	}
	
	@Test
	public void shareBrachDetailsMobileTest() throws RestClientException, IOException {
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("962515454254", "8526569875", "CBDFDX45P", "70009032");
		ShareBrachDetailsResBean shareBrachDetailsResBean = new ShareBrachDetailsResBean();
		ShareBranchDetailsReqBean shareBranchDetailsReqBean = HrappTestUtil.prepareShareBranchDetailsReqBean();
		shareBranchDetailsReqBean.setEmailAddress(null);
		shareBrachDetailsResBean.setMessage("SMS Send Successfuly");
		shareBrachDetailsResBean.setStatus(GenericConstants.SUCCESS);
		Mockito.when(rnlicService.shareBrachDetails(Mockito.any(String.class),Mockito.any(ShareBranchDetailsReqBean.class))).thenReturn(true);
		Mockito.when(rnlicService.getShareBrachDetailsMessage(empReqBean, shareBranchDetailsReqBean)).thenReturn("Hi");
		Mockito.when(rnlicServicesDataTranslator.generateShareBrachDetailsResponse(1,shareBranchDetailsReqBean,true,false,new LinkedHashMap<>()))
		.thenReturn(shareBrachDetailsResBean);
		ShareBrachDetailsResBean response = (ShareBrachDetailsResBean) communicationService.shareBrachDetails(empReqBean, shareBranchDetailsReqBean);
		assertNotNull(response);
	}
	@Test
	public void getLinkedAppConfigurationVersionTest() {
		String[] ob = {"V79"}; 
		List<Object[]> dbResult =new ArrayList<>();
		dbResult.add(ob);
		Mockito.when(linkedAppConfigrationRepository.getLinkedAppConfigrationVersion()).thenReturn(dbResult);
		applicationEnablementService.getLinkedAppConfigurationVersion();
	}
	
	@Test
	public void getLinkedAppConfigurationVersionEmptyTest() {
		List<Object[]> dbResult =new ArrayList<>();
		Mockito.when(linkedAppConfigrationRepository.getLinkedAppConfigrationVersion()).thenReturn(dbResult);
		applicationEnablementService.getLinkedAppConfigurationVersion();
	}
}
