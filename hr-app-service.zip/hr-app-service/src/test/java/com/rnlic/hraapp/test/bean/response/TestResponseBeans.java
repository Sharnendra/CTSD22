package com.rnlic.hraapp.test.bean.response;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hrapp.bean.api.response.AttendanceDetailsRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.BirthdaySms;
import com.rnlic.hrapp.bean.api.response.BirthdaySmsResBean;
import com.rnlic.hrapp.bean.api.response.CheckInCheckOutDateTimeResponseBean;
import com.rnlic.hrapp.bean.api.response.CheckInCheckOutRnlicResponseBean;
import com.rnlic.hrapp.bean.api.response.RnlicRestResponse;
import com.rnlic.hrapp.bean.response.Anniversary;
import com.rnlic.hrapp.bean.response.Attendance;
import com.rnlic.hrapp.bean.response.Birthday;
import com.rnlic.hrapp.bean.response.CheckInInfoResBean;
import com.rnlic.hrapp.bean.response.LocateBranches;
import com.rnlic.hrapp.bean.response.User;

public class TestResponseBeans extends HraServiceTests{
	User user = new User();
	LocateBranches obj = new LocateBranches();
	Attendance attendance = new Attendance();
	Birthday birthday = new Birthday();
	Anniversary anni = new Anniversary();
	
	
	@Test
	public void testMethodsOfUser() {
		user.getMiddleName();
		user.getEmail();
		user.getChannel();
		user.getManagerName();
		user.getLocationCode();
		user.getLocationName();
		user.getZoneCode();
		user.getZoneName();
		user.getUserRole();
		user.getCategory();
	}
	
	@Test
	public void testMethodsOfLocate() {
		obj.toString();
	}
	
	@Test
	public void testMethodsOfAttendance() {
		attendance.getAttendanceCode();
		attendance.getCheckIn();
		attendance.getCheckInBranch();
		attendance.getCheckInBranchAddress();
		attendance.getCheckOut();
		attendance.getCheckOutBranch();
		attendance.getCheckOutBranchAddress();
		attendance.getDate();
		attendance.getDayOfWeek();
		attendance.getDiscription();
	}
	
	@Test
	public void testMethodsOfBirthday() {
		birthday.getChannel();
		birthday.getDateOfBirth();
		birthday.getDateOfJoining();
		birthday.getEmail();
		birthday.getManagerSapcode();
		birthday.getMobile();
		birthday.getName();
		birthday.getRegion();
		birthday.getSapCode();
		birthday.getZone();
	}
	
	@Test
	public void testMethodsOfAnniversary() {
		anni.getChannel();
		anni.getEmail();
		anni.getJoinDate();
		anni.getManagerSapcode();
		anni.getMobile();
		anni.getName();
		anni.getRegion();
		anni.getSapCode();
		anni.getZone();
	}
	@Test
	public void testMethodsOfCheckIninfo() {
		CheckInInfoResBean check = new CheckInInfoResBean("checkInDate", true, "allowedCheckInTime", "allowedCheckOutTime",null);
		check.getAllowedBranches();
		check.getAllowedCheckInTime();
		check.getAllowedCheckOutTime();
		check.getCheckInDate();
		check.getLocationCheckRequired();
	}
	@Test
	public void testMethodsOfAttendanceDetails() {
		AttendanceDetailsRnlicResponseBean attendanceRes = new AttendanceDetailsRnlicResponseBean();
		attendanceRes.getCheckInBrAddress();
		attendanceRes.getCheckInBranch();
		attendanceRes.getCheckOutBrAddress();
		attendanceRes.getCheckOutBranch();
		attendanceRes.getDate();
		attendanceRes.getHolidayName();
		attendanceRes.getInTime();
		attendanceRes.getIsHoliday();
		attendanceRes.getIsLeave();
		attendanceRes.getIsPresent();
		attendanceRes.getIsRejected();
		attendanceRes.getIsWaiting();
		attendanceRes.getLeaveDescription();
		attendanceRes.getLeaveType();
		attendanceRes.getMonth();
		attendanceRes.getOfficialReason();
		attendanceRes.getOutTime();
		attendanceRes.getSapCode();
		attendanceRes.getYear();
		attendanceRes.setCheckInBrAddress("BIPL");
		attendanceRes.setCheckInBranch("BIPL");
		attendanceRes.setCheckOutBrAddress("BIPL");
		attendanceRes.setCheckOutBranch("BIPL");
	}
	@Test
	public void testMethodsOfRnlicRestResponse() {
		RnlicRestResponse rnlicRest = new RnlicRestResponse("status","message") {
			@Override
			public String toString() {
				return super.toString();
			}
		};
		rnlicRest.toString();
	}
	@Test
	public void testMethodsOfCheckIn() {
		List<CheckInCheckOutDateTimeResponseBean> response = new ArrayList<>();
		CheckInCheckOutRnlicResponseBean checkInTime = new CheckInCheckOutRnlicResponseBean();
		CheckInCheckOutRnlicResponseBean checkInTime1 = new CheckInCheckOutRnlicResponseBean(response);
		checkInTime.getErrors();
		checkInTime1.getMessage();
		
	}
	
	@Test
	public void testMethodsOfBirthdaySms() {
		BirthdaySmsResBean birthday = new BirthdaySmsResBean();
		List<BirthdaySms> reponse=new ArrayList<>();
		BirthdaySmsResBean birthday1 = new BirthdaySmsResBean(reponse);
		birthday1.getReponse();
		birthday.getReponse();
	}
}
