package com.rnlic.hraapp.test.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.AttendanceReqBean;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.AttendanceDetailsService;
import com.rnlic.hrapp.service.RnlicService;

public class AttendanceDetailsServiceTest extends HraServiceTests {

	@Mock
	private RnlicService rnlicService;
	
	@InjectMocks
	private AttendanceDetailsService attendanceDetailsService;
	
	/**
	 * Test to ensure the return of Attendance details
	 * @param UserDetailsBean empReqBean
	 * @param AttendanceReqBean attendanceReqBean
	 * @return ResponseData AttendanceResBean
	 */
	@Test
	public void getAttendanceDetailsTest() {
		UserDetailsBean empReqBean = new UserDetailsBean();
		AttendanceReqBean attendanceReqBean = new AttendanceReqBean();
		Mockito.when(rnlicService.getAttendanceDtls(attendanceReqBean, empReqBean)).thenReturn(HrappTestUtil.prepareAttendanceDtls());
		ResponseData response = attendanceDetailsService.getAttendanceDetails(empReqBean, attendanceReqBean);
		assertNotNull(response);
	}
	
	/**
	 * Test to get ReporteeList
	 * @param UserDetailsBean userBean //it will be use for future purpose
	 * @param String sapCode
	 * @return ResponseData reporteeListDataRes 
	 */
	@Test
	public void getReporteeListTest() {
		UserDetailsBean userBean=new UserDetailsBean(); 
		String sapCode = "";
		Mockito.when(rnlicService.getListOfReportees(sapCode)).thenReturn(HrappTestUtil.prepareReporteeList());
		ResponseData response = attendanceDetailsService.getReporteeList(userBean, sapCode);
		assertNotNull(response);
	}
}
