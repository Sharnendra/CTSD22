package com.rnlic.hraapp.test.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.DeRegisterDeviceReqBean;
import com.rnlic.hrapp.bean.request.RegisterDeviceReqBean;
import com.rnlic.hrapp.bean.request.UpdateDeviceRegistrationReqBean;
import com.rnlic.hrapp.bean.request.UpdateInstalledAppReqBean;
import com.rnlic.hrapp.constant.MessagesConstants;
import com.rnlic.hrapp.entity.DeviceRegistrationModel;
import com.rnlic.hrapp.entity.InstalledApplicationModel;
import com.rnlic.hrapp.exception.DeviceRegistrationException;
import com.rnlic.hrapp.repository.DeviceRegistrationRepository;
import com.rnlic.hrapp.repository.InstalledApplicationRepository;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.DeviceRegistrationService;
import com.rnlic.hrapp.service.RnlicService;
import com.rnlic.hrapp.util.RequestLogDeatils;

public class DeviceRegistrationTest extends HraServiceTests {

	@Mock
	private RnlicService rnlicService;

	@Mock
	private DeviceRegistrationRepository deviceRepo;

	@Mock
	private MessagesConstants messagesConstants;

	@Mock
	private InstalledApplicationRepository installAppRepo;
	
	@Mock
	private RequestLogDeatils requestLog;
	
	@InjectMocks
	private DeviceRegistrationService deviceService;
	
	@Test
	public void updateLinkedAppForRegisteredDeviceTest() {
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO2","PANNO2","");
		UpdateInstalledAppReqBean updateInstalledAppReqBean = HrappTestUtil.prepareUpdateInstalledAppReqBean();
		InstalledApplicationModel installedAppEntity = new InstalledApplicationModel();
		String[] ob = {"45336","42878"}; 
		List<Object[]> dbResult =new ArrayList<>();
		dbResult.add(ob);
		Mockito.when(deviceRepo.getRequestIdForRegisteredDecive(Mockito.any(String.class))).thenReturn(dbResult);
		Mockito.doReturn(installedAppEntity).when(installAppRepo).save(Mockito.any(InstalledApplicationModel.class));
		Mockito.when(messagesConstants.getUpdateInstalledAppSuccessMsg()).thenReturn("Updated");
		deviceService.updateLinkedAppForRegisteredDevice(userDetailsBean, updateInstalledAppReqBean);
	}
	
	@Test
	public void updateLinkedAppForRegisteredDeviceNoDataTest() {
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO2","PANNO2","");
		UpdateInstalledAppReqBean updateInstalledAppReqBean = HrappTestUtil.prepareUpdateInstalledAppReqBean();
		InstalledApplicationModel installedAppEntity = new InstalledApplicationModel();
		List<Object[]> dbResult =new ArrayList<>();
		Mockito.when(deviceRepo.getRequestIdForRegisteredDecive(Mockito.any(String.class))).thenReturn(dbResult);
		Mockito.doReturn(installedAppEntity).when(installAppRepo).save(Mockito.any(InstalledApplicationModel.class));
		Mockito.when(messagesConstants.getUpdateInstalledAppSuccessMsg()).thenReturn("Updated");
		deviceService.updateLinkedAppForRegisteredDevice(userDetailsBean, updateInstalledAppReqBean);
	}
	
	@Test
	public void registerDeviceRegisterdWithOtherDeviceTest() {
		RegisterDeviceReqBean registerDeviceReqBean = HrappTestUtil.prepareRegisterDeviceReqBean();
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO1","PANNO1","");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		Mockito.doNothing().when(deviceRepo).delete(Mockito.any(DeviceRegistrationModel.class));
		Mockito.doReturn(true).when(rnlicService).updateDeviceRegInfo(Mockito.any(String.class),Mockito.any(String.class),Mockito.any(String.class),Mockito.any(String.class));
		Mockito.doReturn(new DeviceRegistrationModel()).when(deviceRepo).save(Mockito.any(DeviceRegistrationModel.class));
		Mockito.doReturn("Success").when(messagesConstants).getSuccessRegistrationMsg();
		deviceService.registerDevice(user, registerDeviceReqBean);
	}
	
	@Test
	public void registerDeviceNotAlreadyRegisteredTest() {
		RegisterDeviceReqBean registerDeviceReqBean = HrappTestUtil.prepareRegisterDeviceReqBean();
		List<DeviceRegistrationModel> deviceEntityList = null;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIE1","PANNO1","SAPCODE1");
		user.setFcmToken("fytrdtybtfyty-4fgfdcxfd4dfdf");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		Mockito.doNothing().when(deviceRepo).delete(Mockito.any(DeviceRegistrationModel.class));
		Mockito.doReturn(true).when(rnlicService).updateDeviceRegInfo(Mockito.any(String.class),Mockito.any(String.class),Mockito.any(String.class),Mockito.any(String.class));
		Mockito.doReturn(new DeviceRegistrationModel()).when(deviceRepo).save(Mockito.any(DeviceRegistrationModel.class));
		Mockito.doReturn("Success").when(messagesConstants).getSuccessRegistrationMsg();
		deviceService.registerDevice(user, registerDeviceReqBean);
	}
	
	@Test (expected = DeviceRegistrationException.class)
	public void registerDeviceDeviceRegisteredTest() {
		RegisterDeviceReqBean registerDeviceReqBean = HrappTestUtil.prepareRegisterDeviceReqBean();
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityListTwoData("DEVICE1","MOBLIENO1","PANNO1","","DEVICE2","MOBLIENO2","PANNO2","");
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO1","PANNO1","");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		Mockito.doReturn("Registered with Others").when(messagesConstants).getDeviceRegisteredWithOtherDevice();
		deviceService.registerDevice(user, registerDeviceReqBean);
	}
	
	@Test
	public void registerDeviceNotSavedRegisteredTest() {
		RegisterDeviceReqBean registerDeviceReqBean = HrappTestUtil.prepareRegisterDeviceReqBean();
		List<DeviceRegistrationModel> deviceEntityList = null;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIE1","PANNO1","");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		Mockito.doNothing().when(deviceRepo).delete(Mockito.any(DeviceRegistrationModel.class));
		Mockito.doReturn(true).when(rnlicService).updateDeviceRegInfo(Mockito.any(String.class),Mockito.any(String.class),Mockito.any(String.class),Mockito.any(String.class));
		Mockito.doReturn(null).when(deviceRepo).save(Mockito.any(DeviceRegistrationModel.class));
		Mockito.doReturn("Failure").when(messagesConstants).getErrorInRegistrationMsg();
		deviceService.registerDevice(user, registerDeviceReqBean);
	}
	
//	@Test
//	public void registerDeviceNotRegisteredTest() {
//		RegisterDeviceReqBean registerDeviceReqBean = HrappTestUtil.prepareRegisterDeviceReqBean();
//		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE15","MOBLIENO1","PANNO1","55565");
//		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO1","PANNO1","555615");
//		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
//		Mockito.doNothing().when(deviceRepo).delete(Mockito.any(DeviceRegistrationModel.class));
//		deviceService.registerDevice(user, registerDeviceReqBean);
//	}
	
	@Test
	public void registerDeviceUpdateDeviceRegisteredTest() {
		RegisterDeviceReqBean registerDeviceReqBean = HrappTestUtil.prepareRegisterDeviceReqBean();
		List<DeviceRegistrationModel> deviceEntityList = null;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIE1","PANNO1","");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		Mockito.doNothing().when(deviceRepo).delete(Mockito.any(DeviceRegistrationModel.class));
		Mockito.when(rnlicService.updateDeviceRegInfo(Mockito.any(String.class),Mockito.any(String.class),Mockito.any(String.class),Mockito.any(String.class))).thenReturn(Boolean.valueOf("true"));
		Mockito.doReturn(new DeviceRegistrationModel()).when(deviceRepo).save(Mockito.any(DeviceRegistrationModel.class));
		Mockito.doReturn("Success").when(messagesConstants).getSuccessRegistrationMsg();
		deviceService.registerDevice(user, registerDeviceReqBean);
	}
	
	@Test
	public void deRegDeviceUserTest() {
		UserDetailsBean userDetailsBean =  HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO2","PANNO2","");
		DeRegisterDeviceReqBean deregDeviceReqBean = null;
		Mockito.when(deviceRepo.deleteBySapCode(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(1);
		Mockito.doReturn("Success").when(messagesConstants).getDeregisterDeviceSuccesMsg();
		deviceService.deRegDevice(userDetailsBean, deregDeviceReqBean);
	}
	
	@Test
	public void deRegDeviceCandidateTest() {
		UserDetailsBean userDetailsBean =  HrappTestUtil.prepareUserDtlsCandidateBean();
		userDetailsBean.setCandidate(true);
		DeRegisterDeviceReqBean deregDeviceReqBean = null;
		Mockito.when(deviceRepo.deleteBySapCode(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(0);
		Mockito.doReturn("Failure").when(messagesConstants).getDeregisterDeviceFailureMsg();
		deviceService.deRegDevice(userDetailsBean, deregDeviceReqBean);
	}
	
	@Test
	public void updateDeviceRegCandidateTest() {
		UpdateDeviceRegistrationReqBean updateDeviceRegReqBean = null;
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO2","PANNO1","SAPCODE1");
		userDetailsBean.setCandidate(true);
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		Mockito.when(deviceRepo.updateMobileNoForCandidate(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(1);
		Mockito.doReturn("Sucess").when(messagesConstants).getUpdateDeviceRegistrationSuccessMsg();
		deviceService.updateDeviceReg(userDetailsBean, updateDeviceRegReqBean);
	}
	
	@Test
	public void updateDeviceRegUserTest() {
		UpdateDeviceRegistrationReqBean updateDeviceRegReqBean = null;
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("DEVICE2","MOBLIENO2","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		Mockito.when(deviceRepo.updateMobileNoForEmployee(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(0);
		Mockito.doReturn("Failure").when(messagesConstants).getUpdateDeviceRegistrationFailureMsg();
		deviceService.updateDeviceReg(userDetailsBean, updateDeviceRegReqBean);
	}
	
	@Test
	public void updateDeviceRegSapCodeChangeTest() {
		UpdateDeviceRegistrationReqBean updateDeviceRegReqBean = null;
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		Mockito.when(deviceRepo.updateSapCode(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(0);
		Mockito.doReturn("Failure").when(messagesConstants).getUpdateDeviceRegistrationFailureMsg();
		deviceService.updateDeviceReg(userDetailsBean, updateDeviceRegReqBean);
	}
	
	@Test
	public void updateDeviceRegNoChangeTest() {
		UpdateDeviceRegistrationReqBean updateDeviceRegReqBean = null;
		List<DeviceRegistrationModel> deviceEntityList = HrappTestUtil.prepareDeviceEntityList("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		UserDetailsBean userDetailsBean = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIENO1","PANNO1","SAPCODE1");
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		Mockito.doReturn("Failure").when(messagesConstants).getUpdateDeviceRegistrationNotRequiredMsg();
		deviceService.updateDeviceReg(userDetailsBean, updateDeviceRegReqBean);
	}
	
	@Test
	public void registerDeviceNotAlreadyRegisteredTest1() {
		RegisterDeviceReqBean registerDeviceReqBean = HrappTestUtil.prepareRegisterDeviceReqNullBean();
		List<DeviceRegistrationModel> deviceEntityList = null;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1","MOBLIE1","PANNO1","SAPCODE1");
		user.setFcmToken("fytrdtybtfyty-4fgfdcxfd4dfdf");
		user.setFristName(null);
		user.setDeviceIdentifier(null);
		user.setMobileNumber(null);
		user.setPanNumber(null);
		Mockito.when(deviceRepo.getDeviceRegistrationDetails(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(deviceEntityList);
		Mockito.doNothing().when(deviceRepo).delete(Mockito.any(DeviceRegistrationModel.class));
		Mockito.doReturn(true).when(rnlicService).updateDeviceRegInfo(Mockito.any(String.class),Mockito.any(String.class),Mockito.any(String.class),Mockito.any(String.class));
		Mockito.doReturn(new DeviceRegistrationModel()).when(deviceRepo).save(Mockito.any(DeviceRegistrationModel.class));
		Mockito.doReturn("Success").when(messagesConstants).getSuccessRegistrationMsg();
		deviceService.registerDevice(user, registerDeviceReqBean);
	}
}
