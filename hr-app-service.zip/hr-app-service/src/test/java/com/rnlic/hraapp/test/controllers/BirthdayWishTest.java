package com.rnlic.hraapp.test.controllers;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.constants.TestConstant;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.request.BirthdayReqBean;
import com.rnlic.hrapp.bean.request.WishEmpReqBean;
import com.rnlic.hrapp.bean.response.AttendanceDetailsResBean;
import com.rnlic.hrapp.controller.BirthdayWishController;
import com.rnlic.hrapp.exception.ExecutionException;
import com.rnlic.hrapp.exception.MailingServiceException;
import com.rnlic.hrapp.exception.MandatoryFieldsNotAvailable;
import com.rnlic.hrapp.exception.NoSuchUserExists;
import com.rnlic.hrapp.security.JwtDecriptor;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.BirthdayWishService;
import com.rnlic.hrapp.util.RequestLogDeatils;

public class BirthdayWishTest extends HraServiceTests{

	private MockMvc mockMvc;

	@Mock
	private BirthdayWishService birthdayWishService;

	@Mock
	private JwtDecriptor jwtDecriptor;
	
	@Mock
	private RequestLogDeatils requestLog;
	
	@InjectMocks
	private BirthdayWishController birthdayWishController;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(birthdayWishController).build();
	}
	
	@Test
	public void testSearchBirthday() throws Exception {
		String expectedReq = TestConstant.SEARCH_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		BirthdayReqBean birthdayReqBean = new BirthdayReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(birthdayWishService.searchBirthdayAnniversary(user,birthdayReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.SEARCH_BIRTHDAY_ANNIVERSARY_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testSearchBirthdayExp() throws Exception {
		String expectedReq = TestConstant.SEARCH_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		BirthdayReqBean birthdayReqBean = new BirthdayReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new ExecutionException("Exp", "Exp", false));
		Mockito.when(birthdayWishService.searchBirthdayAnniversary(user,birthdayReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.SEARCH_BIRTHDAY_ANNIVERSARY_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testSearchBirthdayExp2() throws Exception {
		String expectedReq = TestConstant.SEARCH_REQ_JSON1;
		String token = TestConstant.GET_TOKEN;
		BirthdayReqBean birthdayReqBean = new BirthdayReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new ExecutionException("Exp", "Exp", false));
		Mockito.when(birthdayWishService.searchBirthdayAnniversary(user,birthdayReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.SEARCH_BIRTHDAY_ANNIVERSARY_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testSearchBirthdayExp1() throws Exception {
		String expectedReq = TestConstant.SEARCH_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		BirthdayReqBean birthdayReqBean = new BirthdayReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException("Exp"));
		Mockito.when(birthdayWishService.searchBirthdayAnniversary(user,birthdayReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.SEARCH_BIRTHDAY_ANNIVERSARY_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testWishEmployee() throws Exception {
		String expectedReq = TestConstant.WISH_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		WishEmpReqBean wishEmpReqBean = new WishEmpReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(birthdayWishService.wishEmployee(user,wishEmpReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.WISH_EMPLOYEE_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testWishEmployeeExp() throws Exception {
		String expectedReq = TestConstant.WISH_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		WishEmpReqBean wishEmpReqBean = new WishEmpReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new MailingServiceException("Exp"));
		Mockito.when(birthdayWishService.wishEmployee(user,wishEmpReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.WISH_EMPLOYEE_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testWishEmployeeExp1() throws Exception {
		String expectedReq = TestConstant.WISH_REQ_JSON;
		String token = TestConstant.GET_TOKEN;
		WishEmpReqBean wishEmpReqBean = new WishEmpReqBean();
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException("Exp"));
		Mockito.when(birthdayWishService.wishEmployee(user,wishEmpReqBean)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.WISH_EMPLOYEE_URL).contentType(MediaType.APPLICATION_JSON).content(expectedReq).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetBirthday() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(birthdayWishService.getBirthday(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_BIRTHDAY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetBirthdayExp() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new MailingServiceException());
		Mockito.when(birthdayWishService.getBirthday(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_BIRTHDAY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetBirthdayExp1() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException());
		Mockito.when(birthdayWishService.getBirthday(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_BIRTHDAY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetReporteeBirthday() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(birthdayWishService.getReporteeBirthday(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_REPORTEE_BIRTHDAY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetReporteeBirthdayExp() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new MandatoryFieldsNotAvailable());
		Mockito.when(birthdayWishService.getReporteeBirthday(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_REPORTEE_BIRTHDAY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetReporteeBirthdayExp1() throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException());
		Mockito.when(birthdayWishService.getReporteeBirthday(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_REPORTEE_BIRTHDAY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetAnniversary()throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(birthdayWishService.getAnniversary(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_ANNIVERSARY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetAnniversaryExp()throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new MandatoryFieldsNotAvailable("Exp"));
		Mockito.when(birthdayWishService.getAnniversary(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_ANNIVERSARY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetAnniversaryExp1()throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException());
		Mockito.when(birthdayWishService.getAnniversary(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_ANNIVERSARY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetReporteeAnniversary()throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenReturn(user);
		Mockito.when(birthdayWishService.getReporteeAnniversary(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_REPORTEE_ANNIVERSARY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetReporteeAnniversaryExp()throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new NoSuchUserExists());
		Mockito.when(birthdayWishService.getReporteeAnniversary(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_REPORTEE_ANNIVERSARY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	@Test
	public void testGetReporteeAnniversaryExp1()throws Exception {
		String token = TestConstant.GET_TOKEN;
		UserDetailsBean user = HrappTestUtil.prepareUserDtlsBean("DEVICE1", "8981414565", "PANNO1", "SAPCODE1");
		AttendanceDetailsResBean attendatenceDtls = HrappTestUtil.prepareAttandanceDtls();
		Mockito.when(jwtDecriptor.jwtDecript(Mockito.any(String.class))).thenThrow(new RuntimeException());
		Mockito.when(birthdayWishService.getReporteeAnniversary(user)).thenReturn(attendatenceDtls);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(TestConstant.GET_REPORTEE_ANNIVERSARY_URL).contentType(MediaType.APPLICATION_JSON).header("Authorization", token);
		mockMvc.perform(requestBuilder).andReturn();
	}
	
}
