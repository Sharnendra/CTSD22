package com.rnlic.hraapp.test.service;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.rnlic.hraapp.test.HraServiceTests;
import com.rnlic.hraapp.test.util.HrappTestUtil;
import com.rnlic.hrapp.bean.response.MandatoryLearningResBean;
import com.rnlic.hrapp.bean.response.MandatoryLearningStatusResBean;
import com.rnlic.hrapp.bean.response.ResponseData;
import com.rnlic.hrapp.security.UserDetailsBean;
import com.rnlic.hrapp.service.LearningService;
import com.rnlic.hrapp.service.RnlicService;

public class LearningServiceTest extends HraServiceTests {

	@Mock
	private RnlicService rnlicService;
	
	@InjectMocks
	private LearningService learningService;
	
	/**
	 * This service call rnlic service to get mandatory learnings details
	 * @param UserDetailsBean empReqBean
	 * @return MandatoryLearningResBean mandatoryLearningResBean
	 */
	//@Ignore
	@Test
	public void getMandatoryLearningTest() {
		MandatoryLearningResBean mandatoryLearningResBean = HrappTestUtil.preparetMandatoryLearning();
		Mockito.when(rnlicService.getMandatoryLearning()).thenReturn(mandatoryLearningResBean);
		ResponseData responseData = learningService.getMandatoryLearning();
		assertNotNull(responseData);
	}
	
	/**
	 * method return current learning status.
	 * @param UserDetailsBean empReqBean
	 * @return ResponseData ResponseData
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException. 
	 */
	//@Ignore
	@Test
	public void getMandatoryLearningStatusTest() throws JsonParseException, JsonMappingException, IOException{
		UserDetailsBean empReqBean = HrappTestUtil.prepareUserDtlsBean("DRDDFG789O", "8375939142", "DILPK0000M", "70009002");
		MandatoryLearningStatusResBean mandatoryLearningStatusResBean = HrappTestUtil.prepareMandatoryLearningStatus();
		Mockito.when(rnlicService.getMandatoryLearningStatus(empReqBean)).thenReturn(mandatoryLearningStatusResBean);
		ResponseData responseData = learningService.getMandatoryLearningStatus(empReqBean);
		assertNotNull(responseData);
	}
	
	@Test
	public void updateLearningCompletionStatusTest() {
		UserDetailsBean empReqBean = null;
		Mockito.when(rnlicService.updateLearningCompletion(Mockito.any(UserDetailsBean.class), Mockito.any(String.class))).thenReturn(true);
		ResponseData responseData = learningService.updateLearningCompletionStatus(empReqBean, "45242");
		assertNotNull(responseData);
	}
}
